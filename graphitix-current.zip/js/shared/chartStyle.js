(function(global){
  'use strict';
  const Shared = global.Shared = global.Shared || {};
  const chartStyle = Shared.chartStyle = Shared.chartStyle || {};
  const NS = 'http://www.w3.org/2000/svg';
  const FONT_FAMILY = 'Arial, Helvetica, sans-serif';
  const TEXT_COLOR = '#000000';
  const BASE_BOTTOM_FACTOR = 2.4;
  const PT_TO_PX = 96 / 72;
  const BASE_FONT_SIZE_PX = 16;
  const BASE_FONT_SIZE_PT = Number((BASE_FONT_SIZE_PX / PT_TO_PX).toFixed(2));
  const MIN_DEFAULT_SIZE = 320;
  const FALLBACK_VIEWPORT_WIDTH = 960;
  const COLOR_SWATCH_SIZE = 20;
  const LEGEND_LAYOUT_CONSTANTS = Object.freeze({
    gapScale: 0.55,
    minGapPx: 12,
    guardPaddingPx: 24,
    basePlotMinWidth: 320
  });
  chartStyle.LEGEND_LAYOUT_CONSTANTS = LEGEND_LAYOUT_CONSTANTS;

  function normalizeSwatchSize(candidate){
    const parsed = Number(candidate);
    if(Number.isFinite(parsed) && parsed > 2){
      return Math.round(parsed);
    }
    return COLOR_SWATCH_SIZE;
  }

  function normalizeColorInput(input, options){
    if(!input || typeof input !== 'object'){ return null; }
    const el = input;
    const opts = options || {};
    const requestedSize = normalizeSwatchSize(opts.size);
    const px = `${requestedSize}px`;
    const dataset = el.dataset || null;
    const payload = {
      id: el.id || null,
      className: typeof el.className === 'string' ? el.className : undefined,
      size: requestedSize,
      reason: opts.reason || 'normalize',
      alreadyNormalized: dataset?.colorSwatchNormalized === '1'
    };
    try {
      el.style.width = px;
      el.style.height = px;
      el.style.minWidth = px;
      el.style.minHeight = px;
      el.style.flex = `0 0 ${px}`;
      el.style.boxSizing = el.style.boxSizing || 'border-box';
      if(dataset){
        dataset.colorSwatchSize = String(requestedSize);
        dataset.colorSwatchNormalized = '1';
      }
      if(!payload.alreadyNormalized){
        console.debug('Debug: chartStyle.normalizeColorInput applied', payload); // Debug: color swatch normalization
      }
      return requestedSize;
    }catch(err){
      console.error('chartStyle.normalizeColorInput error', err);
      return null;
    }
  }
  chartStyle.normalizeColorInput = normalizeColorInput;
  chartStyle.COLOR_SWATCH_SIZE = COLOR_SWATCH_SIZE;

  function buildOpenRectPath(rect, openSide){
    const left = Number(rect?.left ?? rect?.x);
    const top = Number(rect?.top ?? rect?.y);
    const right = Number(rect?.right ?? (left + Number(rect?.width)));
    const bottom = Number(rect?.bottom ?? (top + Number(rect?.height)));
    if(!Number.isFinite(left) || !Number.isFinite(top) || !Number.isFinite(right) || !Number.isFinite(bottom)){
      return '';
    }
    const safeLeft = Math.min(left, right);
    const safeRight = Math.max(left, right);
    const safeTop = Math.min(top, bottom);
    const safeBottom = Math.max(top, bottom);
    const side = String(openSide || 'bottom').toLowerCase();
    switch(side){
      case 'top':
        return `M ${safeLeft} ${safeTop} L ${safeLeft} ${safeBottom} L ${safeRight} ${safeBottom} L ${safeRight} ${safeTop}`;
      case 'right':
        return `M ${safeRight} ${safeTop} L ${safeLeft} ${safeTop} L ${safeLeft} ${safeBottom} L ${safeRight} ${safeBottom}`;
      case 'left':
        return `M ${safeLeft} ${safeTop} L ${safeRight} ${safeTop} L ${safeRight} ${safeBottom} L ${safeLeft} ${safeBottom}`;
      case 'bottom':
      default:
        return `M ${safeLeft} ${safeBottom} L ${safeLeft} ${safeTop} L ${safeRight} ${safeTop} L ${safeRight} ${safeBottom}`;
    }
  }
  chartStyle.buildOpenRectPath = buildOpenRectPath;

  function computeDefaultGraphSize(reason){
    const doc = global.document || null;
    const winWidth = Number(global.innerWidth) || 0;
    const docElWidth = doc?.documentElement?.clientWidth || 0;
    const bodyWidth = doc?.body?.clientWidth || 0;
    let reference = Math.max(winWidth, docElWidth, bodyWidth);
    if(!Number.isFinite(reference) || reference <= 0){
      reference = FALLBACK_VIEWPORT_WIDTH;
    }
    const normalized = Math.max(MIN_DEFAULT_SIZE, Math.round(reference / 3));
    const payload = {
      reason: reason || 'initial',
      winWidth,
      docElWidth,
      bodyWidth,
      reference,
      normalized
    };
    console.debug('Debug: chartStyle.computeDefaultGraphSize', payload); // Debug: default graph dimension computation
    return { width: normalized, height: normalized };
  }

  const initialGraphSize = computeDefaultGraphSize('initial');
  let DEFAULT_WIDTH = initialGraphSize.width;
  let DEFAULT_HEIGHT = initialGraphSize.height;
  const RESIZE_MIN_SCALE = 0.3;
  const RESIZE_MAX_SCALE = 3;
  const DEFAULT_ASPECT_RATIO = 1;
  const DEFAULT_ASPECT_LOCKED = false;
  const TAB_SCOPE_TOKEN_PREFIX = '@tab:';
  const GLOBAL_TEXT_SCOPE = '__chartstyle_global__';
  let proportionalFontResizeEnabled = false;
  // DOM/runtime registries for the proportional-font-resize option. Durable graph text style state is not stored here.
  const proportionalFontResizeState = new Map();
  const proportionalFontResizeInputs = new Map();
  const proportionalFontResizeListeners = new Map();

  function normalizeScopeId(raw){
    if(typeof raw === 'string'){
      const trimmed = raw.trim();
      if(trimmed){
        return trimmed;
      }
    }
    return null;
  }

  function normalizeTabId(raw){
    if(raw == null){ return null; }
    const trimmed = String(raw).trim();
    return trimmed ? trimmed : null;
  }

  function stripTabScopeSuffix(scopeId){
    const normalized = normalizeScopeId(scopeId);
    if(!normalized){ return null; }
    const token = `::${TAB_SCOPE_TOKEN_PREFIX}`;
    const idx = normalized.indexOf(token);
    if(idx < 0){
      return normalized;
    }
    const base = normalized.slice(0, idx);
    return normalizeScopeId(base);
  }

  function resolveActiveWorkspaceTabId(){
    try{
      const hot = Shared.hot || global.Shared?.hot;
      if(hot && typeof hot.resolveActiveTabId === 'function'){
        const fromHot = normalizeTabId(hot.resolveActiveTabId());
        if(fromHot){ return fromHot; }
      }
    }catch(err){
      console.debug('Debug: chartStyle active tab resolve via hot failed', { error: err?.message || String(err) });
    }
    try{
      const session = global.Main?.session || null;
      if(session && typeof session.getActiveTab === 'function'){
        const active = session.getActiveTab();
        const fromSession = normalizeTabId(active?.id);
        if(fromSession){ return fromSession; }
      }
    }catch(err){
      console.debug('Debug: chartStyle active tab resolve via session failed', { error: err?.message || String(err) });
    }
    try{
      const doc = global.document;
      if(doc && typeof doc.querySelector === 'function'){
        const activeBtn = doc.querySelector('.workspace-tab[data-tab-id][aria-selected="true"], .workspace-tab.workspace-tab--active[data-tab-id], .workspace-tab.is-active[data-tab-id]');
        const fromDom = normalizeTabId(activeBtn?.dataset?.tabId);
        if(fromDom){ return fromDom; }
      }
    }catch(err){
      console.debug('Debug: chartStyle active tab resolve via dom failed', { error: err?.message || String(err) });
    }
    return null;
  }

  function resolveNearestWorkspaceTabId(node){
    if(!node || typeof node.closest !== 'function'){
      return null;
    }
    const owner = node.closest('[data-workspace-tab-id], [data-tab-id]');
    return normalizeTabId(owner?.dataset?.workspaceTabId || owner?.dataset?.tabId || null);
  }

  function resolveScopeTabToken(options){
    const opts = options || {};
    const svgBox = opts.svgBox || opts.container || opts.element || null;
    const input = opts.input || opts.control || null;
    const explicit = normalizeTabId(opts.tabId || opts.workspaceTabId || null);
    const fromInputOwner = resolveNearestWorkspaceTabId(input);
    const fromSvgOwner = resolveNearestWorkspaceTabId(svgBox);
    const fromInput = normalizeTabId(input?.dataset?.workspaceTabId || input?.dataset?.fontTabId || input?.dataset?.tabId || null);
    const fromSvg = normalizeTabId(svgBox?.dataset?.workspaceTabId || svgBox?.dataset?.fontTabId || svgBox?.dataset?.tabId || null);
    const active = resolveActiveWorkspaceTabId();
    return normalizeScopeId(explicit || fromInputOwner || fromSvgOwner || fromInput || fromSvg || active || null);
  }

  function applyTabScope(scopeId, options){
    const baseScope = stripTabScopeSuffix(scopeId);
    if(!baseScope){ return null; }
    const tabToken = resolveScopeTabToken(options);
    if(!tabToken){
      return baseScope;
    }
    return `${baseScope}::${TAB_SCOPE_TOKEN_PREFIX}${tabToken}`;
  }

  function resolveScopeKey(options){
    if(typeof options === 'string'){
      return applyTabScope(options, {});
    }
    const opts = options || {};
    const directScope = normalizeScopeId(opts.scopeId || opts.scope);
    if(directScope){
      return applyTabScope(directScope, opts);
    }
    const svgBox = opts.svgBox || opts.container || opts.element || null;
    if(svgBox && svgBox.dataset){
      const datasetScope = normalizeScopeId(svgBox.dataset.resizerProportionalFontResizeScope);
      if(datasetScope){
        return applyTabScope(datasetScope, opts);
      }
    }
    const input = opts.input || opts.control || null;
    if(input && input.dataset){
      const inputScope = normalizeScopeId(input.dataset.proportionalFontResizeScope);
      if(inputScope){
        return applyTabScope(inputScope, opts);
      }
    }
    if(svgBox && svgBox.id){
      return applyTabScope(svgBox.id, opts);
    }
    if(typeof opts.origin === 'string'){
      return applyTabScope(opts.origin, opts);
    }
    return null;
  }

  function getScopedProportionalFontResize(scopeId){
    if(scopeId && proportionalFontResizeState.has(scopeId)){
      return !!proportionalFontResizeState.get(scopeId);
    }
    return !!proportionalFontResizeEnabled;
  }

  function setScopedProportionalFontResize(scopeId, value){
    const normalized = !!value;
    if(scopeId){
      proportionalFontResizeState.set(scopeId, normalized);
    }else{
      proportionalFontResizeEnabled = normalized;
    }
    return normalized;
  }

  function snapshotProportionalFontResizeSummary(){
    const summary = { global: !!proportionalFontResizeEnabled, scoped: {} };
    proportionalFontResizeState.forEach((val, key) => {
      summary.scoped[key] = !!val;
    });
    return summary;
  }

  function syncProportionalFontResizeInputs(origin, scopeFilter){
    const stale = [];
    proportionalFontResizeInputs.forEach((scopeId, input) => {
      if(!input || typeof input !== 'object' || typeof input.addEventListener !== 'function'){
        stale.push(input);
        return;
      }
      const effectiveScope = scopeId || GLOBAL_TEXT_SCOPE;
      if(scopeFilter && effectiveScope !== scopeFilter){
        return;
      }
      const enabled = getScopedProportionalFontResize(scopeId);
      if('checked' in input && input.checked !== enabled){
        try {
          input.checked = enabled;
        } catch(syncErr){
          console.error('chartStyle.syncProportionalFontResizeInputs assignment error', syncErr);
        }
      }
    });
    if(stale.length){
      stale.forEach(item => proportionalFontResizeInputs.delete(item));
    }
    console.debug('Debug: chartStyle.syncProportionalFontResizeInputs', {
      origin: origin || 'unknown',
      scope: scopeFilter || 'all',
      controlCount: proportionalFontResizeInputs.size,
      staleCount: stale.length,
      stateSummary: snapshotProportionalFontResizeSummary()
    }); // Debug: proportional font resize control sync trace
  }

  function emitProportionalFontResizeChange(origin, scopeId, enabledValue){
    const effectiveScope = scopeId || GLOBAL_TEXT_SCOPE;
    console.debug('Debug: chartStyle.emitProportionalFontResizeChange start', {
      origin: origin || 'unknown',
      enabled: enabledValue,
      scope: effectiveScope,
      listenerCount: proportionalFontResizeListeners.size
    }); // Debug: proportional font resize listener broadcast start
    proportionalFontResizeListeners.forEach((info, listener) => {
      if(!info || typeof listener !== 'function'){
        return;
      }
      if(info.scope && info.scope !== effectiveScope){
        console.debug('Debug: chartStyle.emitProportionalFontResizeChange skip listener', {
          listenerScope: info.scope,
          eventScope: effectiveScope,
          listenerOrigin: info.origin || listener.name || 'anonymous'
        }); // Debug: listener scope filter
        return;
      }
      try {
        listener(enabledValue, origin || 'unknown', { scopeId: scopeId || null, enabled: enabledValue });
      } catch(err){
        console.error('chartStyle proportional font resize listener error', err);
      }
    });
  }

  function clampScale(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return 1;
    }
    return Math.min(RESIZE_MAX_SCALE, Math.max(RESIZE_MIN_SCALE, numeric));
  }

  function resolveStyleScale(scaleInfo){
    if(scaleInfo && typeof scaleInfo === 'object'){
      if(Number.isFinite(scaleInfo.styleScale)){
        return scaleInfo.styleScale;
      }
      if(Number.isFinite(scaleInfo.scale)){
        return scaleInfo.scale;
      }
    }
    return 1;
  }

  chartStyle.FONT_FAMILY = FONT_FAMILY;
  chartStyle.TEXT_COLOR = TEXT_COLOR;
  chartStyle.PT_TO_PX = PT_TO_PX;
  chartStyle.BASE_FONT_SIZE_PT = BASE_FONT_SIZE_PT;
  chartStyle.BASE_FONT_SIZE_PX = BASE_FONT_SIZE_PX;
  chartStyle.DEFAULT_WIDTH = DEFAULT_WIDTH;
  chartStyle.DEFAULT_HEIGHT = DEFAULT_HEIGHT;
  chartStyle.RESIZE_MIN_SCALE = RESIZE_MIN_SCALE;
  chartStyle.RESIZE_MAX_SCALE = RESIZE_MAX_SCALE;
  chartStyle.DEFAULT_ASPECT_RATIO = DEFAULT_ASPECT_RATIO;
  chartStyle.DEFAULT_ASPECT_LOCKED = DEFAULT_ASPECT_LOCKED;

  function refreshDefaultGraphSize(context){
    const updated = computeDefaultGraphSize(context || 'refresh');
    DEFAULT_WIDTH = updated.width;
    DEFAULT_HEIGHT = updated.height;
    chartStyle.DEFAULT_WIDTH = DEFAULT_WIDTH;
    chartStyle.DEFAULT_HEIGHT = DEFAULT_HEIGHT;
    console.debug('Debug: chartStyle.refreshDefaultGraphSize', { context, updated }); // Debug: default size refresh
    return updated;
  }

  chartStyle.getDefaultGraphSize = function getDefaultGraphSize(options){
    const context = options?.context || 'cached';
    const refresh = options?.refresh === true;
    if(refresh){
      const refreshed = refreshDefaultGraphSize(context);
      console.debug('Debug: chartStyle.getDefaultGraphSize refresh result', { context, refreshed }); // Debug: refresh branch trace
      return { width: refreshed.width, height: refreshed.height };
    }
    const current = { width: DEFAULT_WIDTH, height: DEFAULT_HEIGHT };
    console.debug('Debug: chartStyle.getDefaultGraphSize cached result', { context, current }); // Debug: cached branch trace
    return current;
  };

  chartStyle.getSquareGraphSizing = function getSquareGraphSizing(options){
    const context = options?.context || 'default';
    const refresh = options?.refresh === true;
    const baseSize = chartStyle.getDefaultGraphSize({ context, refresh });
    let width = Number(baseSize?.width);
    let height = Number(baseSize?.height);
    if(!Number.isFinite(width) || width <= 0){
      width = DEFAULT_WIDTH;
    }
    if(!Number.isFinite(height) || height <= 0){
      height = DEFAULT_HEIGHT;
    }
    if(!Number.isFinite(width) || width <= 0){
      const fallback = computeDefaultGraphSize(`fallback-${context}`);
      width = fallback.width;
      height = fallback.height;
    }
    if(!Number.isFinite(height) || height <= 0){
      height = width;
    }
    const rawMinScale = Number(options?.minScale);
    const rawMaxScale = Number(options?.maxScale);
    const minScale = clampScale(Number.isFinite(rawMinScale) ? rawMinScale : RESIZE_MIN_SCALE);
    const maxScale = clampScale(Number.isFinite(rawMaxScale) ? rawMaxScale : RESIZE_MAX_SCALE);
    const effectiveMaxScale = Math.max(maxScale, minScale);
    const minWidth = Math.max(1, Math.round(width * minScale));
    const minHeight = Math.max(1, Math.round(height * minScale));
    const maxWidth = Math.max(width, Math.round(width * effectiveMaxScale));
    const maxHeight = Math.max(height, Math.round(height * effectiveMaxScale));
    const sizing = {
      width,
      height,
      minWidth,
      minHeight,
      maxWidth,
      maxHeight,
      aspectRatio: DEFAULT_ASPECT_RATIO,
      aspectLocked: DEFAULT_ASPECT_LOCKED
    };
    console.debug('Debug: chartStyle.getSquareGraphSizing', {
      context,
      refresh,
      minScale,
      maxScale: effectiveMaxScale,
      sizing
    }); // Debug: square sizing helper
    return sizing;
  };

  chartStyle.ptToPx = function ptToPx(pt){
    const numeric = Number(pt);
    const px = Number.isFinite(numeric) ? numeric * PT_TO_PX : BASE_FONT_SIZE_PX;
    console.debug('Debug: chartStyle.ptToPx',{input:pt, numeric, px}); // Debug: pt to px conversion trace
    return px;
  };

  chartStyle.pxToPt = function pxToPt(px){
    const numeric = Number(px);
    const pt = Number.isFinite(numeric) ? numeric / PT_TO_PX : BASE_FONT_SIZE_PT;
    console.debug('Debug: chartStyle.pxToPt',{input:px, numeric, pt}); // Debug: px to pt conversion trace
    return pt;
  };

  chartStyle.normalizeFontSize = function normalizeFontSize(raw){
    const numeric = Number(raw);
    const pt = Number.isFinite(numeric) ? numeric : BASE_FONT_SIZE_PT;
    const px = chartStyle.ptToPx(pt);
    console.debug('Debug: chartStyle.normalizeFontSize',{raw, pt, px}); // Debug: font normalization trace
    return {pt, px};
  };

  function getCanvas(){
    const doc = global.document;
    if(!doc){
      console.warn('chartStyle.getCanvas missing document context');
      return null;
    }
    if(!chartStyle._canvas){
      chartStyle._canvas = doc.createElement('canvas');
      console.debug('Debug: chartStyle created measurement canvas'); // Debug helper creation
    }
    return chartStyle._canvas;
  }

  chartStyle.makeFont = function makeFont(size){
    const font = `${size}px ${FONT_FAMILY}`;
    console.debug('Debug: chartStyle.makeFont', {size, font}); // Debug: font computation trace
    return font;
  };

  function parsePositiveNumber(value){
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric > 0 ? numeric : NaN;
  }

  function readElementSizePx(element, axis){
    if(!element || typeof element !== 'object'){
      return NaN;
    }
    const dataset = element.dataset || {};
    const keys = axis === 'width'
      ? ['resizerBaseWidth', 'graphWidthPx', 'svgWidth', 'resizerDefaultWidth', 'graphDefaultWidth']
      : ['resizerBaseHeight', 'graphHeightPx', 'svgHeight', 'resizerDefaultHeight', 'graphDefaultHeight'];
    for(let i = 0; i < keys.length; i += 1){
      const value = parsePositiveNumber(dataset[keys[i]]);
      if(Number.isFinite(value)){
        return value;
      }
    }
    if(typeof element.getBoundingClientRect === 'function'){
      const rect = element.getBoundingClientRect();
      const rectValue = parsePositiveNumber(axis === 'width' ? rect?.width : rect?.height);
      if(Number.isFinite(rectValue)){
        return rectValue;
      }
    }
    const styleValue = parsePositiveNumber(axis === 'width' ? element.style?.width : element.style?.height);
    return Number.isFinite(styleValue) ? styleValue : NaN;
  }

  function resolveFontResizeReferenceSize(svgBox, width, height, zoomScale){
    const scale = Number.isFinite(zoomScale) && zoomScale > 0 ? zoomScale : 1;
    const rawWidth = parsePositiveNumber(width);
    const rawHeight = parsePositiveNumber(height);
    const widthFromBox = readElementSizePx(svgBox, 'width');
    const heightFromBox = readElementSizePx(svgBox, 'height');
    return {
      width: Number.isFinite(rawWidth) ? rawWidth / scale : widthFromBox,
      height: Number.isFinite(rawHeight) ? rawHeight / scale : heightFromBox
    };
  }

  function resolveCurrentDisplayFontPt(options){
    const opts = options || {};
    const inputEl = opts.input || opts.control || null;
    const svgBox = opts.svgBox || null;
    const inputDataset = inputEl?.dataset || null;
    const svgDataset = svgBox?.dataset || null;
    const candidates = [
      opts.displayPt,
      opts.fontPt,
      opts.pt,
      opts.scaledPt,
      inputDataset?.fontDisplayPt,
      svgDataset?.fontDisplayPt,
      svgDataset?.fontBasePt,
      inputDataset?.fontBasePt,
      inputEl?.value,
      opts.rawSize,
      opts.basePt
    ];
    for(let i = 0; i < candidates.length; i += 1){
      const value = Number(candidates[i]);
      if(Number.isFinite(value) && value > 0){
        return value;
      }
    }
    return NaN;
  }

  function syncFontInputBaseline(inputEl, pt, options = {}){
    if(!inputEl || !inputEl.dataset || !Number.isFinite(pt) || pt <= 0){
      return false;
    }
    inputEl.dataset.fontBasePt = String(pt);
    inputEl.dataset.fontDisplayPt = String(pt);
    delete inputEl.dataset.fontResizeBaselinePending;
    if(options.syncValue === true && 'value' in inputEl){
      const min = Number(inputEl.min);
      const max = Number(inputEl.max);
      const bounded = Math.min(
        Number.isFinite(max) ? max : pt,
        Math.max(Number.isFinite(min) ? min : pt, pt)
      );
      try{
        inputEl.value = String(Math.round(bounded * 10) / 10);
      }catch(err){
        console.error('chartStyle.syncFontInputBaseline value sync error', err);
      }
    }
    return true;
  }

  function commitFontResizeBaseline(options){
    const opts = options || {};
    const svgBox = opts.svgBox || null;
    const dataset = svgBox?.dataset || null;
    const inputEl = opts.input || opts.control || null;
    const displayPt = resolveCurrentDisplayFontPt(opts);
    const size = resolveFontResizeReferenceSize(svgBox, opts.width, opts.height, opts.zoomScale);
    if(dataset){
      if(Number.isFinite(size.width) && size.width > 0){
        dataset.resizerFontResizeBaseWidth = String(size.width);
      }
      if(Number.isFinite(size.height) && size.height > 0){
        dataset.resizerFontResizeBaseHeight = String(size.height);
      }
      if(Number.isFinite(displayPt) && displayPt > 0){
        dataset.fontBasePt = String(displayPt);
        dataset.fontDisplayPt = String(displayPt);
      }
    }
    syncFontInputBaseline(inputEl, displayPt, { syncValue: opts.syncInputValue === true });
    console.debug('Debug: chartStyle.commitFontResizeBaseline', {
      origin: opts.origin || 'unknown',
      scope: opts.scopeId || dataset?.resizerProportionalFontResizeScope || 'global',
      width: Number.isFinite(size.width) ? size.width : null,
      height: Number.isFinite(size.height) ? size.height : null,
      displayPt: Number.isFinite(displayPt) ? displayPt : null,
      hasSvgBox: !!svgBox,
      inputId: inputEl?.id || null
    }); // Debug: font resize baseline commit
    return {
      width: Number.isFinite(size.width) ? size.width : null,
      height: Number.isFinite(size.height) ? size.height : null,
      displayPt: Number.isFinite(displayPt) ? displayPt : null
    };
  }

  chartStyle.commitFontResizeBaseline = commitFontResizeBaseline;

  chartStyle.computeResizeScale = function computeResizeScale(options){
    const defaultWidth = Number(options?.defaultWidth) || DEFAULT_WIDTH;
    const defaultHeight = Number(options?.defaultHeight) || DEFAULT_HEIGHT;
    const rawWidth = Number(options?.width);
    const rawHeight = Number(options?.height);
    const dataset = options?.svgBox && options.svgBox.dataset ? options.svgBox.dataset : null;
    const safeWidth = Number.isFinite(rawWidth) && rawWidth > 0 ? rawWidth : defaultWidth;
    const safeHeight = Number.isFinite(rawHeight) && rawHeight > 0 ? rawHeight : defaultHeight;
    const scaleX = safeWidth / (defaultWidth || 1);
    const scaleY = safeHeight / (defaultHeight || 1);
    const fontBaseWidth = dataset ? parsePositiveNumber(dataset.resizerFontResizeBaseWidth) : NaN;
    const fontBaseHeight = dataset ? parsePositiveNumber(dataset.resizerFontResizeBaseHeight) : NaN;
    const fontReferenceWidth = Number.isFinite(fontBaseWidth) ? fontBaseWidth : defaultWidth;
    const fontReferenceHeight = Number.isFinite(fontBaseHeight) ? fontBaseHeight : defaultHeight;
    const fontScaleX = safeWidth / (fontReferenceWidth || 1);
    const fontScaleY = safeHeight / (fontReferenceHeight || 1);
    const aspectLocked = dataset
      ? (Shared.aspectLock?.resolveLocked
        ? Shared.aspectLock.resolveLocked(dataset, { fallback: false })
        : dataset.resizerAspectLocked === 'true')
      : false;
    const resizeAxis = dataset && (dataset.resizerLastAxis === 'x' || dataset.resizerLastAxis === 'y') ? dataset.resizerLastAxis : 'both';
    const unlockedStyleScaleBase = dataset ? Number(dataset.resizerUnlockedStyleScaleBase) : NaN;
    const lockedStyleScaleBase = dataset ? Number(dataset.resizerLockedStyleScaleBase) : NaN;
    const rawStyleScale = Math.sqrt(Math.max(scaleX * scaleY, 0));
    const rawFontScale = Math.sqrt(Math.max(fontScaleX * fontScaleY, 0));
    let fontResizeUnclamped = rawFontScale;
    if(!aspectLocked && resizeAxis === 'x' && Number.isFinite(fontScaleX) && fontScaleX > 0){
      fontResizeUnclamped = fontScaleX;
    }else if(!aspectLocked && resizeAxis === 'y' && Number.isFinite(fontScaleY) && fontScaleY > 0){
      fontResizeUnclamped = fontScaleY;
    }
    let styleUnclamped = rawStyleScale;
    // Keep non-text style metrics stable in unlocked manual resize flows so
    // one-axis drags change only axis length unless text explicitly opts into
    // proportional font resizing.
    if(!aspectLocked && Number.isFinite(unlockedStyleScaleBase) && unlockedStyleScaleBase > 0){
      styleUnclamped = unlockedStyleScaleBase;
    }else if(aspectLocked && Number.isFinite(lockedStyleScaleBase) && lockedStyleScaleBase > 0){
      styleUnclamped = styleUnclamped / lockedStyleScaleBase;
    }
    const styleScale = clampScale(styleUnclamped);
    const fontResizeScale = clampScale(fontResizeUnclamped);
    const radiusScale = Math.sqrt(styleScale);
    const payload = {
      width: safeWidth,
      height: safeHeight,
      defaultWidth,
      defaultHeight,
      scaleX,
      scaleY,
      fontScaleX,
      fontScaleY,
      fontReferenceWidth,
      fontReferenceHeight,
      scaleW: scaleX,
      scaleH: scaleY,
      rawStyleScale,
      styleUnclamped,
      styleScale,
      fontResizeUnclamped,
      fontResizeScale,
      radiusScale,
      strokeScale: radiusScale,
      aspectLocked,
      resizeAxis,
      unlockedStyleScaleBase: Number.isFinite(unlockedStyleScaleBase) ? unlockedStyleScaleBase : null,
      lockedStyleScaleBase: Number.isFinite(lockedStyleScaleBase) ? lockedStyleScaleBase : null,
      legacyMinScale: Math.min(scaleX, scaleY),
      scale: styleScale
    };
    console.debug('Debug: chartStyle.computeResizeScale', payload); // Debug: resize scaling payload
    return payload;
  };

  chartStyle.resolveScaledFontSize = function resolveScaledFontSize(options){
    const opts = options || {};
    const inputEl = opts.input || opts.control || null;
    const svgBox = opts.svgBox || null;
    const dataset = svgBox && svgBox.dataset ? svgBox.dataset : null;
    const rawSizeNumeric = Number(opts.rawSize);
    const manualBaselinePending = inputEl?.dataset?.fontResizeBaselinePending === 'true';
    let basePt = Number(opts.basePt);
    if(manualBaselinePending){
      const pendingBase = Number(inputEl.dataset.fontBasePt);
      basePt = Number.isFinite(pendingBase) && pendingBase > 0
        ? pendingBase
        : (Number.isFinite(rawSizeNumeric) ? rawSizeNumeric : basePt);
    }
    if(!manualBaselinePending && !Number.isFinite(basePt)){
      const storedGraphBase = Number(dataset?.fontBasePt);
      if(Number.isFinite(storedGraphBase) && storedGraphBase > 0){
        basePt = storedGraphBase;
      }
    }
    if(!Number.isFinite(basePt)){
      const storedControlBase = Number(inputEl?.dataset?.fontBasePt);
      if(Number.isFinite(storedControlBase) && storedControlBase > 0){
        basePt = storedControlBase;
      }
    }
    if(!Number.isFinite(basePt)){
      basePt = Number.isFinite(rawSizeNumeric) ? rawSizeNumeric : undefined;
    }
    let normalized = chartStyle.normalizeFontSize(basePt);
    if(inputEl && inputEl.dataset){
      const datasetBase = Number(inputEl.dataset.fontBasePt);
      if(!Number.isFinite(datasetBase)){
        inputEl.dataset.fontBasePt = String(normalized.pt);
        console.debug('Debug: chartStyle.resolveScaledFontSize init control base', {
          inputId: inputEl.id || null,
          basePt: normalized.pt
        }); // Debug: base initialization for control
      }
    }
    const explicitZoomScale = Number(opts.zoomScale);
    const datasetZoomScale = Number(dataset?.resizerZoomLevel || dataset?.resizerZoom);
    const zoomScale = Number.isFinite(explicitZoomScale) && explicitZoomScale > 0
      ? explicitZoomScale
      : (Number.isFinite(datasetZoomScale) && datasetZoomScale > 0 ? datasetZoomScale : 1);
    const rawWidth = Number(opts.width);
    const rawHeight = Number(opts.height);
    const effectiveWidth = Number.isFinite(rawWidth) ? (rawWidth / zoomScale) : opts.width;
    const effectiveHeight = Number.isFinite(rawHeight) ? (rawHeight / zoomScale) : opts.height;
    if(manualBaselinePending){
      commitFontResizeBaseline({
        svgBox,
        input: inputEl,
        displayPt: normalized.pt,
        width: effectiveWidth,
        height: effectiveHeight,
        zoomScale: 1,
        origin: 'manual-font-size',
        syncInputValue: false
      });
    }
    const resizeInfo = chartStyle.computeResizeScale({
      width: effectiveWidth,
      height: effectiveHeight,
      defaultWidth: opts.defaultWidth,
      defaultHeight: opts.defaultHeight,
      svgBox
    });
    const scopeId = resolveScopeKey({ scopeId: opts.scopeId, svgBox, input: inputEl });
    const isManualResize = dataset ? dataset.resizerResized === 'true' : null;
    let proportionalResizeEnabled;
    if(typeof opts.proportionalFontResize === 'boolean'){
      proportionalResizeEnabled = !!opts.proportionalFontResize;
    }else if(dataset && typeof dataset.resizerProportionalFontResize === 'string'){
      proportionalResizeEnabled = dataset.resizerProportionalFontResize === 'true';
    }else if(scopeId){
      proportionalResizeEnabled = getScopedProportionalFontResize(scopeId);
    }else{
      proportionalResizeEnabled = proportionalFontResizeEnabled;
    }
    const textScale = proportionalResizeEnabled
      ? (Number.isFinite(resizeInfo.fontResizeScale) && resizeInfo.fontResizeScale > 0
        ? resizeInfo.fontResizeScale
        : resizeInfo.styleScale)
      : 1;
    const scaledPxRaw = normalized.px * textScale;
    // Preserve exact pt values when proportional resizing is disabled: rounding
    // 7pt (9.333px) down to 9px causes visible drift in toolbar readback.
    const scaledPx = proportionalResizeEnabled
      ? Math.max(4, Math.round(scaledPxRaw))
      : Math.max(4, scaledPxRaw);
    const scaledPt = chartStyle.pxToPt(scaledPx);
    if(inputEl && inputEl.dataset){
      inputEl.dataset.fontDisplayPt = String(scaledPt);
      console.debug('Debug: chartStyle.resolveScaledFontSize display stored', {
        inputId: inputEl.id || null,
        scaledPt
      }); // Debug: display pt tracking
    }
    if(dataset){
      dataset.fontDisplayPt = String(scaledPt);
      console.debug('Debug: chartStyle.resolveScaledFontSize dataset display stored', {
        scope: scopeId || 'global',
        scaledPt
      }); // Debug: dataset display tracking
    }
    const scaleInfo = {
      ...resizeInfo,
      zoomScale: 1,
      displayZoomScale: zoomScale,
      textScale,
      proportionalFontResize: proportionalResizeEnabled,
      manualResize: !!isManualResize,
      scopeId
    };
    const result = {
      ...normalized,
      scaledPx,
      scaledPt,
      displayPt: scaledPt,
      basePt: normalized.pt,
      scaleInfo,
      proportionalFontResize: proportionalResizeEnabled,
      scopeId
    };
    console.debug('Debug: chartStyle.resolveScaledFontSize', {
      raw: opts.rawSize,
      normalizedPt: normalized.pt,
      basePx: normalized.px,
      scaledPx,
      scaledPt,
      styleScale: resizeInfo.styleScale,
      textScale,
      zoomScale,
      rawWidth,
      rawHeight,
      effectiveWidth: Number.isFinite(effectiveWidth) ? effectiveWidth : null,
      effectiveHeight: Number.isFinite(effectiveHeight) ? effectiveHeight : null,
      proportionalFontResize: proportionalResizeEnabled,
      manualResize: isManualResize,
      width: resizeInfo.width,
      height: resizeInfo.height,
      scope: scopeId || 'global'
    }); // Debug: scaled font resolution
    return result;
  };

  chartStyle.computeFontInfoForSvg = function computeFontInfoForSvg(options){
    const opts = options || {};
    const svgBox = opts.svgBox || null;
    let rect = null;
    if(svgBox && typeof svgBox.getBoundingClientRect === 'function'){
      rect = svgBox.getBoundingClientRect();
    }
    const width = Number.isFinite(opts.width) ? opts.width : rect?.width;
    const height = Number.isFinite(opts.height) ? opts.height : rect?.height;
    const scopeId = opts.scopeId || null;
    const fontInfo = chartStyle.resolveScaledFontSize({
      rawSize: opts.rawSize,
      width,
      height,
      defaultWidth: opts.defaultWidth,
      defaultHeight: opts.defaultHeight,
      svgBox,
      scopeId,
      proportionalFontResize: opts.proportionalFontResize,
      input: opts.input
    });
    console.debug('Debug: chartStyle.computeFontInfoForSvg', {
      debugLabel: opts.debugLabel || 'chartStyle.computeFontInfoForSvg',
      rawSize: opts.rawSize,
      width,
      height,
      scope: fontInfo.scopeId || scopeId || 'global',
      proportionalFontResize: fontInfo.proportionalFontResize,
      scaledPx: fontInfo.scaledPx
    }); // Debug: svg font helper summary
    return fontInfo;
  };

  chartStyle.computeViewBoxScale = function computeViewBoxScale(options){
    const opts = options || {};
    const svg = opts.svg || null;
    const svgBox = opts.svgBox || (svg && typeof svg.closest === 'function' ? svg.closest('.svgbox') : null);
    const rawViewWidth = Number(opts.viewBoxWidth);
    const rawViewHeight = Number(opts.viewBoxHeight);
    let displayWidth = Number.isFinite(opts.displayWidth) ? opts.displayWidth : NaN;
    let displayHeight = Number.isFinite(opts.displayHeight) ? opts.displayHeight : NaN;
    if((!Number.isFinite(displayWidth) || !Number.isFinite(displayHeight)) && svgBox && typeof svgBox.getBoundingClientRect === 'function'){
      try{
        const rect = svgBox.getBoundingClientRect();
        if(!Number.isFinite(displayWidth)) displayWidth = rect?.width;
        if(!Number.isFinite(displayHeight)) displayHeight = rect?.height;
      }catch(rectErr){
        console.error('chartStyle.computeViewBoxScale rect error', rectErr);
      }
    }
    if((!Number.isFinite(displayWidth) || !Number.isFinite(displayHeight)) && svg && typeof svg.getBoundingClientRect === 'function'){
      try{
        const rect = svg.getBoundingClientRect();
        if(!Number.isFinite(displayWidth)) displayWidth = rect?.width;
        if(!Number.isFinite(displayHeight)) displayHeight = rect?.height;
      }catch(svgErr){
        console.error('chartStyle.computeViewBoxScale svg rect error', svgErr);
      }
    }
    if(!Number.isFinite(displayWidth) && svg && svg.viewBox && svg.viewBox.baseVal){
      const base = svg.viewBox.baseVal;
      if(Number.isFinite(base?.width)) displayWidth = base.width;
      if(Number.isFinite(base?.height)) displayHeight = base.height;
    }
    const safeViewWidth = Number.isFinite(rawViewWidth) && rawViewWidth > 0 ? rawViewWidth : (Number.isFinite(displayWidth) && displayWidth > 0 ? displayWidth : 1);
    const safeViewHeight = Number.isFinite(rawViewHeight) && rawViewHeight > 0 ? rawViewHeight : (Number.isFinite(displayHeight) && displayHeight > 0 ? displayHeight : safeViewWidth);
    const safeDisplayWidth = Number.isFinite(displayWidth) && displayWidth > 0 ? displayWidth : safeViewWidth;
    const safeDisplayHeight = Number.isFinite(displayHeight) && displayHeight > 0 ? displayHeight : safeViewHeight;
    const scaleX = safeViewWidth > 0 ? safeDisplayWidth / safeViewWidth : 1;
    const scaleY = safeViewHeight > 0 ? safeDisplayHeight / safeViewHeight : 1;
    let scale = Math.sqrt(Math.max(scaleX * scaleY, 0));
    if(!Number.isFinite(scale) || scale <= 0){
      scale = 1;
    }
    const payload = {
      scaleX,
      scaleY,
      scale,
      displayWidth: safeDisplayWidth,
      displayHeight: safeDisplayHeight,
      viewBoxWidth: safeViewWidth,
      viewBoxHeight: safeViewHeight,
      debugLabel: opts.debugLabel || 'chartStyle.computeViewBoxScale'
    };
    console.debug('Debug: chartStyle.computeViewBoxScale', payload); // Debug: viewBox scale computation
    return payload;
  };

  chartStyle.adjustFontSizeForViewBox = function adjustFontSizeForViewBox(fontInfo, viewScale, options){
    const info = fontInfo || {};
    const opts = options || {};
    const base = Number.isFinite(info.scaledPx) ? info.scaledPx : Number.isFinite(opts.basePx) ? opts.basePx : Number(info);
    const scale = Number.isFinite(viewScale?.scale) && viewScale.scale > 0 ? viewScale.scale : 1;
    const inverse = scale > 0 ? 1 / scale : 1;
    const min = Number.isFinite(opts.min) ? opts.min : 0;
    let adjusted = Number.isFinite(base) ? base * inverse : base;
    if(Number.isFinite(adjusted) && adjusted < min){
      adjusted = min;
    }
    console.debug('Debug: chartStyle.adjustFontSizeForViewBox', {
      debugLabel: opts.debugLabel || 'chartStyle.adjustFontSizeForViewBox',
      base,
      scale,
      inverse,
      adjusted,
      min
    }); // Debug: font adjustment for viewBox
    return {
      fontSizePx: Number.isFinite(adjusted) ? adjusted : base,
      basePx: base,
      scaleApplied: scale,
      inverseScale: inverse
    };
  };

  chartStyle.setProportionalFontResize = function setProportionalFontResize(enabled, options){
    const nextValue = !!enabled;
    const opts = options || {};
    const origin = opts.origin || 'setProportionalFontResize';
    const svgBox = opts.svgBox || null;
    const scopeId = resolveScopeKey({ ...opts, svgBox });
    const effectiveScope = scopeId || GLOBAL_TEXT_SCOPE;
    const force = opts.force === true;
    const previous = getScopedProportionalFontResize(scopeId);
    if(previous === nextValue && !force){
      console.debug('Debug: chartStyle.setProportionalFontResize noop', { enabled: previous, origin, scope: effectiveScope });
      return previous;
    }
    commitFontResizeBaseline({
      svgBox,
      displayPt: opts.displayPt,
      width: opts.width,
      height: opts.height,
      zoomScale: opts.zoomScale,
      scopeId,
      origin,
      syncInputValue: true
    });
    setScopedProportionalFontResize(scopeId, nextValue);
    if(svgBox && svgBox.dataset){
      if(scopeId){
        svgBox.dataset.resizerProportionalFontResizeScope = scopeId;
      }
      svgBox.dataset.resizerProportionalFontResize = nextValue ? 'true' : 'false';
    }
    console.debug('Debug: chartStyle.setProportionalFontResize', {
      enabled: nextValue,
      origin,
      force,
      scope: effectiveScope,
      stateSummary: snapshotProportionalFontResizeSummary()
    });
    syncProportionalFontResizeInputs(origin, effectiveScope);
    emitProportionalFontResizeChange(origin, scopeId, nextValue);
    return nextValue;
  };

  chartStyle.isProportionalFontResizeEnabled = function isProportionalFontResizeEnabled(scopeOptions){
    const scopeId = resolveScopeKey(scopeOptions);
    const result = getScopedProportionalFontResize(scopeId);
    console.debug('Debug: chartStyle.isProportionalFontResizeEnabled query', {
      enabled: result,
      scope: scopeId || 'global'
    });
    return result;
  };

  chartStyle.registerProportionalFontResizeControl = function registerProportionalFontResizeControl(input, options){
    const el = input;
    const opts = options || {};
    const origin = opts.origin || el?.id || 'proportional-font-resize-control';
    if(!el || typeof el.addEventListener !== 'function'){
      console.debug('Debug: chartStyle.registerProportionalFontResizeControl skipped', { origin, reason: 'invalid element' });
      return function noopUnregister(){
        console.debug('Debug: chartStyle.unregisterProportionalFontResizeControl noop', { origin });
      };
    }
    const scopeId = resolveScopeKey({ ...opts, input: el });
    const effectiveScope = scopeId || GLOBAL_TEXT_SCOPE;
    const svgBox = opts.svgBox || null;
    if(svgBox && svgBox.dataset){
      if(scopeId){
        svgBox.dataset.resizerProportionalFontResizeScope = scopeId;
      }
      if(typeof svgBox.dataset.resizerProportionalFontResize !== 'string'){
        svgBox.dataset.resizerProportionalFontResize = getScopedProportionalFontResize(scopeId) ? 'true' : 'false';
      }
    }
    if(el.dataset){
      el.dataset.proportionalFontResizeScope = scopeId || '';
    }
    if(el.__chartStyleProportionalFontResizeHandler){
      el.removeEventListener('change', el.__chartStyleProportionalFontResizeHandler);
      delete el.__chartStyleProportionalFontResizeHandler;
      console.debug('Debug: chartStyle.registerProportionalFontResizeControl removed existing handler', { origin });
    }
    if('checked' in el){
      try {
        el.checked = getScopedProportionalFontResize(scopeId);
      } catch(assignErr){
        console.error('chartStyle.registerProportionalFontResizeControl assign error', assignErr);
      }
    }
    const handler = () => {
      const enabled = !!el.checked;
      if(svgBox && svgBox.dataset){
        svgBox.dataset.resizerProportionalFontResize = enabled ? 'true' : 'false';
      }
      console.debug('Debug: chartStyle.proportionalFontResizeControl change', { origin, enabled, scope: effectiveScope });
      chartStyle.setProportionalFontResize(enabled, { origin: `control-${origin}`, scopeId, svgBox });
    };
    el.addEventListener('change', handler);
    el.__chartStyleProportionalFontResizeHandler = handler;
    proportionalFontResizeInputs.set(el, scopeId);
    console.debug('Debug: chartStyle.registerProportionalFontResizeControl', {
      origin,
      enabled: getScopedProportionalFontResize(scopeId),
      controlCount: proportionalFontResizeInputs.size,
      scope: effectiveScope
    });
    const cleanup = () => {
      if(el.__chartStyleProportionalFontResizeHandler){
        el.removeEventListener('change', el.__chartStyleProportionalFontResizeHandler);
        delete el.__chartStyleProportionalFontResizeHandler;
      }
      proportionalFontResizeInputs.delete(el);
      console.debug('Debug: chartStyle.unregisterProportionalFontResizeControl', {
        origin,
        remaining: proportionalFontResizeInputs.size,
        scope: effectiveScope
      });
    };
    if(opts.signal && typeof opts.signal.addEventListener === 'function'){
      opts.signal.addEventListener('abort', cleanup, { once: true });
    }
    return cleanup;
  };

  chartStyle.onProportionalFontResizeChange = function onProportionalFontResizeChange(callback, options){
    if(typeof callback !== 'function'){
      console.debug('Debug: chartStyle.onProportionalFontResizeChange skipped', { reason: 'invalid callback' });
      return function noopRemove(){
        console.debug('Debug: chartStyle.onProportionalFontResizeChange noop remove');
      };
    }
    const opts = options || {};
    const origin = opts.origin || callback.name || 'anonymous';
    const scopeId = resolveScopeKey(opts);
    const effectiveScope = scopeId || null;
    proportionalFontResizeListeners.set(callback, { origin, scope: effectiveScope ? effectiveScope : null });
    console.debug('Debug: chartStyle.onProportionalFontResizeChange registered', {
      origin,
      listenerCount: proportionalFontResizeListeners.size,
      scope: effectiveScope || 'all'
    });
    if(opts.immediate){
      try {
        const initial = getScopedProportionalFontResize(scopeId);
        callback(initial, 'immediate', { scopeId: scopeId || null, enabled: initial });
      } catch(err){
        console.error('chartStyle proportional font resize immediate callback error', err);
      }
    }
    const cleanup = () => {
      proportionalFontResizeListeners.delete(callback);
      console.debug('Debug: chartStyle.onProportionalFontResizeChange removed', {
        origin,
        remaining: proportionalFontResizeListeners.size,
        scope: effectiveScope || 'all'
      });
    };
    if(opts.signal && typeof opts.signal.addEventListener === 'function'){
      opts.signal.addEventListener('abort', cleanup, { once: true });
    }
    return cleanup;
  };

  chartStyle.scaleLength = function scaleLength(base, scaleInfo, options){
    const opts = options || {};
    const numeric = Number(base);
    if(!Number.isFinite(numeric)){
      console.debug('Debug: chartStyle.scaleLength fallback', { base, context: opts.context || 'length' });
      return 0;
    }
    const styleScale = clampScale(resolveStyleScale(scaleInfo));
    const zoomScaleRaw = Number(scaleInfo?.zoomScale);
    const zoomScale = Number.isFinite(zoomScaleRaw) && zoomScaleRaw > 0 ? zoomScaleRaw : 1;
    const zoomActive = Math.abs(zoomScale - 1) > 1e-4;
    const rawStyleScale = Number(scaleInfo?.styleUnclamped);
    const styleScaleForZoom = Number.isFinite(rawStyleScale) && rawStyleScale > 0 ? rawStyleScale : styleScale;
    const resizeOnlyScale = zoomActive
      ? clampScale(styleScaleForZoom / zoomScale)
      : styleScale;
    const lengthScale = zoomActive
      ? (Math.sqrt(resizeOnlyScale) * zoomScale)
      : Math.sqrt(styleScale);
    const scaled = numeric * lengthScale;
    const min = Number.isFinite(opts.min) ? opts.min : 0;
    const max = Number.isFinite(opts.max) ? opts.max : Infinity;
    const clamped = Math.min(max, Math.max(min, scaled));
    console.debug('Debug: chartStyle.scaleLength', {
      base: numeric,
      styleScale,
      resizeOnlyScale,
      lengthScale,
      zoomScale,
      zoomActive,
      result: clamped,
      context: opts.context || 'length'
    }); // Debug: length scaling trace
    return clamped;
  };

  chartStyle.scaleRadius = function scaleRadius(base, scaleInfo, options){
    const opts = options || {};
    return chartStyle.scaleLength(base, scaleInfo, { ...opts, context: opts.context || 'radius' });
  };

  chartStyle.scaleStrokeWidth = function scaleStrokeWidth(base, scaleInfo, options){
    const opts = options || {};
    const min = Number.isFinite(opts.min) ? opts.min : 0;
    const max = Number.isFinite(opts.max) ? opts.max : Infinity;
    const numeric = Number(base);
    if(opts.exact === true){
      const exactValue = Number.isFinite(numeric) ? numeric : 0;
      const clampedExact = Math.min(max, Math.max(min, exactValue));
      console.debug('Debug: chartStyle.scaleStrokeWidth exact applied', {
        base,
        min,
        max,
        result: clampedExact,
        context: opts.context || 'stroke'
      });
      return clampedExact;
    }
    const result = chartStyle.scaleLength(base, scaleInfo, { ...opts, min, max, context: opts.context || 'stroke' });
    console.debug('Debug: chartStyle.scaleStrokeWidth applied', {
      base,
      min,
      max,
      result,
      context: opts.context || 'stroke'
    }); // Debug: stroke scaling trace
    return result;
  };

  chartStyle.estimateTickCount = function estimateTickCount(spanPx, options){
    const px = Number(spanPx);
    const fallback = Number.isFinite(options?.fallback) ? options.fallback : 6;
    if(!Number.isFinite(px) || px <= 0){
      const fallbackCount = Math.max(2, fallback);
      console.debug('Debug: chartStyle.estimateTickCount fallback', {
        spanPx: spanPx,
        fallback: fallbackCount,
        reason: 'invalid span',
        axis: options?.axis || 'generic'
      });
      return fallbackCount;
    }
    const baseSpacing = Number.isFinite(options?.baseSpacing) ? options.baseSpacing : 80;
    const minTicks = Number.isFinite(options?.min) ? options.min : 3;
    const maxTicks = Number.isFinite(options?.max) ? options.max : 12;
    const rawEstimate = px / Math.max(baseSpacing, 1);
    const rounded = Math.round(rawEstimate);
    const clamped = Math.min(maxTicks, Math.max(minTicks, rounded));
    const final = Math.max(2, Number.isFinite(clamped) ? clamped : fallback);
    console.debug('Debug: chartStyle.estimateTickCount', {
      spanPx: px,
      baseSpacing,
      rawEstimate,
      rounded,
      minTicks,
      maxTicks,
      final,
      axis: options?.axis || 'generic'
    }); // Debug: tick estimation trace
    return final;
  };

  chartStyle.measureText = function measureText(text, font){
    const canvas = getCanvas();
    if(!canvas){
      const fallback = (text || '').length * 8;
      console.warn('chartStyle.measureText fallback width', {text, fallback});
      return fallback;
    }
    const ctx = canvas.getContext('2d');
    ctx.font = font || chartStyle.makeFont(12);
    const width = ctx.measureText(text || '').width;
    console.debug('Debug: chartStyle.measureText', {text, font: ctx.font, width}); // Debug: measurement trace
    return width;
  };

  function parseFontSizePx(value, fallbackPx){
    const fallback = Number.isFinite(fallbackPx) && fallbackPx > 0 ? fallbackPx : 12;
    if(value === null || value === undefined || value === ''){
      return fallback;
    }
    if(typeof value === 'number'){
      return Number.isFinite(value) && value > 0 ? value : fallback;
    }
    const raw = String(value).trim();
    if(!raw){
      return fallback;
    }
    const match = raw.match(/^(-?\d*\.?\d+)\s*(px|pt)?$/i);
    if(!match){
      return fallback;
    }
    const numeric = Number(match[1]);
    if(!Number.isFinite(numeric) || numeric <= 0){
      return fallback;
    }
    const unit = (match[2] || 'px').toLowerCase();
    if(unit === 'pt'){
      return numeric * PT_TO_PX;
    }
    return numeric;
  }

  function extractFontSizePxFromFontSpec(fontSpec, fallbackPx){
    const fallback = Number.isFinite(fallbackPx) && fallbackPx > 0 ? fallbackPx : 12;
    if(typeof fontSpec !== 'string'){
      return fallback;
    }
    const raw = fontSpec.trim();
    if(!raw){
      return fallback;
    }
    const matches = raw.match(/(-?\d*\.?\d+)\s*(px|pt)\b/ig);
    if(!matches || !matches.length){
      return fallback;
    }
    const token = String(matches[matches.length - 1] || '').trim();
    if(!token){
      return fallback;
    }
    return parseFontSizePx(token, fallback);
  }

  chartStyle.resolveScopedLabelMeasureFont = function resolveScopedLabelMeasureFont(options){
    const opts = options || {};
    const styles = opts.styles && typeof opts.styles === 'object' ? opts.styles : null;
    const role = typeof opts.role === 'string' ? opts.role.trim() : '';
    const fallbackPxRaw = Number(opts.fallbackPx);
    const fallbackPx = Number.isFinite(fallbackPxRaw) && fallbackPxRaw > 0 ? fallbackPxRaw : 12;
    const defaultFamily = typeof chartStyle.FONT_FAMILY === 'string' && chartStyle.FONT_FAMILY.trim()
      ? chartStyle.FONT_FAMILY.trim()
      : 'Arial, Helvetica, sans-serif';
    let fontSizePx = fallbackPx;
    let fontFamily = defaultFamily;
    let fontStyle = 'normal';
    let fontWeight = 'normal';
    const applyStyle = style => {
      if(!style || typeof style !== 'object'){
        return;
      }
      fontSizePx = parseFontSizePx(style.fontSize, fontSizePx);
      const family = typeof style.fontFamily === 'string' ? style.fontFamily.trim() : '';
      if(family){
        fontFamily = family;
      }
      const nextStyle = typeof style.fontStyle === 'string' ? style.fontStyle.trim() : '';
      if(nextStyle){
        fontStyle = nextStyle;
      }
      if(style.fontWeight !== null && style.fontWeight !== undefined){
        const nextWeight = String(style.fontWeight).trim();
        if(nextWeight){
          fontWeight = nextWeight;
        }
      }
    };
    if(styles){
      applyStyle(styles.__graph__);
      if(role){
        applyStyle(styles[role]);
      }
    }
    const safeSize = Number.isFinite(fontSizePx) && fontSizePx > 0 ? fontSizePx : fallbackPx;
    const safeFamily = fontFamily || defaultFamily;
    const safeStyle = fontStyle || 'normal';
    const safeWeight = fontWeight || 'normal';
    const fontSpec = `${safeStyle} ${safeWeight} ${safeSize}px ${safeFamily}`;
    return {
      fontSpec,
      fontSizePx: safeSize,
      fontFamily: safeFamily,
      fontStyle: safeStyle,
      fontWeight: safeWeight
    };
  };

  /**
   * Unicode superscript digits for rendering exponents.
   * @type {Object<string, string>}
   */
  const SUPERSCRIPT_MAP = {
    '-': '⁻',
    '0': '⁰',
    '1': '¹',
    '2': '²',
    '3': '³',
    '4': '⁴',
    '5': '⁵',
    '6': '⁶',
    '7': '⁷',
    '8': '⁸',
    '9': '⁹'
  };

  /**
   * Tolerance for floating point comparison when determining integer mantissa.
   * @type {number}
   */
  const MANTISSA_INTEGER_TOLERANCE = 1e-9;

  /**
   * Maximum decimal places for mantissa in scientific notation.
   * Kept at 2 for readability on chart axes regardless of maxDecimals setting.
   * @type {number}
   */
  const MANTISSA_MAX_DECIMALS = 2;

  /**
   * Convert a number string to Unicode superscript characters.
   * Only processes digits 0-9 and the minus sign; other characters pass through unchanged.
   * @param {string|number} num - The number to convert (e.g., "-3", "10")
   * @returns {string} - The superscript version (e.g., "⁻³", "¹⁰")
   */
  function toSuperscript(num){
    const str = String(num);
    let result = '';
    for(let i = 0; i < str.length; i++){
      const char = str[i];
      // Only map known characters; others pass through (shouldn't happen for valid exponents)
      result += SUPERSCRIPT_MAP[char] || char;
    }
    return result;
  }

  /**
   * Threshold for using scientific notation (absolute value >= this uses scientific notation)
   * @type {number}
   */
  const SCIENTIFIC_THRESHOLD_HIGH = 10000;

  /**
   * Threshold for small numbers (absolute value > 0 and <= this uses scientific notation).
   * Zero is handled separately and always formatted as "0".
   * @type {number}
   */
  const SCIENTIFIC_THRESHOLD_LOW = 0.001;

  /**
   * Format a number for axis tick labels, using scientific notation for
   * very large (>=10000) or very small (<=0.001 and >0) numbers unless
   * forceScientific is provided, which bypasses the thresholds.
   * Uses Unicode superscript for the exponent (e.g., 10³ instead of 10^3).
   *
   * Note: Zero is always formatted as "0", not in scientific notation.
   * The low threshold check excludes zero to avoid "0×10⁰" formatting.
   *
   * @param {number} value - The numeric value to format
   * @param {Object} [options] - Formatting options
   * @param {number} [options.maxDecimals=2] - Maximum decimal places for non-scientific notation.
   *        Note: Mantissa in scientific notation is capped at 2 decimals for readability.
   * @param {number} [options.thresholdHigh=10000] - Threshold above which to use scientific notation
   * @param {number} [options.thresholdLow=0.001] - Threshold at or below which to use scientific notation (for non-zero values)
   * @param {boolean} [options.forceScientific=false] - Always use scientific notation when true
   * @returns {string} - The formatted string representation
   */
  chartStyle.formatScientific = function formatScientific(value, options){
    const opts = options || {};
    const maxDecimals = Number.isFinite(opts.maxDecimals) ? opts.maxDecimals : 2;
    const thresholdHigh = Number.isFinite(opts.thresholdHigh) ? opts.thresholdHigh : SCIENTIFIC_THRESHOLD_HIGH;
    const thresholdLow = Number.isFinite(opts.thresholdLow) ? opts.thresholdLow : SCIENTIFIC_THRESHOLD_LOW;
    const forceScientific = opts.forceScientific === true;

    // Handle non-finite values
    if(!Number.isFinite(value)){
      return String(value);
    }

    // Handle zero specially - never use scientific notation for zero
    if(value === 0){
      return '0';
    }

    const absValue = Math.abs(value);

    // Check if scientific notation is needed.
    // For small values, we check absValue > 0 to exclude zero (already handled above).
    const needsScientific = forceScientific || absValue >= thresholdHigh || (absValue > 0 && absValue <= thresholdLow);

    if(needsScientific){
      // Calculate exponent
      const exponent = Math.floor(Math.log10(absValue));
      const mantissa = value / Math.pow(10, exponent);

      // Format mantissa with appropriate precision
      // Mantissa decimals capped at MANTISSA_MAX_DECIMALS for axis readability
      let mantissaStr;
      if(Math.abs(mantissa - Math.round(mantissa)) < MANTISSA_INTEGER_TOLERANCE){
        // Integer mantissa
        mantissaStr = String(Math.round(mantissa));
      }else{
        // Decimal mantissa - use up to MANTISSA_MAX_DECIMALS for readability
        mantissaStr = mantissa.toFixed(Math.min(MANTISSA_MAX_DECIMALS, maxDecimals));
        // Remove trailing zeros after decimal point
        mantissaStr = mantissaStr.replace(/\.?0+$/, '');
      }

      // Format: mantissa×10ⁿ or just 10ⁿ if mantissa is 1
      const superExp = toSuperscript(exponent);
      if(mantissaStr === '1'){
        return `10${superExp}`;
      }else if(mantissaStr === '-1'){
        return `-10${superExp}`;
      }
      return `${mantissaStr}×10${superExp}`;
    }

    // Standard formatting for regular numbers
    // Use toLocaleString for nice formatting without excessive decimals
    const formatted = value.toLocaleString('en-US', {
      maximumFractionDigits: maxDecimals,
      useGrouping: false
    });

    return formatted;
  };

  function formatDecimal(value, options){
    if(!Number.isFinite(value)){
      return String(value);
    }
    const opts = options || {};
    const maxDigits = Number.isFinite(opts.maxDecimals) ? Math.min(12, Math.max(0, opts.maxDecimals)) : 6;
    const minDigits = Number.isFinite(opts.minDecimals) ? Math.max(0, Math.min(maxDigits, opts.minDecimals)) : 0;
    const digits = Math.max(minDigits, maxDigits);
    let text;
    try{
      text = value.toFixed(digits);
    }catch(err){
      text = String(value);
    }
    if(text && text.indexOf('e') !== -1){
      // Fallback when toFixed resorts to exponential form
      text = Number(value).toLocaleString('en-US', {
        useGrouping: false,
        maximumFractionDigits: digits,
        minimumFractionDigits: minDigits
      });
    }
    if(opts.trimTrailingZeros !== false){
      text = text.replace(/\.0+$/,'').replace(/(\.\d*?[1-9])0+$/,'$1');
    }
    if(text === '-0'){
      return '0';
    }
    return text;
  }

  chartStyle.formatDecimal = formatDecimal;

  const AXIS_NOTATION_ALLOWED = new Set(['auto','decimal','scientific']);

  function normalizeAxisNotation(value){
    if(typeof value !== 'string'){ return 'auto'; }
    const trimmed = value.trim().toLowerCase();
    return AXIS_NOTATION_ALLOWED.has(trimmed) ? trimmed : 'auto';
  }

  /**
   * Format axis ticks using the requested notation mode.
   * @param {number} value
   * @param {Object} [options]
   * @param {'auto'|'decimal'|'scientific'} [options.notation='auto']
   * @param {number} [options.maxDecimals=2]
   * @param {number} [options.decimalDigits]
   * @returns {string}
   */
  chartStyle.formatAxisValue = function formatAxisValue(value, options){
    const opts = options || {};
    const notation = normalizeAxisNotation(opts.notation);
    if(notation === 'scientific'){
      return chartStyle.formatScientific(value, {
        ...opts,
        forceScientific: true
      });
    }
    if(notation === 'decimal'){
      const decimalDigits = Number.isFinite(opts.decimalDigits)
        ? Math.max(0, Math.min(12, opts.decimalDigits))
        : Math.max(4, Math.min(8, (Number.isFinite(opts.maxDecimals) ? opts.maxDecimals + 4 : 6)));
      return formatDecimal(value, {
        maxDecimals: decimalDigits,
        trimTrailingZeros: opts.trimTrailingZeros !== false
      });
    }
    return chartStyle.formatScientific(value, opts);
  };

  /**
   * Create a tick formatter function that uses scientific notation
   * for very large or very small values.
   *
   * @param {Object} [options] - Options to pass to formatScientific
   * @returns {function(number): string} - A formatter function
   */
  chartStyle.createTickFormatter = function createTickFormatter(options){
    const opts = options || {};
    return function formatTick(value){
      return chartStyle.formatScientific(value, opts);
    };
  };

  chartStyle.createAxisMetrics = function createAxisMetrics(fontSize, scaleInfo){
    const safeFont = Number(fontSize) || BASE_FONT_SIZE_PX;
    const hasScaleInfo = !!(scaleInfo && (Number.isFinite(scaleInfo.styleScale) || Number.isFinite(scaleInfo.scale)));
    const resizeScale = hasScaleInfo ? clampScale(resolveStyleScale(scaleInfo)) : 1;
    const baseMetrics = {
      tickLength: 6,
      tickLabelGap: Math.max(3, Math.round(safeFont * 0.35)),
      axisTitleGap: Math.max(4, Math.round(safeFont * 0.75)),
      outerPadding: Math.max(6, Math.round(safeFont * 0.6)),
      yTitleGap: Math.max(4, Math.round(safeFont * 0.5))
    };
    const scaleMetric = (base, min) => Math.max(min, base * resizeScale);
    const tickLengthRaw = scaleMetric(baseMetrics.tickLength, 1);
    const tickLengthPx = Math.max(1, Math.floor(tickLengthRaw));
    const metrics = hasScaleInfo
      ? {
          tickLength: tickLengthPx,
          tickLabelGap: scaleMetric(baseMetrics.tickLabelGap, 1.5),
          axisTitleGap: scaleMetric(baseMetrics.axisTitleGap, 1.5),
          outerPadding: scaleMetric(baseMetrics.outerPadding, 2),
          yTitleGap: scaleMetric(baseMetrics.yTitleGap, 1.5)
        }
      : baseMetrics;
    console.debug('Debug: chartStyle.createAxisMetrics',{
      fontSize:safeFont,
      hasScaleInfo,
      scale: scaleInfo?.styleScale ?? scaleInfo?.scale ?? null,
      resizeScale,
      baseMetrics,
      tickLengthRaw,
      tickLengthPx,
      metrics
    }); // Debug: axis metric computation
    return metrics;
  };

  chartStyle.computeBottomLayout = function computeBottomLayout(options){
    const labels = options?.labels || [];
    const fontSize = options?.fontSize || 12;
    const plotWidth = options?.plotWidth || 0;
    const axisMetrics = options?.axisMetrics || chartStyle.createAxisMetrics(fontSize);
    const tickLength = axisMetrics.tickLength ?? 6;
    const tickLabelGap = axisMetrics.tickLabelGap ?? Math.max(3, Math.round(fontSize * 0.35));
    const axisTitleGap = axisMetrics.axisTitleGap ?? Math.max(4, Math.round(fontSize * 0.75));
    const outerPadding = axisMetrics.outerPadding ?? Math.max(6, Math.round(fontSize * 0.6));
    const baseLabelOffset = tickLength + tickLabelGap;
    const customMeasureFontRaw = typeof options?.labelMeasureFont === 'string' ? options.labelMeasureFont.trim() : '';
    const labelMeasureFont = customMeasureFontRaw || chartStyle.makeFont(fontSize);
    const explicitLabelFontSize = Number(options?.labelFontSizePx);
    const tickLabelFontSize = (Number.isFinite(explicitLabelFontSize) && explicitLabelFontSize > 0)
      ? explicitLabelFontSize
      : extractFontSizePxFromFontSpec(labelMeasureFont, fontSize);
    const adjustedLabelOffset = baseLabelOffset + tickLabelFontSize;
    const includeAxisTitleReserve = options?.includeAxisTitleReserve !== false;
    const axisTitleReserve = includeAxisTitleReserve ? axisTitleGap + fontSize : 0;
    const titleOffset = adjustedLabelOffset + axisTitleReserve;
    const labelReserveMarginRaw = Number(options?.labelReserveMarginPx);
    const labelReserveMarginPx = Number.isFinite(labelReserveMarginRaw) && labelReserveMarginRaw >= 0
      ? labelReserveMarginRaw
      : outerPadding;
    const baseBottom = options?.baseBottom || Math.max(
      titleOffset + labelReserveMarginPx,
      Math.round(fontSize * BASE_BOTTOM_FACTOR) + tickLabelFontSize + 8
    );
    const widths = labels.map(label => chartStyle.measureText(label || '', labelMeasureFont));
    const maxLabelWidth = widths.length ? Math.max(...widths) : 0;
    const explicitBandWidth = Number(options?.bandWidth);
    const bandWidth = labels.length
      ? (
          Number.isFinite(explicitBandWidth) && explicitBandWidth > 0
            ? explicitBandWidth
            : plotWidth / labels.length
        )
      : plotWidth;
    const maxLabelWidthRatio = labels.length > 1 && Number.isFinite(bandWidth) && bandWidth > 0
      ? (maxLabelWidth / bandWidth)
      : 0;
    let maxAdjacentOverlapRatio = 0;
    if(labels.length > 1 && Number.isFinite(bandWidth) && bandWidth > 0){
      for(let i = 1; i < widths.length; i += 1){
        const leftWidth = Number(widths[i - 1]) || 0;
        const rightWidth = Number(widths[i]) || 0;
        const pairHalfSpan = (leftWidth + rightWidth) / 2;
        const overlapRatio = pairHalfSpan / bandWidth;
        if(overlapRatio > maxAdjacentOverlapRatio){
          maxAdjacentOverlapRatio = overlapRatio;
        }
      }
    }
    const rotationHysteresis = options?.rotationHysteresis && typeof options.rotationHysteresis === 'object'
      ? options.rotationHysteresis
      : null;
    const previousRotate = rotationHysteresis ? (rotationHysteresis.previousRotate === true) : null;
    const baseRotateRatioRaw = Number(options?.rotateRatioThreshold);
    const baseRotateRatio = Number.isFinite(baseRotateRatioRaw) && baseRotateRatioRaw > 0
      ? baseRotateRatioRaw
      : 1.0;
    const enterRatioRaw = Number(rotationHysteresis?.enterRatio);
    const enterRatio = Number.isFinite(enterRatioRaw) && enterRatioRaw > 0
      ? enterRatioRaw
      : baseRotateRatio;
    const exitRatioRaw = Number(rotationHysteresis?.exitRatio);
    const fallbackExitRatio = Math.max(0.1, enterRatio - 0.08);
    let exitRatio = Number.isFinite(exitRatioRaw) && exitRatioRaw > 0
      ? exitRatioRaw
      : fallbackExitRatio;
    if(exitRatio >= enterRatio){
      exitRatio = Math.max(0.1, enterRatio - 0.01);
    }
    const reserveRotatedLabelSpace = options?.reserveRotatedLabelSpace === true;
    const projectedTickLabelReserve = options?.bottomReserveMode === 'projected-tick-label';
    const shouldRotateRaw = labels.length > 1 && maxAdjacentOverlapRatio > baseRotateRatio;
    const shouldRotate = labels.length > 1
      ? (
          previousRotate === true
            ? (maxAdjacentOverlapRatio > exitRatio)
            : (maxAdjacentOverlapRatio > enterRatio)
        )
      : false;
    const rotationAngleDegRaw = Number(options?.labelRotationAngleDeg);
    const rotationAngleDeg = Number.isFinite(rotationAngleDegRaw) ? Math.abs(rotationAngleDegRaw) : 45;
    const rotationAngleRad = rotationAngleDeg * Math.PI / 180;
    const projectedRotatedLabelHeight = Math.ceil(
      Math.abs(Math.sin(rotationAngleRad)) * maxLabelWidth
      + Math.abs(Math.cos(rotationAngleRad)) * tickLabelFontSize
    );
    const rotatedExtra = projectedTickLabelReserve
      ? Math.max(0, projectedRotatedLabelHeight - tickLabelFontSize)
      : Math.min(220, Math.max(tickLabelFontSize * 1.8, Math.ceil(Math.SQRT1_2 * maxLabelWidth) + tickLabelFontSize));
    const extra = (shouldRotate || reserveRotatedLabelSpace) ? rotatedExtra : 0;
    const bottom = projectedTickLabelReserve
      ? Math.max(baseBottom, adjustedLabelOffset + axisTitleReserve + labelReserveMarginPx + extra)
      : Math.max(baseBottom, titleOffset + outerPadding + extra);
    console.debug('Debug: chartStyle.computeBottomLayout', {
      labelCount: labels.length,
      fontSize,
      plotWidth,
      shouldRotate,
      shouldRotateRaw,
      maxLabelWidthRatio,
      maxAdjacentOverlapRatio,
      previousRotate,
      enterRatio,
      exitRatio,
      reserveRotatedLabelSpace,
      projectedTickLabelReserve,
      includeAxisTitleReserve,
      labelMeasureFont,
      tickLabelFontSize,
      labelReserveMarginPx,
      extra,
      rotatedExtra,
      projectedRotatedLabelHeight,
      bottom,
      labelOffset: adjustedLabelOffset,
      titleOffset,
      tickLength
    }); // Debug: bottom layout computation
    return {bottom, shouldRotate, shouldRotateRaw, widths, bandWidth, maxLabelWidth, maxLabelWidthRatio, maxAdjacentOverlapRatio, labelOffset: adjustedLabelOffset, titleOffset, tickLength, tickLabelGap, axisTitleGap, outerPadding, labelMeasureFont, tickLabelFontSize};
  };

  chartStyle.applyLabelOrientation = function applyLabelOrientation(nodes, options){
    const list = Array.from(nodes || []);
    if(!list.length){
      console.debug('Debug: chartStyle.applyLabelOrientation skipped (no labels)');
      return false;
    }
    const angle = options?.angle ?? -45;
    const anchor = options?.anchor ?? 'end';
    const dy = options?.dy ?? '0.35em';
    const force = options?.force ?? false;
    const disableAuto = options?.disableAuto === true;
    let rotate = !!force;
    if(!rotate && !disableAuto){
      for(let i=1;i<list.length;i+=1){
        const prev = list[i-1];
        const curr = list[i];
        if(prev?.getBBox && curr?.getBBox){
          const prevBox = prev.getBBox();
          const currBox = curr.getBBox();
          if(prevBox.x + prevBox.width > currBox.x){
            rotate = true;
            break;
          }
        }
      }
    }
    if(rotate){
      list.forEach(node => {
        if(!node) return;
        const x = node.getAttribute('x');
        const y = node.getAttribute('y');
        if(x==null || y==null) return;
        node.setAttribute('transform', `rotate(${angle} ${x} ${y})`);
        node.setAttribute('text-anchor', anchor);
        if(dy !== null){
          node.setAttribute('dy', dy);
        }
      });
    }
    console.debug('Debug: chartStyle.applyLabelOrientation result', {count: list.length, rotated: rotate, angle, disableAuto}); // Debug: label orientation summary
    return rotate;
  };

  function axisTicksDebug(label, payload){
    try{
      if(typeof Shared.isDebugEnabled === 'function' && !Shared.isDebugEnabled()){
        return;
      }
    }catch(err){
      // Ignore debug toggle lookup failures and log by default
    }
    console.debug(label, payload);
  }

  function normalizePrecision(value){
    if(!Number.isFinite(value)){
      return value;
    }
    return Number.parseFloat(value.toPrecision(12));
  }

  function clampTickTarget(value){
    if(!Number.isFinite(value)){
      return 6;
    }
    const rounded = Math.round(value);
    return Math.max(5, Math.min(8, rounded));
  }

  function selectTickStep(span, targetCount, manualSpan){
    const safeSpan = Number.isFinite(span) && span > 0 ? span : 1;
    const safeTarget = Number.isFinite(targetCount) && targetCount > 1 ? targetCount : 6;
    const approxStep = safeSpan / Math.max(safeTarget - 1, 1);
    let baseExp = Math.floor(Math.log10(Math.abs(approxStep)));
    if(!Number.isFinite(baseExp)){
      baseExp = 0;
    }
    const multipliers = [1, 2, 2.5, 5, 10];
    let best = null;
    const manualSpanFinite = Number.isFinite(manualSpan) && manualSpan > 0;
    for(let exp = baseExp - 1; exp <= baseExp + 1; exp += 1){
      const pow = Math.pow(10, exp);
      for(let i = 0; i < multipliers.length; i += 1){
        const step = multipliers[i] * pow;
        if(!Number.isFinite(step) || step <= 0){
          continue;
        }
        const tickEstimate = Math.ceil(safeSpan / step) + 1;
        const tickCount = Math.max(2, tickEstimate);
        const diffScore = Math.abs(tickCount - safeTarget);
        const rangePenalty = (tickCount < 5 || tickCount > 8) ? 2 : 0;
        let manualPenalty = 0;
        if(manualSpanFinite){
          const multiples = manualSpan / step;
          const nearest = Math.round(multiples);
          manualPenalty = Math.min(Math.abs(multiples - nearest), 0.5);
        }
        const score = diffScore + rangePenalty + manualPenalty;
        if(!best || score < best.score - 1e-9 || (Math.abs(score - best.score) <= 1e-9 && step < best.step)){
          best = { step, score };
        }
      }
    }
    if(best){
      return best.step;
    }
    const fallbackStep = multipliers[0] * Math.pow(10, baseExp);
    return Number.isFinite(fallbackStep) && fallbackStep > 0 ? fallbackStep : 1;
  }

  function buildAxisScale(options){
    const {
      dataMin,
      dataMax,
      manualMin,
      manualMax,
      targetTickCount,
      fixedStep
    } = options || {};
    const manualMinFinite = Number.isFinite(manualMin);
    const manualMaxFinite = Number.isFinite(manualMax);
    let normalizedManualMin = manualMinFinite ? manualMin : NaN;
    let normalizedManualMax = manualMaxFinite ? manualMax : NaN;
    if(manualMinFinite && manualMaxFinite && normalizedManualMax < normalizedManualMin){
      const swap = normalizedManualMin;
      normalizedManualMin = normalizedManualMax;
      normalizedManualMax = swap;
    }
    const dataMinFinite = Number.isFinite(dataMin);
    const dataMaxFinite = Number.isFinite(dataMax);
    let normalizedDataMin = dataMinFinite ? dataMin : NaN;
    let normalizedDataMax = dataMaxFinite ? dataMax : NaN;
    if(dataMinFinite && dataMaxFinite && normalizedDataMax < normalizedDataMin){
      const swap = normalizedDataMin;
      normalizedDataMin = normalizedDataMax;
      normalizedDataMax = swap;
    }
    const baseLowerCandidates = [];
    const baseUpperCandidates = [];
    if(Number.isFinite(normalizedDataMin)){ baseLowerCandidates.push(normalizedDataMin); }
    if(Number.isFinite(normalizedDataMax)){ baseUpperCandidates.push(normalizedDataMax); }
    if(manualMinFinite){ baseLowerCandidates.push(normalizedManualMin); }
    if(manualMaxFinite){ baseUpperCandidates.push(normalizedManualMax); }
    let baseLower = baseLowerCandidates.length ? Math.min(...baseLowerCandidates) : 0;
    let baseUpper = baseUpperCandidates.length ? Math.max(...baseUpperCandidates) : (baseLower + 1);
    if(!Number.isFinite(baseUpper) || baseUpper <= baseLower){
      const offset = Math.max(Math.abs(baseLower), 1);
      baseUpper = baseLower + offset;
    }
    const requiredLower = manualMinFinite ? normalizedManualMin : baseLower;
    const requiredUpper = manualMaxFinite ? normalizedManualMax : baseUpper;
    const spanCandidates = [];
    if(Number.isFinite(normalizedDataMin) && Number.isFinite(normalizedDataMax)){
      spanCandidates.push(Math.abs(normalizedDataMax - normalizedDataMin));
    }
    spanCandidates.push(Math.abs(requiredUpper - requiredLower));
    const spanValues = spanCandidates.filter(v => Number.isFinite(v) && v > 0);
    const span = spanValues.length ? Math.max(...spanValues) : 1;
    if(!spanValues.length){
      axisTicksDebug('Debug: chartStyle.axisTicks span fallback',{
        dataMin,
        dataMax,
        manualMin: manualMinFinite ? normalizedManualMin : null,
        manualMax: manualMaxFinite ? normalizedManualMax : null,
        requiredLower,
        requiredUpper
      });
    }
    const manualSpan = manualMinFinite && manualMaxFinite
      ? Math.abs(normalizedManualMax - normalizedManualMin)
      : NaN;
    const step = Number.isFinite(fixedStep) && fixedStep > 0
      ? fixedStep
      : selectTickStep(span, clampTickTarget(targetTickCount), manualSpan);
    const tolerance = Math.max(Math.abs(step) * 1e-9, 1e-9);
    const ticks = [];
    const maxGuard = 8192;
    if(manualMinFinite){
      let current = normalizedManualMin;
      let guard = 0;
      while(current <= requiredUpper + tolerance && guard < maxGuard){
        ticks.push(normalizePrecision(current));
        current += step;
        guard += 1;
      }
      if(ticks.length){
        const last = ticks[ticks.length - 1];
        if(last < requiredUpper - tolerance){
          ticks.push(normalizePrecision(last + step));
        }
      }
      if(manualMaxFinite && ticks.length){
        const lastIdx = ticks.length - 1;
        if(Math.abs(ticks[lastIdx] - normalizedManualMax) <= tolerance){
          ticks[lastIdx] = normalizePrecision(normalizedManualMax);
        }
      }
    }else if(manualMaxFinite){
      let current = normalizedManualMax;
      let guard = 0;
      while(current >= requiredLower - tolerance && guard < maxGuard){
        ticks.unshift(normalizePrecision(current));
        current -= step;
        guard += 1;
      }
      if(ticks.length){
        if(ticks[0] > requiredLower + tolerance){
          ticks.unshift(normalizePrecision(ticks[0] - step));
        }
        const lastIdx = ticks.length - 1;
        ticks[lastIdx] = normalizePrecision(normalizedManualMax);
      }
    }else{
      const baseStartReference = Number.isFinite(normalizedDataMin) ? normalizedDataMin : requiredLower;
      let start = Math.floor(baseStartReference / step) * step;
      if(!Number.isFinite(start)){
        start = baseStartReference;
      }
      let current = start;
      let guard = 0;
      while(current <= requiredUpper + tolerance && guard < maxGuard){
        ticks.push(normalizePrecision(current));
        current += step;
        guard += 1;
      }
      if(ticks.length){
        const last = ticks[ticks.length - 1];
        if(last < requiredUpper - tolerance){
          ticks.push(normalizePrecision(last + step));
        }
        if(ticks[0] > requiredLower + tolerance){
          ticks.unshift(normalizePrecision(ticks[0] - step));
        }
      }
    }
    if(!ticks.length){
      ticks.push(normalizePrecision(requiredLower));
    }
    if(ticks.length === 1){
      ticks.push(normalizePrecision(ticks[0] + step));
    }
    ticks.sort((a, b) => a - b);
    if(manualMinFinite){
      ticks[0] = normalizePrecision(normalizedManualMin);
    }else if(ticks[0] > requiredLower + tolerance){
      ticks.unshift(normalizePrecision(ticks[0] - step));
    }
    const lastTick = ticks[ticks.length - 1];
    if(manualMaxFinite){
      if(Math.abs(lastTick - normalizedManualMax) <= tolerance){
        ticks[ticks.length - 1] = normalizePrecision(normalizedManualMax);
      }else if(lastTick < normalizedManualMax - tolerance){
        ticks.push(normalizePrecision(lastTick + step));
        ticks[ticks.length - 1] = normalizePrecision(ticks[ticks.length - 1]);
      }
    }else if(lastTick < requiredUpper - tolerance){
      ticks.push(normalizePrecision(lastTick + step));
    }
    if(ticks.length === 1){
      ticks.push(normalizePrecision(ticks[0] + step));
    }
    ticks.sort((a, b) => a - b);
    const cleanTicks = ticks.filter(v => Number.isFinite(v)).map(normalizePrecision);
    const minTick = cleanTicks[0];
    const maxTick = cleanTicks[cleanTicks.length - 1];
    const finalMin = Number.isFinite(minTick) ? minTick : requiredLower;
    const finalMax = Number.isFinite(maxTick) ? maxTick : requiredUpper;
    axisTicksDebug('Debug: chartStyle.axisTicks scale computed',{
      dataMin,
      dataMax,
      manualMin: manualMinFinite ? normalizedManualMin : null,
      manualMax: manualMaxFinite ? normalizedManualMax : null,
      step,
      tickCount: cleanTicks.length,
      min: finalMin,
      max: finalMax
    });
    return {
      min: finalMin,
      max: finalMax,
      ticks: cleanTicks,
      step
    };
  }

  function applyLogTicks(scale, options){
    if(!scale || typeof scale !== 'object'){
      return false;
    }
    const manualMin = Number.isFinite(options?.manualMin) ? options.manualMin : null;
    const manualMax = Number.isFinite(options?.manualMax) ? options.manualMax : null;
    const fallbackMin = Number.isFinite(options?.fallbackMin) ? options.fallbackMin : null;
    const fallbackMax = Number.isFinite(options?.fallbackMax) ? options.fallbackMax : null;
    let resolvedMin = Number.isFinite(scale.min) ? scale.min : fallbackMin;
    let resolvedMax = Number.isFinite(scale.max) ? scale.max : fallbackMax;
    const autoRangeSource = { min: 'scale', max: 'scale' };
    if(manualMin === null && Number.isFinite(fallbackMin)){
      resolvedMin = fallbackMin;
      autoRangeSource.min = 'fallback';
    }
    if(manualMax === null && Number.isFinite(fallbackMax)){
      resolvedMax = fallbackMax;
      autoRangeSource.max = 'fallback';
    }
    if((autoRangeSource.min !== 'scale' || autoRangeSource.max !== 'scale') && (fallbackMin !== null || fallbackMax !== null)){
      axisTicksDebug('Debug: chartStyle.axisTicks log range source',{
        resolvedMin,
        resolvedMax,
        fallbackMin,
        fallbackMax,
        scaleMin: Number.isFinite(scale.min) ? scale.min : null,
        scaleMax: Number.isFinite(scale.max) ? scale.max : null,
        manualMinApplied: manualMin !== null,
        manualMaxApplied: manualMax !== null,
        source: autoRangeSource
      });
    }
    if(!Number.isFinite(resolvedMin) || !Number.isFinite(resolvedMax) || resolvedMin >= resolvedMax){
      return false;
    }
    const epsilon = Math.max(1e-9, Math.abs(resolvedMax - resolvedMin) * 1e-6);
    if(manualMin === null){
      const alignedMin = Math.floor(resolvedMin - epsilon);
      if(Number.isFinite(alignedMin)){
        scale.min = alignedMin;
        resolvedMin = alignedMin;
      }
    }else{
      scale.min = manualMin;
      resolvedMin = manualMin;
    }
    if(Object.is(scale.min, -0)){
      scale.min = 0;
      resolvedMin = 0;
    }
    if(manualMax === null){
      const alignedMax = Math.ceil(resolvedMax + epsilon);
      if(Number.isFinite(alignedMax)){
        scale.max = alignedMax;
        resolvedMax = alignedMax;
      }
    }else{
      scale.max = manualMax;
      resolvedMax = manualMax;
    }
    if(Object.is(scale.max, -0)){
      scale.max = 0;
      resolvedMax = 0;
    }
    if(!Number.isFinite(resolvedMin) || !Number.isFinite(resolvedMax) || resolvedMin >= resolvedMax){
      return false;
    }
    const tickStart = Math.ceil(resolvedMin - epsilon);
    const tickEnd = Math.floor(resolvedMax + epsilon);
    if(tickStart > tickEnd){
      return false;
    }
    const ticks = [];
    for(let exp = tickStart; exp <= tickEnd; exp += 1){
      ticks.push(exp);
    }
    if(!ticks.length){
      return false;
    }
    const normalizedTicks = ticks.map(value => (Object.is(value, -0) ? 0 : value));
    scale.ticks = normalizedTicks;
    scale.step = 1;
    axisTicksDebug('Debug: chartStyle.axisTicks log override',{
      min: resolvedMin,
      max: resolvedMax,
      tickCount: normalizedTicks.length,
      manualMinApplied: manualMin !== null,
      manualMaxApplied: manualMax !== null
    });
    return true;
  }

  chartStyle.axisTicks = Object.freeze({
    clampTickTarget,
    selectStep: selectTickStep,
    buildScale: buildAxisScale,
    applyLogTicks
  });

  const DEFAULT_MINOR_TICK_SUBDIVISIONS = 3;
  chartStyle.DEFAULT_MINOR_TICK_SUBDIVISIONS = DEFAULT_MINOR_TICK_SUBDIVISIONS;

  chartStyle.computeMinorTickPositions = function computeMinorTickPositions(options){
    const opts = options || {};
    const majorTicks = Array.isArray(opts.majorTicks)
      ? opts.majorTicks.filter(v => Number.isFinite(v)).slice().sort((a, b) => a - b)
      : [];
    if(majorTicks.length < 2){
      return [];
    }
    const min = Number.isFinite(opts.min) ? opts.min : majorTicks[0];
    const max = Number.isFinite(opts.max) ? opts.max : majorTicks[majorTicks.length - 1];
    const scale = opts.scale === 'log' ? 'log' : 'linear';
    const subdivisionsRaw = Number.isFinite(opts.subdivisions) ? opts.subdivisions : DEFAULT_MINOR_TICK_SUBDIVISIONS;
    const subdivisions = Math.max(1, Math.min(12, Math.round(subdivisionsRaw)));
    const tolerance = Math.max(Math.abs(max - min) * 1e-9, 1e-9);
    const minors = [];

    if(
      scale === 'log' &&
      Number.isFinite(opts.domainMin) && opts.domainMin > 0 &&
      Number.isFinite(opts.domainMax) && opts.domainMax > 0
    ){
      const base = Number.isFinite(opts.logBase) && opts.logBase > 1 ? opts.logBase : 10;
      const logFn = typeof opts.logFn === 'function'
        ? opts.logFn
        : (value => Math.log(value) / Math.log(base));
      const domainTicks = majorTicks.map(t => Math.pow(base, t));
      for(let i = 0; i < domainTicks.length - 1; i += 1){
        const start = domainTicks[i];
        const end = domainTicks[i + 1];
        if(!Number.isFinite(start) || !Number.isFinite(end) || !(start > 0) || !(end > start)){
          continue;
        }
        for(let m = 2; m < base; m += 1){
          const candidate = start * m;
          if(candidate >= end - tolerance){
            break;
          }
          if(candidate <= start + tolerance){
            continue;
          }
          const logValue = logFn(candidate);
          if(!Number.isFinite(logValue)){
            continue;
          }
          if(logValue <= min - tolerance || logValue >= max + tolerance){
            continue;
          }
          minors.push(logValue);
        }
      }
    }else{
      for(let i = 0; i < majorTicks.length - 1; i += 1){
        const start = majorTicks[i];
        const end = majorTicks[i + 1];
        const span = end - start;
        if(!Number.isFinite(span) || span <= tolerance){
          continue;
        }
        const step = span / (subdivisions + 1);
        for(let sub = 1; sub <= subdivisions; sub += 1){
          const value = start + step * sub;
          if(value <= min + tolerance || value >= max - tolerance){
            continue;
          }
          minors.push(value);
        }
      }
    }

    const unique = [];
    minors.forEach(value => {
      if(!Number.isFinite(value)){
        return;
      }
      if(value < min - tolerance || value > max + tolerance){
        return;
      }
      const nearMajor = majorTicks.some(major => Math.abs(major - value) <= tolerance * 1.5);
      if(nearMajor){
        return;
      }
      const duplicate = unique.some(existing => Math.abs(existing - value) <= tolerance * 0.5);
      if(!duplicate){
        unique.push(value);
      }
    });
    unique.sort((a, b) => a - b);
    if(Shared.isDebugEnabled?.()){
      console.debug('Debug: chartStyle.computeMinorTickPositions', {
        majorCount: majorTicks.length,
        minorCount: unique.length,
        min,
        max,
        scale,
        subdivisions,
        domainMin: opts.domainMin ?? null,
        domainMax: opts.domainMax ?? null
      });
    }
    return unique;
  };

  chartStyle.resolveMinorTickStyle = function resolveMinorTickStyle(options){
    const tickLength = Number.isFinite(options?.tickLength) ? options.tickLength : 6;
    const axisStrokeWidth = Number.isFinite(options?.strokeWidth) ? options.strokeWidth : 1;
    const length = Math.max(2, Math.round(tickLength * 0.55));
    const strokeWidth = Math.max(0.5, Math.max(axisStrokeWidth * 0.75, axisStrokeWidth - 0.25));
    const opacity = Number.isFinite(options?.opacity) ? options.opacity : 0.85;
    return { length, strokeWidth, opacity };
  };

  chartStyle.computeLabelPadding = function computeLabelPadding(options){
    const opts = options || {};
    const labels = Array.isArray(opts.labels) ? opts.labels.map(label => label == null ? '' : String(label)) : [];
    const angleDeg = Math.abs(Number(opts.angle) || 0);
    const rad = angleDeg * (Math.PI / 180);
    const sin = Math.sin(rad);
    const cos = Math.cos(rad);
    const units = typeof opts.units === 'string' ? opts.units.toLowerCase() : 'pt';
    let fontPx;
    let fontPt;
    const rawSize = Number(opts.fontSize);
    if(units === 'px'){
      fontPx = Number.isFinite(rawSize) && rawSize > 0 ? rawSize : BASE_FONT_SIZE_PX;
      fontPt = fontPx / PT_TO_PX;
    }else{
      const normalized = chartStyle.normalizeFontSize(rawSize);
      fontPt = normalized.pt;
      fontPx = normalized.px;
    }
    const basePadding = Number.isFinite(opts.basePadding) ? opts.basePadding : Math.max(fontPx * 0.4, 8);
    const fontForMeasure = chartStyle.makeFont(Math.max(4, Math.round(fontPx)));
    let maxLabelWidth = 0;
    labels.forEach(label => {
      const width = chartStyle.measureText(label, fontForMeasure);
      if(Number.isFinite(width) && width > maxLabelWidth){
        maxLabelWidth = width;
      }
    });
    const verticalSpan = angleDeg === 0 ? fontPx : Math.abs(sin) * maxLabelWidth + Math.abs(cos) * fontPx;
    const horizontalSpan = angleDeg === 0 ? maxLabelWidth : Math.abs(cos) * maxLabelWidth + Math.abs(sin) * fontPx;
    const vertical = Math.ceil(verticalSpan + basePadding);
    const horizontal = Math.ceil(horizontalSpan + basePadding);
    const summary = {
      debugLabel: opts.debugLabel || 'chartStyle.computeLabelPadding',
      labelCount: labels.length,
      angle: angleDeg,
      basePadding,
      maxLabelWidth,
      fontPx,
      fontPt,
      vertical,
      horizontal
    };
    console.debug('Debug: chartStyle.computeLabelPadding', summary); // Debug: label padding computation
    return { ...summary, sin, cos };
  };

  chartStyle.ensureLabelPadding = function ensureLabelPadding(currentMargin, options){
    const info = chartStyle.computeLabelPadding(options);
    const directionRaw = options?.direction || 'vertical';
    const direction = typeof directionRaw === 'string' ? directionRaw.toLowerCase() : 'vertical';
    const applied = Number.isFinite(currentMargin) ? currentMargin : 0;
    const required = direction === 'horizontal' ? info.horizontal : info.vertical;
    const margin = Math.max(applied, required);
    console.debug('Debug: chartStyle.ensureLabelPadding', {
      debugLabel: options?.debugLabel || 'chartStyle.ensureLabelPadding',
      direction,
      applied,
      required,
      margin
    }); // Debug: label padding safeguard summary
    return { margin, required, applied, info };
  };

  chartStyle.computeBaseMargins = function computeBaseMargins(options){
    const fontSize = options?.fontSize || 12;
    const legendWidth = options?.legendWidth || 0;
    const maxYLabelWidth = options?.maxYLabelWidth || 0;
    const legacyYTitleWidthRaw = Number(options?.yTitleWidth);
    const legacyYTitleWidth = Number.isFinite(legacyYTitleWidthRaw) && legacyYTitleWidthRaw > 0 ? legacyYTitleWidthRaw : 0;
    const explicitHasYTitle = typeof options?.hasYTitle === 'boolean' ? options.hasYTitle : null;
    const yTickFontSizeRaw = Number(options?.yTickFontSize);
    const yTickFontSize = Number.isFinite(yTickFontSizeRaw) && yTickFontSizeRaw > 0 ? yTickFontSizeRaw : fontSize;
    const xTickFontSizeRaw = Number(options?.xTickFontSize);
    const xTickFontSize = Number.isFinite(xTickFontSizeRaw) && xTickFontSizeRaw > 0 ? xTickFontSizeRaw : fontSize;
    const axisMetrics = options?.axisMetrics || chartStyle.createAxisMetrics(fontSize);
    const tickLength = axisMetrics.tickLength ?? 6;
    const tickLabelGap = axisMetrics.tickLabelGap ?? Math.max(3, Math.round(fontSize * 0.35));
    const axisTitleGap = axisMetrics.axisTitleGap ?? Math.max(4, Math.round(fontSize * 0.75));
    const outerPadding = axisMetrics.outerPadding ?? Math.max(6, Math.round(fontSize * 0.6));
    const yTitleThicknessRaw = Number(options?.yTitleThickness ?? options?.yTitleFontSize);
    const yTitleThickness = Number.isFinite(yTitleThicknessRaw) && yTitleThicknessRaw > 0 ? yTitleThicknessRaw : fontSize;
    const hasYTitle = explicitHasYTitle !== null ? explicitHasYTitle : legacyYTitleWidth > 0;
    const top = Math.max(36, Math.round(fontSize * BASE_BOTTOM_FACTOR));
    const leftTickReserve = maxYLabelWidth + tickLength + tickLabelGap;
    const leftTickLabelReserve = leftTickReserve + yTickFontSize + outerPadding;
    const leftTitleReserve = hasYTitle
      ? leftTickReserve + axisTitleGap + yTitleThickness + outerPadding
      : 0;
    const left = Math.max(56, Math.round(fontSize * 3.2), leftTickLabelReserve, leftTitleReserve);
    const right = 24 + legendWidth;
    const bottomSpacing = tickLength + tickLabelGap + xTickFontSize + axisTitleGap + fontSize + outerPadding;
    const bottom = Math.max(bottomSpacing, Math.max(36, Math.round(fontSize * BASE_BOTTOM_FACTOR)) + fontSize * 0.5);
    console.debug('Debug: chartStyle.computeBaseMargins', {
      fontSize,
      legendWidth,
      maxYLabelWidth,
      legacyYTitleWidth,
      hasYTitle,
      yTitleThickness,
      xTickFontSize,
      yTickFontSize,
      axisMetrics,
      top,
      left,
      right,
      bottom
    }); // Debug: margin base computation
    return chartStyle.stabilizeAxisResizeMargins({top, right, bottom, left}, options);
  };

  const axisResizeMarginLocks = typeof WeakMap !== 'undefined' ? new WeakMap() : null;

  function normalizeMarginLock(margin){
    if(!margin || typeof margin !== 'object'){
      return null;
    }
    return {
      top: Number(margin.top) || 0,
      right: Number(margin.right) || 0,
      bottom: Number(margin.bottom) || 0,
      left: Number(margin.left) || 0
    };
  }

  chartStyle.stabilizeAxisResizeMargins = function stabilizeAxisResizeMargins(margin, options){
    const locked = normalizeMarginLock(margin);
    if(!locked){
      return margin;
    }
    const svgBox = options?.svgBox || options?.container || options?.resizeTarget || null;
    const dataset = svgBox?.dataset || null;
    if(!dataset){
      return locked;
    }
    const axis = dataset.resizerLastAxis === 'x' || dataset.resizerLastAxis === 'y'
      ? dataset.resizerLastAxis
      : 'both';
    const aspectLocked = dataset.resizerAspectLocked === 'true';
    const markedAxis = dataset.resizerAxisViewportLockAxis;
    const lockUntil = Number(dataset.resizerAxisViewportLockUntil);
    const lockActive = !aspectLocked
      && (axis === 'x' || axis === 'y')
      && markedAxis === axis
      && Number.isFinite(lockUntil)
      && Date.now() <= lockUntil;
    const previous = axisResizeMarginLocks ? axisResizeMarginLocks.get(svgBox) : svgBox.__chartStyleAxisResizeMarginLock;
    if(lockActive && previous){
      locked.top = previous.top;
      locked.right = previous.right;
      locked.bottom = previous.bottom;
      locked.left = previous.left;
    }
    if(axisResizeMarginLocks){
      axisResizeMarginLocks.set(svgBox, { ...locked });
    }else{
      svgBox.__chartStyleAxisResizeMarginLock = { ...locked };
    }
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: chartStyle.stabilizeAxisResizeMargins', {
        scope: options?.scopeId || options?.scope || svgBox.id || null,
        axis,
        aspectLocked,
        lockActive,
        previous: previous || null,
        margin: locked
      });
    }
    return locked;
  };

  chartStyle.ensureSquarePlot = function ensureSquarePlot(totalWidth, totalHeight, margin){
    const innerW = Math.max(20, totalWidth - margin.left - margin.right);
    const innerH = Math.max(20, totalHeight - margin.top - margin.bottom);
    const size = Math.min(innerW, innerH);
    const adjusted = {top: margin.top, right: margin.right, bottom: margin.bottom, left: margin.left};
    if(innerW > size){
      adjusted.right += innerW - size;
    }
    if(innerH > size){
      adjusted.bottom += innerH - size;
    }
    console.debug('Debug: chartStyle.ensureSquarePlot', {
      totalWidth,
      totalHeight,
      originalMargin: margin,
      adjustedMargin: adjusted,
      targetSize: size
    }); // Debug: square enforcement summary
    return {margin: adjusted, plotW: size, plotH: size};
  };

  chartStyle.applySvgDefaults = function applySvgDefaults(svg){
    if(svg){
      svg.setAttribute('font-family', FONT_FAMILY);
      svg.setAttribute('color', TEXT_COLOR);
      const fontControls = (global.Shared && global.Shared.fontControls) || {};
      if(fontControls && typeof fontControls.enableForSvg === 'function'){
        try {
          fontControls.enableForSvg(svg,{ scopeId: svg.id || svg.dataset?.fontScope || svg.closest?.('.svgbox')?.id || null });
          console.debug('Debug: chartStyle.applySvgDefaults fontControls attached',{ scope: svg.id || svg.dataset?.fontScope || null }); // Debug: font panel auto-binding
        } catch(fontErr){
          console.error('chartStyle.applySvgDefaults fontControls error', fontErr);
        }
      }
    }
    console.debug('Debug: chartStyle.applySvgDefaults', {hasSvg: !!svg}); // Debug: svg defaults applied
  };

  chartStyle.renderFontSizeLabel = function renderFontSizeLabel(options){
    const opts = options || {};
    const el = opts.element;
    if(!el){
      console.debug('Debug: chartStyle.renderFontSizeLabel skipped', { reason: 'missing element', options: opts }); // Debug: font label skip
      return '';
    }
    const info = opts.fontInfo || {};
    const inputEl = opts.input || opts.control || null;
    const manualUpdate = opts.manual === true;
    const dataset = inputEl && inputEl.dataset ? inputEl.dataset : null;
    let basePt = Number.isFinite(info.basePt) ? info.basePt : Number(opts.basePt);
    if(!Number.isFinite(basePt)){
      basePt = Number.isFinite(info.pt) ? info.pt : Number(opts.pt);
    }
    let displayPt = Number.isFinite(info.displayPt) ? info.displayPt : Number(opts.displayPt);
    if(!Number.isFinite(displayPt)){
      displayPt = Number.isFinite(info.scaledPt) ? info.scaledPt : Number(opts.pt);
    }
    let pxSource = Number.isFinite(info.scaledPx) ? info.scaledPx : Number(opts.scaledPx);
    if(!Number.isFinite(pxSource)){
      if(Number.isFinite(displayPt)){
        pxSource = chartStyle.ptToPx(displayPt);
      }else if(Number.isFinite(basePt)){
        pxSource = chartStyle.ptToPx(basePt);
      }
    }
    if(dataset){
      if(manualUpdate){
        if(Number.isFinite(displayPt)){
          dataset.fontBasePt = String(displayPt);
          dataset.fontDisplayPt = String(displayPt);
          dataset.fontResizeBaselinePending = 'true';
        }else if(Number.isFinite(basePt)){
          dataset.fontBasePt = String(basePt);
          dataset.fontDisplayPt = String(basePt);
          dataset.fontResizeBaselinePending = 'true';
        }
        console.debug('Debug: chartStyle.renderFontSizeLabel manual control sync', {
          inputId: inputEl?.id || null,
          basePt: Number(dataset.fontBasePt),
          displayPt: Number(dataset.fontDisplayPt)
        }); // Debug: manual slider sync
      }else{
        if(Number.isFinite(basePt) && !Number.isFinite(Number(dataset.fontBasePt))){
          dataset.fontBasePt = String(basePt);
          console.debug('Debug: chartStyle.renderFontSizeLabel base cached', {
            inputId: inputEl?.id || null,
            basePt
          }); // Debug: cache base for control
        }
        if(Number.isFinite(displayPt)){
          dataset.fontDisplayPt = String(displayPt);
          if(inputEl){
            const min = Number(inputEl.min);
            const max = Number(inputEl.max);
            const payload = {
              inputId: inputEl.id || null,
              displayPt,
              min,
              max
            };
            console.debug('Debug: chartStyle.renderFontSizeLabel control observed', payload); // Debug: control state observation
          }
        }
      }
    }
    const effectivePt = Number.isFinite(displayPt) ? displayPt : basePt;
    const roundedPt = Number.isFinite(effectivePt) ? Math.round(effectivePt * 10) / 10 : null;
    const roundedPx = Number.isFinite(pxSource) ? Math.round(pxSource) : null;
    let label = '';
    if(roundedPt !== null && roundedPx !== null){
      label = roundedPt + ' pt (' + roundedPx + 'px)';
    } else if(roundedPt !== null){
      label = roundedPt + ' pt';
    } else if(roundedPx !== null){
      label = roundedPx + 'px';
    }
    el.textContent = label;
    console.debug('Debug: chartStyle.renderFontSizeLabel applied', {
      pt: roundedPt,
      px: roundedPx,
      label,
      inputId: inputEl?.id || null,
      manualUpdate
    }); // Debug: font label render
    return label;
  };

  chartStyle.createLegendRenderer = function createLegendRenderer(options){
    const opts = options || {};
    const rawEntries = Array.isArray(opts.entries) ? opts.entries : [];
    const defaultFill = typeof opts.defaultFill === 'string' ? opts.defaultFill : chartStyle.TEXT_COLOR;
    const defaultStroke = typeof opts.defaultStroke === 'string' ? opts.defaultStroke : 'none';
    const textColor = (typeof opts.textColor === 'string' && opts.textColor.trim())
      ? opts.textColor
      : chartStyle.TEXT_COLOR;
    const defaultStrokeWidth = Number.isFinite(opts.strokeWidth) ? Number(opts.strokeWidth) : 0;
    const normalizedEntries = [];
    rawEntries.forEach((entry, index) => {
      if(!entry){ return; }
      const labelRaw = entry.label ?? entry.name ?? entry.title ?? '';
      const label = labelRaw == null ? '' : String(labelRaw);
      const fill = typeof entry.fill === 'string' ? entry.fill : (typeof entry.color === 'string' ? entry.color : defaultFill);
      const stroke = typeof entry.stroke === 'string' ? entry.stroke : (typeof entry.border === 'string' ? entry.border : defaultStroke);
      const strokeWidth = Number.isFinite(entry.strokeWidth) ? Number(entry.strokeWidth) : defaultStrokeWidth;
      const keyRaw = entry.key ?? entry.id ?? label;
      const key = keyRaw == null ? '' : String(keyRaw);
      const editable = entry.editable === true;
      normalizedEntries.push({ label, fill, stroke, strokeWidth, sourceIndex: index, key, editable, raw: entry });
    });
    const fontSize = Math.max(4, Number(opts.fontSize) || 12);
    const rowGap = Number.isFinite(opts.rowGap) ? Number(opts.rowGap) : Math.max(4, Math.round(fontSize * 0.3));
    // Keep legend symbols compact by default while scaling with legend font size.
    const swatchSize = Number.isFinite(opts.swatchSize) ? Number(opts.swatchSize) : Math.max(4, Math.round(fontSize * 0.6));
    const swatchWidth = Number.isFinite(opts.swatchWidth) ? Math.max(1, Number(opts.swatchWidth)) : swatchSize;
    const swatchHeight = Number.isFinite(opts.swatchHeight) ? Math.max(1, Number(opts.swatchHeight)) : swatchSize;
    const swatchGap = Number.isFinite(opts.swatchGap) ? Number(opts.swatchGap) : Math.max(8, Math.round(fontSize * 0.4));
    const minWidth = Number.isFinite(opts.minWidth) ? Number(opts.minWidth) : Math.max(60, Math.round(fontSize * 5.5));
    const fontForMeasure = chartStyle.makeFont(fontSize);
    let maxLabelWidth = 0;
    normalizedEntries.forEach(entry => {
      const width = chartStyle.measureText(entry.label, fontForMeasure);
      entry.labelWidth = Number.isFinite(width) ? width : 0;
      if(Number.isFinite(width) && width > maxLabelWidth){
        maxLabelWidth = width;
      }
    });
    const width = normalizedEntries.length ? Math.max(minWidth, swatchWidth + swatchGap + maxLabelWidth) : 0;
    // Keep row spacing large enough for either text or swatch content to avoid overlap at small fonts.
    const rowContentHeight = Math.max(fontSize, swatchHeight);
    const rowHeight = rowContentHeight + rowGap;
    const baselineOffset = Number.isFinite(opts.baselineOffset) ? Number(opts.baselineOffset) : 0;
    const textCenterOffset = rowContentHeight / 2;
    const swatchOffsetY = (rowContentHeight - swatchHeight) / 2;
    const height = normalizedEntries.length ? baselineOffset + (normalizedEntries.length - 1) * rowHeight + rowContentHeight : 0;
    const debugSummary = {
      entryCount: normalizedEntries.length,
      fontSize,
      rowGap,
      swatchSize,
      swatchWidth,
      swatchHeight,
      swatchGap,
      minWidth,
      width,
      height,
      maxLabelWidth
    };
    console.debug('Debug: chartStyle.createLegendRenderer metrics', debugSummary);
    const createLegendSwatch = (doc, entry, idx, swatchCenterY) => {
      const rawShape = entry?.raw?.shape;
      const shape = typeof rawShape === 'string' ? rawShape : 'square';
      const swatchTop = swatchCenterY - (swatchHeight / 2);
      const centerX = swatchWidth / 2;
      const centerY = swatchCenterY;
      const radius = Math.max(1, Math.min(swatchWidth, swatchHeight) * 0.42);
      let node = null;
      if(shape === 'circle'){
        node = doc.createElementNS(NS, 'circle');
        node.setAttribute('cx', String(centerX));
        node.setAttribute('cy', String(centerY));
        node.setAttribute('r', String(radius));
      }else if(shape === 'triangle'){
        node = doc.createElementNS(NS, 'path');
        const d = `M ${centerX} ${centerY - radius} L ${centerX + radius} ${centerY + radius} L ${centerX - radius} ${centerY + radius} Z`;
        node.setAttribute('d', d);
      }else if(shape === 'diamond'){
        node = doc.createElementNS(NS, 'path');
        const d = `M ${centerX} ${centerY - radius} L ${centerX + radius} ${centerY} L ${centerX} ${centerY + radius} L ${centerX - radius} ${centerY} Z`;
        node.setAttribute('d', d);
      }else if(shape === 'cross'){
        node = doc.createElementNS(NS, 'path');
        const half = radius;
        const bar = Math.max((radius * 2) / 3, 2);
        const hb = bar / 2;
        const top = centerY - half;
        const bottom = centerY + half;
        const left = centerX - half;
        const right = centerX + half;
        const d = [
          `M ${left} ${top + hb}`,
          `L ${left + hb} ${top}`,
          `L ${centerX} ${centerY - hb}`,
          `L ${right - hb} ${top}`,
          `L ${right} ${top + hb}`,
          `L ${centerX + hb} ${centerY}`,
          `L ${right} ${bottom - hb}`,
          `L ${right - hb} ${bottom}`,
          `L ${centerX} ${centerY + hb}`,
          `L ${left + hb} ${bottom}`,
          `L ${left} ${bottom - hb}`,
          `L ${centerX - hb} ${centerY}`,
          'Z'
        ].join(' ');
        node.setAttribute('d', d);
      }else if(shape === 'plus'){
        node = doc.createElementNS(NS, 'path');
        const half = radius;
        const bar = Math.max((radius * 2) / 3, 2);
        const halfBar = bar / 2;
        const d = `M ${centerX - halfBar} ${centerY - half} H ${centerX + halfBar} V ${centerY - halfBar} H ${centerX + half} V ${centerY + halfBar} H ${centerX + halfBar} V ${centerY + half} H ${centerX - halfBar} V ${centerY + halfBar} H ${centerX - half} V ${centerY - halfBar} H ${centerX - halfBar} Z`;
        node.setAttribute('d', d);
      }else if(shape === 'star'){
        node = doc.createElementNS(NS, 'path');
        const outer = Math.max(radius, 1);
        const inner = Math.max(outer * 0.45, 1);
        const points = [];
        for(let i = 0; i < 5; i += 1){
          const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
          points.push({ x: centerX + Math.cos(a) * outer, y: centerY + Math.sin(a) * outer });
          const b = a + Math.PI / 5;
          points.push({ x: centerX + Math.cos(b) * inner, y: centerY + Math.sin(b) * inner });
        }
        const d = points.map((pt, pointIdx) => `${pointIdx === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ') + ' Z';
        node.setAttribute('d', d);
      }else if(shape === 'rect' || shape === 'rectangle'){
        node = doc.createElementNS(NS, 'rect');
        node.setAttribute('x', '0');
        node.setAttribute('y', String(swatchTop));
        node.setAttribute('width', String(swatchWidth));
        node.setAttribute('height', String(swatchHeight));
      }else{
        node = doc.createElementNS(NS, 'rect');
        node.setAttribute('x', '0');
        node.setAttribute('y', String(swatchCenterY - (swatchSize / 2)));
        node.setAttribute('width', String(swatchSize));
        node.setAttribute('height', String(swatchSize));
      }
      if(entry.key){
        node.dataset.legendKey = entry.key;
      }
      node.dataset.legendIndex = String(idx);
      node.setAttribute('fill', entry.fill);
      const effectiveStrokeWidth = entry.strokeWidth > 0 ? entry.strokeWidth : 0;
      if(effectiveStrokeWidth > 0){
        node.setAttribute('stroke', entry.stroke || entry.fill);
        node.setAttribute('stroke-width', effectiveStrokeWidth);
      }else if(entry.stroke){
        node.setAttribute('stroke', entry.stroke);
        node.setAttribute('stroke-width', '0');
      }
      return node;
    };
    const renderer = {
      entries: normalizedEntries,
      width,
      height,
      fontSize,
      rowGap,
      rowHeight,
      rowContentHeight,
      swatchSize,
      swatchWidth,
      swatchHeight,
      swatchGap,
      baselineOffset,
      minWidth,
      maxLabelWidth,
      draw(svg, position){
        if(!svg || typeof svg.appendChild !== 'function'){
          console.warn('chartStyle.createLegendRenderer.draw skipped: invalid svg target');
          return null;
        }
        if(!normalizedEntries.length){
          console.debug('Debug: chartStyle.createLegendRenderer.draw skipped',{ reason: 'no entries' });
          return null;
        }
        const doc = svg.ownerDocument || global.document;
        const group = doc.createElementNS(NS, 'g');
        const posX = Number.isFinite(position?.x) ? Number(position.x) : 0;
        const posY = Number.isFinite(position?.y) ? Number(position.y) : 0;
        group.setAttribute('transform', `translate(${posX},${posY})`);
        normalizedEntries.forEach((entry, idx) => {
          const rowStartY = idx * rowHeight + baselineOffset;
          const textCenterY = rowStartY + textCenterOffset;
          const swatchCenterY = rowStartY + swatchOffsetY + (swatchSize / 2);
          const swatch = createLegendSwatch(doc, entry, idx, swatchCenterY);
          if(entry.editable && typeof opts.onSwatchClick === 'function'){
            swatch.style.cursor = 'pointer';
            swatch.addEventListener('click', (evt) => {
              console.debug('Debug: legend swatch click', {
                label: entry.label,
                key: entry.key,
                index: idx
              });
              opts.onSwatchClick({
                event: evt,
                entry,
                index: idx,
                swatch,
                textNode: null,
                renderer,
                svg
              });
            });
          }
          group.appendChild(swatch);
          const text = doc.createElementNS(NS, 'text');
          text.setAttribute('x', swatchWidth + swatchGap);
          text.setAttribute('y', textCenterY);
          text.setAttribute('font-size', fontSize);
          text.setAttribute('fill', textColor);
          text.setAttribute('dominant-baseline', 'middle');
          text.textContent = entry.label;
          if(entry.editable && typeof opts.onSwatchClick === 'function'){
            text.dataset.legendIndex = String(idx);
            if(entry.key){ text.dataset.legendKey = entry.key; }
          }
          group.appendChild(text);
        });
        svg.appendChild(group);
        console.debug('Debug: chartStyle.createLegendRenderer.draw applied',{ entryCount: normalizedEntries.length, x: posX, y: posY });
        return group;
      }
    };
    return renderer;
  };

  chartStyle.computeLegendLayout = function computeLegendLayout(options){
    const opts = options || {};
    const renderer = chartStyle.createLegendRenderer({
      entries: opts.entries,
      fontSize: opts.fontSize,
      strokeWidth: opts.strokeWidth,
      swatchSize: opts.swatchSize,
      swatchWidth: opts.swatchWidth,
      swatchHeight: opts.swatchHeight,
      swatchGap: opts.swatchGap,
      rowGap: opts.rowGap,
      minWidth: opts.minWidth,
      baselineOffset: opts.baselineOffset,
      textColor: opts.textColor,
      onSwatchClick: opts.onSwatchClick
    });
    const entryCount = renderer.entries.length;
    const fontSize = renderer.fontSize;
    const gapScale = Number.isFinite(opts.gapScale) ? opts.gapScale : LEGEND_LAYOUT_CONSTANTS.gapScale;
    const minGapPx = Number.isFinite(opts.minGapPx) ? opts.minGapPx : LEGEND_LAYOUT_CONSTANTS.minGapPx;
    const legendGapPx = entryCount ? Math.max(minGapPx, Math.round(fontSize * gapScale)) : 0;
    const legendWidthForMargin = entryCount ? renderer.width + legendGapPx : 0;
    const guardPaddingPx = Number.isFinite(opts.guardPaddingPx)
      ? Math.max(0, opts.guardPaddingPx)
      : LEGEND_LAYOUT_CONSTANTS.guardPaddingPx;
    const basePlotWidth = Number.isFinite(opts.basePlotWidth)
      ? Math.max(0, opts.basePlotWidth)
      : LEGEND_LAYOUT_CONSTANTS.basePlotMinWidth;
    const minSvgWidth = entryCount ? basePlotWidth + legendWidthForMargin + guardPaddingPx : basePlotWidth;
    console.debug('Debug: chartStyle.computeLegendLayout',{ entryCount, legendGapPx, legendWidthForMargin, minSvgWidth, basePlotWidth, guardPaddingPx });
    return {
      renderer,
      legendGapPx,
      legendWidthForMargin,
      minSvgWidth,
      basePlotWidth,
      guardPaddingPx
    };
  };

  chartStyle.drawPlotFrame = function drawPlotFrame(options){
    const opts = options || {};
    const svg = opts.svg;
    const margin = opts.margin;
    const plotW = Number(opts.plotW);
    const plotH = Number(opts.plotH);
    const doc = svg && (svg.ownerDocument || global.document);
    const stroke = opts.stroke || "#000";
    const strokeWidth = Number.isFinite(opts.strokeWidth) && opts.strokeWidth > 0 ? Number(opts.strokeWidth) : null;
    let sides = Array.isArray(opts.sides) ? opts.sides.slice() : (opts.sides === "all" ? ["top","right","bottom","left"] : []);
    if(!sides.length){ sides = ["top","right"]; }
    if(!svg || !margin || !Number.isFinite(plotW) || !Number.isFinite(plotH) || plotW <= 0 || plotH <= 0 || !doc){
      console.debug("Debug: chartStyle.drawPlotFrame skipped", { hasSvg: !!svg, hasMargin: !!margin, plotW, plotH, sides }); // Debug: frame skip reasoning
      return [];
    }
    const group = opts.group && typeof opts.group.appendChild === 'function' ? opts.group : svg;
    const coords = {
      top: { x1: margin.left, y1: margin.top, x2: margin.left + plotW, y2: margin.top },
      right: { x1: margin.left + plotW, y1: margin.top, x2: margin.left + plotW, y2: margin.top + plotH },
      bottom: { x1: margin.left, y1: margin.top + plotH, x2: margin.left + plotW, y2: margin.top + plotH },
      left: { x1: margin.left, y1: margin.top, x2: margin.left, y2: margin.top + plotH }
    };
    const drawn = [];
    sides.forEach(side => {
      const pos = coords[side];
      if(!pos) return;
      const line = doc && doc.createElementNS ? doc.createElementNS(NS, 'line') : null;
      if(!line) return;
      line.setAttribute('x1', pos.x1);
      line.setAttribute('y1', pos.y1);
      line.setAttribute('x2', pos.x2);
      line.setAttribute('y2', pos.y2);
      line.setAttribute('stroke', stroke);
      line.setAttribute('stroke-linecap', 'square');
      if(strokeWidth !== null){
        line.setAttribute('stroke-width', strokeWidth);
      }
      group.appendChild(line);
      drawn.push(side);
    });
    console.debug("Debug: chartStyle.drawPlotFrame applied", { sides: drawn, stroke, plotW, plotH, strokeWidth: strokeWidth ?? 'auto' }); // Debug: frame draw summary with stroke scaling
    return drawn;
  };

  const labelLayout = Shared.labelLayout = Shared.labelLayout || {};

  labelLayout.computeConvexHull2d = function computeConvexHull2d(points){
    if(!Array.isArray(points) || points.length === 0){
      return [];
    }
    const cleaned = [];
    for(let i = 0; i < points.length; i += 1){
      const pt = points[i];
      const x = Number(pt?.x);
      const y = Number(pt?.y);
      if(Number.isFinite(x) && Number.isFinite(y)){
        cleaned.push({ x, y });
      }
    }
    if(cleaned.length <= 2){
      return cleaned;
    }
    const sorted = cleaned.slice().sort((a, b) => {
      if(a.x === b.x){
        return a.y - b.y;
      }
      return a.x - b.x;
    });
    const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    const lower = [];
    for(let i = 0; i < sorted.length; i += 1){
      const p = sorted[i];
      while(lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0){
        lower.pop();
      }
      lower.push(p);
    }
    const upper = [];
    for(let i = sorted.length - 1; i >= 0; i -= 1){
      const p = sorted[i];
      while(upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0){
        upper.pop();
      }
      upper.push(p);
    }
    lower.pop();
    upper.pop();
    return lower.concat(upper);
  };

  labelLayout.readFontSizeFromNodes = function readFontSizeFromNodes(nodes){
    if(!nodes || typeof nodes.length !== 'number'){
      return null;
    }
    let minSize = Infinity;
    let found = false;
    for(let i = 0; i < nodes.length; i += 1){
      const node = nodes[i];
      const attr = node && typeof node.getAttribute === 'function' ? node.getAttribute('font-size') : null;
      const size = Number.parseFloat(attr);
      if(Number.isFinite(size) && size > 0){
        found = true;
        if(size < minSize){
          minSize = size;
        }
      }
    }
    if(!found){
      return null;
    }
    return minSize;
  };

  labelLayout.computePointLabelLayout = function computePointLabelLayout(entries, options){
    if(!Array.isArray(entries) || !entries.length){
      return [];
    }
    const plotLeft = Number(options?.plotLeft) || 0;
    const plotRight = Number(options?.plotRight) || 0;
    const plotTop = Number(options?.plotTop) || 0;
    const plotBottom = Number(options?.plotBottom) || 0;
    const labelFontSize = Math.max(6, Number(options?.labelFontSize) || 10);
    const leaderGap = Math.max(2, Number(options?.leaderGap) || 2);
    const angleSteps = Math.max(8, Math.min(36, Number(options?.angleSteps) || 16));
    const maxLeaderScale = Math.max(1, Math.min(5, Number(options?.maxLeaderScale) || 5));
    const pointBounds = Array.isArray(options?.pointBounds) ? options.pointBounds : [];
    const measureText = typeof options?.measureText === 'function' ? options.measureText : null;
    const font = options?.font || null;
    const labelHeight = Math.max(6, labelFontSize);
    const leaderScale = Math.max(0.45, Math.min(1, Number(options?.leaderScale) || 1));
    const minOffset = Math.max(labelFontSize * 0.85, 8);
    const plotHull = Array.isArray(options?.plotHull) ? options.plotHull : null;
    const enforceHull = options?.enforceHull === true;
    const hullPenalty = Number.isFinite(options?.hullPenalty) ? options.hullPenalty : 12;
    let normalizedHull = null;
    if(plotHull && plotHull.length >= 3){
      normalizedHull = [];
      for(let i = 0; i < plotHull.length; i += 1){
        const pt = plotHull[i];
        const x = Number(pt?.x);
        const y = Number(pt?.y);
        if(Number.isFinite(x) && Number.isFinite(y)){
          normalizedHull.push({ x, y });
        }
      }
      if(normalizedHull.length < 3){
        normalizedHull = null;
      }
    }
    const angles = [];
    const tau = Math.PI * 2;
    for(let i = 0; i < angleSteps; i += 1){
      angles.push((i / angleSteps) * tau);
    }
    const estimateWidth = text => {
      const value = text ? String(text) : '';
      if(!value){
        return labelFontSize * 0.5;
      }
      if(measureText && font){
        const measured = measureText(value, font);
        if(Number.isFinite(measured)){
          return measured;
        }
      }
      return Math.max(labelFontSize * 0.6, value.length * labelFontSize * 0.6);
    };
    const overlapArea = (a, b) => {
      const overlapX = Math.max(0, Math.min(a.maxX, b.maxX) - Math.max(a.minX, b.minX));
      const overlapY = Math.max(0, Math.min(a.maxY, b.maxY) - Math.max(a.minY, b.minY));
      return overlapX * overlapY;
    };
    const pointOnSegment = (px, py, ax, ay, bx, by) => {
      const crossVal = (px - ax) * (by - ay) - (py - ay) * (bx - ax);
      if(Math.abs(crossVal) > 1e-6){
        return false;
      }
      const dot = (px - ax) * (bx - ax) + (py - ay) * (by - ay);
      if(dot < -1e-6){
        return false;
      }
      const lenSq = (bx - ax) * (bx - ax) + (by - ay) * (by - ay);
      if(dot - lenSq > 1e-6){
        return false;
      }
      return true;
    };
    const pointInPolygon = (x, y, polygon) => {
      if(!Array.isArray(polygon) || polygon.length < 3){
        return true;
      }
      for(let i = 0, j = polygon.length - 1; i < polygon.length; j = i++){
        const xi = polygon[i].x;
        const yi = polygon[i].y;
        const xj = polygon[j].x;
        const yj = polygon[j].y;
        if(pointOnSegment(x, y, xi, yi, xj, yj)){
          return true;
        }
      }
      let inside = false;
      for(let i = 0, j = polygon.length - 1; i < polygon.length; j = i++){
        const xi = polygon[i].x;
        const yi = polygon[i].y;
        const xj = polygon[j].x;
        const yj = polygon[j].y;
        const intersect = ((yi > y) !== (yj > y))
          && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if(intersect){
          inside = !inside;
        }
      }
      return inside;
    };
    const boxInsideHull = (minX, maxX, minY, maxY) => {
      if(!normalizedHull){
        return true;
      }
      return pointInPolygon(minX, minY, normalizedHull)
        && pointInPolygon(maxX, minY, normalizedHull)
        && pointInPolygon(maxX, maxY, normalizedHull)
        && pointInPolygon(minX, maxY, normalizedHull);
    };
    const tryNudgeBoxInsideHull = (box, cx, cy) => {
      if(!normalizedHull){
        return { shiftX: 0, shiftY: 0, inside: true };
      }
      if(boxInsideHull(box.minX, box.maxX, box.minY, box.maxY)){
        return { shiftX: 0, shiftY: 0, inside: true };
      }
      const centerX = (box.minX + box.maxX) / 2;
      const centerY = (box.minY + box.maxY) / 2;
      const targetX = Number.isFinite(cx) ? cx : centerX;
      const targetY = Number.isFinite(cy) ? cy : centerY;
      const dx = targetX - centerX;
      const dy = targetY - centerY;
      const steps = 8;
      for(let step = 1; step <= steps; step += 1){
        const t = step / steps;
        const shiftX = dx * t;
        const shiftY = dy * t;
        const nextMinX = box.minX + shiftX;
        const nextMaxX = box.maxX + shiftX;
        const nextMinY = box.minY + shiftY;
        const nextMaxY = box.maxY + shiftY;
        if(boxInsideHull(nextMinX, nextMaxX, nextMinY, nextMaxY)){
          return { shiftX, shiftY, inside: true };
        }
      }
      return { shiftX: 0, shiftY: 0, inside: false };
    };
    const placedBoxes = [];
    const placedLeaders = [];
    const placements = [];
    const distancePointToSegment = (px, py, ax, ay, bx, by) => {
      const dx = bx - ax;
      const dy = by - ay;
      if(dx === 0 && dy === 0){
        const rx = px - ax;
        const ry = py - ay;
        return Math.hypot(rx, ry);
      }
      const t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy);
      const clamped = Math.max(0, Math.min(1, t));
      const cx = ax + clamped * dx;
      const cy = ay + clamped * dy;
      return Math.hypot(px - cx, py - cy);
    };
    const segmentsIntersect = (ax, ay, bx, by, cx, cy, dx, dy) => {
      const eps = 1e-6;
      const orient = (px, py, qx, qy, rx, ry) => (qy - py) * (rx - qx) - (qx - px) * (ry - qy);
      const onSegment = (px, py, qx, qy, rx, ry) =>
        Math.min(px, rx) - eps <= qx && qx <= Math.max(px, rx) + eps
        && Math.min(py, ry) - eps <= qy && qy <= Math.max(py, ry) + eps;
      const o1 = orient(ax, ay, bx, by, cx, cy);
      const o2 = orient(ax, ay, bx, by, dx, dy);
      const o3 = orient(cx, cy, dx, dy, ax, ay);
      const o4 = orient(cx, cy, dx, dy, bx, by);
      if(Math.abs(o1) < eps && onSegment(ax, ay, cx, cy, bx, by)) return true;
      if(Math.abs(o2) < eps && onSegment(ax, ay, dx, dy, bx, by)) return true;
      if(Math.abs(o3) < eps && onSegment(cx, cy, ax, ay, dx, dy)) return true;
      if(Math.abs(o4) < eps && onSegment(cx, cy, bx, by, dx, dy)) return true;
      return (o1 > 0 && o2 < 0 || o1 < 0 && o2 > 0)
        && (o3 > 0 && o4 < 0 || o3 < 0 && o4 > 0);
    };
    const scaleSteps = [];
    for(let scale = 1; scale <= maxLeaderScale; scale += 1){
      scaleSteps.push(scale);
    }
    entries.forEach(entry => {
      const cx = Number(entry?.cx) || 0;
      const cy = Number(entry?.cy) || 0;
      const textValue = entry?.text ? String(entry.text) : '';
      if(!textValue){
        return;
      }
      const baseOffset = Math.max(minOffset, (Number(entry?.radius) || 0) * 1.6) * 2 * leaderScale;
      const textWidth = estimateWidth(textValue);
      let best = null;
      angles.forEach(angle => {
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        scaleSteps.forEach(scale => {
          let textX = cx + cos * (baseOffset * scale);
          let textY = cy + sin * (baseOffset * scale);
          const anchor = cos >= 0 ? 'start' : 'end';
          let minX = anchor === 'start' ? textX : textX - textWidth;
          let maxX = anchor === 'start' ? textX + textWidth : textX;
          let minY = textY - labelHeight * 0.5;
          let maxY = textY + labelHeight * 0.5;
          let shiftX = 0;
          if(minX < plotLeft + 2){
            shiftX = (plotLeft + 2) - minX;
          }else if(maxX > plotRight - 2){
            shiftX = (plotRight - 2) - maxX;
          }
          let shiftY = 0;
          if(minY < plotTop + 2){
            shiftY = (plotTop + 2) - minY;
          }else if(maxY > plotBottom - 2){
            shiftY = (plotBottom - 2) - maxY;
          }
          if(shiftX || shiftY){
            textX += shiftX;
            textY += shiftY;
            minX += shiftX;
            maxX += shiftX;
            minY += shiftY;
            maxY += shiftY;
          }
          let insideHull = true;
          if(normalizedHull){
            if(enforceHull){
              const nudge = tryNudgeBoxInsideHull({ minX, maxX, minY, maxY }, cx, cy);
              if(nudge.shiftX || nudge.shiftY){
                textX += nudge.shiftX;
                textY += nudge.shiftY;
                minX += nudge.shiftX;
                maxX += nudge.shiftX;
                minY += nudge.shiftY;
                maxY += nudge.shiftY;
              }
              insideHull = nudge.inside;
            }else{
              insideHull = boxInsideHull(minX, maxX, minY, maxY);
            }
          }
          let score = 0;
          const labelArea = Math.max(1, textWidth * labelHeight);
          placedBoxes.forEach(box => {
            const area = overlapArea({ minX, maxX, minY, maxY }, box);
            if(area > 0){
              score += (area / labelArea) * 14;
            }
          });
          pointBounds.forEach(point => {
            const pr = Math.max(0, Number(point?.r) || 0);
            const px = Number(point?.cx) || 0;
            const py = Number(point?.cy) || 0;
            if(px >= minX - pr && px <= maxX + pr && py >= minY - pr && py <= maxY + pr){
              score += 3;
            }
            const leaderDist = distancePointToSegment(px, py, cx, cy, textX, textY);
            if(leaderDist < pr + 2){
              score += 1 + (pr + 2 - leaderDist) * 0.2;
            }
          });
          const lineX2 = textX + (anchor === 'start' ? -leaderGap : leaderGap);
          let leaderCross = false;
          placedLeaders.forEach(seg => {
            if(segmentsIntersect(seg.x1, seg.y1, seg.x2, seg.y2, cx, cy, lineX2, textY)){
              leaderCross = true;
            }
          });
          if(leaderCross){
            score += 3;
          }
          const overflow = Math.max(0, plotLeft - minX)
            + Math.max(0, maxX - plotRight)
            + Math.max(0, plotTop - minY)
            + Math.max(0, maxY - plotBottom);
          if(overflow > 0){
            score += overflow * 0.2 + 6;
          }
          if(normalizedHull && !insideHull){
            score += hullPenalty;
          }
          if(shiftX || shiftY){
            score += 0.5;
          }
          score += (scale - 1) * 0.2;
          if(best === null || score < best.score){
            best = {
              textX,
              textY,
              anchor,
              lineX2,
              lineY2: textY,
              bbox: { minX, maxX, minY, maxY },
              score
            };
          }
        });
      });
      if(best){
        placements.push({ entry, placement: best });
        placedBoxes.push(best.bbox);
        placedLeaders.push({ x1: entry.cx, y1: entry.cy, x2: best.lineX2, y2: best.lineY2 });
      }
    });
    return placements;
  };

  labelLayout.computePointLabelFontSize = function computePointLabelFontSize(baseFontSize, labelCount, plotWidth, plotHeight){
    const safeBase = Math.max(5, Number(baseFontSize) || 10);
    const count = Math.max(0, Number(labelCount) || 0);
    const width = Math.max(1, Number(plotWidth) || 0);
    const height = Math.max(1, Number(plotHeight) || 0);
    if(count <= 0){
      return safeBase;
    }
    const area = width * height;
    const density = count / Math.max(1, area);
    const axisReference = 520;
    const axisScale = Math.max(0.25, Math.min(2.2, width / axisReference));
    const targetCount = 12;
    const countRatio = (targetCount + 2) / (count + 2);
    const countScale = Math.max(0.25, Math.min(3, countRatio * countRatio));
    const targetDensity = 0.0008;
    const densityRatio = density / targetDensity;
    const densityScale = 1 / Math.sqrt(1 + densityRatio * densityRatio);
    const combinedScale = axisScale * countScale * densityScale;
    const scale = Math.max(0.12, Math.min(2.6, combinedScale));
    return Math.max(4, safeBase * scale);
  };
})(window);
