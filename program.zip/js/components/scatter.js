(function(global){
  'use strict';
  const Shared = global.Shared = global.Shared || {};
  const Components = global.Components = global.Components || {};
  const scatter = Components.scatter = Components.scatter || {};
  const chartStyle = Shared.chartStyle = Shared.chartStyle || {};
  const fontControls = Shared.fontControls = Shared.fontControls || {};
  const exportFontStyles = scopeId => (fontControls && typeof fontControls.exportScopeStyles === 'function')
    ? fontControls.exportScopeStyles(scopeId)
    : null;
  const importFontStyles = (scopeId, styles) => {
    if(fontControls && typeof fontControls.importScopeStyles === 'function'){
      fontControls.importScopeStyles(scopeId, styles, { prune: true });
    }
  };
  const axisControls = Shared.axisControls = Shared.axisControls || {};
  const axisExtras = Shared.axisExtras = Shared.axisExtras || {};
  const additionalLineControls = Shared.additionalLineControls = Shared.additionalLineControls || {};
  const gridControls = Shared.gridControls = Shared.gridControls || {};
  if((typeof additionalLineControls.show !== 'function' || typeof additionalLineControls.registerAdditionalLineElement !== 'function') && typeof require === 'function'){
    try{
      require('../shared/additionalLineControls.js');
    }catch(err){
      console.debug('Debug: scatter component additionalLineControls helper require failed', { message: err?.message || String(err) });
    }
  }
  if((typeof gridControls.show !== 'function' || typeof gridControls.registerGraphElement !== 'function') && typeof require === 'function'){
    try{
      require('../shared/gridControls.js');
    }catch(err){
      console.debug('Debug: scatter component gridControls helper require failed', { message: err?.message || String(err) });
    }
  }
  const notesHelper = Shared.notes = Shared.notes || {};
  if(typeof notesHelper.mountFoldable !== 'function' && typeof require === 'function'){
    try{
      require('../shared/notes.js');
    }catch(err){
      console.debug('Debug: scatter component notes helper require failed', { message: err?.message || String(err) });
    }
  }
  const notesState = { text: '', open: false, control: null };
  const formControls = Shared.formControls = Shared.formControls || {};
  const dataTransformsApi = Shared.dataTransforms = Shared.dataTransforms || {};
  if(typeof dataTransformsApi.applyTransform !== 'function' && typeof require === 'function'){
    try{
      require('../shared/dataTransforms.js');
    }catch(err){
      console.debug('Debug: scatter component dataTransforms helper require failed', { message: err?.message || String(err) });
    }
  }
  const dataViewsApi = Shared.dataViews = Shared.dataViews || {};
  if(typeof dataViewsApi.createManager !== 'function' && typeof require === 'function'){
    try{
      require('../shared/dataViews.js');
    }catch(err){
      console.debug('Debug: scatter component dataViews helper require failed', { message: err?.message || String(err) });
    }
  }
  const plot3d = Shared.plot3d = Shared.plot3d || {};
  if(typeof plot3d.createRotationState !== 'function' && typeof require === 'function'){
    try {
      require('../shared/plot3d.js');
    }catch(err){
      console.debug('Debug: scatter component plot3d helper require failed', { message: err?.message || String(err) });
    }
  }
  if(typeof plot3d.createRotationState !== 'function'){
    plot3d.createRotationState = (defaults) => ({
      x: Number.isFinite(defaults?.x) ? defaults.x : 0,
      y: Number.isFinite(defaults?.y) ? defaults.y : 0,
      z: Number.isFinite(defaults?.z) ? defaults.z : 0,
      quaternion: null
    });
  }
  if(typeof plot3d.rotatePoint !== 'function'){
    plot3d.rotatePoint = (pt) => ({ x: Number(pt?.x) || 0, y: Number(pt?.y) || 0, z: Number(pt?.z) || 0 });
  }
  if(typeof plot3d.attachRotationControls !== 'function'){
    plot3d.attachRotationControls = () => {};
  }
  if(typeof plot3d.renderAxesAndGrid !== 'function'){
    plot3d.renderAxesAndGrid = () => null;
  }
  if(typeof plot3d.createProjector !== 'function'){
    plot3d.createProjector = (options) => {
      const width = Math.max(1, Math.floor(options?.width || 1));
      const height = Math.max(1, Math.floor(options?.height || 1));
      const margin = options?.margin || {};
      const shiftX = Number.isFinite(options?.shiftX) ? options.shiftX : 0;
      const baseX = Number(margin.left || 0) + shiftX;
      const baseY = Number(margin.top || 0);
      return {
        project: () => ({ x: baseX, y: baseY, depth: 0 }),
        bounds: {},
        scale: 1,
        offsets: { x: baseX, y: baseY },
        plotSize: { width, height }
      };
    };
  }
  if(typeof plot3d.applyLegendPointerGuards !== 'function'){
    plot3d.applyLegendPointerGuards = () => {};
  }
  if(typeof plot3d.isLegendPointerTarget !== 'function'){
    plot3d.isLegendPointerTarget = () => false;
  }
  if(typeof plot3d.isInteractivePointerTarget !== 'function'){
    plot3d.isInteractivePointerTarget = target => plot3d.isLegendPointerTarget(target);
  }
  const NS = 'http://www.w3.org/2000/svg';
  const DEFAULT_ROWS = 100;
  const DEFAULT_COLS = 5;
  const SCATTER_SINGLE_FIXED_COLS = 5;
  const SCATTER_GROUPED_BASE_COLS = 2; // label + x
  const SCATTER_TABLE_FORMAT_SINGLE = 'single';
  const SCATTER_TABLE_FORMAT_GROUPED = 'grouped';
  const SCATTER_MIN_REPLICATES = 1;
  const SCATTER_MAX_REPLICATES = 10;
  const SCATTER_DEFAULT_GROUP_COUNT = 2;
  const SCATTER_DEFAULT_GROUPED_REPLICATES = 3;
  const SCATTER_POINT_LABEL_COL = 4;
  const SCATTER_POINT_LABEL_COL_ALT = 0;
  const SCATTER_POINT_LABEL_MARK = '✓';
  const SCATTER_POINT_LABEL_HEADER = 'Label point';

  const SCATTER_DATA_VIEW_MAX = 12;
  const SCATTER_TRANSFORM_SCOPE_DEFAULT = Object.freeze({
    headerRows: 1,
    startCol: 1
  });

  const SCATTER_DENSITY_MODE_DEFAULT = 'auto';
  const SCATTER_DENSITY_PALETTE_DEFAULT = 'viridis';
  const SCATTER_DENSITY_POINT_THRESHOLD = 1500;
  const SCATTER_STATS_WORKER = {
    url: 'js/workers/scatter.worker.js',
    minPoints: 2000,
    timeoutMs: 20000
  };
  const SCATTER_RENDER_WORKER = {
    url: 'js/workers/scatter.worker.js',
    minPoints: 5000,
    timeoutMs: 20000
  };

  const SCATTER_DENSITY_RAMPS = Object.freeze({
    grayscale: Object.freeze(['#f2f2f2', '#d9d9d9', '#bdbdbd', '#969696', '#737373', '#525252', '#2e2e2e', '#000000']),
    viridis: Object.freeze(['#440154','#482777','#3f4a8a','#31688e','#26838f','#1f9d8a','#6cce5a','#b6de2b','#fee825']),
    turbo: Object.freeze(['#30123b','#4145ab','#4675e7','#2fb5f4','#14cdd4','#34d35c','#8fd625','#f9e524','#fca108','#f1605d','#b91372']),
    inferno: Object.freeze(['#000004','#1b0c41','#4a0c6b','#781c6d','#a52c5f','#cf4446','#ef6a32','#fb9b06','#f7d13d','#fcffa4']),
    magma: Object.freeze(['#000004','#1c1044','#4f127b','#812581','#b5367a','#e65164','#fb8761','#febb78','#fcfdbf']),
    plasma: Object.freeze(['#0d0887','#5b02a3','#9a179b','#cb4679','#ed7953','#fb9f3a','#fdca26','#f0f921']),
    cividis: Object.freeze(['#00204c','#11306b','#364f8a','#566f9e','#7a90a5','#a6bda9','#d4e7b0','#f6fbd1']),
    sunset: Object.freeze(['#331832','#6a2042','#a72c50','#d44842','#f26e3d','#fca635','#fde164'])
  });

  const SCATTER_ADAPTIVE_SIZE_MIN = 1;
  const SCATTER_ADAPTIVE_SIZE_MAX = 3;
  const SCATTER_ADAPTIVE_SIZE_THRESHOLD_LOW = 50;
  const SCATTER_ADAPTIVE_SIZE_THRESHOLD_HIGH = 5000;
  const SCATTER_POINT_BATCH_THRESHOLD = 12000;
  const SCATTER_POINT_CANVAS_RESOLUTION_SCALE = 2;
  const SCATTER_POINT_CANVAS_FRAME_POINT_BUDGET = 6000;
  const SCATTER_DENSITY_LARGE_COLOR_STEPS = 32;
  const SCATTER_THRESHOLD_SELECTION_ROW_LIMIT = 5000;
  const SCATTER_THRESHOLD_SELECTION_SELECTED_LIMIT = 1000;
  const SCATTER_SIGNIFICANT_LABELS_AUTO_OFF_POINT_LIMIT = SCATTER_POINT_BATCH_THRESHOLD;

  const SCATTER_SHAPE_OPTIONS = Shared.getShapePickerOptions
    ? Shared.getShapePickerOptions()
    : Object.freeze([
        { value: 'circle', label: 'Circle' },
        { value: 'triangle', label: 'Triangle' },
        { value: 'square', label: 'Square' },
        { value: 'diamond', label: 'Diamond' },
        { value: 'cross', label: 'Cross' },
        { value: 'plus', label: 'Plus' },
        { value: 'star', label: 'Star' }
      ]);
  const SCATTER_SHAPE_DEFAULTS = Object.freeze(SCATTER_SHAPE_OPTIONS.map(opt => opt.value));
  const SCATTER_SHAPE_VALUES = Shared.getShapePickerValues
    ? Shared.getShapePickerValues()
    : new Set(SCATTER_SHAPE_DEFAULTS);

  const SCATTER_3D_DEFAULTS = Object.freeze({
    rotationX: 0.24,
    rotationY: 1.96,
    aspectRatio: 4 / 3
  });

  const SCATTER_ANNOTATION_COMFORTABLE_COUNT = 8;
  const SCATTER_ANNOTATION_MIN_SCALE = 0.35;

  const BROKEN_AXIS_GAP_SIZE_PX = 20;
  const BROKEN_AXIS_BREAK_WIDTH = 8;
  const BROKEN_AXIS_BREAK_HEIGHT = 6;
  const BROKEN_AXIS_DEFAULT_SEGMENT = { start: 0, end: 1 };

  const palette = Shared.palette = Shared.palette || {};
  if(typeof palette.ensureDefaultScatterColors !== 'function' && typeof require === 'function'){
    try {
      require('../shared/palette.js');
    } catch(err) {
      // ignore palette preload failures
    }
  }
  const DEFAULT_SCATTER_COLORS = typeof palette.ensureDefaultScatterColors === 'function'
    ? palette.ensureDefaultScatterColors()
    : (Array.isArray(palette.DEFAULT_SCATTER_COLORS) && palette.DEFAULT_SCATTER_COLORS.length
      ? palette.DEFAULT_SCATTER_COLORS
      : global.DEFAULT_SCATTER_COLORS);
  if(Array.isArray(DEFAULT_SCATTER_COLORS) && DEFAULT_SCATTER_COLORS.length){
    palette.DEFAULT_SCATTER_COLORS = DEFAULT_SCATTER_COLORS;
    if(typeof global.DEFAULT_SCATTER_COLORS === 'undefined'){
      global.DEFAULT_SCATTER_COLORS = DEFAULT_SCATTER_COLORS;
    }
  }

  const SIGNIFICANT_COLOR = (typeof global.SIGNIFICANT_COLOR !== 'undefined' && global.SIGNIFICANT_COLOR) 
    ? global.SIGNIFICANT_COLOR
    : (DEFAULT_SCATTER_COLORS[0] || '#e41a1c');
  if(typeof global.SIGNIFICANT_COLOR === 'undefined') global.SIGNIFICANT_COLOR = SIGNIFICANT_COLOR;

  const SIGNIFICANT_NEGATIVE_COLOR = (typeof global.SIGNIFICANT_NEGATIVE_COLOR !== 'undefined' && global.SIGNIFICANT_NEGATIVE_COLOR)
    ? global.SIGNIFICANT_NEGATIVE_COLOR
    : (DEFAULT_SCATTER_COLORS[1] || '#0000ff');
  if(typeof global.SIGNIFICANT_NEGATIVE_COLOR === 'undefined') global.SIGNIFICANT_NEGATIVE_COLOR = SIGNIFICANT_NEGATIVE_COLOR;

  const DEFAULT_NON_SIG_COLOR = (typeof global.DEFAULT_NON_SIG_COLOR !== 'undefined' && global.DEFAULT_NON_SIG_COLOR)
    ? global.DEFAULT_NON_SIG_COLOR
    : (DEFAULT_SCATTER_COLORS[DEFAULT_SCATTER_COLORS.length - 1] || '#999999');
  if(typeof global.DEFAULT_NON_SIG_COLOR === 'undefined') global.DEFAULT_NON_SIG_COLOR = DEFAULT_NON_SIG_COLOR;

  const GRAPH_TYPE_DEFAULTS = Object.freeze({
    scatter: Object.freeze({ title: 'Scatter plot' }),
    volcano: Object.freeze({ title: 'Volcano plot' }),
    ma: Object.freeze({ title: 'MA plot' })
  });

  const MAX_SIGNIFICANT_ANNOTATIONS = Number.isFinite(global.MAX_SIGNIFICANT_ANNOTATIONS)
    ? global.MAX_SIGNIFICANT_ANNOTATIONS
    : 25;
  if(typeof global.MAX_SIGNIFICANT_ANNOTATIONS === 'undefined') global.MAX_SIGNIFICANT_ANNOTATIONS = MAX_SIGNIFICANT_ANNOTATIONS;

  const scatterState = {
    viewMode: '2d',
    requestedViewMode: null,
    rotation: plot3d.createRotationState({
      x: SCATTER_3D_DEFAULTS.rotationX,
      y: SCATTER_3D_DEFAULTS.rotationY
    }),
    rotationPending: false,
    rotationPendingLogged: false,
    axesVarianceScaled: false,
    equalAxes: false,
    equalScaleAxes: false,
    supports3d: false,
    supportsBubble: false,
    dotSizeOverrideEnabled: false,
    dotSizeOverrideRaw: null,
    logPlusOneX: false,
    logPlusOneY: false,
    statsContext: null,
    statsContextSignature: null,
    statsContextVersion: 0,
    statsLastRunVersion: 0,
    statsComputationPending: false,
    statsCacheBySignature: new Map(),
    statsRestorePending: null,
    skipNextDraw: false,
    skipNextDrawReason: null,
    drawInProgress: false,
    pendingDrawOpts: null,
    lastDrawAt: 0,
    drawCooldownTimer: null,
    lastDrawMeta: null,
    pendingDrawReasons: null,
    activeDrawReasons: null,
    useDelegatedPointEvents: true,
    dataDirty: true,
    cachedCollect: null,
    cachedGeometry: null,
    significanceRefreshSignature: null,
    significantLabelsUserModified: false,
    axisLabelModes: { x: 'auto', y: 'auto', z: 'auto' }
  };
  let scatterRoot = null;
  function resolveScatterRoot(tabLike){
    const activeTabId = tabLike
      || Shared.hot?.resolveActiveTabId?.()
      || global.Main?.tabs?.getActiveTab?.()?.id
      || null;
    return Shared.workspaceTabs?.getMountedRoot?.(activeTabId, 'scatter')
      || scatterRoot
      || global.document?.getElementById?.('scatterPage')
      || global.document
      || null;
  }
  function queryScatterRoot(selector, tabLike){
    const root = resolveScatterRoot(tabLike);
    if(!root || !selector){
      return null;
    }
    return root.querySelector?.(selector) || null;
  }
  function getScatterNodeById(id, tabLike){
    if(!id){
      return null;
    }
    const root = resolveScatterRoot(tabLike);
    if(root?.getElementById){
      const byId = root.getElementById(id);
      if(byId && byId.isConnected){
        return byId;
      }
    }
    const scoped = root?.querySelector?.(`#${id}`) || null;
    if(scoped && scoped.isConnected){
      return scoped;
    }
    const docNode = global.document?.getElementById?.(id) || null;
    if(docNode && docNode.isConnected){
      return docNode;
    }
    return scoped || docNode || null;
  }
  let scatterDrawToken = 0;
  function normalizeScatterAxisLabelMode(value){
    return String(value || '').toLowerCase() === 'manual' ? 'manual' : 'auto';
  }
  function normalizeScatterAxisLabelModes(value, fallback){
    const base = (fallback && typeof fallback === 'object') ? fallback : scatterState.axisLabelModes;
    const raw = (value && typeof value === 'object') ? value : {};
    return {
      x: normalizeScatterAxisLabelMode(raw.x ?? base?.x),
      y: normalizeScatterAxisLabelMode(raw.y ?? base?.y),
      z: normalizeScatterAxisLabelMode(raw.z ?? base?.z)
    };
  }
  let scatterColorSchemeId = 'scientific';
  let scatterTextColor = chartStyle.TEXT_COLOR || '#000000';
  let scatterBackgroundColor = '#ffffff';

  function normalizeScatterThemeColor(value, fallback){
    return (typeof value === 'string' && value.trim()) ? value.trim() : fallback;
  }

  function applyScatterThemeConfig(config){
    const cfg = config && typeof config === 'object' ? config : {};
    const schemeId = typeof cfg.colorScheme === 'string' && cfg.colorScheme.trim()
      ? cfg.colorScheme.trim().toLowerCase()
      : scatterColorSchemeId;
    const isDark = schemeId === 'dark';
    scatterColorSchemeId = schemeId || 'scientific';
    scatterTextColor = normalizeScatterThemeColor(
      cfg.textColor,
      isDark ? '#f2f2f2' : (chartStyle.TEXT_COLOR || '#000000')
    );
    scatterBackgroundColor = normalizeScatterThemeColor(
      cfg.backgroundColor,
      isDark ? '#000000' : '#ffffff'
    );
  }

  function scheduleScatterViewRefresh(reason, extraOptions){
    if(typeof scheduleDrawScatter !== 'function'){
      return;
    }
    const options = Object.assign({}, extraOptions || {}, {
      viewOnly: true,
      reason: reason || (extraOptions && extraOptions.reason) || 'scatter-view-refresh'
    });
    scheduleDrawScatter(options);
  }

  function scheduleScatterPublicationStyleStabilization(reason){
    const schedule = global.requestAnimationFrame || global.setTimeout;
    if(typeof schedule !== 'function'){
      scheduleScatterViewRefresh(reason || 'publication-style-stabilize');
      return;
    }
    const queueSecondPass = () => {
      scheduleScatterViewRefresh(reason || 'publication-style-stabilize', {
        force: true
      });
    };
    schedule(() => {
      schedule(queueSecondPass);
    });
  }

  let scatterFontEventBound = false;
  function isScatterFontStyleEvent(detail){
    const scopeId = detail?.scopeId || null;
    const storeKey = typeof detail?.storeKey === 'string' ? detail.storeKey : '';
    return scopeId === 'scatter' || storeKey.startsWith('scatter::');
  }

  function ensureScatterFontEventListener(){
    if(scatterFontEventBound || !global.document || typeof global.document.addEventListener !== 'function'){
      return;
    }
    global.document.addEventListener('fontControls:styleChanged', event => {
      const detail = event?.detail || {};
      if(!isScatterFontStyleEvent(detail)){
        return;
      }
      scheduleScatterViewRefresh('font-style-change');
    });
    scatterFontEventBound = true;
    console.debug('Debug: scatter font style listener attached');
  }

  function isScatterHeaderScheduleSource(source){
    if(typeof source !== 'string'){
      return false;
    }
    return source.startsWith('scatter-x-axis-') || source.startsWith('scatter-y-axis-');
  }

  function appendScatter3dBackground(svg, width, height){
    if(!svg){
      return;
    }
    const staleBackgrounds = svg.querySelectorAll('[data-color-scheme-background="1"]');
    staleBackgrounds.forEach(node => {
      try { node.remove(); } catch (err) {}
    });
    const isDark = String(scatterColorSchemeId || '').toLowerCase() === 'dark';
    if(isDark){
      svg.setAttribute('data-color-scheme-bg-color', normalizeScatterThemeColor(scatterBackgroundColor, '#000000'));
    }else{
      svg.removeAttribute('data-color-scheme-bg-color');
    }
  }

  function getActiveScatterPalette(){
    return Array.isArray(DEFAULT_SCATTER_COLORS) && DEFAULT_SCATTER_COLORS.length
      ? DEFAULT_SCATTER_COLORS
      : ['#0000ff', '#ff0000', '#00aa00', '#666666'];
  }

  function getScatterPrimaryFillColor(){
    const palette = getActiveScatterPalette();
    return String((palette[0] || '#0000ff')).toLowerCase();
  }

  function getScatterSignificanceColors(){
    const palette = getActiveScatterPalette();
    const schemeId = String(scatterColorSchemeId || '').toLowerCase();
    if(schemeId === 'grayscale'){
      return {
        positive: palette[0] || '#000000',
        negative: palette[1] || '#555555',
        neutral: palette[4] || '#999999'
      };
    }
    if(schemeId === 'colorblind'){
      return {
        positive: palette[1] || '#d55e00',
        negative: palette[0] || '#0072b2',
        neutral: palette[7] || '#999999'
      };
    }
    return {
      positive: palette[1] || '#ff0000',
      negative: palette[0] || '#0000ff',
      neutral: palette[palette.length - 1] || '#666666'
    };
  }

  function resetScatterRotation(reason){
    if(typeof plot3d.createRotationState !== 'function'){
      scatterState.rotation.x = SCATTER_3D_DEFAULTS.rotationX;
      scatterState.rotation.y = SCATTER_3D_DEFAULTS.rotationY;
      scatterState.rotation.z = 0;
      scatterState.rotation.quaternion = null;
      scatterDebug('Debug: scatter rotation reset (fallback)', { reason, rotation: { x: scatterState.rotation.x, y: scatterState.rotation.y, z: scatterState.rotation.z } });
      return;
    }
    const defaults = plot3d.createRotationState({
      x: SCATTER_3D_DEFAULTS.rotationX,
      y: SCATTER_3D_DEFAULTS.rotationY
    });
    scatterState.rotation.x = defaults.x;
    scatterState.rotation.y = defaults.y;
    scatterState.rotation.z = defaults.z || 0;
    scatterState.rotation.quaternion = defaults.quaternion
      ? { w: defaults.quaternion.w, x: defaults.quaternion.x, y: defaults.quaternion.y, z: defaults.quaternion.z }
      : null;
    if(typeof plot3d.normalizeRotation === 'function'){
      plot3d.normalizeRotation(scatterState.rotation);
    }
    scatterDebug('Debug: scatter rotation reset', { reason, rotation: { x: scatterState.rotation.x, y: scatterState.rotation.y, z: scatterState.rotation.z } });
  }
  let emptyPayloadTemplate = null;
  let scatterLabelColors = {};
  let scatterLabelShapes = {};
  const scatterLabelCache = {
    colorsSet: null,
    shapesSet: null,
    colorsValid: false,
    shapesValid: false
  };
  let scatterLabelStyles = {};
  const SCATTER_OVERLAY_LINKABLE_KEYS = Object.freeze(new Set(['confidence', 'prediction']));
  const SCATTER_OVERLAY_STYLE_DEFAULTS = Object.freeze({
    trend: Object.freeze({ color: '#d00', thickness: 1.5, transparency: 0, pattern: 'solid', linkColorToTrend: false }),
    confidence: Object.freeze({ color: '#d62728', thickness: 0, transparency: 85, pattern: 'solid', linkColorToTrend: true }),
    prediction: Object.freeze({ color: '#d62728', thickness: 0, transparency: 92, pattern: 'solid', linkColorToTrend: true })
  });
  function cloneScatterOverlayStyleDefaults(){
    return {
      trend: { ...SCATTER_OVERLAY_STYLE_DEFAULTS.trend },
      confidence: { ...SCATTER_OVERLAY_STYLE_DEFAULTS.confidence },
      prediction: { ...SCATTER_OVERLAY_STYLE_DEFAULTS.prediction }
    };
  }
  function sanitizeScatterOverlayKey(key){
    const normalized = String(key || '').trim().toLowerCase();
    if(normalized === 'trend' || normalized === 'confidence' || normalized === 'prediction'){
      return normalized;
    }
    return null;
  }
  function sanitizeScatterOverlayStyleEntry(entry, key){
    const safeKey = sanitizeScatterOverlayKey(key);
    if(!safeKey){
      return null;
    }
    const fallback = SCATTER_OVERLAY_STYLE_DEFAULTS[safeKey] || SCATTER_OVERLAY_STYLE_DEFAULTS.trend;
    const next = entry && typeof entry === 'object' ? entry : {};
    const color = typeof next.color === 'string' && next.color.trim()
      ? next.color.trim()
      : fallback.color;
    const thicknessRaw = Number(next.thickness);
    const thickness = Number.isFinite(thicknessRaw)
      ? Math.max(0, thicknessRaw)
      : fallback.thickness;
    const transparencyRaw = Number(next.transparency);
    const transparency = Number.isFinite(transparencyRaw)
      ? Math.min(100, Math.max(0, transparencyRaw))
      : fallback.transparency;
    const patternRaw = String(next.pattern || next.linePattern || fallback.pattern || 'solid').toLowerCase();
    const pattern = (patternRaw === 'dashed' || patternRaw === 'dotted' || patternRaw === 'solid' || patternRaw === 'continuous')
      ? (patternRaw === 'continuous' ? 'solid' : patternRaw)
      : 'solid';
    const linkColorToTrend = SCATTER_OVERLAY_LINKABLE_KEYS.has(safeKey)
      ? (() => {
          if(Object.prototype.hasOwnProperty.call(next, 'linkColorToTrend')){
            return !!next.linkColorToTrend;
          }
          const hasExplicitColor = Object.prototype.hasOwnProperty.call(next, 'color')
            && typeof next.color === 'string'
            && next.color.trim() !== '';
          if(hasExplicitColor){
            const explicitColor = next.color.trim().toLowerCase();
            const fallbackColor = String(fallback.color || '').trim().toLowerCase();
            if(explicitColor && fallbackColor && explicitColor !== fallbackColor){
              return false;
            }
          }
          return !!fallback.linkColorToTrend;
        })()
      : false;
    return { color, thickness, transparency, pattern, linkColorToTrend };
  }
  function scatterOverlayPatternToDasharray(pattern, width){
    const normalized = String(pattern || 'solid').toLowerCase();
    const thickness = Number.isFinite(Number(width)) ? Math.max(0.5, Number(width)) : 1;
    if(normalized === 'dashed'){
      return `${Math.max(2, Math.round(thickness * 4))} ${Math.max(2, Math.round(thickness * 2.4))}`;
    }
    if(normalized === 'dotted'){
      return `${Math.max(1, Math.round(thickness))} ${Math.max(2, Math.round(thickness * 2.2))}`;
    }
    return '';
  }
  function sanitizeScatterOverlayStylesMap(value){
    const defaults = cloneScatterOverlayStyleDefaults();
    if(!value || typeof value !== 'object'){
      return defaults;
    }
    Object.keys(defaults).forEach(key => {
      defaults[key] = sanitizeScatterOverlayStyleEntry(value[key], key) || defaults[key];
    });
    return defaults;
  }
  let scatterOverlayStyles = cloneScatterOverlayStyleDefaults();
  let scatterOverlayToolbarScope = 'global';
  function getScatterOverlayScopeKeys(scopeKey){
    const normalized = normalizeScatterOverlayToolbarScope(scopeKey);
    if(normalized === 'global'){
      return ['trend', 'confidence', 'prediction'];
    }
    const safeKey = sanitizeScatterOverlayKey(normalized);
    return safeKey ? [safeKey] : ['trend'];
  }
  function getScatterOverlayPreviewStyle(scopeKey){
    const keys = getScatterOverlayScopeKeys(scopeKey);
    const firstKey = keys.length ? keys[0] : 'trend';
    return getScatterOverlayStyle(firstKey);
  }
  const scatterRowSelectionsByTab = new Map();
  const scatterThresholdSelectionsByTab = new Map();
  let scatterSelectionSyncInProgress = false;
  let scatterThresholdSelectionPending = false;
  let scatterSelectionEventSuppressUntil = 0;

  function markScatterThresholdSelectionPending(reason){
    scatterThresholdSelectionPending = true;
    scatterDebug('Debug: scatter threshold selection pending', { reason: reason || 'unspecified' });
  }

  function suppressScatterSelectionEvents(reason){
    const now = (global.performance && typeof global.performance.now === 'function')
      ? global.performance.now()
      : Date.now();
    scatterSelectionEventSuppressUntil = now + 50;
    scatterDebug('Debug: scatter selection events suppressed', {
      reason: reason || 'sync',
      until: scatterSelectionEventSuppressUntil
    });
  }

  function clampScatterAlpha(value){
    const numeric = Number(value);
    return Number.isFinite(numeric) ? Math.min(1, Math.max(0, numeric)) : null;
  }
  function clampScatterSize(value){
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric >= 0 ? numeric : null;
  }
  function clampScatterBorderWidth(value){
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric >= 0 ? numeric : null;
  }
  function getScatterOverlayStoredStyle(key){
    const safeKey = sanitizeScatterOverlayKey(key);
    if(!safeKey){
      return null;
    }
    return sanitizeScatterOverlayStyleEntry(scatterOverlayStyles?.[safeKey], safeKey)
      || sanitizeScatterOverlayStyleEntry(SCATTER_OVERLAY_STYLE_DEFAULTS[safeKey], safeKey);
  }
  function getScatterOverlayStyle(key){
    const safeKey = sanitizeScatterOverlayKey(key);
    if(!safeKey){
      return null;
    }
    const style = getScatterOverlayStoredStyle(safeKey);
    if(!style){
      return null;
    }
    if(SCATTER_OVERLAY_LINKABLE_KEYS.has(safeKey) && style.linkColorToTrend){
      const trendStyle = getScatterOverlayStoredStyle('trend');
      return { ...style, color: trendStyle?.color || style.color };
    }
    return style;
  }
  function updateScatterOverlayStyle(key, patch){
    const safeKey = sanitizeScatterOverlayKey(key);
    if(!safeKey){
      return;
    }
    const nextPatch = (patch && typeof patch === 'object')
      ? { ...patch }
      : {};
    if(SCATTER_OVERLAY_LINKABLE_KEYS.has(safeKey) && Object.prototype.hasOwnProperty.call(nextPatch, 'color')){
      nextPatch.linkColorToTrend = false;
    }
    const previous = getScatterOverlayStoredStyle(safeKey) || sanitizeScatterOverlayStyleEntry(null, safeKey);
    const merged = sanitizeScatterOverlayStyleEntry(Object.assign({}, previous || {}, nextPatch), safeKey);
    if(!merged){
      return;
    }
    scatterOverlayStyles = scatterOverlayStyles && typeof scatterOverlayStyles === 'object'
      ? scatterOverlayStyles
      : cloneScatterOverlayStyleDefaults();
    scatterOverlayStyles[safeKey] = merged;
  }
  function normalizeScatterOverlayToolbarScope(value){
    const normalized = String(value == null ? '' : value).trim().toLowerCase();
    if(normalized === 'global'){
      return 'global';
    }
    return sanitizeScatterOverlayKey(normalized) || 'global';
  }
  function getScatterOverlayToolbarLabels(scopeKey){
    const safeScope = normalizeScatterOverlayToolbarScope(scopeKey);
    if(safeScope === 'global'){
      return {
        colorLabel: 'Color',
        thicknessLabel: 'Thickness',
        patternLabel: 'Line pattern',
        transparencyLabel: 'Transparency'
      };
    }
    if(safeScope === 'trend'){
      return {
        colorLabel: 'Line',
        thicknessLabel: 'Line width',
        patternLabel: 'Line pattern',
        transparencyLabel: 'Line transparency'
      };
    }
    return {
      colorLabel: 'Fill',
      thicknessLabel: 'Border thickness',
      patternLabel: 'Line pattern',
      transparencyLabel: 'Fill transparency'
    };
  }
  function getScatterOverlaySummary(scopeKey){
    const safeScope = normalizeScatterOverlayToolbarScope(scopeKey);
    if(safeScope === 'global'){
      return 'Global';
    }
    if(safeScope === 'confidence'){
      return 'Confidence interval';
    }
    if(safeScope === 'prediction'){
      return 'Prediction interval';
    }
    return 'Trend line';
  }
  function resolveScatterToolbarHost(doc){
    if(!doc){ return null; }
    const anchor = doc.getElementById('scatterFontHost');
    if(anchor && anchor.nextElementSibling && anchor.nextElementSibling.classList && anchor.nextElementSibling.classList.contains('font-toolbar-host')){
      return anchor.nextElementSibling;
    }
    return doc.querySelector('.font-toolbar-host[data-font-toolbar-scope="scatter"]') || null;
  }
  function resetScatterDualHostLayout(host){
    if(!host){ return; }
    host.classList.remove('font-toolbar-host--scatter-dual');
    host.style.removeProperty('grid-auto-flow');
    host.style.removeProperty('grid-auto-columns');
    host.style.removeProperty('column-gap');
    host.style.removeProperty('align-items');
  }
  function clearScatterSymbolPanel(host){
    syncScatterSymbolToolbarDotToggles = null;
    if(!host || !host.querySelectorAll){ return; }
    host.querySelectorAll('.workspace-toolbar__panel--symbol').forEach(node => node.remove());
    host.querySelectorAll('.scatter-point-controls.workspace-toolbar__form--single').forEach(node => {
      const panel = node.closest ? node.closest('.workspace-toolbar__panel') : null;
      if(panel && panel.parentNode){
        panel.parentNode.removeChild(panel);
      }else if(node.parentNode){
        node.parentNode.removeChild(node);
      }
    });
  }
  function mountScatterSymbolToolbarGroupedControls(toolbarState){
    const doc = global.document;
    const wrap = toolbarState?.wrap;
    if(!doc || !wrap){
      syncScatterSymbolToolbarDotToggles = null;
      return;
    }
    const showErrorBarsInput = doc.getElementById('scatterShowErrorBars');
    const showGroupedReplicatesInput = doc.getElementById('scatterShowGroupedReplicates');
    const showGroupedReplicatesRow = doc.getElementById('scatterShowGroupedReplicatesRow');
    if(!showErrorBarsInput && !showGroupedReplicatesInput){
      syncScatterSymbolToolbarDotToggles = null;
      return;
    }
    wrap.querySelectorAll('[data-scatter-symbol-grouped-controls="1"]').forEach(node => node.remove());
    const field = doc.createElement('div');
    field.className = 'additional-line-controls-panel__field additional-line-controls-panel__field--scatter-grouped-controls';
    field.dataset.scatterSymbolGroupedControls = '1';
    const title = doc.createElement('span');
    title.className = 'additional-line-controls-panel__field-label';
    title.textContent = 'Grouped mode';
    field.appendChild(title);
    const modeSelect = doc.createElement('select');
    modeSelect.className = 'workspace-toolbar__select additional-line-controls-panel__input additional-line-controls-panel__input--select scatter-grouped-mode-select';
    modeSelect.setAttribute('data-undo-ignore', '1');
    const optionIndividual = doc.createElement('option');
    optionIndividual.value = 'individual';
    optionIndividual.textContent = 'Show individual values';
    const optionErrorBars = doc.createElement('option');
    optionErrorBars.value = 'errorbars';
    optionErrorBars.textContent = 'Show mean + error bars';
    modeSelect.appendChild(optionIndividual);
    modeSelect.appendChild(optionErrorBars);
    let isApplying = false;
    const applySelection = nextValue => {
      if(isApplying){
        return;
      }
      const desired = String(nextValue || '').toLowerCase() === 'errorbars' ? 'errorbars' : 'individual';
      isApplying = true;
      try{
        if(desired === 'individual'){
          if(showErrorBarsInput && showErrorBarsInput.checked){
            showErrorBarsInput.checked = false;
            showErrorBarsInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
          if(showGroupedReplicatesInput && !showGroupedReplicatesInput.checked){
            showGroupedReplicatesInput.checked = true;
            showGroupedReplicatesInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }else{
          if(showGroupedReplicatesInput && showGroupedReplicatesInput.checked){
            showGroupedReplicatesInput.checked = false;
            showGroupedReplicatesInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
          if(showErrorBarsInput && !showErrorBarsInput.checked){
            showErrorBarsInput.checked = true;
            showErrorBarsInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }
      }finally{
        isApplying = false;
      }
    };
    modeSelect.addEventListener('change', () => {
      applySelection(modeSelect.value);
    });
    field.appendChild(modeSelect);
    wrap.appendChild(field);
    const sync = () => {
      const groupedModeActive = scatterCurrentGraphType === 'scatter'
        && normalizeScatterTableFormat(scatterTableFormat) === SCATTER_TABLE_FORMAT_GROUPED;
      const individualVisible = groupedModeActive && !!showGroupedReplicatesInput && (!showGroupedReplicatesRow || showGroupedReplicatesRow.style.display !== 'none');
      const errorBarsVisible = groupedModeActive && !!showErrorBarsInput;
      const individualEnabled = individualVisible && !showGroupedReplicatesInput?.disabled;
      const errorBarsEnabled = errorBarsVisible && !showErrorBarsInput?.disabled;
      optionIndividual.hidden = !individualVisible;
      optionErrorBars.hidden = !errorBarsVisible;
      optionIndividual.disabled = !individualEnabled;
      optionErrorBars.disabled = !errorBarsEnabled;
      const hasVisible = individualVisible || errorBarsVisible;
      modeSelect.disabled = !hasVisible || (!individualEnabled && !errorBarsEnabled);
      if(!scatterGroupedModeDefaultApplied && individualEnabled){
        applySelection('individual');
        scatterGroupedModeDefaultApplied = true;
      }
      const selectedValue = showGroupedReplicatesInput?.checked
        ? 'individual'
        : (showErrorBarsInput?.checked ? 'errorbars' : (individualVisible ? 'individual' : 'errorbars'));
      if(modeSelect.value !== selectedValue){
        modeSelect.value = selectedValue;
      }
      field.hidden = !hasVisible;
      field.setAttribute('aria-hidden', hasVisible ? 'false' : 'true');
    };
    syncScatterSymbolToolbarDotToggles = sync;
    sync();
  }
  function isScatterTrendLineEnabled(){
    const toggle = getScatterNodeById('scatterShowLine');
    return !!(toggle && toggle.checked);
  }
  function getScatterLabelStyle(label){
    if(!label){ return null; }
    const style = scatterLabelStyles[label];
    return style && typeof style === 'object' ? style : null;
  }

  function cloneSimple(value){
    if(!value) return null;
    try{
      return JSON.parse(JSON.stringify(value));
    }catch(err){
      console.error('scatter cloneSimple error', err);
      return null;
    }
  }

  function cloneScatterPoint(point){
    if(!point || typeof point !== 'object'){
      return point;
    }
    const clone = { ...point };
    if(Array.isArray(point.replicates)){
      clone.replicates = point.replicates.slice();
    }
    if(Array.isArray(point.xReplicates)){
      clone.xReplicates = point.xReplicates.slice();
    }
    return clone;
  }

  function cloneScatterPoints(points){
    if(!Array.isArray(points) || !points.length){
      return [];
    }
    return points.map(point => cloneScatterPoint(point));
  }

  function buildScatterRowSetSignature(rowSet){
    if(!rowSet || typeof rowSet.size !== 'number' || rowSet.size <= 0){
      return '0:0:0:0';
    }
    let hash = 2166136261;
    let min = Number.POSITIVE_INFINITY;
    let max = Number.NEGATIVE_INFINITY;
    rowSet.forEach(value => {
      const n = Number(value);
      if(!Number.isFinite(n)){
        return;
      }
      if(n < min){
        min = n;
      }
      if(n > max){
        max = n;
      }
      hash ^= (n | 0);
      hash = Math.imul(hash, 16777619);
      hash >>>= 0;
    });
    if(!Number.isFinite(min) || !Number.isFinite(max)){
      return `0:${rowSet.size}:0:0`;
    }
    return `${hash}:${rowSet.size}:${min}:${max}`;
  }

  function ensureEmptyPayloadTemplate(){
    if(emptyPayloadTemplate){
      return;
    }
    emptyPayloadTemplate = { type: 'scatter', config: {} };
  }

  function getScatterSessionRecord(tabLike, options = {}){
    const helper = Shared.workspaceTabs;
    if(options.create === false){
      return helper?.getSessionRecord?.(tabLike, 'scatter') || null;
    }
    return helper?.ensureSessionRecord?.(tabLike, 'scatter') || helper?.getSessionRecord?.(tabLike, 'scatter') || null;
  }

  function buildScatterSessionMeta(options = {}){
    if(Shared.workspaceTabs?.buildSessionMeta){
      return Shared.workspaceTabs.buildSessionMeta('scatter', options || {});
    }
    const activeTabId = Shared.hot?.resolveActiveTabId?.() || null;
    return {
      tabId: options?.tabId || activeTabId || null,
      sessionGeneration: Number(options?.sessionGeneration) || 0,
      componentKey: 'scatter'
    };
  }

  function isCurrentScatterSessionMeta(meta){
    if(Shared.workspaceTabs?.isSessionMetaCurrent){
      return Shared.workspaceTabs.isSessionMetaCurrent('scatter', meta);
    }
    return true;
  }

  function normalizeScatterSessionOptions(options = {}){
    const source = options && typeof options === 'object' ? options : {};
    const sessionMeta = source.__workspaceSessionMeta || buildScatterSessionMeta(source);
    return {
      ...source,
      tabId: source.tabId || sessionMeta?.tabId || null,
      sessionGeneration: source.sessionGeneration || sessionMeta?.sessionGeneration || 0,
      __workspaceSessionMeta: sessionMeta
    };
  }

  function clearScatterScheduledDraw(reason){
    if(scatterState.drawCooldownTimer){
      try{
        (global.clearTimeout || clearTimeout)(scatterState.drawCooldownTimer);
      }catch(err){
        console.debug('Debug: scatter draw cooldown clear failed', { reason: reason || 'unspecified', message: err?.message || String(err) });
      }
      scatterState.drawCooldownTimer = null;
    }
    scatterState.pendingDrawOpts = null;
    scatterState.pendingDrawReasons = null;
  }

  function captureScatterRuntimeSnapshot(reason){
    const snapshot = {
      dataDirty: scatterState.dataDirty !== false,
      stats: {
        contextSignature: scatterState.statsContextSignature || null,
        contextVersion: Number.isFinite(Number(scatterState.statsContextVersion)) ? Number(scatterState.statsContextVersion) : 0,
        lastRunVersion: Number.isFinite(Number(scatterState.statsLastRunVersion)) ? Number(scatterState.statsLastRunVersion) : 0,
        restorePending: cloneSimple(scatterState.statsRestorePending) || null
      },
      view: {
        lastDrawAt: Number.isFinite(Number(scatterState.lastDrawAt)) ? Number(scatterState.lastDrawAt) : 0,
        lastDrawMeta: cloneSimple(scatterState.lastDrawMeta) || null
      }
    };
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter runtime snapshot captured', {
        reason: reason || 'unspecified',
        dataDirty: snapshot.dataDirty,
        statsContextVersion: snapshot.stats.contextVersion
      });
    }
    return snapshot;
  }

  function applyScatterRuntimeSnapshot(snapshot, reason){
    const runtime = snapshot && typeof snapshot === 'object' ? snapshot : null;
    scatterState.dataDirty = runtime ? runtime.dataDirty !== false : true;
    scatterState.statsContextSignature = runtime?.stats?.contextSignature || null;
    scatterState.statsContextVersion = Number.isFinite(Number(runtime?.stats?.contextVersion))
      ? Number(runtime.stats.contextVersion)
      : 0;
    scatterState.statsLastRunVersion = Number.isFinite(Number(runtime?.stats?.lastRunVersion))
      ? Number(runtime.stats.lastRunVersion)
      : 0;
    scatterState.statsRestorePending = cloneSimple(runtime?.stats?.restorePending) || null;
    scatterState.statsContext = null;
    scatterState.statsComputationPending = false;
    scatterState.pendingDrawOpts = null;
    scatterState.pendingDrawReasons = null;
    scatterState.lastDrawAt = Number.isFinite(Number(runtime?.view?.lastDrawAt))
      ? Number(runtime.view.lastDrawAt)
      : 0;
    scatterState.lastDrawMeta = cloneSimple(runtime?.view?.lastDrawMeta) || null;
    scatterDrawToken += 1;
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter runtime snapshot applied', {
        reason: reason || 'unspecified',
        hasRuntime: !!runtime,
        dataDirty: scatterState.dataDirty,
        statsContextVersion: scatterState.statsContextVersion,
        drawToken: scatterDrawToken
      });
    }
    return !!runtime;
  }
  if(typeof plot3d.normalizeRotation === 'function'){
    plot3d.normalizeRotation(scatterState.rotation);
  }

  const regressionTools = Shared.regressionTools = Shared.regressionTools || {};
  let scatterFitRegressionModelForTests = null;
  let scatterFitDemingRegressionForTests = null;
  let scatterFitLowessRegressionForTests = null;
  const regressionDebugNamespace = 'scatter-regression';
  const getScatterJStat = () => global.jStat || global.window?.jStat || null;

  const ensureFiniteNumber = typeof regressionTools.ensureFiniteNumber === 'function'
    ? regressionTools.ensureFiniteNumber
    : (value => (Number.isFinite(value) ? value : NaN));

  const DEFAULT_AXIS_COLOR = '#000000';
  const DEFAULT_GRID_COLOR = '#dddddd';
  const MIN_MINOR_TICK_SUBDIVISIONS = 1;
  const MAX_MINOR_TICK_SUBDIVISIONS = 9;
  const DEFAULT_MINOR_TICK_SUBDIVISIONS = Number.isFinite(chartStyle.DEFAULT_MINOR_TICK_SUBDIVISIONS)
    ? chartStyle.DEFAULT_MINOR_TICK_SUBDIVISIONS
    : 3;
  const DEFAULT_AXIS_ADDITIONAL_TICK = Object.freeze({
    value: 0,
    showTick: false,
    showLine: true,
    label: '',
    lineColor: null,
    lineWidth: 1,
    linePattern: 'dotted',
    lineTransparency: 0
  });

  function clampMinorTickSubdivisions(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return DEFAULT_MINOR_TICK_SUBDIVISIONS;
    }
    const rounded = Math.round(numeric);
    return Math.max(MIN_MINOR_TICK_SUBDIVISIONS, Math.min(MAX_MINOR_TICK_SUBDIVISIONS, rounded));
  }

  function sanitizeScatterAxisAdditionalTickEntry(entry){
    if(axisExtras && typeof axisExtras.sanitizeEntry === 'function'){
      return axisExtras.sanitizeEntry(entry, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
    }
    if(!entry || typeof entry !== 'object'){
      return null;
    }
    const rawValue = entry.value ?? entry.at ?? entry.position ?? entry.y ?? entry.x;
    const value = Number(rawValue);
    if(!Number.isFinite(value)){
      return null;
    }
    const showTick = entry.showTick !== undefined ? !!entry.showTick : (entry.tick !== undefined ? !!entry.tick : DEFAULT_AXIS_ADDITIONAL_TICK.showTick);
    const showLine = entry.showLine !== undefined ? !!entry.showLine : (entry.line !== undefined ? !!entry.line : DEFAULT_AXIS_ADDITIONAL_TICK.showLine);
    let label = DEFAULT_AXIS_ADDITIONAL_TICK.label;
    if(entry.label !== undefined && entry.label !== null){
      label = String(entry.label);
    }else if(entry.text !== undefined && entry.text !== null){
      label = String(entry.text);
    }
    const lineColor = typeof entry.lineColor === 'string' && entry.lineColor.trim()
      ? entry.lineColor.trim()
      : DEFAULT_AXIS_ADDITIONAL_TICK.lineColor;
    const lineWidthRaw = Number(entry.lineWidth ?? entry.thickness ?? entry.strokeWidth);
    const lineWidth = Number.isFinite(lineWidthRaw) && lineWidthRaw > 0
      ? lineWidthRaw
      : DEFAULT_AXIS_ADDITIONAL_TICK.lineWidth;
    const rawPattern = typeof entry.linePattern === 'string'
      ? entry.linePattern
      : (typeof entry.pattern === 'string' ? entry.pattern : DEFAULT_AXIS_ADDITIONAL_TICK.linePattern);
    const normalizedPattern = String(rawPattern || '').trim().toLowerCase();
    const linePattern = (normalizedPattern === 'solid' || normalizedPattern === 'continuous')
      ? 'solid'
      : (normalizedPattern === 'dotted' || normalizedPattern === 'dots')
        ? 'dotted'
        : 'dashed';
    const lineTransparencyRaw = Number(entry.lineTransparency ?? entry.transparency);
    const lineTransparency = Number.isFinite(lineTransparencyRaw)
      ? Math.min(100, Math.max(0, lineTransparencyRaw))
      : DEFAULT_AXIS_ADDITIONAL_TICK.lineTransparency;
    return {
      value,
      showTick,
      showLine,
      label,
      lineColor,
      lineWidth,
      linePattern,
      lineTransparency
    };
  }

  function sanitizeScatterAxisAdditionalTicks(entries){
    if(axisExtras && typeof axisExtras.sanitizeEntries === 'function'){
      return axisExtras.sanitizeEntries(entries, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
    }
    if(!Array.isArray(entries)){
      return [];
    }
    return entries
      .map(entry => sanitizeScatterAxisAdditionalTickEntry(entry))
      .filter(entry => !!entry);
  }

  const scatterRefs = {};
  // Merge the second scatterState declaration with the first one
  scatterState.hot = null;
  scatterState.xLabelText = 'X';
  scatterState.yLabelText = 'Y';
  scatterState.zLabelText = 'Z';
  scatterState.titleText = 'Scatter plot';
  let scatterSvgBoxRef = null;
  let scatterLegendControl = null;
  let scatterLockRatioInput = null;
  let scatterEqualAxesInput = null;
  let scatterEqualScaleAxesInput = null;
  let scatterVarianceAxisScaleInput = null;
  let scatterAxesLengthLockRatioPrevious = null;
  let scatterAspectSyncing = false;
  let scatterViewModeInput = null;
  let scatterTooltipEl = null;
  let scatterPointContextMenu = null;
  let scatterPointContextMenuGlobalBound = false;
  const EMPTY_LEGEND_RENDERER = Object.freeze({
    entries: Object.freeze([]),
    width: 0,
    height: 0,
    draw(){ /* noop legend renderer when hidden */ }
  });


  function scatterDebug(label, payload){
    try{
      if(typeof Shared.isDebugEnabled === 'function' && !Shared.isDebugEnabled()){
        return;
      }
    }catch(err){
      // ignore toggle errors and log by default
    }
    console.debug(label, payload);
  }

  function scatterLog(...args){
    try{
      if(typeof Shared.isDebugEnabled === 'function' && !Shared.isDebugEnabled()){
        return;
      }
    }catch(err){
      // ignore
    }
    console.debug(...args);
  }

  function computeScatterMedianForLowess(values){
    const data = Array.isArray(values) ? values.filter(Number.isFinite).slice().sort((a, b) => a - b) : [];
    if(!data.length){
      return NaN;
    }
    const mid = Math.floor(data.length / 2);
    return (data.length % 2)
      ? data[mid]
      : ((data[mid - 1] + data[mid]) / 2);
  }

  function computeScatterAicMetricsForLowess(sseValue, sampleSize, parameterCount){
    const n = Number(sampleSize);
    const k = Number(parameterCount);
    const sse = Number(sseValue);
    if(!Number.isFinite(n) || !Number.isFinite(k) || n <= 0 || k <= 0 || !Number.isFinite(sse) || sse <= 0){
      return { aic: NaN, aicc: NaN, bic: NaN };
    }
    const aic = (n * Math.log(sse / n)) + (2 * k);
    const aicc = (n - k - 1) > 0 ? aic + ((2 * k * (k + 1)) / (n - k - 1)) : NaN;
    const bic = (n * Math.log(sse / n)) + (k * Math.log(n));
    return { aic, aicc, bic };
  }

  function fitScatterLowessRegressionCore(inputPoints, options = {}){
    const fitSpec = options.fitSpec && typeof options.fitSpec === 'object' ? options.fitSpec : {};
    const span = Math.min(0.95, Math.max(0.2, Number(
      fitSpec?.span
      ?? fitSpec?.parameters?.span
      ?? fitSpec?.initialValues?.span
      ?? 0.75
    )));
    const points = (Array.isArray(inputPoints) ? inputPoints : [])
      .filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y))
      .map(pt => ({ ...pt, x: Number(pt.x), y: Number(pt.y) }))
      .sort((a, b) => a.x - b.x);
    const n = points.length;
    if(n < 3){
      return null;
    }
    const k = Math.max(2, Math.ceil(span * n));
    const tricube = value => {
      const t = Math.min(1, Math.abs(value));
      const base = 1 - Math.pow(t, 3);
      return Math.pow(Math.max(0, base), 3);
    };
    const smoothAt = (targetIndex, robustWeights) => {
      const x0 = points[targetIndex].x;
      const distances = points.map((pt, idx) => ({ idx, dist: Math.abs(pt.x - x0) })).sort((a, b) => a.dist - b.dist);
      const bandwidth = Math.max(1e-9, distances[Math.min(distances.length - 1, k - 1)].dist || 1e-9);
      let sw = 0;
      let sx = 0;
      let sy = 0;
      let sxx = 0;
      let sxy = 0;
      points.forEach((pt, idx) => {
        const distanceWeight = tricube((pt.x - x0) / bandwidth);
        const weight = distanceWeight * (robustWeights ? robustWeights[idx] : 1);
        sw += weight;
        sx += weight * pt.x;
        sy += weight * pt.y;
        sxx += weight * pt.x * pt.x;
        sxy += weight * pt.x * pt.y;
      });
      const det = (sw * sxx) - (sx * sx);
      if(!(Math.abs(det) > 1e-18)){
        return points[targetIndex].y;
      }
      const intercept = ((sy * sxx) - (sx * sxy)) / det;
      const slope = ((sw * sxy) - (sx * sy)) / det;
      return intercept + (slope * x0);
    };
    let robustWeights = new Array(n).fill(1);
    let smoothed = points.map((_, idx) => smoothAt(idx, robustWeights));
    for(let iter = 0; iter < 2; iter += 1){
      const residuals = points.map((pt, idx) => pt.y - smoothed[idx]);
      const medianAbs = computeScatterMedianForLowess(residuals.map(value => Math.abs(value))) || 1e-9;
      robustWeights = residuals.map(value => {
        const ratio = Math.abs(value) / (6 * medianAbs);
        if(ratio >= 1){
          return 0;
        }
        const base = 1 - (ratio * ratio);
        return base * base;
      });
      smoothed = points.map((_, idx) => smoothAt(idx, robustWeights));
    }
    const curveSamples = points.map((pt, idx) => ({ x: pt.x, y: smoothed[idx] }));
    const predict = xValue => {
      const x = Number(xValue);
      if(!Number.isFinite(x) || !curveSamples.length){
        return NaN;
      }
      if(x <= curveSamples[0].x){
        return curveSamples[0].y;
      }
      if(x >= curveSamples[curveSamples.length - 1].x){
        return curveSamples[curveSamples.length - 1].y;
      }
      for(let i = 1; i < curveSamples.length; i += 1){
        const a = curveSamples[i - 1];
        const b = curveSamples[i];
        if(x <= b.x){
          const spanX = b.x - a.x || 1;
          const t = (x - a.x) / spanX;
          return a.y + (t * (b.y - a.y));
        }
      }
      return NaN;
    };
    const residuals = points.map((pt, idx) => pt.y - smoothed[idx]);
    const sse = residuals.reduce((sum, value) => sum + (value * value), 0);
    const yMean = points.reduce((sum, pt) => sum + pt.y, 0) / n;
    const tss = points.reduce((sum, pt) => sum + Math.pow(pt.y - yMean, 2), 0);
    const parameterCount = Math.max(2, Math.round(span * n));
    const spanLabel = typeof options.formatSpanLabel === 'function'
      ? options.formatSpanLabel(span)
      : span.toFixed(3);
    return {
      mode: 'lowess',
      fitMethod: 'ols',
      fitSpec,
      domain: {
        minX: points[0].x,
        maxX: points[points.length - 1].x
      },
      predict,
      summary: {
        parameters: { Span: span },
        equation: `LOWESS smoother (span = ${spanLabel})`
      },
      metrics: {
        sampleSize: n,
        parameterCount,
        residualDf: Math.max(1, n - parameterCount),
        sse,
        r2: tss > 0 ? (1 - (sse / tss)) : NaN,
        adjR2: NaN,
        rmse: Math.sqrt(sse / n),
        mae: residuals.reduce((sum, value) => sum + Math.abs(value), 0) / n,
        ...computeScatterAicMetricsForLowess(sse, n, parameterCount)
      },
      residuals: {
        mean: residuals.reduce((sum, value) => sum + value, 0) / n,
        sd: Math.sqrt(sse / Math.max(1, n - parameterCount)),
        min: Math.min(...residuals),
        max: Math.max(...residuals)
      },
      warnings: ['LOWESS is intended for descriptive smoothing. Use mechanistic regression for parameter inference.'],
      curveSamples,
      intervals: { samples: [], summary: {} }
    };
  }

  function collectScatterStatPairsCore(points, options = {}){
    const safePoints = Array.isArray(points) ? points : [];
    const pairedPoints = [];
    const xValues = [];
    const yValues = [];
    for(let idx = 0; idx < safePoints.length; idx += 1){
      const point = safePoints[idx];
      const x = Number(point?.x);
      const y = Number(point?.y);
      if(!Number.isFinite(x) || !Number.isFinite(y)){
        continue;
      }
      pairedPoints.push(options.preservePointFields ? { ...point, x, y } : { x, y });
      xValues.push(x);
      yValues.push(y);
    }
    return {
      points: pairedPoints,
      x: xValues,
      y: yValues,
      count: pairedPoints.length,
      totalRows: safePoints.length,
      droppedRows: Math.max(0, safePoints.length - pairedPoints.length)
    };
  }

  function normalizeScatterAssociationSelectionFallback(value){
    const raw = String(value || 'auto').trim().toLowerCase();
    return (raw === 'pearson' || raw === 'spearman' || raw === 'none' || raw === 'auto')
      ? raw
      : 'auto';
  }

  function resolveScatterAssociationMethodFallback(selection, regressionMode){
    const normalizedSelection = normalizeScatterAssociationSelectionFallback(selection);
    if(normalizedSelection === 'pearson' || normalizedSelection === 'spearman' || normalizedSelection === 'none'){
      return normalizedSelection;
    }
    const policy = {
      linear: 'pearson',
      linearthroughorigin: 'pearson',
      deming: 'pearson',
      orthogonal: 'pearson',
      lowess: 'none',
      quadratic: 'none',
      cubic: 'none',
      logistic: 'spearman',
      doseresponse3pl: 'spearman',
      doseresponse4pl: 'spearman',
      doseresponse5pl: 'spearman',
      exponential: 'spearman',
      onephaseassociation: 'spearman',
      onephasedecay: 'spearman',
      gompertz: 'spearman',
      power: 'spearman',
      gaussian: 'none',
      spline: 'none',
      bindingsaturation: 'spearman',
      bindingcompetitive: 'spearman',
      enzymekineticssubstrate: 'spearman',
      enzymekineticsinhibition: 'spearman'
    };
    const modeKey = String(regressionMode || 'linear').trim().toLowerCase();
    return normalizeScatterAssociationSelectionFallback(policy[modeKey] || 'pearson');
  }

  function getScatterAssociationMethodLabelFallback(method){
    const normalized = normalizeScatterAssociationSelectionFallback(method);
    if(normalized === 'spearman') return 'Spearman';
    if(normalized === 'none') return 'None (model fit only)';
    return 'Pearson';
  }

  function computeScatterStatsCore(points, method, options = {}, deps = {}){
    const safeOptions = options || {};
    const normalizeAssociationSelection = typeof deps.normalizeAssociationSelection === 'function'
      ? deps.normalizeAssociationSelection
      : normalizeScatterAssociationSelectionFallback;
    const resolveAssociationMethod = typeof deps.resolveAssociationMethod === 'function'
      ? deps.resolveAssociationMethod
      : resolveScatterAssociationMethodFallback;
    const getAssociationLabel = typeof deps.getAssociationMethodLabel === 'function'
      ? deps.getAssociationMethodLabel
      : getScatterAssociationMethodLabelFallback;
    const collectPairs = typeof deps.collectPairs === 'function'
      ? deps.collectPairs
      : value => collectScatterStatPairsCore(value);
    const computeCorrelationStats = typeof deps.computeCorrelationStats === 'function'
      ? deps.computeCorrelationStats
      : null;
    const statsApi = typeof deps.getStatsApi === 'function'
      ? deps.getStatsApi()
      : (global.jStat || global.window?.jStat || null);
    const regressionMode = safeOptions.regressionMode || 'linear';
    const fitMethod = safeOptions.fitMethod || 'ols';
    const associationSelection = normalizeAssociationSelection(safeOptions.associationSelection || method || 'auto');
    const associationResolveInput = deps.resolveAssociationFromSelection ? associationSelection : method;
    const resolvedAssociationMethod = resolveAssociationMethod(associationResolveInput, regressionMode);
    const fitSpec = safeOptions.fitSpec && typeof safeOptions.fitSpec === 'object' ? safeOptions.fitSpec : {};
    const domainOption = safeOptions.domain || null;
    const paired = collectPairs(points);
    const n = paired.count;
    const x = paired.x;
    const y = paired.y;
    if(typeof deps.onPaired === 'function'){
      deps.onPaired(paired);
    }
    if(n < 3){
      return {
        method: getAssociationLabel(resolvedAssociationMethod),
        associationSelection,
        associationMethod: resolvedAssociationMethod,
        r: NaN,
        p: NaN,
        r2: NaN,
        m: NaN,
        b: NaN,
        regression: null,
        pointCount: n
      };
    }
    const correlation = computeCorrelationStats
      ? computeCorrelationStats(resolvedAssociationMethod, x, y)
      : { methodCode: resolvedAssociationMethod, methodLabel: getAssociationLabel(resolvedAssociationMethod), r: NaN, p: NaN };
    const pearson = Number.isFinite(correlation?.r)
      ? Number(correlation.r)
      : ((statsApi && typeof statsApi.corrcoeff === 'function')
        ? Number(statsApi.corrcoeff(x, y))
        : NaN);
    const xMean = (statsApi && typeof statsApi.mean === 'function')
      ? Number(statsApi.mean(x))
      : (x.reduce((sum, value) => sum + value, 0) / Math.max(1, x.length));
    const yMean = (statsApi && typeof statsApi.mean === 'function')
      ? Number(statsApi.mean(y))
      : (y.reduce((sum, value) => sum + value, 0) / Math.max(1, y.length));
    const num = x.reduce((sum, xi, index) => sum + ((xi - xMean) * (y[index] - yMean)), 0);
    const den = x.reduce((sum, xi) => sum + Math.pow(xi - xMean, 2), 0);
    const linearSlope = den !== 0 ? (num / den) : NaN;
    const linearIntercept = yMean - (linearSlope * xMean);
    let regression = null;
    try{
      const modeKey = String(regressionMode || 'linear').trim().toLowerCase();
      if((modeKey === 'deming' || modeKey === 'orthogonal') && typeof deps.fitDemingRegression === 'function'){
        regression = deps.fitDemingRegression(paired.points, {
          mode: regressionMode,
          method: fitMethod,
          fitSpec,
          domain: domainOption || null
        });
      }else if(modeKey === 'lowess' && typeof deps.fitLowessRegression === 'function'){
        regression = deps.fitLowessRegression(paired.points, {
          mode: regressionMode,
          method: fitMethod,
          fitSpec,
          domain: domainOption || null
        });
      }else if(typeof deps.fitRegressionModel === 'function'){
        regression = deps.fitRegressionModel(paired.points, {
          mode: regressionMode,
          method: fitMethod,
          fitSpec,
          domain: domainOption || null,
          preferDoseResponse: regressionMode === 'logistic'
        });
      }else if(regressionTools && typeof regressionTools.fitRegression === 'function'){
        regression = regressionTools.fitRegression(paired.points, {
          mode: regressionMode,
          method: fitMethod,
          fitSpec,
          domain: domainOption || null,
          preferDoseResponse: regressionMode === 'logistic'
        });
      }
      if(regression && domainOption){
        const minCandidate = Number.isFinite(domainOption.minX) ? domainOption.minX : Number.isFinite(domainOption.min) ? domainOption.min : undefined;
        const maxCandidate = Number.isFinite(domainOption.maxX) ? domainOption.maxX : Number.isFinite(domainOption.max) ? domainOption.max : undefined;
        if(Number.isFinite(minCandidate) && Number.isFinite(maxCandidate)){
          regression.domain = { minX: minCandidate, maxX: maxCandidate };
        }
      }
    }catch(err){
      console.error('Regression fit error', err);
    }
    const summaryForRegression = regression?.summary;
    const regressionSlope = summaryForRegression?.slope;
    const regressionIntercept = summaryForRegression?.intercept;
    let resolvedSlope = Number.isFinite(regressionSlope) ? regressionSlope : linearSlope;
    if(summaryForRegression?.primaryParameter && Number.isFinite(summaryForRegression.primaryParameter.value)){
      resolvedSlope = summaryForRegression.primaryParameter.value;
    }
    const resolvedIntercept = Number.isFinite(regressionIntercept) ? regressionIntercept : linearIntercept;
    const regressionR2 = regression?.metrics?.r2;
    const derived = {
      ...(typeof deps.computeDerivedRegressionStats === 'function'
        ? (deps.computeDerivedRegressionStats(regression) || {})
        : {}),
      ...(regression?.derived || {})
    };
    return {
      method: correlation?.methodLabel || getAssociationLabel(resolvedAssociationMethod),
      associationSelection,
      associationMethod: correlation?.methodCode || resolvedAssociationMethod,
      r: correlation?.r,
      p: correlation?.p,
      pMethod: correlation?.pMethod,
      correlationCI: correlation?.ci || null,
      correlationCiApproximate: !!correlation?.ciApproximate,
      r2: Number.isFinite(regressionR2) ? regressionR2 : (pearson * pearson),
      m: resolvedSlope,
      b: resolvedIntercept,
      pointCount: n,
      regression,
      derived
    };
  }

  function getScatterLockRatioCheckbox(){
    if(scatterLockRatioInput && scatterLockRatioInput.isConnected){
      return scatterLockRatioInput;
    }
    const svgBox = scatterSvgBoxRef;
    if(!svgBox){
      return null;
    }
    const checkbox = svgBox.querySelector('.resizer-aspect-checkbox');
    if(checkbox){
      scatterLockRatioInput = checkbox;
    }
    return checkbox;
  }

  function syncScatterAspectControls(reason){
    if(scatterAspectSyncing){
      return;
    }
    scatterAspectSyncing = true;
    try{
      const equalAxesEnabled = !!scatterState.equalAxes;
      const equalScaleEnabled = !!scatterState.equalScaleAxes;
      const varianceAxesEnabled = !!scatterState.axesVarianceScaled;
      const viewMode = scatterViewModeInput?.value || scatterState.viewMode || '2d';
      const is3dView = String(viewMode).toLowerCase() === '3d';
      const enforceLockRatio = varianceAxesEnabled || is3dView;
      if(scatterEqualAxesInput && scatterEqualAxesInput.checked !== equalAxesEnabled){
        scatterEqualAxesInput.checked = equalAxesEnabled;
      }
      if(scatterEqualScaleAxesInput && scatterEqualScaleAxesInput.checked !== equalScaleEnabled){
        scatterEqualScaleAxesInput.checked = equalScaleEnabled;
      }
      if(scatterVarianceAxisScaleInput && scatterVarianceAxisScaleInput.checked !== varianceAxesEnabled){
        scatterVarianceAxisScaleInput.checked = varianceAxesEnabled;
      }
      const lockRatioCheckbox = getScatterLockRatioCheckbox();
      if(lockRatioCheckbox){
        const lockLabel = lockRatioCheckbox.closest('label');
        if(enforceLockRatio){
          if(scatterAxesLengthLockRatioPrevious === null){
            scatterAxesLengthLockRatioPrevious = !!lockRatioCheckbox.checked;
          }
          if(!lockRatioCheckbox.checked){
            lockRatioCheckbox.checked = true;
            lockRatioCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
          }
          lockRatioCheckbox.disabled = true;
          if(lockLabel){
            if(!lockLabel.__scatterOriginalTitle){
              lockLabel.__scatterOriginalTitle = lockLabel.title || '';
            }
            lockLabel.title = 'Locked while axes length is constrained';
          }
        }else{
          lockRatioCheckbox.disabled = false;
          if(lockLabel && lockLabel.__scatterOriginalTitle !== undefined){
            lockLabel.title = lockLabel.__scatterOriginalTitle;
            delete lockLabel.__scatterOriginalTitle;
          }
          if(scatterAxesLengthLockRatioPrevious !== null){
            const restoreValue = scatterAxesLengthLockRatioPrevious;
            scatterAxesLengthLockRatioPrevious = null;
            if(lockRatioCheckbox.checked !== restoreValue){
              lockRatioCheckbox.checked = restoreValue;
              lockRatioCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        }
      }
      scatterDebug('Debug: scatter axes length sync',{
        equalAxesEnabled,
        equalScaleEnabled,
        varianceAxesEnabled,
        is3dView,
        lockRatioEnabled: lockRatioCheckbox ? !!lockRatioCheckbox.checked : null,
        reason: reason || null
      });
    } finally {
      scatterAspectSyncing = false;
    }
  }

  function ensureScatterLegendControlPlacement(){
    if(!scatterLegendControl || !scatterSvgBoxRef){
      return;
    }
    if(Shared.resizer && typeof Shared.resizer.ensureLegendControlPlacement === 'function'){
      Shared.resizer.ensureLegendControlPlacement({
        svgBox: scatterSvgBoxRef,
        control: scatterLegendControl,
        debugLabel: 'scatter-legend'
      });
      return;
    }
    const hostBox = scatterSvgBoxRef;
    let tray = hostBox.querySelector('.resizer-control-tray');
    if(!tray){
      const doc = hostBox.ownerDocument || global.document;
      if(doc){
        tray = doc.createElement('div');
        tray.className = 'resizer-control-tray';
        hostBox.appendChild(tray);
        console.debug('Debug: scatter legend tray fallback created',{ trayChildren: tray.childElementCount });
      }
    }
    if(!tray){
      return;
    }
    if(scatterLegendControl.parentNode !== tray){
      tray.appendChild(scatterLegendControl);
      console.debug('Debug: scatter legend control moved',{ trayChildren: tray.childElementCount });
    }
    scatterLegendControl.classList.remove('config-panel__checkbox','config-panel__checkbox--inline');
    scatterLegendControl.classList.add('resizer-legend-control');
    if(!scatterLegendControl.title){
      scatterLegendControl.title = 'Toggle legend visibility';
    }
    if(scatterLegendControl.dataset){
      scatterLegendControl.dataset.scatterLegendTray = 'true';
    }
  }

  function ensureScatterAxesLengthControlPlacement(){
    if(!scatterSvgBoxRef){
      return;
    }
    const doc = scatterSvgBoxRef.ownerDocument || global.document;
    if(!doc){
      return;
    }
    let tray = scatterSvgBoxRef.querySelector('.resizer-control-tray');
    if(!tray){
      tray = doc.createElement('div');
      tray.className = 'resizer-control-tray';
      scatterSvgBoxRef.appendChild(tray);
      scatterDebug('Debug: scatter axes length tray created', { trayChildren: tray.childElementCount });
    }
    let axesControl = tray.querySelector('.resizer-axeslength-control');
    if(!axesControl){
      axesControl = doc.createElement('details');
      axesControl.className = 'resizer-axeslength-control';
      const summary = doc.createElement('summary');
      summary.className = 'resizer-axeslength-summary';
      summary.textContent = 'Axes length';
      const menu = doc.createElement('div');
      menu.className = 'resizer-axeslength-menu';
      axesControl.appendChild(summary);
      axesControl.appendChild(menu);
      const aspectControl = tray.querySelector('.resizer-aspect-control');
      if(aspectControl && aspectControl.parentNode === tray){
        tray.insertBefore(axesControl, aspectControl);
      }else{
        tray.appendChild(axesControl);
      }
      scatterDebug('Debug: scatter axes length control created', { trayChildren: tray.childElementCount });
    }
    const menu = axesControl.querySelector('.resizer-axeslength-menu');
    if(menu){
      let equalScaleItem = menu.querySelector('.resizer-axeslength-item--equal-scale');
      if(!equalScaleItem){
        equalScaleItem = doc.createElement('label');
        equalScaleItem.className = 'resizer-axeslength-item resizer-axeslength-item--equal-scale';
        const checkbox = doc.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--equal-scale';
        const textSpan = doc.createElement('span');
        textSpan.className = 'resizer-axeslength-text';
        equalScaleItem.appendChild(checkbox);
        equalScaleItem.appendChild(textSpan);
        menu.appendChild(equalScaleItem);
      }else{
        equalScaleItem.classList.add('resizer-axeslength-item');
      }
      if(equalScaleItem){
        equalScaleItem.title = 'Equal axis lengths with the same data scale';
        const equalScaleCheckbox = equalScaleItem.querySelector('input[type="checkbox"]');
        if(equalScaleCheckbox){
          equalScaleCheckbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--equal-scale';
          equalScaleCheckbox.setAttribute('aria-label', 'Equal axis lengths with the same data scale');
        }
        const equalScaleText = equalScaleItem.querySelector('.resizer-axeslength-text');
        if(equalScaleText){
          equalScaleText.textContent = 'Equal length / same scale';
        }
      }
      let equalLengthItem = menu.querySelector('.resizer-axeslength-item--equal-length');
      if(!equalLengthItem){
        equalLengthItem = doc.createElement('label');
        equalLengthItem.className = 'resizer-axeslength-item resizer-axeslength-item--equal-length';
        const checkbox = doc.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--equal-length';
        const textSpan = doc.createElement('span');
        textSpan.className = 'resizer-axeslength-text';
        equalLengthItem.appendChild(checkbox);
        equalLengthItem.appendChild(textSpan);
      }
      if(equalLengthItem){
        equalLengthItem.title = 'Equal axis lengths with independent scales';
        const equalLengthCheckbox = equalLengthItem.querySelector('input[type="checkbox"]');
        if(equalLengthCheckbox){
          equalLengthCheckbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--equal-length';
          equalLengthCheckbox.setAttribute('aria-label', 'Equal axis lengths with independent scales');
        }
        const equalLengthText = equalLengthItem.querySelector('.resizer-axeslength-text');
        if(equalLengthText){
          equalLengthText.textContent = 'Equal length / different scale';
        }
        if(equalLengthItem.parentNode !== menu){
          menu.appendChild(equalLengthItem);
        }
      }
      const equalScaleCheckbox = equalScaleItem.querySelector('input[type="checkbox"]');
      if(equalScaleCheckbox){
        scatterEqualScaleAxesInput = equalScaleCheckbox;
        if(equalScaleCheckbox.__scatterEqualScaleAxesHandler){
          equalScaleCheckbox.removeEventListener('change', equalScaleCheckbox.__scatterEqualScaleAxesHandler);
        }
        const onChange = () => {
          const enabled = !!equalScaleCheckbox.checked;
          const previous = !!scatterState.equalScaleAxes;
          if(enabled){
            scatterState.equalAxes = false;
            scatterState.axesVarianceScaled = false;
            if(scatterEqualAxesInput){
              scatterEqualAxesInput.checked = false;
            }
            if(scatterVarianceAxisScaleInput){
              scatterVarianceAxisScaleInput.checked = false;
            }
            scatterDebug('Debug: scatter axes length exclusivity enforced', { disabled: 'equal-length/variance', reason: 'equal-scale-toggle' });
          }
          scatterState.equalScaleAxes = enabled;
          scatterDebug('Debug: scatter equal scale toggled', { enabled, previous });
          syncScatterAspectControls('equal-scale-toggle');
          if(typeof scheduleDrawScatter === 'function'){
            scheduleScatterViewRefresh('equal-scale-toggle');
          }
        };
        equalScaleCheckbox.addEventListener('change', onChange);
        equalScaleCheckbox.__scatterEqualScaleAxesHandler = onChange;
      }
      const equalLengthCheckbox = equalLengthItem ? equalLengthItem.querySelector('input[type="checkbox"]') : null;
      if(equalLengthCheckbox){
        scatterEqualAxesInput = equalLengthCheckbox;
        if(equalLengthCheckbox.__scatterEqualAxesHandler){
          equalLengthCheckbox.removeEventListener('change', equalLengthCheckbox.__scatterEqualAxesHandler);
        }
        const onChange = () => {
          const enabled = !!equalLengthCheckbox.checked;
          const previous = !!scatterState.equalAxes;
          if(enabled){
            scatterState.equalScaleAxes = false;
            scatterState.axesVarianceScaled = false;
            if(scatterEqualScaleAxesInput){
              scatterEqualScaleAxesInput.checked = false;
            }
            if(scatterVarianceAxisScaleInput){
              scatterVarianceAxisScaleInput.checked = false;
            }
            scatterDebug('Debug: scatter axes length exclusivity enforced', { disabled: 'equal-scale/variance', reason: 'equal-length-toggle' });
          }
          scatterState.equalAxes = enabled;
          scatterDebug('Debug: scatter equal length toggled', { enabled, previous });
          syncScatterAspectControls('equal-length-toggle');
          if(typeof scheduleDrawScatter === 'function'){
            scheduleScatterViewRefresh('equal-length-toggle');
          }
        };
        equalLengthCheckbox.addEventListener('change', onChange);
        equalLengthCheckbox.__scatterEqualAxesHandler = onChange;
      }
      let varianceItem = menu.querySelector('.resizer-axeslength-item--variance');
      if(!varianceItem){
        varianceItem = doc.createElement('label');
        varianceItem.className = 'resizer-axeslength-item resizer-axeslength-item--variance';
        const checkbox = doc.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--variance';
        const textSpan = doc.createElement('span');
        textSpan.className = 'resizer-axeslength-text';
        varianceItem.appendChild(checkbox);
        varianceItem.appendChild(textSpan);
        menu.appendChild(varianceItem);
      }
      if(varianceItem){
        varianceItem.title = 'Scale axes by variance';
        const varianceCheckbox = varianceItem.querySelector('input[type="checkbox"]');
        if(varianceCheckbox){
          varianceCheckbox.className = 'resizer-axeslength-checkbox resizer-axeslength-checkbox--variance';
          varianceCheckbox.setAttribute('aria-label', 'Scale axes by variance');
        }
        const varianceText = varianceItem.querySelector('.resizer-axeslength-text');
        if(varianceText){
          varianceText.textContent = 'Variance-scaled';
        }
      }
      const varianceCheckbox = varianceItem ? varianceItem.querySelector('input[type="checkbox"]') : null;
      if(varianceCheckbox){
        scatterVarianceAxisScaleInput = varianceCheckbox;
        if(varianceCheckbox.__scatterVarianceAxesHandler){
          varianceCheckbox.removeEventListener('change', varianceCheckbox.__scatterVarianceAxesHandler);
        }
        const onChange = () => {
          const enabled = !!varianceCheckbox.checked;
          const previous = !!scatterState.axesVarianceScaled;
          if(enabled){
            scatterState.equalAxes = false;
            scatterState.equalScaleAxes = false;
            if(scatterEqualAxesInput){
              scatterEqualAxesInput.checked = false;
            }
            if(scatterEqualScaleAxesInput){
              scatterEqualScaleAxesInput.checked = false;
            }
            scatterDebug('Debug: scatter axes length exclusivity enforced', { disabled: 'equal-length/equal-scale', reason: 'variance-axis-toggle' });
          }
          scatterState.axesVarianceScaled = enabled;
          scatterDebug('Debug: scatter variance axis scaling toggled', { enabled, previous });
          syncScatterAspectControls('variance-axis-scale');
          if(typeof scheduleDrawScatter === 'function'){
            scheduleScatterViewRefresh('variance-axis-scale');
          }
        };
        varianceCheckbox.addEventListener('change', onChange);
        varianceCheckbox.__scatterVarianceAxesHandler = onChange;
      }
      if(equalScaleItem && equalScaleItem.parentNode === menu){
        menu.appendChild(equalScaleItem);
      }
      if(equalLengthItem && equalLengthItem.parentNode === menu){
        menu.appendChild(equalLengthItem);
      }
      if(varianceItem && varianceItem.parentNode === menu){
        menu.appendChild(varianceItem);
      }
    }
    syncScatterAspectControls('axes-length-ensure');
  }

  function ensureScatterResizerControls(){
    ensureScatterLegendControlPlacement();
    ensureScatterAxesLengthControlPlacement();
  }

  function closeScatterAxesLengthMenu(reason){
    const svgBox = scatterSvgBoxRef;
    if(!svgBox){
      return;
    }
    const axesControl = svgBox.querySelector('.resizer-axeslength-control');
    if(axesControl && axesControl.hasAttribute('open')){
      axesControl.removeAttribute('open');
      scatterDebug('Debug: scatter axes length menu closed', { reason: reason || null });
    }
  }

  function normalizeScatterColorMode(value){
    const normalized = typeof value === 'string' ? value.toLowerCase() : '';
    if(normalized === 'density'){
      return 'density';
    }
    if(normalized === 'solid'){
      return 'solid';
    }
    return SCATTER_DENSITY_MODE_DEFAULT;
  }

  function normalizeScatterDensityPalette(value){
    const key = typeof value === 'string' ? value.toLowerCase() : '';
    return SCATTER_DENSITY_RAMPS[key] ? key : SCATTER_DENSITY_PALETTE_DEFAULT;
  }

  function resolveScatterAxisVariance(points){
    if(!Array.isArray(points) || points.length < 2){
      return null;
    }
    let count = 0;
    let sumX = 0;
    let sumY = 0;
    let sumXX = 0;
    let sumYY = 0;
    for(let i = 0; i < points.length; i += 1){
      const point = points[i];
      const x = Number(point?.x);
      const y = Number(point?.y);
      if(!Number.isFinite(x) || !Number.isFinite(y)){
        continue;
      }
      count += 1;
      sumX += x;
      sumY += y;
      sumXX += x * x;
      sumYY += y * y;
    }
    if(count < 2){
      return null;
    }
    const meanX = sumX / count;
    const meanY = sumY / count;
    const varX = Math.max(0, (sumXX / count) - (meanX * meanX));
    const varY = Math.max(0, (sumYY / count) - (meanY * meanY));
    const info = {
      count,
      weights: { x: varX, y: varY },
      ratio: varY > 0 ? varX / varY : null
    };
    scatterDebug('Debug: scatter resolveAxisVariance', info);
    return info;
  }

  function scatterHexToRgb(hex){
    if(!hex){ return null; }
    const match = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim());
    if(!match){ return null; }
    const intValue = parseInt(match[1], 16);
    return {
      r: (intValue >> 16) & 255,
      g: (intValue >> 8) & 255,
      b: intValue & 255
    };
  }

  function scatterMixColors(a, b, t){
    const clamped = Math.min(Math.max(t, 0), 1);
    const safeA = a || { r: 0, g: 0, b: 0 };
    const safeB = b || safeA;
    return {
      r: Math.round(safeA.r + (safeB.r - safeA.r) * clamped),
      g: Math.round(safeA.g + (safeB.g - safeA.g) * clamped),
      b: Math.round(safeA.b + (safeB.b - safeA.b) * clamped)
    };
  }

  function scatterRgbToCss(rgb){
    if(!rgb){ return '#000000'; }
    const r = Math.min(255, Math.max(0, Math.round(rgb.r)));
    const g = Math.min(255, Math.max(0, Math.round(rgb.g)));
    const b = Math.min(255, Math.max(0, Math.round(rgb.b)));
    return `rgb(${r}, ${g}, ${b})`;
  }

  function createScatterDensityColorMapper(paletteKey){
    const rampKey = normalizeScatterDensityPalette(paletteKey);
    const stops = SCATTER_DENSITY_RAMPS[rampKey] || SCATTER_DENSITY_RAMPS[SCATTER_DENSITY_PALETTE_DEFAULT];
    const parsed = (Array.isArray(stops) ? stops : []).map((hex, idx) => ({
      t: stops.length > 1 ? idx / (stops.length - 1) : 0,
      color: scatterHexToRgb(hex)
    })).filter(entry => entry.color);
    if(!parsed.length){
      const fallback = scatterHexToRgb('#0000ff');
      return () => scatterRgbToCss(fallback);
    }
    return ratio => {
      const t = Math.min(Math.max(Number(ratio) || 0, 0), 1);
      if(parsed.length === 1){
        return scatterRgbToCss(parsed[0].color);
      }
      let start = parsed[0];
      let end = parsed[parsed.length - 1];
      for(let i = 0; i < parsed.length - 1; i += 1){
        const a = parsed[i];
        const b = parsed[i + 1];
        if(t >= a.t && t <= b.t){
          start = a;
          end = b;
          break;
        }
      }
      const span = end.t - start.t || 1;
      const localT = span ? (t - start.t) / span : 0;
      return scatterRgbToCss(scatterMixColors(start.color, end.color, localT));
    };
  }

  function computeScatterDensityValues(points, size){
    const width = Math.max(1, Number(size?.width) || 1);
    const height = Math.max(1, Number(size?.height) || 1);
    const offsetX = Number(size?.offsetX) || 0;
    const offsetY = Number(size?.offsetY) || 0;
    const data = Array.isArray(points) ? points : [];
    const count = data.length;
    if(!count){
      return { values: [], max: 0 };
    }
    const gridResolution = Math.max(10, Math.min(80, Math.round(Math.sqrt(count))));
    const gridX = gridResolution;
    const gridY = gridResolution;
    const cellW = width / gridX;
    const cellH = height / gridY;
    const grid = new Int32Array(gridX * gridY);
    const gxArr = new Int32Array(count);
    const gyArr = new Int32Array(count);
    for(let i = 0; i < count; i += 1){
      const pt = data[i];
      const rawX = pt?.x ?? pt?.cx;
      const rawY = pt?.y ?? pt?.cy;
      const x = Math.min(Math.max((Number(rawX) || 0) - offsetX, 0), width - 1e-6);
      const y = Math.min(Math.max((Number(rawY) || 0) - offsetY, 0), height - 1e-6);
      const gx = Math.min(gridX - 1, Math.max(0, Math.floor(x / cellW)));
      const gy = Math.min(gridY - 1, Math.max(0, Math.floor(y / cellH)));
      grid[gy * gridX + gx] += 1;
      gxArr[i] = gx;
      gyArr[i] = gy;
    }
    const values = new Float64Array(count);
    let maxDensity = 0;
    for(let idx = 0; idx < count; idx += 1){
      const gx = gxArr[idx];
      const gy = gyArr[idx];
      let sum = 0;
      let n = 0;
      for(let dy = -1; dy <= 1; dy += 1){
        const ny = gy + dy;
        if(ny < 0 || ny >= gridY){
          continue;
        }
        const row = ny * gridX;
        for(let dx = -1; dx <= 1; dx += 1){
          const nx = gx + dx;
          if(nx < 0 || nx >= gridX){
            continue;
          }
          sum += grid[row + nx];
          n += 1;
        }
      }
      const density = n ? sum / n : 0;
      values[idx] = density;
      if(density > maxDensity){
        maxDensity = density;
      }
    }
    return { values, max: maxDensity };
  }

  function computeScatterDensityValuesFromGeometry(cxValues, cyValues, size){
    const width = Math.max(1, Number(size?.width) || 1);
    const height = Math.max(1, Number(size?.height) || 1);
    const offsetX = Number(size?.offsetX) || 0;
    const offsetY = Number(size?.offsetY) || 0;
    const count = Math.min(
      Array.isArray(cxValues) || ArrayBuffer.isView(cxValues) ? cxValues.length : 0,
      Array.isArray(cyValues) || ArrayBuffer.isView(cyValues) ? cyValues.length : 0
    );
    if(!count){
      return { values: [], max: 0 };
    }
    const gridResolution = Math.max(10, Math.min(80, Math.round(Math.sqrt(count))));
    const gridX = gridResolution;
    const gridY = gridResolution;
    const cellW = width / gridX;
    const cellH = height / gridY;
    const grid = new Int32Array(gridX * gridY);
    const gxArr = new Int32Array(count);
    const gyArr = new Int32Array(count);
    for(let i = 0; i < count; i += 1){
      const rawX = Number(cxValues[i]);
      const rawY = Number(cyValues[i]);
      const x = Math.min(Math.max((Number.isFinite(rawX) ? rawX : 0) - offsetX, 0), width - 1e-6);
      const y = Math.min(Math.max((Number.isFinite(rawY) ? rawY : 0) - offsetY, 0), height - 1e-6);
      const gx = Math.min(gridX - 1, Math.max(0, Math.floor(x / cellW)));
      const gy = Math.min(gridY - 1, Math.max(0, Math.floor(y / cellH)));
      grid[gy * gridX + gx] += 1;
      gxArr[i] = gx;
      gyArr[i] = gy;
    }
    const values = new Float64Array(count);
    let maxDensity = 0;
    for(let idx = 0; idx < count; idx += 1){
      const gx = gxArr[idx];
      const gy = gyArr[idx];
      let sum = 0;
      let n = 0;
      for(let dy = -1; dy <= 1; dy += 1){
        const ny = gy + dy;
        if(ny < 0 || ny >= gridY){
          continue;
        }
        const row = ny * gridX;
        for(let dx = -1; dx <= 1; dx += 1){
          const nx = gx + dx;
          if(nx < 0 || nx >= gridX){
            continue;
          }
          sum += grid[row + nx];
          n += 1;
        }
      }
      const density = n ? sum / n : 0;
      values[idx] = density;
      if(density > maxDensity){
        maxDensity = density;
      }
    }
    return { values, max: maxDensity };
  }

  function resolveScatterLargeDatasetPolicy(options = {}){
    const graphType = String(options?.graphType || 'scatter').toLowerCase();
    const viewMode = typeof options?.viewMode === 'string'
      ? options.viewMode.toLowerCase()
      : (scatterState.viewMode || '2d');
    const requestedViewMode = typeof options?.requestedViewMode === 'string'
      ? options.requestedViewMode.toLowerCase()
      : viewMode;
    const rowCount = Math.max(0, Number(options?.rowCount) || 0);
    const pointCountRaw = Number(options?.pointCount);
    const pointCount = Math.max(0, Number.isFinite(pointCountRaw) ? pointCountRaw : rowCount);
    const largeRows = rowCount >= SCATTER_POINT_BATCH_THRESHOLD;
    const largePoints = pointCount >= SCATTER_POINT_BATCH_THRESHOLD;
    const is2d = viewMode === '2d';
    const large2dPoints = is2d && largePoints;
    const large2dRows = is2d && largeRows;
    const isPlainScatter = graphType === 'scatter';
    const allowDensity = isPlainScatter && viewMode !== '3d';
    const autoDensity = allowDensity
      && pointCount > SCATTER_DENSITY_POINT_THRESHOLD;
    const collectLabelSet = isPlainScatter && !large2dRows;
    const autoDisableSignificantLabels = (graphType === 'volcano' || graphType === 'ma')
      && !!options?.significantLabelsEnabled
      && !options?.significantLabelsUserModified
      && rowCount > SCATTER_SIGNIFICANT_LABELS_AUTO_OFF_POINT_LIMIT;
    return {
      graphType,
      viewMode,
      requestedViewMode,
      rowCount,
      pointCount,
      largeRows,
      largePoints,
      large2dRows,
      large2dPoints,
      collectLabelSet,
      autoDensity,
      autoDisableSignificantLabels,
      useLargePointMode: large2dPoints
    };
  }

  function resolveScatterColorMode(options){
    const desired = normalizeScatterColorMode(options?.mode);
    const graphType = options?.graphType || 'scatter';
    const viewMode = typeof options?.viewMode === 'string' ? options.viewMode.toLowerCase() : scatterState.viewMode || '2d';
    const pointCount = Number(options?.pointCount) || 0;
    const largeDatasetPolicy = options?.largeDatasetPolicy || resolveScatterLargeDatasetPolicy({
      graphType,
      viewMode,
      pointCount
    });
    const allowDensity = graphType === 'scatter' && viewMode !== '3d';
    const applied = allowDensity && (desired === 'density' || (desired === 'auto' && largeDatasetPolicy.autoDensity))
      ? 'density'
      : 'solid';
    return { desired, applied, allowDensity, largeDatasetPolicy };
  }

  /**
   * Computes an adaptive point size based on the number of data points.
   * More points result in smaller point sizes for better visualization.
   * @param {number} pointCount - The number of data points to display
   * @returns {number} - Point size between SCATTER_ADAPTIVE_SIZE_MIN (1) and SCATTER_ADAPTIVE_SIZE_MAX (3)
   */
  function computeAdaptivePointSize(pointCount){
    const count = Number(pointCount) || 0;
    if(count <= SCATTER_ADAPTIVE_SIZE_THRESHOLD_LOW){
      return SCATTER_ADAPTIVE_SIZE_MAX;
    }
    if(count >= SCATTER_ADAPTIVE_SIZE_THRESHOLD_HIGH){
      return SCATTER_ADAPTIVE_SIZE_MIN;
    }
    // Linear interpolation between thresholds
    const range = SCATTER_ADAPTIVE_SIZE_THRESHOLD_HIGH - SCATTER_ADAPTIVE_SIZE_THRESHOLD_LOW;
    const ratio = (count - SCATTER_ADAPTIVE_SIZE_THRESHOLD_LOW) / range;
    const size = SCATTER_ADAPTIVE_SIZE_MAX - ratio * (SCATTER_ADAPTIVE_SIZE_MAX - SCATTER_ADAPTIVE_SIZE_MIN);
    return Math.max(SCATTER_ADAPTIVE_SIZE_MIN, Math.min(SCATTER_ADAPTIVE_SIZE_MAX, size));
  }

  function ensureScatterTooltipHost(tooltip, doc){
    if(!tooltip){ return null; }
    const documentRef = doc || tooltip.ownerDocument || global.document;
    if(!documentRef){ return tooltip; }
    const parent = tooltip.parentElement;
    if(!parent){ return tooltip; }
    let needsDetach = false;
    if(typeof tooltip.closest === 'function'){
      const hiddenAncestor = tooltip.closest('[hidden]');
      if(hiddenAncestor && hiddenAncestor !== tooltip){
        needsDetach = true;
      }
    }
    if(!needsDetach){
      try{
        const view = documentRef.defaultView;
        if(view && typeof view.getComputedStyle === 'function'){
          const parentDisplay = view.getComputedStyle(parent).display;
          if(parentDisplay === 'none'){
            needsDetach = true;
          }
        }else if(typeof parent.style?.display === 'string' && parent.style.display === 'none'){
          needsDetach = true;
        }
      }catch(err){
        scatterDebug('Debug: scatter tooltip host inspection error',{ error: err?.message || String(err) });
      }
    }
    const host = documentRef.body || documentRef.documentElement;
    if(needsDetach && host && parent !== host){
      host.appendChild(tooltip);
      scatterDebug('Debug: scatter tooltip host realigned',{ previousParent: parent.id || parent.className || parent.tagName || null });
    }
    return tooltip;
  }

  function getScatterTooltipElement(){
    if(scatterTooltipEl && scatterTooltipEl.isConnected){
      return scatterTooltipEl;
    }
    const doc = global.document;
    const tooltip = scatterRefs.tooltip || doc?.getElementById?.('tooltip') || null;
    if(tooltip){
      ensureScatterTooltipHost(tooltip, doc);
      scatterTooltipEl = tooltip;
      scatterRefs.tooltip = tooltip;
    }
    return scatterTooltipEl;
  }

  function formatScatterTooltipNumber(value){
    const formatter = Shared.formatters?.formatShortNumber;
    if(typeof formatter === 'function'){
      return formatter(value, { emptyValue: 'n/a' });
    }
    if(value === null || value === undefined){ return 'n/a'; }
    if(typeof value === 'number'){
      if(!Number.isFinite(value)){ return String(value); }
      return value.toLocaleString('en-US',{ maximumSignificantDigits: 6 });
    }
    const numeric = Number(value);
    if(Number.isFinite(numeric)){
      return numeric.toLocaleString('en-US',{ maximumSignificantDigits: 6 });
    }
    return String(value);
  }

  function updateScatterTooltipContent(tooltip, data){
    if(!tooltip || !data){ return false; }
    const doc = tooltip.ownerDocument || global.document;
    tooltip.textContent = '';
    tooltip.style.fontSize = '12px';
    tooltip.style.columnCount = 1;
    tooltip.style.columnWidth = 'auto';
    tooltip.style.columnGap = '0';
    tooltip.style.maxWidth = '320px';
    tooltip.style.maxHeight = 'none';
    tooltip.style.width = 'auto';
    tooltip.style.height = 'auto';
    tooltip.style.whiteSpace = 'normal';
    tooltip.style.overflow = 'visible';
    const fragment = doc.createDocumentFragment();
    const appendRow = (text, bold) => {
      if(!text){ return; }
      const row = doc.createElement('div');
      if(bold){ row.style.fontWeight = '600'; }
      row.textContent = text;
      fragment.appendChild(row);
    };
    if(data.label){
      appendRow(data.label, true);
    }
    appendRow(`X: ${formatScatterTooltipNumber(data.x)}`);
    appendRow(`Y: ${formatScatterTooltipNumber(data.y)}`);
    if(data.isGroupedReplicatePoint){
      const replicateSuffix = Number.isInteger(data.groupedReplicateIndex)
        ? ` #${data.groupedReplicateIndex}`
        : '';
      appendRow(`Grouped replicate${replicateSuffix}`);
    }
    if(data.z !== undefined){
      appendRow(`Z: ${formatScatterTooltipNumber(data.z)}`);
    }
    if(data.size !== undefined){
      appendRow(`Size: ${formatScatterTooltipNumber(data.size)}`);
    }
    if(data.logXValue !== undefined && data.logXValue !== data.x){
      appendRow(`Log X: ${formatScatterTooltipNumber(data.logXValue)}`);
    }
    if(data.logYValue !== undefined && data.logYValue !== data.y){
      appendRow(`Log Y: ${formatScatterTooltipNumber(data.logYValue)}`);
    }
    if(typeof data.series === 'string' && data.series){
      appendRow(`Series: ${data.series}`);
    }
    if(Array.isArray(data.replicates) && data.replicates.length){
      const values = data.replicates.map(formatScatterTooltipNumber).join(', ');
      appendRow(`Replicates (${data.replicates.length}): ${values}`);
    }
    if(Array.isArray(data.replicates) && data.replicates.length > 1 && Number.isFinite(data.stdev)){
      appendRow(`Std Dev: ${formatScatterTooltipNumber(data.stdev)}`);
    }
    if(Array.isArray(data.xReplicates) && data.xReplicates.length){
      const values = data.xReplicates.map(formatScatterTooltipNumber).join(', ');
      appendRow(`X replicates (${data.xReplicates.length}): ${values}`);
    }
    if(Array.isArray(data.xReplicates) && data.xReplicates.length > 1 && Number.isFinite(data.xStdev)){
      appendRow(`X Std Dev: ${formatScatterTooltipNumber(data.xStdev)}`);
    }
    if(data.graphType && data.graphType !== 'scatter'){
      appendRow(`Graph: ${data.graphType.toUpperCase()}`);
      if(typeof data.isSignificant === 'boolean'){
        appendRow(`Significant: ${data.isSignificant ? 'Yes' : 'No'}`);
      }
    }
    if(!fragment.childNodes.length){
      return false;
    }
    tooltip.appendChild(fragment);
    return true;
  }

  function getScatterEventPagePosition(evt){
    const win = global.window;
    const scrollX = win?.scrollX ?? win?.pageXOffset ?? global.document?.documentElement?.scrollLeft ?? 0;
    const scrollY = win?.scrollY ?? win?.pageYOffset ?? global.document?.documentElement?.scrollTop ?? 0;
    const pageX = typeof evt?.pageX === 'number' ? evt.pageX : ((evt?.clientX || 0) + scrollX);
    const pageY = typeof evt?.pageY === 'number' ? evt.pageY : ((evt?.clientY || 0) + scrollY);
    return { x: pageX, y: pageY };
  }

  function positionScatterTooltipAt(tooltip, pageX, pageY){
    if(!tooltip){ return; }
    const win = global.window;
    const offset = 12;
    let left = pageX + offset;
    let top = pageY + offset;
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
    const rect = tooltip.getBoundingClientRect();
    const scrollX = win?.scrollX ?? win?.pageXOffset ?? global.document?.documentElement?.scrollLeft ?? 0;
    const scrollY = win?.scrollY ?? win?.pageYOffset ?? global.document?.documentElement?.scrollTop ?? 0;
    const maxX = scrollX + (win?.innerWidth ?? rect.width) - 8;
    const maxY = scrollY + (win?.innerHeight ?? rect.height) - 8;
    if(rect.right > maxX){
      left = Math.max(scrollX + 8, maxX - rect.width);
    }
    if(rect.bottom > maxY){
      top = Math.max(scrollY + 8, maxY - rect.height);
    }
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  function hideScatterTooltip(reason){
    const tooltip = getScatterTooltipElement();
    if(!tooltip){ return; }
    const wasVisible = tooltip.style.display !== 'none';
    tooltip.style.display = 'none';
    tooltip.textContent = '';
    tooltip.style.width = 'auto';
    tooltip.style.height = 'auto';
    if(wasVisible){
      scatterDebug('Debug: scatter tooltip hide',{ reason });
    }
  }

  function clampScatterValue(value, min, max){
    if(!Number.isFinite(value)){
      return Number.isFinite(min) ? min : 0;
    }
    if(Number.isFinite(min) && value < min){
      return min;
    }
    if(Number.isFinite(max) && value > max){
      return max;
    }
    return value;
  }

  function computeScatterManualLabelLayout(entries, options){
    const labelLayout = Shared.labelLayout;
    if(labelLayout && typeof labelLayout.computePointLabelLayout === 'function'){
      return labelLayout.computePointLabelLayout(entries, options);
    }
    return [];
  }

  function computeScatterManualLabelFontSize(baseFontSize, labelCount, plotWidth, plotHeight){
    const labelLayout = Shared.labelLayout;
    if(labelLayout && typeof labelLayout.computePointLabelFontSize === 'function'){
      return labelLayout.computePointLabelFontSize(baseFontSize, labelCount, plotWidth, plotHeight);
    }
    const safeBase = Math.max(5, Number(baseFontSize) || 10);
    return safeBase;
  }

  function computeScatterLabelBounds3d(corners, project){
    if(!Array.isArray(corners) || typeof project !== 'function'){
      return null;
    }
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for(let i = 0; i < corners.length; i += 1){
      const projected = project(corners[i]);
      const x = Number(projected?.x);
      const y = Number(projected?.y);
      if(!Number.isFinite(x) || !Number.isFinite(y)){
        continue;
      }
      if(x < minX){ minX = x; }
      if(x > maxX){ maxX = x; }
      if(y < minY){ minY = y; }
      if(y > maxY){ maxY = y; }
    }
    if(!Number.isFinite(minX) || !Number.isFinite(maxX) || !Number.isFinite(minY) || !Number.isFinite(maxY)){
      return null;
    }
    if(minX === maxX || minY === maxY){
      return null;
    }
    return { minX, maxX, minY, maxY };
  }



  function normalizeScatterHeader(value){
    return String(value ?? '').trim().toLowerCase();
  }

  function isScatterLabelHeader(value){
    const normalized = normalizeScatterHeader(value);
    return normalized === 'label' || normalized === 'gene' || normalized === 'name';
  }

  function clampScatterReplicateCount(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return SCATTER_MIN_REPLICATES;
    }
    return Math.max(
      SCATTER_MIN_REPLICATES,
      Math.min(SCATTER_MAX_REPLICATES, Math.round(numeric))
    );
  }

  function normalizeScatterTableFormat(value){
    const normalized = String(value || '').trim().toLowerCase();
    return normalized === SCATTER_TABLE_FORMAT_GROUPED
      ? SCATTER_TABLE_FORMAT_GROUPED
      : SCATTER_TABLE_FORMAT_SINGLE;
  }

  function isScatterGroupedMode(options = {}){
    const graphType = String(options.graphType || scatterCurrentGraphType || 'scatter').trim().toLowerCase();
    const tableFormat = normalizeScatterTableFormat(options.tableFormat || scatterTableFormat);
    return graphType === 'scatter' && tableFormat === SCATTER_TABLE_FORMAT_GROUPED;
  }

  function normalizeScatterGroupedXReplicates(value){
    return value === true;
  }

  function isScatterGroupedXReplicatesEnabled(options = {}){
    if(typeof options.xReplicatesEnabled === 'boolean'){
      return options.xReplicatesEnabled;
    }
    if(typeof options.groupedXReplicates === 'boolean'){
      return options.groupedXReplicates;
    }
    return !!scatterGroupedXReplicates;
  }

  function getScatterGroupedXReplicateCount(replicates, options = {}){
    const safeReplicates = clampScatterReplicateCount(replicates ?? scatterReplicates);
    return isScatterGroupedXReplicatesEnabled(options) ? safeReplicates : 1;
  }

  function getScatterGroupedBaseCols(replicates, options = {}){
    const xReplicateCount = getScatterGroupedXReplicateCount(replicates, options);
    return 1 + xReplicateCount;
  }

  function getScatterGroupedSeriesStartCol(seriesIndex, replicates, options = {}){
    const safeSeriesIndex = Math.max(0, Number(seriesIndex) || 0);
    const safeReplicates = clampScatterReplicateCount(replicates ?? scatterReplicates);
    const baseCols = getScatterGroupedBaseCols(safeReplicates, options);
    return baseCols + safeSeriesIndex * safeReplicates;
  }

  function sanitizeScatterGroupLabel(value, index){
    const trimmed = value == null ? '' : String(value).trim();
    return trimmed || `Group ${index + 1}`;
  }

  function formatScatterGroupHeaderTitle(value, index){
    const trimmed = value == null ? '' : String(value).trim();
    if(!trimmed){
      return `Group ${index + 1} title`;
    }
    if(/^group\s*\d+$/i.test(trimmed)){
      return `${trimmed} title`;
    }
    return trimmed;
  }

  function inferScatterGroupBaseName(value, fallback){
    const base = value == null ? '' : String(value).trim();
    if(!base){
      return fallback;
    }
    if(/^y\s*title$/i.test(base) || /^z\s*title$/i.test(base)){
      return fallback;
    }
    if(/^rep(?:licate)?\s*\d+$/i.test(base)){
      return fallback;
    }
    const stripped = base
      .replace(/[:\-]\s*rep(?:licate)?\s*\d+$/i, '')
      .replace(/\s+rep(?:licate)?\s*\d+$/i, '')
      .replace(/\s+title$/i, '')
      .replace(/[:\-]\s*$/, '')
      .trim();
    return stripped || fallback;
  }

  function normalizeScatterGroupLabels(count, sourceLabels, baseNames){
    const target = Math.max(0, Number(count) || 0);
    const resolved = new Array(target).fill('');
    for(let i = 0; i < target; i += 1){
      const candidate = Array.isArray(sourceLabels) ? sourceLabels[i] : null;
      const base = Array.isArray(baseNames) ? baseNames[i] : null;
      resolved[i] = sanitizeScatterGroupLabel(candidate != null && String(candidate).trim() ? candidate : base, i);
    }
    return resolved;
  }

  function getScatterGroupedHeaderCellRole(colIndex, options = {}){
    const col = Number(colIndex);
    if(!Number.isInteger(col) || col < 0){
      return null;
    }
    const groupedActive = options.forceGrouped === true
      ? true
      : isScatterGroupedMode({
          graphType: options.graphType || scatterCurrentGraphType,
          tableFormat: options.tableFormat || scatterTableFormat
        });
    if(!groupedActive){
      return null;
    }
    const replicates = clampScatterReplicateCount(options.replicates ?? scatterReplicates);
    const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
    const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
    const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
    if(col === 0){
      return 'label';
    }
    if(col >= 1 && col < baseCols){
      return col === 1 ? 'xAnchor' : 'xFollower';
    }
    if(col >= baseCols){
      const offset = col - baseCols;
      if(replicates <= 1){
        return 'groupAnchor';
      }
      return offset % replicates === 0 ? 'groupAnchor' : 'groupFollower';
    }
    return null;
  }

  function getScatterGroupedHeaderMergeSegment(colIndex, options = {}){
    const col = Number(colIndex);
    if(!Number.isInteger(col) || col < 0){
      return null;
    }
    const role = getScatterGroupedHeaderCellRole(col, options);
    if(!role){
      return null;
    }
    const replicates = clampScatterReplicateCount(options.replicates ?? scatterReplicates);
    const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
    const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
    const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
    if(role === 'xAnchor'){
      return xReplicateCount > 1 ? 'start' : 'single';
    }
    if(role === 'xFollower'){
      const position = col - 1;
      return position === xReplicateCount - 1 ? 'end' : 'middle';
    }
    if(role === 'groupAnchor'){
      return replicates > 1 ? 'start' : 'single';
    }
    if(role === 'groupFollower'){
      const position = (col - baseCols) % replicates;
      return position === replicates - 1 ? 'end' : 'middle';
    }
    return null;
  }

  function normalizeScatterGroupedHeaderRow(hotInstance, options = {}){
    const hot = hotInstance || scatterHot || scatterRefs.hot;
    if(!hot || typeof hot.getData !== 'function' || typeof hot.setDataAtCell !== 'function'){
      return false;
    }
    const groupedActive = options.forceGrouped === true
      ? true
      : isScatterGroupedMode({
          graphType: options.graphType || scatterCurrentGraphType,
          tableFormat: options.tableFormat || scatterTableFormat
        });
    if(!groupedActive){
      return false;
    }
    const data = hot.getData() || [];
    const headerRow = Array.isArray(data[0]) ? data[0] : [];
    const shouldFill = value => value == null || String(value).trim() === '';
    const replicates = clampScatterReplicateCount(options.replicates ?? scatterReplicates);
    const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
    const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
    const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
    const usedSeriesCols = computeScatterUsedSeriesColumns(data, { startCol: baseCols, replicates, xReplicatesEnabled });
    const seriesCount = Math.max(1, Math.ceil(usedSeriesCols / Math.max(replicates, 1)));
    const minCols = baseCols + seriesCount * replicates;
    const changes = [];
    for(let c = headerRow.length; c < minCols; c += 1){
      changes.push([0, c, '']);
    }
    if(shouldFill(headerRow[0])){
      changes.push([0, 0, 'Labels']);
    }
    const xAnchorRaw = headerRow[1] != null ? String(headerRow[1]).trim() : '';
    const genericLegacyXHeader = /^x(?:\s*(?:value|values|title))?$/i.test(xAnchorRaw);
    const xAnchorValue = (!xAnchorRaw || genericLegacyXHeader) ? 'X title' : xAnchorRaw;
    if(String(headerRow[1] ?? '').trim() !== xAnchorValue){
      changes.push([0, 1, xAnchorValue]);
    }
    for(let xRep = 1; xRep < xReplicateCount; xRep += 1){
      const xCol = 1 + xRep;
      const xValue = headerRow[xCol];
      if(xValue != null && String(xValue).trim() !== ''){
        changes.push([0, xCol, '']);
      }
    }
    const baseNames = [];
    for(let s = 0; s < seriesCount; s += 1){
      const startCol = getScatterGroupedSeriesStartCol(s, replicates, { xReplicatesEnabled });
      const raw = headerRow[startCol] != null ? String(headerRow[startCol]).trim() : '';
      baseNames.push(raw || `Group ${s + 1}`);
    }
    const labels = normalizeScatterGroupLabels(seriesCount, scatterSeriesGroupLabels, baseNames);
    for(let s = 0; s < seriesCount; s += 1){
      const startCol = getScatterGroupedSeriesStartCol(s, replicates, { xReplicatesEnabled });
      const currentRaw = headerRow[startCol] != null ? String(headerRow[startCol]).trim() : '';
      const genericLegacyHeader = /^rep(?:licate)?\s*\d+$/i.test(currentRaw)
        || /^series\s*\d+$/i.test(currentRaw)
        || /^y\s*title$/i.test(currentRaw)
        || /^z\s*title$/i.test(currentRaw);
      const usableRaw = genericLegacyHeader ? '' : currentRaw;
      const nextBaseLabel = inferScatterGroupBaseName(
        sanitizeScatterGroupLabel(usableRaw || labels[s], s),
        `Group ${s + 1}`
      );
      labels[s] = nextBaseLabel;
      const nextHeaderLabel = formatScatterGroupHeaderTitle(usableRaw || nextBaseLabel, s);
      if(currentRaw !== nextHeaderLabel){
        changes.push([0, startCol, nextHeaderLabel]);
      }
      for(let rep = 1; rep < replicates; rep += 1){
        const col = startCol + rep;
        const repValue = headerRow[col];
        if(repValue != null && String(repValue).trim() !== ''){
          changes.push([0, col, '']);
        }
      }
    }
    scatterSeriesGroupLabels = labels.slice();
    if(!changes.length){
      return false;
    }
    hot.setDataAtCell(changes, options.source || 'scatter-grouped-header-normalize');
    scatterDebug('Debug: scatter grouped header row normalized', {
      changes: changes.length,
      seriesCount,
      replicates,
      xReplicateCount
    });
    return true;
  }

  function getScatterGroupedSeriesCount(colCount, replicates, options = {}){
    const safeCols = Math.max(0, Number(colCount) || 0);
    const safeReplicates = Math.max(SCATTER_MIN_REPLICATES, Number(replicates) || SCATTER_MIN_REPLICATES);
    const baseCols = getScatterGroupedBaseCols(safeReplicates, options);
    const yCols = Math.max(0, safeCols - baseCols);
    return Math.max(1, Math.ceil(yCols / safeReplicates));
  }

  function padScatterRowToLength(row, length){
    const target = Math.max(0, Number(length) || 0);
    const src = Array.isArray(row) ? row.slice() : [];
    if(src.length >= target){
      return src;
    }
    while(src.length < target){
      src.push('');
    }
    return src;
  }

  function computeScatterUsedSeriesColumns(matrix, options = {}){
    const defaultStartCol = getScatterGroupedBaseCols(
      clampScatterReplicateCount(options.replicates ?? scatterReplicates),
      options
    );
    const startCol = Number.isInteger(options.startCol) ? options.startCol : defaultStartCol;
    const maxCol = Number.isInteger(options.maxCol) ? options.maxCol : null;
    if(!Array.isArray(matrix) || !matrix.length){
      return 0;
    }
    const hasValue = value => value != null && String(value).trim() !== '';
    let maxUsed = startCol - 1;
    for(let r = 0; r < matrix.length; r += 1){
      const row = Array.isArray(matrix[r]) ? matrix[r] : [];
      const upper = Number.isInteger(maxCol) ? Math.min(row.length - 1, maxCol) : (row.length - 1);
      for(let c = Math.max(0, startCol); c <= upper; c += 1){
        if(hasValue(row[c]) && c > maxUsed){
          maxUsed = c;
        }
      }
    }
    if(maxUsed < startCol){
      return 0;
    }
    return (maxUsed - startCol) + 1;
  }

  function summarizeScatterReplicateValues(values){
    const numeric = Array.isArray(values) ? values.filter(Number.isFinite) : [];
    if(!numeric.length){
      return { value: '', numericCount: 0 };
    }
    const mean = numeric.reduce((sum, value) => sum + value, 0) / numeric.length;
    return { value: mean, numericCount: numeric.length };
  }

  function isScatterMatrixEmpty(matrix){
    if(!Array.isArray(matrix) || !matrix.length){
      return true;
    }
    for(let r = 1; r < matrix.length; r += 1){
      const row = Array.isArray(matrix[r]) ? matrix[r] : [];
      for(let c = 0; c < row.length; c += 1){
        const value = row[c];
        if(value != null && String(value).trim() !== ''){
          return false;
        }
      }
    }
    return true;
  }

  function buildScatterReplicateMatrix(matrix, sourceReplicates, targetReplicates, options = {}){
    const sourceCount = clampScatterReplicateCount(sourceReplicates);
    const targetCount = clampScatterReplicateCount(targetReplicates);
    const sourceFormat = normalizeScatterTableFormat(options.sourceFormat);
    const targetXReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
    const sourceXReplicatesEnabled = sourceFormat === SCATTER_TABLE_FORMAT_GROUPED
      ? normalizeScatterGroupedXReplicates(options.sourceXReplicatesEnabled)
      : false;
    const sourceXReplicateCount = sourceFormat === SCATTER_TABLE_FORMAT_GROUPED
      ? getScatterGroupedXReplicateCount(sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled })
      : 1;
    const targetXReplicateCount = getScatterGroupedXReplicateCount(targetCount, { xReplicatesEnabled: targetXReplicatesEnabled });
    const sourceBaseCols = sourceFormat === SCATTER_TABLE_FORMAT_GROUPED
      ? getScatterGroupedBaseCols(sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled })
      : SCATTER_GROUPED_BASE_COLS;
    const targetBaseCols = getScatterGroupedBaseCols(targetCount, { xReplicatesEnabled: targetXReplicatesEnabled });
    const safeMatrix = Array.isArray(matrix)
      ? matrix.map(row => (Array.isArray(row) ? row.slice() : []))
      : [];
    const minSeriesCount = Math.max(1, Number(options.minSeriesCount) || 1);
    const desiredSeriesCount = Number.isInteger(options.seriesCount)
      ? Math.max(1, options.seriesCount)
      : (Array.isArray(options.groupLabels) && options.groupLabels.length ? options.groupLabels.length : null);
    const usedSeriesCols = sourceFormat === SCATTER_TABLE_FORMAT_SINGLE
      ? (computeScatterUsedSeriesColumns(safeMatrix, { startCol: 2, maxCol: 2 }) > 0 ? 1 : 0)
      : computeScatterUsedSeriesColumns(safeMatrix, { startCol: sourceBaseCols });
    const inferredSeriesCount = Math.max(minSeriesCount, Math.ceil(usedSeriesCols / Math.max(sourceCount, 1)));
    const seriesCount = Math.max(1, desiredSeriesCount || inferredSeriesCount);
    const targetCols = targetBaseCols + seriesCount * targetCount;
    const totalRows = Math.max(safeMatrix.length, DEFAULT_ROWS);
    const headerRow = padScatterRowToLength(safeMatrix[0] || [], Math.max(targetCols, SCATTER_SINGLE_FIXED_COLS));
    const labelHeader = headerRow[0] != null && String(headerRow[0]).trim() ? headerRow[0] : 'Labels';
    const sourceXHeader = headerRow[1] != null && String(headerRow[1]).trim() ? headerRow[1] : 'X title';
    const xHeaderBase = inferScatterGroupBaseName(sourceXHeader, 'X title');
    const baseNames = [];
    for(let s = 0; s < seriesCount; s += 1){
      const fallback = `Group ${s + 1}`;
      const sourceIndex = sourceFormat === SCATTER_TABLE_FORMAT_SINGLE
        ? (s === 0 ? 2 : -1)
        : getScatterGroupedSeriesStartCol(s, sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled });
      let candidate = sourceIndex >= 0 && sourceIndex < headerRow.length ? headerRow[sourceIndex] : null;
      if(sourceFormat === SCATTER_TABLE_FORMAT_SINGLE){
        candidate = null;
      }
      baseNames.push(inferScatterGroupBaseName(candidate, fallback));
    }
    const nextGroupLabels = normalizeScatterGroupLabels(seriesCount, options.groupLabels || scatterSeriesGroupLabels, baseNames);
    scatterSeriesGroupLabels = nextGroupLabels.slice();
    const newHeader = new Array(targetCols).fill('');
    newHeader[0] = labelHeader;
    for(let rep = 0; rep < targetXReplicateCount; rep += 1){
      const newXCol = 1 + rep;
      const oldXCol = sourceFormat === SCATTER_TABLE_FORMAT_GROUPED
        ? (1 + Math.min(rep, sourceXReplicateCount - 1))
        : 1;
      const oldLabel = oldXCol >= 0 && oldXCol < headerRow.length
        ? headerRow[oldXCol]
        : '';
      const trimmed = oldLabel == null ? '' : String(oldLabel).trim();
      if(rep === 0){
        newHeader[newXCol] = trimmed || xHeaderBase;
      }else{
        newHeader[newXCol] = '';
      }
    }
    for(let s = 0; s < seriesCount; s += 1){
      const groupLabel = scatterSeriesGroupLabels[s] || `Group ${s + 1}`;
      for(let rep = 0; rep < targetCount; rep += 1){
        const newIdx = getScatterGroupedSeriesStartCol(s, targetCount, { xReplicatesEnabled: targetXReplicatesEnabled }) + rep;
        if(rep === 0){
          let label = '';
          if(rep < sourceCount){
            const oldIdx = sourceFormat === SCATTER_TABLE_FORMAT_SINGLE
              ? (s === 0 ? 2 : -1)
              : getScatterGroupedSeriesStartCol(s, sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled });
            if(oldIdx >= 0 && oldIdx < headerRow.length){
              label = headerRow[oldIdx];
            }
          }
          const labelTrimmed = typeof label === 'string' ? label.trim() : '';
          const usableLabel = /^rep(?:licate)?\s*\d+$/i.test(labelTrimmed) ? '' : labelTrimmed;
          newHeader[newIdx] = formatScatterGroupHeaderTitle(usableLabel || groupLabel, s);
        }else{
          newHeader[newIdx] = '';
        }
      }
    }
    const newData = new Array(totalRows);
    newData[0] = padScatterRowToLength(newHeader, targetCols);
    for(let r = 1; r < totalRows; r += 1){
      const srcRow = padScatterRowToLength(safeMatrix[r] || [], Math.max(targetCols, SCATTER_SINGLE_FIXED_COLS));
      const newRow = new Array(targetCols).fill('');
      newRow[0] = srcRow[0] ?? '';
      const sourceXValues = [];
      if(sourceFormat === SCATTER_TABLE_FORMAT_GROUPED){
        for(let rep = 0; rep < sourceXReplicateCount; rep += 1){
          sourceXValues.push(srcRow[1 + rep]);
        }
      }else{
        sourceXValues.push(srcRow[1]);
      }
      const sourceNumericX = sourceXValues
        .map(value => parseFloat(value))
        .filter(Number.isFinite);
      for(let rep = 0; rep < targetXReplicateCount; rep += 1){
        const newXCol = 1 + rep;
        let value = sourceXValues[Math.min(rep, sourceXValues.length - 1)];
        if(targetXReplicateCount === 1 && sourceXReplicateCount > 1){
          const summary = summarizeScatterReplicateValues(sourceNumericX);
          value = summary.numericCount ? summary.value : sourceXValues[0];
        }else if(targetXReplicateCount > 1 && sourceXReplicateCount <= 1){
          value = sourceXValues[0];
        }
        newRow[newXCol] = value ?? '';
      }
      for(let s = 0; s < seriesCount; s += 1){
        for(let rep = 0; rep < targetCount; rep += 1){
          const newIdx = getScatterGroupedSeriesStartCol(s, targetCount, { xReplicatesEnabled: targetXReplicatesEnabled }) + rep;
          let value = '';
          if(rep < sourceCount){
            const oldIdx = sourceFormat === SCATTER_TABLE_FORMAT_SINGLE
              ? (s === 0 ? 2 : -1)
              : (getScatterGroupedSeriesStartCol(s, sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled }) + rep);
            if(oldIdx >= 0 && oldIdx < srcRow.length){
              value = srcRow[oldIdx];
            }
          }
          newRow[newIdx] = value ?? '';
        }
      }
      newData[r] = padScatterRowToLength(newRow, targetCols);
    }
    scatterDebug('Debug: scatter buildReplicateMatrix', {
      sourceCount,
      targetCount,
      sourceFormat,
      sourceXReplicateCount,
      targetXReplicateCount,
      targetXReplicatesEnabled,
      seriesCount,
      targetCols
    });
    return {
      data: newData,
      seriesCount,
      targetCols,
      groupLabels: scatterSeriesGroupLabels.slice()
    };
  }

  function buildScatterSingleMatrixFromGrouped(matrix, sourceReplicates, options = {}){
    const sourceCount = clampScatterReplicateCount(sourceReplicates);
    const sourceXReplicatesEnabled = normalizeScatterGroupedXReplicates(
      options.xReplicatesEnabled ?? options.sourceXReplicatesEnabled ?? scatterGroupedXReplicates
    );
    const sourceXReplicateCount = getScatterGroupedXReplicateCount(sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled });
    const sourceBaseCols = getScatterGroupedBaseCols(sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled });
    const safeMatrix = Array.isArray(matrix)
      ? matrix.map(row => (Array.isArray(row) ? row.slice() : []))
      : [];
    const headerRow = Array.isArray(safeMatrix[0]) ? safeMatrix[0] : [];
    const usedSeriesCols = computeScatterUsedSeriesColumns(safeMatrix, { startCol: sourceBaseCols, replicates: sourceCount, xReplicatesEnabled: sourceXReplicatesEnabled });
    const seriesCount = Math.max(1, Math.ceil(usedSeriesCols / Math.max(sourceCount, 1)));
    const baseNames = [];
    for(let s = 0; s < seriesCount; s += 1){
      const idx = getScatterGroupedSeriesStartCol(s, sourceCount, { xReplicatesEnabled: sourceXReplicatesEnabled });
      baseNames.push(inferScatterGroupBaseName(headerRow[idx], `Group ${s + 1}`));
    }
    const groupLabels = normalizeScatterGroupLabels(
      seriesCount,
      options.groupLabels || scatterSeriesGroupLabels,
      baseNames
    );
    const labelHeader = headerRow[0] != null && String(headerRow[0]).trim() ? headerRow[0] : 'Labels';
    const xHeader = headerRow[1] != null && String(headerRow[1]).trim()
      ? inferScatterGroupBaseName(headerRow[1], 'X title')
      : 'X title';
    const yHeader = groupLabels[0] || 'Y title';
    const singleRows = [[labelHeader, xHeader, yHeader, 'Z title', '']];
    for(let r = 1; r < safeMatrix.length; r += 1){
      const row = Array.isArray(safeMatrix[r]) ? safeMatrix[r] : [];
      const labelBase = row[0] == null ? '' : String(row[0]).trim();
      const xReplicateValues = [];
      const xRawValues = [];
      for(let xCol = 1; xCol <= sourceXReplicateCount; xCol += 1){
        const rawX = row[xCol];
        if(rawX == null || rawX === ''){
          continue;
        }
        xRawValues.push(rawX);
        const numericX = parseFloat(rawX);
        if(Number.isFinite(numericX)){
          xReplicateValues.push(numericX);
        }
      }
      const xSummary = summarizeScatterReplicateValues(xReplicateValues);
      const xRaw = xSummary.numericCount ? xSummary.value : (xRawValues[0] ?? '');
      for(let s = 0; s < seriesCount; s += 1){
        const repValues = [];
        for(let rep = 0; rep < sourceCount; rep += 1){
          const colIndex = sourceBaseCols + s * sourceCount + rep;
          if(colIndex >= row.length){
            continue;
          }
          const numeric = parseFloat(row[colIndex]);
          if(Number.isFinite(numeric)){
            repValues.push(numeric);
          }
        }
        if(!repValues.length){
          continue;
        }
        const mean = repValues.reduce((sum, value) => sum + value, 0) / repValues.length;
        const safeGroupLabel = groupLabels[s] || `Group ${s + 1}`;
        const pointLabel = labelBase
          ? `${labelBase} (${safeGroupLabel})`
          : safeGroupLabel;
        singleRows.push([pointLabel, xRaw, mean, '', '']);
      }
    }
    while(singleRows.length < DEFAULT_ROWS){
      singleRows.push(['', '', '', '', '']);
    }
    scatterDebug('Debug: scatter buildSingleMatrixFromGrouped', {
      sourceCount,
      seriesCount,
      rows: singleRows.length
    });
    return { data: singleRows };
  }

  function convertScatterLineImportToGroupedMatrix(matrix, options = {}){
    const replicateCount = clampScatterReplicateCount(options.replicates ?? scatterReplicates);
    const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
    const xReplicateCount = getScatterGroupedXReplicateCount(replicateCount, { xReplicatesEnabled });
    const baseCols = getScatterGroupedBaseCols(replicateCount, { xReplicatesEnabled });
    const safeMatrix = Array.isArray(matrix)
      ? matrix.map(row => (Array.isArray(row) ? row.slice() : []))
      : [];
    const sourceHeader = Array.isArray(safeMatrix[0]) ? safeMatrix[0] : [];
    const sourceCols = Math.max(1, sourceHeader.length);
    const yCols = Math.max(1, sourceCols - 1);
    const targetCols = Math.max(baseCols + yCols, SCATTER_SINGLE_FIXED_COLS);
    const totalRows = Math.max(DEFAULT_ROWS, safeMatrix.length || 1);
    const xHeader = sourceHeader[0] != null && String(sourceHeader[0]).trim()
      ? String(sourceHeader[0]).trim()
      : 'X title';
    const converted = new Array(totalRows);
    const header = new Array(targetCols).fill('');
    header[0] = 'Labels';
    for(let xRep = 0; xRep < xReplicateCount; xRep += 1){
      const xHeaderCol = 1 + xRep;
      header[xHeaderCol] = xReplicateCount > 1 ? `X rep ${xRep + 1}` : xHeader;
    }
    if(sourceCols > 1){
      for(let c = 1; c < sourceCols; c += 1){
        header[baseCols + (c - 1)] = sourceHeader[c] != null ? sourceHeader[c] : '';
      }
    }else{
      header[baseCols] = 'Rep 1';
    }
    converted[0] = header;
    for(let r = 1; r < totalRows; r += 1){
      const srcRow = Array.isArray(safeMatrix[r]) ? safeMatrix[r] : [];
      const nextRow = new Array(targetCols).fill('');
      nextRow[0] = '';
      for(let xRep = 0; xRep < xReplicateCount; xRep += 1){
        nextRow[1 + xRep] = srcRow[0] ?? '';
      }
      for(let c = 1; c < sourceCols; c += 1){
        nextRow[baseCols + (c - 1)] = srcRow[c] ?? '';
      }
      converted[r] = nextRow;
    }
    return converted;
  }

  function ensureScatterHeaderTitles(hotInstance, options = {}){
    const hot = hotInstance;
    if(!hot || typeof hot.getData !== 'function' || typeof hot.setDataAtCell !== 'function'){
      return;
    }
    const data = hot.getData() || [];
    const headerRow = Array.isArray(data[0]) ? data[0] : [];
    const shouldFill = value => value == null || String(value).trim() === '';
    const changes = [];
    const groupedMode = isScatterGroupedMode({ graphType: options.graphType });
    const hasHeaderValues = groupedMode
      ? [0, 1, 2].some(idx => !shouldFill(headerRow[idx]))
      : [0, 1, 2, 3].some(idx => !shouldFill(headerRow[idx]));
    const hasData = data.some((row, rowIdx) => {
      if(rowIdx === 0 || !Array.isArray(row)){
        return false;
      }
      return row.some(cell => !shouldFill(cell));
    });
    if(!hasHeaderValues && !hasData){
      changes.push([0, 0, 'Labels']);
      if(groupedMode){
        const replicates = clampScatterReplicateCount(scatterReplicates);
        const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
        const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
        const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
        const usedSeriesCols = computeScatterUsedSeriesColumns(data, { startCol: baseCols, replicates, xReplicatesEnabled });
        const inferredGroupCount = Math.max(1, Math.ceil(usedSeriesCols / Math.max(replicates, 1)));
        const seededGroupCount = Array.isArray(scatterSeriesGroupLabels) && scatterSeriesGroupLabels.length
          ? scatterSeriesGroupLabels.length
          : SCATTER_DEFAULT_GROUP_COUNT;
        const groupCount = Math.max(
          SCATTER_DEFAULT_GROUP_COUNT,
          seededGroupCount,
          inferredGroupCount
        );
        const labels = normalizeScatterGroupLabels(groupCount, scatterSeriesGroupLabels, null);
        scatterSeriesGroupLabels = labels.slice();
        const minCols = baseCols + groupCount * replicates;
        for(let c = headerRow.length; c < minCols; c += 1){
          changes.push([0, c, '']);
        }
        for(let xRep = 0; xRep < xReplicateCount; xRep += 1){
          const xCol = 1 + xRep;
          const xFallback = xRep === 0 ? 'X title' : '';
          changes.push([0, xCol, xFallback]);
        }
        for(let s = 0; s < groupCount; s += 1){
          for(let rep = 0; rep < replicates; rep += 1){
            const colIndex = baseCols + s * replicates + rep;
            const fallback = rep === 0
              ? formatScatterGroupHeaderTitle(labels[s] || `Group ${s + 1}`, s)
              : '';
            changes.push([0, colIndex, fallback]);
          }
        }
      }else{
        changes.push([0, 1, 'X title']);
        changes.push([0, 2, 'Y title']);
        changes.push([0, 3, 'Z title']);
      }
    }
    if(!changes.length){
      if(groupedMode){
        normalizeScatterGroupedHeaderRow(hot, {
          graphType: options.graphType,
          tableFormat: options.tableFormat,
          source: 'scatter-grouped-header-normalize'
        });
      }
      return;
    }
    hot.setDataAtCell(changes, 'scatter-header-init');
    if(groupedMode){
      normalizeScatterGroupedHeaderRow(hot, {
        graphType: options.graphType,
        tableFormat: options.tableFormat,
        source: 'scatter-grouped-header-normalize'
      });
    }
  }

  function resolveScatterColumnLayout(data, colCountOverride){
    const headerRow = Array.isArray(data?.[0]) ? data[0] : [];
    const colCount = Number.isInteger(colCountOverride) ? colCountOverride : headerRow.length;
    if(isScatterGroupedMode()){
      const replicates = clampScatterReplicateCount(scatterReplicates);
      const xReplicatesEnabled = !!scatterGroupedXReplicates;
      const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
      const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
      const usedSeriesCols = computeScatterUsedSeriesColumns(data, { startCol: baseCols, replicates, xReplicatesEnabled });
      const seriesCount = Math.max(1, Math.ceil(usedSeriesCols / Math.max(replicates, 1)));
      const baseNames = [];
      for(let s = 0; s < seriesCount; s += 1){
        const idx = getScatterGroupedSeriesStartCol(s, replicates, { xReplicatesEnabled });
        baseNames.push(inferScatterGroupBaseName(headerRow[idx], `Series ${s + 1}`));
      }
      const labels = normalizeScatterGroupLabels(seriesCount, scatterSeriesGroupLabels, baseNames);
      scatterSeriesGroupLabels = labels.slice();
      const groups = labels.map((label, index) => {
        const startCol = getScatterGroupedSeriesStartCol(index, replicates, { xReplicatesEnabled });
        return {
          index,
          label,
          startCol,
          endCol: startCol + replicates - 1
        };
      });
      return {
        grouped: true,
        labelCol: 0,
        xCol: 1,
        xCols: Array.from({ length: xReplicateCount }, (_, idx) => 1 + idx),
        yCol: baseCols,
        yCols: groups.reduce((acc, group) => {
          for(let col = group.startCol; col <= group.endCol; col += 1){
            acc.push(col);
          }
          return acc;
        }, []),
        extraCol: -1,
        replicates,
        xReplicateCount,
        xReplicatesEnabled,
        baseCols,
        seriesCount,
        groups
      };
    }
    return {
      grouped: false,
      labelCol: 0,
      xCol: 1,
      xCols: [1],
      yCol: 2,
      yCols: [2],
      extraCol: 3
    };
  }

  function getScatterHeaderValue(data, colIndex){
    if(!Array.isArray(data) || !data.length){
      return '';
    }
    const headerRow = Array.isArray(data[0]) ? data[0] : [];
    if(!Number.isInteger(colIndex) || colIndex < 0 || colIndex >= headerRow.length){
      return '';
    }
    const value = headerRow[colIndex];
    return value != null ? String(value).trim() : '';
  }

  function syncScatterAxisHeader(axisKey, value, options = {}){
    const hotInstance = options.hot
      || scatter.__ensureHotForActiveTab?.()
      || scatterHot
      || scatterRefs.hot;
    if(!hotInstance || typeof hotInstance.getData !== 'function' || typeof hotInstance.setDataAtCell !== 'function'){
      scatterDebug('Debug: scatter axis header sync skipped', { axis: axisKey, reason: 'hot-missing' });
      return;
    }
    const data = hotInstance.getData() || [];
    const layout = resolveScatterColumnLayout(data);
    const colIndex = axisKey === 'x'
      ? layout.xCol
      : (axisKey === 'y' ? layout.yCol : layout.extraCol);
    const maxCols = typeof hotInstance.countCols === 'function'
      ? hotInstance.countCols()
      : (Array.isArray(data?.[0]) ? data[0].length : 0);
    if(!Number.isInteger(colIndex) || colIndex < 0 || (maxCols && colIndex >= maxCols)){
      return;
    }
    const resolved = value != null ? String(value).trim() : '';
    const current = getScatterHeaderValue(data, colIndex);
    if(current === resolved){
      return;
    }
    hotInstance.setDataAtCell(0, colIndex, resolved, options.source || 'scatter-axis-inline');
    scatterDebug('Debug: scatter axis header synced', { axis: axisKey, colIndex, value: resolved });
  }

  function getScatterSelectedRowSet(hotInstance){
    const api = hotInstance?.gridApi;
    if(!api || typeof api.getSelectedNodes !== 'function'){
      return null;
    }
    try{
      const nodes = api.getSelectedNodes() || [];
      if(!nodes.length){
        return null;
      }
      const set = new Set();
      nodes.forEach(node => {
        const rowIndex = resolveScatterNodeRowIndex(node);
        if(Number.isInteger(rowIndex) && rowIndex >= 0){
          set.add(rowIndex);
        }
      });
      return set.size ? set : null;
    }catch(err){
      scatterDebug('Debug: scatter selected rows read failed', { message: err?.message || String(err) });
      return null;
    }
  }

  function resolveScatterTabId(hotInstance){
    return hotInstance?.__scatterTabId
      || Shared.hot?.resolveActiveTabId?.()
      || null;
  }

  function storeScatterRowSelection(hotInstance, reason){
    if(scatterSelectionSyncInProgress){
      return;
    }
    const tabId = resolveScatterTabId(hotInstance);
    if(!tabId){
      return;
    }
    const selected = getScatterSelectedRowSet(hotInstance);
    if(selected && selected.size){
      scatterRowSelectionsByTab.set(tabId, Array.from(selected).sort((a, b) => a - b));
    }else{
      scatterRowSelectionsByTab.delete(tabId);
    }
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter selection stored', { tabId, count: selected?.size || 0, reason: reason || 'unknown' });
    }
  }

  function applyScatterRowSelection(hotInstance, tabIdOverride){
    const tabId = tabIdOverride || resolveScatterTabId(hotInstance);
    if(!tabId){
      return;
    }
    const api = hotInstance?.gridApi;
    if(!api || typeof api.deselectAll !== 'function'){
      return;
    }
    const rows = scatterRowSelectionsByTab.get(tabId) || [];
    api.deselectAll();
    if(!rows.length || typeof api.forEachNode !== 'function'){
      return;
    }
    const rowSet = new Set(rows);
    api.forEachNode(node => {
      const rowIndex = resolveScatterNodeRowIndex(node);
      if(Number.isInteger(rowIndex) && rowSet.has(rowIndex) && typeof node.setSelected === 'function'){
        node.setSelected(true);
      }
    });
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter selection restored', { tabId, count: rows.length });
    }
  }

  function scheduleScatterSelectionRestore(hotInstance, tabId){
    let attempts = 0;
    const tryRestore = () => {
      attempts += 1;
      const api = hotInstance?.gridApi;
      if(api && typeof api.deselectAll === 'function'){
        applyScatterRowSelection(hotInstance, tabId);
        return;
      }
      if(attempts < 10){
        setTimeout(tryRestore, 120);
      }
    };
    setTimeout(tryRestore, 0);
  }

  function restoreScatterSelectedRowsFromPayload(hotInstance, rows, tabId){
    const selectedRows = Array.isArray(rows)
      ? Array.from(new Set(rows.map(value => Number(value)).filter(value => Number.isInteger(value) && value >= 0))).sort((a, b) => a - b)
      : [];
    const resolvedTabId = tabId || resolveScatterTabId(hotInstance);
    if(resolvedTabId){
      if(selectedRows.length){
        scatterRowSelectionsByTab.set(resolvedTabId, selectedRows);
      }else{
        scatterRowSelectionsByTab.delete(resolvedTabId);
      }
    }
    let attempts = 0;
    const tryRestore = () => {
      attempts += 1;
      const api = hotInstance?.gridApi;
      if(!api || typeof api.deselectAll !== 'function'){
        if(attempts < 12){
          setTimeout(tryRestore, 120);
        }
        return;
      }
      api.deselectAll();
      selectedRows.forEach(rowIndex => {
        setScatterRowSelected(hotInstance, rowIndex, true, { preserveExisting: true });
      });
      scheduleScatterViewRefresh('row-selection-restore');
      if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
        console.debug('Debug: scatter payload selection restored', {
          tabId: resolvedTabId || null,
          count: selectedRows.length,
          attempts
        });
      }
    };
    setTimeout(tryRestore, 0);
  }

  function syncScatterThresholdSelection(){
    const hotInstance = scatter.__ensureHotForActiveTab?.() || scatterHot;
    if(!hotInstance){
      scatterDebug('Debug: scatter threshold selection skipped', { reason: 'missing-hot' });
      return false;
    }
    const tabId = resolveScatterTabId(hotInstance);
    if(!tabId){
      scatterDebug('Debug: scatter threshold selection skipped', { reason: 'missing-tab' });
      return false;
    }
    const api = hotInstance?.gridApi;
    if(!api || typeof api.forEachNode !== 'function'){
      scatterDebug('Debug: scatter threshold selection skipped', { reason: 'missing-api' });
      return false;
    }
    const graphTypeRaw = getScatterNodeById('scatterGraphType')?.value
      || scatterCurrentGraphType
      || 'scatter';
    const graphType = String(graphTypeRaw).toLowerCase();
    const showSignificant = !!(scatterShowSignificantLabels && scatterShowSignificantLabels.checked);
    const prevAuto = scatterThresholdSelectionsByTab.get(tabId) || new Set();
    if((graphType !== 'volcano' && graphType !== 'ma') || !showSignificant){
      if(prevAuto.size){
        const nodesToClear = [];
        const iterate = typeof api.forEachNodeAfterFilterAndSort === 'function'
          ? api.forEachNodeAfterFilterAndSort.bind(api)
          : api.forEachNode.bind(api);
        iterate(node => {
          const rowIndex = resolveScatterNodeRowIndex(node);
          if(!Number.isInteger(rowIndex) || rowIndex <= 0 || node?.rowPinned){
            return;
          }
          if(prevAuto.has(rowIndex)){
            nodesToClear.push(node);
          }
        });
        scatterSelectionSyncInProgress = true;
        try{
          if(nodesToClear.length){
            suppressScatterSelectionEvents('threshold-clear');
            if(typeof api.setNodesSelected === 'function'){
              api.setNodesSelected({ nodes: nodesToClear, newValue: false });
            }else{
              nodesToClear.forEach(node => {
                if(typeof node.setSelected === 'function'){
                  node.setSelected(false);
                }
              });
            }
            if(typeof api.refreshCells === 'function'){
              try{
                api.refreshCells({ force: true });
              }catch(err){
                api.refreshCells();
              }
            }
          }
        }finally{
          scatterSelectionSyncInProgress = false;
        }
        scatterThresholdSelectionsByTab.delete(tabId);
        storeScatterRowSelection(hotInstance, 'threshold-clear');
        scatterDebug('Debug: scatter threshold selection cleared', {
          tabId,
          cleared: prevAuto.size,
          reason: (graphType !== 'volcano' && graphType !== 'ma') ? 'graph-type' : 'toggle-off'
        });
      }
      return false;
    }
    const log2fcThresholdValue = parseFloat(scatterLog2FCThreshold?.value);
    const negLogPThresholdValue = parseFloat(scatterNegLogPThreshold?.value);
    const log2fcThreshold = Number.isFinite(log2fcThresholdValue) ? log2fcThresholdValue : 0;
    const negLogPThreshold = Number.isFinite(negLogPThresholdValue) ? negLogPThresholdValue : 0;
    const tableRowCount = typeof hotInstance.countRows === 'function'
      ? Number(hotInstance.countRows())
      : (typeof api.getDisplayedRowCount === 'function'
        ? Number(api.getDisplayedRowCount())
        : (Array.isArray(hotInstance.getData?.()) ? hotInstance.getData().length : NaN));
    if(Number.isFinite(tableRowCount) && tableRowCount > SCATTER_THRESHOLD_SELECTION_ROW_LIMIT){
      if(prevAuto.size){
        scatterThresholdSelectionsByTab.delete(tabId);
      }
      scatterDebug('Debug: scatter threshold selection skipped before scan for large dataset', {
        tabId,
        graphType,
        rowCount: tableRowCount,
        rowLimit: SCATTER_THRESHOLD_SELECTION_ROW_LIMIT,
        thresholds: { log2fcThreshold, negLogPThreshold }
      });
      return false;
    }
    const selectedRowSet = getScatterSelectedRowSet(hotInstance) || new Set();
    const significantRows = new Set();
    const nextAuto = new Set();
    const targetSelection = new Set(selectedRowSet);
    let examinedCount = 0;
    let selectedCount = 0;
    let clearedCount = 0;
    let selectionUnchanged = false;
    const iterate = typeof api.forEachNodeAfterFilterAndSort === 'function'
      ? api.forEachNodeAfterFilterAndSort.bind(api)
      : api.forEachNode.bind(api);
    scatterSelectionSyncInProgress = true;
    try{
      iterate(node => {
        const visualRow = Number.isInteger(node?.rowIndex) ? node.rowIndex : null;
        const rowIndex = resolveScatterNodeRowIndex(node);
        if(!Number.isInteger(visualRow) || !Number.isInteger(rowIndex)){
          return;
        }
        if(node?.rowPinned || visualRow <= 0 || rowIndex <= 0){
          return;
        }
        examinedCount += 1;
        let log2fc, pRaw;
        if(graphType === 'ma'){
          // For MA plots: Column 1 = Mean Expression, Column 2 = log2FC, Column 3 = p-value
          log2fc = parseFloat(hotInstance.getDataAtCell(visualRow, 2)); // log2FC is in column 2 for MA
          pRaw = parseFloat(hotInstance.getDataAtCell(visualRow, 3)); // p-value is in column 3 for MA
        }else{
          // For Volcano plots: Column 1 = log2FC, Column 2 = p-value
          log2fc = parseFloat(hotInstance.getDataAtCell(visualRow, 1));
          pRaw = parseFloat(hotInstance.getDataAtCell(visualRow, 2));
        }
        if(!Number.isFinite(log2fc) || !Number.isFinite(pRaw) || pRaw <= 0){
          return;
        }
        const negLogP = -Math.log10(pRaw);
        const isSignificant = Number.isFinite(negLogP)
          && Math.abs(log2fc) >= log2fcThreshold
          && negLogP >= negLogPThreshold;
        if(isSignificant){
          significantRows.add(rowIndex);
        }
      });
      significantRows.forEach(rowIndex => {
        if(prevAuto.has(rowIndex) && !selectedRowSet.has(rowIndex)){
          return; // user deselected an auto-labeled row
        }
        nextAuto.add(rowIndex);
        if(!targetSelection.has(rowIndex)){
          targetSelection.add(rowIndex);
          selectedCount += 1;
        }
      });
      prevAuto.forEach(rowIndex => {
        if(!significantRows.has(rowIndex) && !selectedRowSet.has(rowIndex)){
          if(targetSelection.delete(rowIndex)){
            clearedCount += 1;
          }
        }
      });
      const selectionSyncTooLarge = examinedCount > SCATTER_THRESHOLD_SELECTION_ROW_LIMIT
        || nextAuto.size > SCATTER_THRESHOLD_SELECTION_SELECTED_LIMIT;
      if(selectionSyncTooLarge){
        if(prevAuto.size){
          scatterThresholdSelectionsByTab.delete(tabId);
        }
        scatterDebug('Debug: scatter threshold selection skipped for large dataset', {
          tabId,
          graphType,
          examinedCount,
          significantCount: significantRows.size,
          autoSelectedCount: nextAuto.size,
          rowLimit: SCATTER_THRESHOLD_SELECTION_ROW_LIMIT,
          selectionLimit: SCATTER_THRESHOLD_SELECTION_SELECTED_LIMIT,
          thresholds: { log2fcThreshold, negLogPThreshold }
        });
        return false;
      }
      selectionUnchanged = targetSelection.size === selectedRowSet.size;
      if(selectionUnchanged){
        for(const rowIndex of targetSelection){
          if(!selectedRowSet.has(rowIndex)){
            selectionUnchanged = false;
            break;
          }
        }
      }
      if(!selectionUnchanged){
        const nodesToSelect = [];
        iterate(node => {
          const rowIndex = resolveScatterNodeRowIndex(node);
          if(!Number.isInteger(rowIndex) || rowIndex <= 0 || node?.rowPinned){
            return;
          }
          if(targetSelection.has(rowIndex)){
            nodesToSelect.push(node);
          }
        });
        suppressScatterSelectionEvents('threshold-sync');
        if(typeof api.deselectAll === 'function'){
          api.deselectAll();
        }
        if(nodesToSelect.length){
          if(typeof api.setNodesSelected === 'function'){
            api.setNodesSelected({ nodes: nodesToSelect, newValue: true, clearSelection: false });
          }else{
            nodesToSelect.forEach(node => {
              if(typeof node.setSelected === 'function'){
                node.setSelected(true, false);
              }
            });
          }
        }
        if(typeof api.refreshCells === 'function'){
          try{
            api.refreshCells({ force: true });
          }catch(err){
            api.refreshCells();
          }
        }
      }
    }finally{
      scatterSelectionSyncInProgress = false;
    }
    if(nextAuto.size){
      scatterThresholdSelectionsByTab.set(tabId, nextAuto);
    }else{
      scatterThresholdSelectionsByTab.delete(tabId);
    }
    storeScatterRowSelection(hotInstance, 'threshold-sync');
    scatterDebug('Debug: scatter threshold selection synced', {
      tabId,
      significantCount: significantRows.size,
      autoSelectedCount: nextAuto.size,
      examinedCount,
      selectedCount,
      clearedCount,
      selectionUnchanged,
      thresholds: { log2fcThreshold, negLogPThreshold }
    });
    return true;
  }

  function buildScatterAnnotationRequests(points, options){
    const enabled = !!options?.enabled;
    const fontSize = Math.max(6, Number(options?.fontSize) || 10);
    if(!enabled || !Array.isArray(points) || !points.length){
      return { requests: [], fontSize };
    }
    const axisMid = Number.isFinite(options?.axisMid) ? options.axisMid : 0;
    const limitSource = Number.isFinite(options?.maxAnnotations) ? options.maxAnnotations : MAX_SIGNIFICANT_ANNOTATIONS;
    const limit = Math.max(0, limitSource);
    const safeMakeFont = typeof chartStyle?.makeFont === 'function'
      ? chartStyle.makeFont
      : (() => null);
    const measureText = typeof chartStyle?.measureText === 'function'
      ? chartStyle.measureText
      : null;
    const font = safeMakeFont(fontSize);
    const requests = [];
    const widthEstimator = label => {
      const length = Math.max(1, (label || '').length);
      return fontSize * 0.65 * length;
    };
    for(let idx = 0; idx < points.length && requests.length < limit; idx += 1){
      const pt = points[idx];
      if(!pt || !pt.label || !pt.isSignificant){
        continue;
      }
      const side = Number.isFinite(pt.x) && pt.x >= axisMid ? 'right' : 'left';
      let textWidth = measureText ? measureText(pt.label, font) : NaN;
      if(!Number.isFinite(textWidth) || textWidth <= 0){
        textWidth = widthEstimator(pt.label);
      }
      textWidth = Math.max(textWidth, widthEstimator(pt.label));
      requests.push({ pointIndex: idx, label: pt.label, side, textWidth });
    }
    return { requests, fontSize };
  }

  function resolveScatterAnnotationCrowdingScale(count, options){
    if(!Number.isFinite(count) || count <= 0){
      return 1;
    }
    const comfortable = Math.max(1, Number(options?.comfortable) || SCATTER_ANNOTATION_COMFORTABLE_COUNT);
    const minScale = Math.min(1, Math.max(0.25, Number(options?.minScale) || SCATTER_ANNOTATION_MIN_SCALE));
    if(count <= comfortable){
      return 1;
    }
    const estimated = comfortable / count;
    return Math.max(minScale, Math.min(1, estimated));
  }

  function scatterPointInsideCircle(point, circle){
    if(!point || !circle){ return false; }
    const dx = point.x - circle.cx;
    const dy = point.y - circle.cy;
    return Math.hypot(dx, dy) <= (circle.r || 0) + 1e-6;
  }

  function scatterCircleFromTwoPoints(a, b){
    const cx = (a.x + b.x) / 2;
    const cy = (a.y + b.y) / 2;
    const r = Math.hypot(a.x - b.x, a.y - b.y) / 2;
    return { cx, cy, r };
  }

  function scatterCircleFromThreePoints(a, b, c){
    const A = b.x - a.x;
    const B = b.y - a.y;
    const C = c.x - a.x;
    const D = c.y - a.y;
    const E = A * (a.x + b.x) + B * (a.y + b.y);
    const F = C * (a.x + c.x) + D * (a.y + c.y);
    const G = 2 * (A * (c.y - b.y) - B * (c.x - b.x));
    if(Math.abs(G) < 1e-6){
      return null; // Points are collinear; no unique circle.
    }
    const cx = (D * E - B * F) / G;
    const cy = (A * F - C * E) / G;
    const r = Math.hypot(cx - a.x, cy - a.y);
    return { cx, cy, r };
  }

  function scatterSmallestCircleForCollinear(a, b, c){
    const candidates = [
      scatterCircleFromTwoPoints(a, b),
      scatterCircleFromTwoPoints(a, c),
      scatterCircleFromTwoPoints(b, c)
    ];
    let best = null;
    candidates.forEach(candidate => {
      if(!candidate){ return; }
      if(!scatterPointInsideCircle(a, candidate) || !scatterPointInsideCircle(b, candidate) || !scatterPointInsideCircle(c, candidate)){
        return;
      }
      if(!best || candidate.r < best.r){
        best = candidate;
      }
    });
    return best;
  }

  function computeScatterEnclosingCircle(points){
    const pts = Array.isArray(points) ? points : [];
    if(!pts.length){
      return { cx: 0, cy: 0, r: 0 };
    }
    let circle = null;
    for(let i = 0; i < pts.length; i += 1){
      const p = pts[i];
      if(circle && scatterPointInsideCircle(p, circle)){
        continue;
      }
      circle = { cx: p.x, cy: p.y, r: 0 };
      for(let j = 0; j < i; j += 1){
        const q = pts[j];
        if(scatterPointInsideCircle(q, circle)){
          continue;
        }
        circle = scatterCircleFromTwoPoints(p, q);
        for(let k = 0; k < j; k += 1){
          const rPt = pts[k];
          if(scatterPointInsideCircle(rPt, circle)){
            continue;
          }
          const throughThree = scatterCircleFromThreePoints(p, q, rPt)
            || scatterSmallestCircleForCollinear(p, q, rPt);
          if(throughThree){
            circle = throughThree;
          }
        }
      }
    }
    return circle || { cx: 0, cy: 0, r: 0 };
  }

  const SCATTER_LABEL_LINE_HEIGHT = 1.35;
  const SCATTER_LABEL_PADDING = 2;
  const SCATTER_LEADER_COLLISION_STEP = 8;
  const SCATTER_LEADER_MIN_LENGTH = 6;

  function computeAnnotationSegment(entry){
    return {
      x1: Number(entry.pointX) || 0,
      y1: Number(entry.pointY) || 0,
      x2: Number(entry.attachX) || 0,
      y2: Number(entry.anchorY) || 0
    };
  }

  function computeAnnotationLabelRect(entry, context){
    const height = context?.labelLineHeight || (context?.fontSize || 10) * SCATTER_LABEL_LINE_HEIGHT;
    const half = height / 2;
    const padding = context?.labelPadding ?? SCATTER_LABEL_PADDING;
    let x1;
    let x2;
    if(entry.textAnchor === 'end'){
      x2 = entry.textX + padding;
      x1 = entry.textX - entry.textWidth - padding;
    }else{
      x1 = entry.textX - padding;
      x2 = entry.textX + entry.textWidth + padding;
    }
    const y1 = entry.anchorY - half - padding;
    const y2 = entry.anchorY + half + padding;
    return { x1, x2, y1, y2 };
  }

  function rectanglesOverlap(a, b){
    if(!a || !b){ return false; }
    return !(a.x2 <= b.x1 || a.x1 >= b.x2 || a.y2 <= b.y1 || a.y1 >= b.y2);
  }

  function pointInRect(point, rect){
    if(!rect || !point){ return false; }
    return point.x >= rect.x1 && point.x <= rect.x2 && point.y >= rect.y1 && point.y <= rect.y2;
  }

  function orientation(p, q, r){
    const val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if(Math.abs(val) < 1e-6){ return 0; }
    return val > 0 ? 1 : 2;
  }

  function onSegment(p, q, r){
    return q.x <= Math.max(p.x, r.x) + 1e-6 && q.x + 1e-6 >= Math.min(p.x, r.x)
      && q.y <= Math.max(p.y, r.y) + 1e-6 && q.y + 1e-6 >= Math.min(p.y, r.y);
  }

  function segmentsIntersect(a, b){
    if(!a || !b){ return false; }
    const p1 = { x: a.x1, y: a.y1 };
    const q1 = { x: a.x2, y: a.y2 };
    const p2 = { x: b.x1, y: b.y1 };
    const q2 = { x: b.x2, y: b.y2 };
    const o1 = orientation(p1, q1, p2);
    const o2 = orientation(p1, q1, q2);
    const o3 = orientation(p2, q2, p1);
    const o4 = orientation(p2, q2, q1);
    if(o1 !== o2 && o3 !== o4){
      return true;
    }
    if(o1 === 0 && onSegment(p1, p2, q1)){ return true; }
    if(o2 === 0 && onSegment(p1, q2, q1)){ return true; }
    if(o3 === 0 && onSegment(p2, p1, q2)){ return true; }
    if(o4 === 0 && onSegment(p2, q1, q2)){ return true; }
    return false;
  }

  function segmentIntersectsRect(segment, rect){
    if(!segment || !rect){ return false; }
    if(pointInRect({ x: segment.x1, y: segment.y1 }, rect) || pointInRect({ x: segment.x2, y: segment.y2 }, rect)){
      return true;
    }
    const edges = [
      { x1: rect.x1, y1: rect.y1, x2: rect.x2, y2: rect.y1 },
      { x1: rect.x2, y1: rect.y1, x2: rect.x2, y2: rect.y2 },
      { x1: rect.x2, y1: rect.y2, x2: rect.x1, y2: rect.y2 },
      { x1: rect.x1, y1: rect.y2, x2: rect.x1, y2: rect.y1 }
    ];
    return edges.some(edge => segmentsIntersect(segment, edge));
  }

  function refreshAnnotationGeometry(entry, context){
    clampAnnotationHorizontal(entry, context);
    entry.rect = computeAnnotationLabelRect(entry, context);
    entry.segment = computeAnnotationSegment(entry);
    return entry;
  }

  function availableLeaderSlack(entry, context){
    if(!entry){ return 0; }
    const dx = Math.abs((entry.attachX ?? 0) - (entry.pointX ?? 0));
    const minLen = Math.max(context?.minimumLeaderLength || 0, 0);
    return Math.max(0, dx - minLen);
  }

  function availableLeaderExtension(entry, context){
    if(!entry){ return 0; }
    const direction = entry.side === 'left' ? -1 : 1;
    const boundaryLimit = direction > 0
      ? (context.outerRight ?? context.innerRight) - context.labelOffset
      : (context.outerLeft ?? context.innerLeft) + context.labelOffset;
    let cappedLimit = boundaryLimit;
    if(Number.isFinite(context?.maxLeaderLength) && context.maxLeaderLength > 0){
      const dy = Math.abs((entry.anchorY ?? 0) - (entry.pointY ?? 0));
      const maxHorizontal = Math.sqrt(Math.max(context.maxLeaderLength * context.maxLeaderLength - dy * dy, 0));
      const capAttach = (entry.pointX ?? 0) + (direction > 0 ? maxHorizontal : -maxHorizontal);
      cappedLimit = direction > 0 ? Math.min(boundaryLimit, capAttach) : Math.max(boundaryLimit, capAttach);
    }
    if(direction > 0){
      return Math.max(0, cappedLimit - (entry.attachX ?? 0));
    }
    return Math.max(0, (entry.attachX ?? 0) - cappedLimit);
  }

  function clampAnnotationVertical(entry, value, context){
    const base = Number.isFinite(entry.baseAnchorY) ? entry.baseAnchorY : entry.anchorY;
    const drift = Math.max(context?.maxVerticalDrift || 0, 0);
    const lower = Math.max(context.clampMinY, base - drift);
    const upper = Math.min(context.clampMaxY, base + drift);
    return clampScatterValue(value, lower, upper);
  }

  function moveAnnotationVertically(entry, direction, context, magnitude){
    if(!entry){ return entry; }
    const step = magnitude || (context.labelLineHeight + context.labelPadding);
    const next = clampAnnotationVertical(entry, entry.anchorY + direction * step, context);
    entry.anchorY = next;
    return refreshAnnotationGeometry(entry, context);
  }

  function extendAnnotationLeader(entry, context, step){
    if(!entry){ return entry; }
    const direction = entry.side === 'left' ? -1 : 1;
    const available = availableLeaderExtension(entry, context);
    if(available <= 0){
      return entry;
    }
    const delta = Math.min(Math.max(step || context.collisionShortenStep, 2), available);
    if(delta <= 0){
      return entry;
    }
    moveAnnotationLabel(entry, direction * delta, context);
    enforceAnnotationLeaderLength(entry, context);
    return refreshAnnotationGeometry(entry, context);
  }

  function separateAnnotationPair(entryA, entryB, context){
    if(!entryA || !entryB){ return false; }
    const up = entryA.anchorY <= entryB.anchorY ? entryA : entryB;
    const down = up === entryA ? entryB : entryA;
    moveAnnotationVertically(up, -1, context);
    moveAnnotationVertically(down, 1, context);
    return true;
  }

  function resolveAnnotationPairSegments(entryA, entryB, context){
    const aHitsB = segmentIntersectsRect(entryA.segment, entryB.rect);
    const bHitsA = segmentIntersectsRect(entryB.segment, entryA.rect);
    if(aHitsB || bHitsA){
      const target = aHitsB ? entryB : entryA;
      if(availableLeaderExtension(target, context) > 0){
        extendAnnotationLeader(target, context, context.collisionShortenStep);
        refreshAnnotationGeometry(target, context);
        return true;
      }
    }
    const isRight = (context.side || 'right') !== 'left';
    const earlier = entryA.anchorY <= entryB.anchorY ? entryA : entryB;
    const later = earlier === entryA ? entryB : entryA;
    const attachesOutOfOrder = isRight
      ? (later.attachX ?? 0) + 0.5 < (earlier.attachX ?? 0)
      : (later.attachX ?? 0) - 0.5 > (earlier.attachX ?? 0);
    if(attachesOutOfOrder){
      if(availableLeaderExtension(later, context) > 0){
        extendAnnotationLeader(later, context, context.collisionShortenStep * 1.05);
        refreshAnnotationGeometry(later, context);
        return true;
      }
      if(availableLeaderSlack(earlier, context) > 0){
        shortenAnnotationLeader(earlier, context, context.collisionShortenStep * 1.05);
        refreshAnnotationGeometry(earlier, context);
        return true;
      }
      const verticalDir = isRight ? 1 : -1;
      moveAnnotationVertically(later, verticalDir, context, context.labelLineHeight * 0.75);
      refreshAnnotationGeometry(later, context);
      return true;
    }
    const slackA = availableLeaderSlack(entryA, context);
    const slackB = availableLeaderSlack(entryB, context);
    if(slackA <= 0 && slackB <= 0){
      const extensionA = availableLeaderExtension(entryA, context);
      const extensionB = availableLeaderExtension(entryB, context);
      if(extensionA > 0 || extensionB > 0){
        const target = extensionA >= extensionB ? entryA : entryB;
        extendAnnotationLeader(target, context, context.collisionShortenStep * 1.15);
        refreshAnnotationGeometry(target, context);
        return true;
      }
      const upper = entryA.anchorY <= entryB.anchorY ? entryA : entryB;
      const lower = upper === entryA ? entryB : entryA;
      moveAnnotationVertically(upper, -1, context, context.labelLineHeight);
      moveAnnotationVertically(lower, 1, context, context.labelLineHeight);
      return true;
    }
    const target = slackA >= slackB ? entryA : entryB;
    shortenAnnotationLeader(target, context, context.collisionShortenStep * 1.15);
    refreshAnnotationGeometry(target, context);
    return true;
  }

  function polishScatterAnnotationLayout(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const maxPasses = 16;
    for(let pass = 0; pass < maxPasses; pass += 1){
      let changed = false;
      for(let i = 0; i < entries.length; i += 1){
        for(let j = i + 1; j < entries.length; j += 1){
          const a = entries[i];
          const b = entries[j];
          if(rectanglesOverlap(a.rect, b.rect)){
            changed = separateAnnotationPair(a, b, context) || changed;
            continue;
          }
          if(segmentIntersectsRect(a.segment, b.rect) || segmentIntersectsRect(b.segment, a.rect) || segmentsIntersect(a.segment, b.segment)){
            changed = resolveAnnotationPairSegments(a, b, context) || changed;
          }
        }
      }
      if(!changed){
        break;
      }
    }
    return entries;
  }

  function detectAnnotationConflict(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return null;
    }
    for(let i = 0; i < entries.length; i += 1){
      const entryA = entries[i];
      if(!entryA){ continue; }
      if(!entryA.rect || !entryA.segment){
        refreshAnnotationGeometry(entryA, context);
      }
      for(let j = i + 1; j < entries.length; j += 1){
        const entryB = entries[j];
        if(!entryB){ continue; }
        if(!entryB.rect || !entryB.segment){
          refreshAnnotationGeometry(entryB, context);
        }
        if(rectanglesOverlap(entryA.rect, entryB.rect)){
          return { type: 'label', a: i, b: j };
        }
        if(segmentIntersectsRect(entryA.segment, entryB.rect) || segmentIntersectsRect(entryB.segment, entryA.rect)){
          return { type: 'leader-label', a: i, b: j };
        }
        if(segmentsIntersect(entryA.segment, entryB.segment)){
          return { type: 'leader', a: i, b: j };
        }
      }
    }
    return null;
  }

  function resolveResidualAnnotationConflicts(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const maxIterations = 32;
    for(let iter = 0; iter < maxIterations; iter += 1){
      const conflict = detectAnnotationConflict(entries, context);
      if(!conflict){
        break;
      }
      const entryA = entries[conflict.a];
      const entryB = entries[conflict.b];
      if(!entryA || !entryB){
        break;
      }
      let handled = false;
      if(conflict.type === 'label'){
        handled = separateAnnotationPair(entryA, entryB, context);
      }else{
        handled = resolveAnnotationPairSegments(entryA, entryB, context);
      }
      if(!handled){
        moveAnnotationVertically(entryB, entryB.anchorY >= entryA.anchorY ? 1 : -1, context, context.labelLineHeight * 0.5);
        refreshAnnotationGeometry(entryB, context);
      }
    }
    return entries;
  }

  function placeVolcanoAnnotation(entry, context){
    const dir = entry.dir || { x: entry.side === 'left' ? -1 : 1, y: 0 };
    const minLeader = Math.max(context.minimumLeaderLength || 0, SCATTER_LEADER_MIN_LENGTH);
    const desiredLeader = Math.max(entry.leaderLength || minLeader, minLeader);
    let anchorX = entry.pointX + dir.x * desiredLeader;
    let anchorY = entry.pointY + dir.y * desiredLeader;
    const clampMinY = Number.isFinite(context.clampMinY) ? context.clampMinY : anchorY;
    const clampMaxY = Number.isFinite(context.clampMaxY) ? context.clampMaxY : anchorY;
    if(anchorY < clampMinY || anchorY > clampMaxY){
      if(Math.abs(dir.y) > 1e-4){
        const targetY = clampScatterValue(anchorY, clampMinY, clampMaxY);
        const adjustedLength = (targetY - entry.pointY) / dir.y;
        const bounded = clampScatterValue(
          Math.abs(adjustedLength),
          minLeader,
          Math.max(minLeader, entry.maxLeaderLength || adjustedLength)
        );
        anchorY = entry.pointY + dir.y * bounded;
        anchorX = entry.pointX + dir.x * bounded;
        entry.leaderLength = bounded;
      }else{
        anchorY = clampScatterValue(anchorY, clampMinY, clampMaxY);
      }
    }
    const textAnchor = dir.x >= 0 ? 'start' : 'end';
    const offset = Math.max(context.textPad || 0, (context.labelPadding || 0) + 1.5);
    const textX = anchorX + (textAnchor === 'start' ? offset : -offset);
    const layout = {
      label: entry.label,
      pointIndex: entry.pointIndex,
      textWidth: entry.textWidth,
      textAnchor,
      textX,
      anchorY,
      attachX: anchorX,
      pointX: entry.pointX,
      pointY: entry.pointY,
      side: entry.side
    };
    layout.rect = computeAnnotationLabelRect(layout, context);
    layout.segment = computeAnnotationSegment(layout);
    return layout;
  }

  function findVolcanoAnnotationConflict(entries){
    if(!Array.isArray(entries) || entries.length < 2){
      return null;
    }
    for(let i = 0; i < entries.length; i += 1){
      const aLayout = entries[i].layout;
      if(!aLayout){ continue; }
      for(let j = i + 1; j < entries.length; j += 1){
        const bLayout = entries[j].layout;
        if(!bLayout){ continue; }
        if(rectanglesOverlap(aLayout.rect, bLayout.rect)){
          return { a: entries[i], b: entries[j], type: 'label' };
        }
        if(segmentIntersectsRect(aLayout.segment, bLayout.rect) || segmentIntersectsRect(bLayout.segment, aLayout.rect) || segmentsIntersect(aLayout.segment, bLayout.segment)){
          return { a: entries[i], b: entries[j], type: 'leader' };
        }
      }
    }
    return null;
  }

  function layoutScatterVolcanoCloud(entries, context){
    if(!Array.isArray(entries) || !entries.length){
      return [];
    }
    const maxLeaderScale = Number.isFinite(context.maxLeaderScale) ? context.maxLeaderScale : 1.5;
    const results = entries.map(entry => {
      const dx = entry.pointX - context.circle.cx;
      const dy = entry.pointY - context.circle.cy;
      const distance = Math.hypot(dx, dy);
      const dirX = distance > 1e-3 ? dx / distance : (entry.side === 'left' ? -1 : 1);
      const dirY = distance > 1e-3 ? dy / distance : -0.05;
      const baseLeader = Math.max(
        context.minimumLeaderLength || SCATTER_LEADER_MIN_LENGTH,
        (context.textPad || 0) * 2 + entry.textWidth * 0.25,
        (context.circle.r || 0) * 0.12,
        context.leaderPad || SCATTER_LEADER_MIN_LENGTH
      );
      const maxLeader = Math.max(baseLeader, baseLeader * maxLeaderScale);
      const enriched = {
        ...entry,
        dir: { x: dirX, y: dirY },
        leaderLength: baseLeader,
        maxLeaderLength: maxLeader,
        distanceFromCenter: distance
      };
      enriched.layout = placeVolcanoAnnotation(enriched, context);
      return enriched;
    });
    const extensionStep = Math.max(context.extensionStep || 0, Math.max(context.leaderPad || 0, 8) * 0.25, 3);
    const maxIterations = 48;
    for(let iter = 0; iter < maxIterations; iter += 1){
      const conflict = findVolcanoAnnotationConflict(results);
      if(!conflict){
        break;
      }
      const farther = (conflict.a.distanceFromCenter || 0) >= (conflict.b.distanceFromCenter || 0) ? conflict.a : conflict.b;
      let extended = false;
      const targetNext = Math.min(farther.maxLeaderLength, farther.leaderLength + extensionStep);
      if(targetNext > farther.leaderLength + 1e-3){
        farther.leaderLength = targetNext;
        farther.layout = placeVolcanoAnnotation(farther, context);
        extended = true;
      }
      if(!extended){
        const other = farther === conflict.a ? conflict.b : conflict.a;
        const otherNext = Math.min(other.maxLeaderLength, other.leaderLength + extensionStep);
        if(otherNext > other.leaderLength + 1e-3){
          other.leaderLength = otherNext;
          other.layout = placeVolcanoAnnotation(other, context);
          extended = true;
        }
      }
      if(!extended){
        break;
      }
    }
    return results.map(entry => ({
      label: entry.label,
      pointIndex: entry.pointIndex,
      textWidth: entry.textWidth,
      textAnchor: entry.layout?.textAnchor || (entry.side === 'left' ? 'end' : 'start'),
      textX: entry.layout?.textX ?? entry.pointX,
      anchorY: entry.layout?.anchorY ?? entry.pointY,
      attachX: entry.layout?.attachX ?? entry.pointX,
      pointX: entry.pointX,
      pointY: entry.pointY,
      side: entry.side
    }));
  }

  function enforceAnnotationMinimumSpacing(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const minSpacing = Math.max(context.minSpacing || 0, context.labelLineHeight + context.labelPadding);
    const sorted = entries.slice().sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
    for(let i = 1; i < sorted.length; i += 1){
      const prev = sorted[i - 1];
      const curr = sorted[i];
      if(curr.anchorY - prev.anchorY < minSpacing){
        curr.anchorY = clampAnnotationVertical(curr, prev.anchorY + minSpacing, context);
        refreshAnnotationGeometry(curr, context);
      }
    }
    for(let i = sorted.length - 2; i >= 0; i -= 1){
      const next = sorted[i + 1];
      const curr = sorted[i];
      if(next.anchorY - curr.anchorY < minSpacing){
        curr.anchorY = clampAnnotationVertical(curr, next.anchorY - minSpacing, context);
        refreshAnnotationGeometry(curr, context);
      }
    }
    return entries;
  }

  function enforceAnnotationAttachOrder(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const ordered = entries.slice().sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
    if((context.side || 'right') === 'right'){
      for(let i = 1; i < ordered.length; i += 1){
        const prev = ordered[i - 1];
        const curr = ordered[i];
        if(curr.attachX + 0.5 < prev.attachX){
          const delta = (prev.attachX - curr.attachX) + context.labelOffset;
          moveAnnotationLabel(curr, delta, context);
          enforceAnnotationLeaderLength(curr, context);
          refreshAnnotationGeometry(curr, context);
        }
      }
    }else{
      for(let i = 1; i < ordered.length; i += 1){
        const prev = ordered[i - 1];
        const curr = ordered[i];
        if(curr.attachX - 0.5 > prev.attachX){
          const delta = (prev.attachX - curr.attachX) - context.labelOffset;
          moveAnnotationLabel(curr, delta, context);
          enforceAnnotationLeaderLength(curr, context);
          refreshAnnotationGeometry(curr, context);
        }
      }
    }
    return entries;
  }

  function enforceAnnotationDeltaOrder(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const ordered = entries.slice().sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
    const direction = (context.side || 'right') === 'left' ? -1 : 1;
    let prevDelta = null;
    for(let i = 0; i < ordered.length; i += 1){
      const entry = ordered[i];
      const dx = (entry.attachX ?? 0) - (entry.pointX ?? 0);
      if(prevDelta === null){
        prevDelta = dx;
        continue;
      }
      const minStep = Math.max(context.labelOffset * 0.75, 2);
      const desiredDelta = direction > 0
        ? Math.max(prevDelta + minStep, dx)
        : Math.min(prevDelta - minStep, dx);
      if(direction > 0 ? dx < desiredDelta - 1e-3 : dx > desiredDelta + 1e-3){
        entry.attachX = entry.pointX + desiredDelta;
        entry.textX = direction > 0
          ? entry.attachX + context.labelOffset
          : entry.attachX - context.labelOffset;
        clampAnnotationHorizontal(entry, context);
        enforceAnnotationLeaderLength(entry, context);
        refreshAnnotationGeometry(entry, context);
        prevDelta = (entry.attachX ?? 0) - (entry.pointX ?? 0);
      }else{
        prevDelta = dx;
      }
    }
    return entries;
  }

  function applyIsotonicRegression(values, weights, nonDecreasing){
    const n = values.length;
    const result = new Array(n);
    const stack = [];
    for(let i = 0; i < n; i += 1){
      let value = values[i];
      let weight = Math.max(1e-3, weights[i] || 1);
      stack.push({ value, weight, count: 1 });
      while(stack.length >= 2){
        const b = stack[stack.length - 1];
        const a = stack[stack.length - 2];
        const violates = nonDecreasing ? (a.value > b.value) : (a.value < b.value);
        if(!violates){ break; }
        const totalWeight = a.weight + b.weight;
        const mergedValue = (a.value * a.weight + b.value * b.weight) / totalWeight;
        stack.pop();
        stack.pop();
        stack.push({ value: mergedValue, weight: totalWeight, count: a.count + b.count });
      }
    }
    let idx = n - 1;
    while(stack.length){
      const block = stack.pop();
      for(let i = 0; i < block.count; i += 1){
        result[idx - i] = block.value;
      }
      idx -= block.count;
    }
    return result;
  }

  function enforceAnnotationSlopeIsotonic(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const ordered = entries.slice().sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
    const isRight = (context.side || 'right') !== 'left';
    const slopes = [];
    const weights = [];
    const dyInfo = [];
    ordered.forEach(entry => {
      const dyRaw = (entry.anchorY ?? 0) - (entry.pointY ?? 0);
      const dySign = dyRaw === 0 ? (isRight ? 1 : -1) : Math.sign(dyRaw);
      const dyAbs = Math.max(Math.abs(dyRaw), context.labelLineHeight);
      const dy = dyAbs * dySign;
      dyInfo.push({ dy, dyAbs });
      let slope = ((entry.attachX ?? entry.pointX) - (entry.pointX ?? 0)) / dy;
      if(!Number.isFinite(slope)){
        slope = isRight ? 0.01 : -0.01;
      }
      slopes.push(slope);
      weights.push(Math.max(1, dyAbs));
    });
    const adjusted = applyIsotonicRegression(slopes, weights, isRight);
    ordered.forEach((entry, idx) => {
      const dy = dyInfo[idx].dy;
      const slope = adjusted[idx];
      let targetAttach = (entry.pointX ?? 0) + slope * dy;
      if(Number.isFinite(context.maxLeaderLength) && context.maxLeaderLength > 0){
        const horizontalLimit = Math.sqrt(Math.max(context.maxLeaderLength * context.maxLeaderLength - dyInfo[idx].dyAbs * dyInfo[idx].dyAbs, 0));
        if(horizontalLimit > 0){
          const limit = (entry.pointX ?? 0) + (isRight ? 1 : -1) * horizontalLimit;
          targetAttach = isRight ? Math.min(targetAttach, limit) : Math.max(targetAttach, limit);
        }
      }
      entry.attachX = targetAttach;
      entry.textX = isRight
        ? entry.attachX + context.labelOffset
        : entry.attachX - context.labelOffset;
      clampAnnotationHorizontal(entry, context);
      refreshAnnotationGeometry(entry, context);
    });
    return entries;
  }

  function enforceAnnotationAnchorFan(entries, context){
    if(!Array.isArray(entries) || entries.length < 2){
      return entries;
    }
    const ordered = entries.slice().sort((a, b) => a.anchorY - b.anchorY);
    const isRight = (context.side || 'right') !== 'left';
    const step = Math.max(context.labelOffset * 0.9, 4);
    let prevRect = null;
    ordered.forEach(entry => {
      if(prevRect){
        if(isRight){
          const clearance = prevRect.x2 + step;
          if(entry.attachX < clearance){
            entry.attachX = clearance;
            entry.textX = entry.attachX + context.labelOffset;
          }
        }else{
          const clearance = prevRect.x1 - step;
          if(entry.attachX > clearance){
            entry.attachX = clearance;
            entry.textX = entry.attachX - context.labelOffset;
          }
        }
      }
      enforceAnnotationLeaderLength(entry, context);
      refreshAnnotationGeometry(entry, context);
      prevRect = entry.rect;
    });
    return entries;
  }

  function clampAnnotationHorizontal(entry, context){
    const direction = entry.side === 'left' ? -1 : 1;
    const minGap = Number.isFinite(entry.minLeaderGap) ? entry.minLeaderGap : context.minLeaderGap;
    if(direction > 0){
      const minText = Math.max(context.innerLeft + context.textPad, entry.pointX + minGap + context.textPad);
      const maxText = (context.outerRight ?? context.innerRight) - entry.textWidth;
      entry.textX = clampScatterValue(entry.textX, Math.min(minText, maxText), Math.max(minText, maxText));
    }else{
      const maxText = Math.min(context.innerRight - context.textPad, entry.pointX - minGap - context.textPad);
      const minText = (context.outerLeft ?? context.innerLeft) + entry.textWidth;
      entry.textX = clampScatterValue(entry.textX, Math.min(minText, maxText), Math.max(minText, maxText));
    }
    entry.attachX = direction > 0
      ? Math.min(entry.textX - context.labelOffset, (context.outerRight ?? context.innerRight) - context.labelOffset)
      : Math.max(entry.textX + context.labelOffset, (context.outerLeft ?? context.innerLeft) + context.labelOffset);
    return entry;
  }

  function moveAnnotationLabel(entry, delta, context){
    entry.textX += delta;
    clampAnnotationHorizontal(entry, context);
    return entry;
  }

  function tightenAnnotationLeaderGap(entry, context){
    const absoluteMin = context.absoluteMinLeaderGap ?? context.textPad ?? 2;
    const desired = Math.max(absoluteMin, context.minimumLeaderLength * 0.5);
    if(!Number.isFinite(entry.minLeaderGap) || entry.minLeaderGap > desired){
      entry.minLeaderGap = desired;
    }
  }

  function enforceAnnotationLeaderLength(entry, context){
    if(!Number.isFinite(context.maxLeaderLength) || context.maxLeaderLength <= 0){
      return entry;
    }
    const dx = entry.attachX - entry.pointX;
    const dy = entry.anchorY - entry.pointY;
    const currentLength = Math.hypot(dx, dy);
    if(currentLength <= context.maxLeaderLength){
      return entry;
    }
    tightenAnnotationLeaderGap(entry, context);
    const direction = entry.side === 'left' ? -1 : 1;
    const verticalSpan = Math.abs(dy);
    const horizontalLimit = Math.max(0, Math.sqrt(Math.max(context.maxLeaderLength * context.maxLeaderLength - verticalSpan * verticalSpan, 0)));
    const desiredAttachX = entry.pointX + Math.sign(dx || direction) * horizontalLimit;
    const delta = entry.attachX - desiredAttachX;
    if(Math.abs(delta) < 0.5){
      entry.attachX = desiredAttachX;
      return clampAnnotationHorizontal(entry, context);
    }
    return moveAnnotationLabel(entry, -delta, context);
  }

  function shortenAnnotationLeader(entry, context, step){
    const dx = Math.abs(entry.attachX - entry.pointX);
    const available = Math.max(0, dx - context.minimumLeaderLength);
    const delta = Math.min(Math.max(step || SCATTER_LEADER_COLLISION_STEP, 2), available);
    if(delta <= 0){
      return entry;
    }
    tightenAnnotationLeaderGap(entry, context);
    const direction = entry.side === 'left' ? -1 : 1;
    return moveAnnotationLabel(entry, -direction * delta, context);
  }

  function nudgeAnnotationVertically(entry, reference, context){
    const direction = entry.anchorY >= reference.anchorY ? 1 : -1;
    const minSpacing = context.labelLineHeight + context.labelPadding;
    const target = direction > 0
      ? reference.anchorY + minSpacing
      : reference.anchorY - minSpacing;
    entry.anchorY = clampAnnotationVertical(entry, target, context);
    return entry;
  }

  function resolveAnnotationConflicts(candidate, placed, context){
    let current = refreshAnnotationGeometry(candidate, context);
    const maxIterations = 36;
    for(let iteration = 0; iteration < maxIterations; iteration += 1){
      current = enforceAnnotationLeaderLength(current, context);
      refreshAnnotationGeometry(current, context);
      let conflictResolved = true;
      for(let idx = 0; idx < placed.length; idx += 1){
        const prev = placed[idx];
        if(rectanglesOverlap(current.rect, prev.rect)){
          const direction = current.anchorY >= prev.anchorY ? 1 : -1;
          moveAnnotationVertically(current, direction, context);
          conflictResolved = false;
          break;
        }
        if(segmentIntersectsRect(current.segment, prev.rect) || segmentIntersectsRect(prev.segment, current.rect) || segmentsIntersect(current.segment, prev.segment)){
          const slack = availableLeaderSlack(current, context);
          if(slack > 0){
            shortenAnnotationLeader(current, context, context.collisionShortenStep);
          }else if(availableLeaderExtension(current, context) > 0){
            extendAnnotationLeader(current, context, context.collisionShortenStep);
          }else if(availableLeaderExtension(prev, context) > 0){
            extendAnnotationLeader(prev, context, context.collisionShortenStep);
            refreshAnnotationGeometry(prev, context);
          }else{
            moveAnnotationVertically(current, current.anchorY >= prev.anchorY ? 1 : -1, context);
          }
          refreshAnnotationGeometry(current, context);
          conflictResolved = false;
          break;
        }
      }
      if(conflictResolved){
        return current;
      }
    }
    return current;
  }
  function layoutScatterAnnotationSide(entries, config){
    if(!Array.isArray(entries) || !entries.length){
      return [];
    }
    const minY = Number.isFinite(config?.minY) ? config.minY : 0;
    const maxY = Number.isFinite(config?.maxY) ? config.maxY : minY + 1;
    const fontSize = Math.max(6, Number(config?.fontSize) || 10);
    const textPad = Math.max(2, Number(config?.textPad) || 4);
    const minSpacing = Math.max(fontSize * 1.35, Number(config?.minSpacing) || 12) + Math.max(2, textPad * 0.4);
    const verticalPadding = Math.max(2, Number(config?.verticalPadding) || 6);
    const leaderPad = Math.max(6, Number(config?.leaderPad) || 10);
      const leaderGap = Math.max(leaderPad * 1.2, Number(config?.leaderGap) || leaderPad * 1.2);
    const axisPadding = Math.max(4, Number(config?.axisPadding) || 8);
    const plotLeft = Number.isFinite(config?.plotLeft) ? config.plotLeft : 0;
    const plotRight = Number.isFinite(config?.plotRight) ? config.plotRight : plotLeft + 1;
    const innerLeft = plotLeft + axisPadding;
    const innerRight = plotRight - axisPadding;
    const labelRegionExtra = Math.max(leaderPad * 2.5, textPad * 6, 60);
    const outerLeft = innerLeft - labelRegionExtra;
    const outerRight = innerRight + labelRegionExtra;
    const labelOffset = Math.max(2, textPad * 0.75);
    const clampMinY = Math.min(minY + verticalPadding, maxY - verticalPadding);
    const clampMaxY = Math.max(minY + verticalPadding, maxY - verticalPadding);
    const horizontalSpan = Math.max(0, innerRight - innerLeft);
    const fallbackLeaderLength = Math.min(Math.max(leaderPad * 2.25, horizontalSpan * 0.2), Math.max(horizontalSpan * 0.45, leaderPad * 2.25));
    const maxLeaderLength = Number.isFinite(config?.maxLeaderLength) && config.maxLeaderLength > 0
      ? config.maxLeaderLength
      : fallbackLeaderLength;
    const labelLineHeight = Math.max(fontSize * SCATTER_LABEL_LINE_HEIGHT, fontSize + 4);
    const labelPadding = Math.max(SCATTER_LABEL_PADDING, textPad * 0.35);
    const resolvedSpacing = Math.max(minSpacing, labelLineHeight + labelPadding * 2 + 1);
    const context = {
      innerLeft,
      innerRight,
      outerLeft,
      outerRight,
      textPad,
      labelOffset,
      clampMinY,
      clampMaxY,
      fontSize,
      labelLineHeight,
      labelPadding,
      minSpacing: resolvedSpacing,
      maxLeaderLength,
      collisionShortenStep: Math.max(textPad * 1.75, SCATTER_LEADER_COLLISION_STEP),
      minimumLeaderLength: Math.max(SCATTER_LEADER_MIN_LENGTH, leaderPad * 0.5),
      minLeaderGap: Math.max(leaderGap, leaderPad * 0.9),
      absoluteMinLeaderGap: Math.max(2, textPad),
      maxVerticalDrift: Math.max(fontSize * 5.5, verticalPadding * 4),
      labelRegionExtra
    };
    const sorted = entries.slice().sort((a, b) => a.baseY - b.baseY).map((entry, idx) => ({
      ...entry,
      orderIndex: idx
    }));
    const assigned = sorted.map(entry => ({
      ...entry,
      targetY: clampScatterValue(entry.baseY, clampMinY, clampMaxY)
    }));
    for(let i = 1; i < assigned.length; i += 1){
      const prev = assigned[i - 1];
      if(assigned[i].targetY - prev.targetY < minSpacing){
        assigned[i].targetY = prev.targetY + minSpacing;
      }
    }
    for(let i = assigned.length - 2; i >= 0; i -= 1){
      const next = assigned[i + 1];
      if(next.targetY - assigned[i].targetY < minSpacing){
        assigned[i].targetY = next.targetY - minSpacing;
      }
    }
    assigned.forEach(entry => {
      entry.targetY = clampScatterValue(entry.targetY, clampMinY, clampMaxY);
    });
    for(let i = 1; i < assigned.length; i += 1){
      const prev = assigned[i - 1];
      if(assigned[i].targetY - prev.targetY < minSpacing){
        assigned[i].targetY = prev.targetY + minSpacing;
      }
    }
    for(let i = assigned.length - 2; i >= 0; i -= 1){
      const next = assigned[i + 1];
      if(next.targetY - assigned[i].targetY < minSpacing){
        assigned[i].targetY = next.targetY - minSpacing;
      }
    }
    assigned.forEach(entry => {
      entry.targetY = clampScatterValue(entry.targetY, clampMinY, clampMaxY);
    });
    const side = config?.side === 'left' ? 'left' : 'right';
    context.side = side;
    const placed = [];
    assigned.forEach(entry => {
      const direction = side === 'left' ? -1 : 1;
      const idealText = entry.pointX + direction * (leaderPad * 1.25 + textPad);
      let textX;
      if(direction > 0){
        const minTextRaw = Math.max(innerLeft + textPad, entry.pointX + leaderGap + textPad);
        const maxTextRaw = innerRight - entry.textWidth;
        const lower = Math.min(minTextRaw, maxTextRaw);
        const upper = Math.max(minTextRaw, maxTextRaw);
        textX = clampScatterValue(idealText, lower, upper);
      }else{
        const maxTextRaw = Math.min(innerRight - textPad, entry.pointX - leaderGap - textPad);
        const minTextRaw = innerLeft + entry.textWidth;
        const lower = Math.min(minTextRaw, maxTextRaw);
        const upper = Math.max(minTextRaw, maxTextRaw);
        textX = clampScatterValue(idealText, lower, upper);
      }
      const attachX = direction > 0
        ? Math.min(textX - labelOffset, innerRight - labelOffset)
        : Math.max(textX + labelOffset, innerLeft + labelOffset);
      const candidate = {
        label: entry.label,
        pointIndex: entry.pointIndex,
        textWidth: entry.textWidth,
        textAnchor: side === 'left' ? 'end' : 'start',
        textX,
        anchorY: entry.targetY,
        baseAnchorY: entry.targetY,
        attachX,
        pointX: entry.pointX,
        pointY: entry.pointY,
        side,
        minLeaderGap: context.minLeaderGap,
        orderIndex: entry.orderIndex
      };
      const resolved = resolveAnnotationConflicts(candidate, placed, context);
      placed.push(resolved);
    });
    polishScatterAnnotationLayout(placed, context);
    enforceAnnotationMinimumSpacing(placed, context);
    polishScatterAnnotationLayout(placed, context);
    enforceAnnotationMinimumSpacing(placed, context);
    enforceAnnotationSlopeIsotonic(placed, context);
    enforceAnnotationAnchorFan(placed, context);
    enforceAnnotationDeltaOrder(placed, context);
    enforceAnnotationAttachOrder(placed, context);
    enforceAnnotationMinimumSpacing(placed, context);
    for(let finalPass = 0; finalPass < 2; finalPass += 1){
      polishScatterAnnotationLayout(placed, context);
      enforceAnnotationMinimumSpacing(placed, context);
    }
    resolveResidualAnnotationConflicts(placed, context);
    enforceAnnotationMinimumSpacing(placed, context);
    resolveResidualAnnotationConflicts(placed, context);
    return placed.map(entry => ({
      label: entry.label,
      pointIndex: entry.pointIndex,
      textWidth: entry.textWidth,
      textAnchor: entry.textAnchor,
      textX: entry.textX,
      anchorY: entry.anchorY,
      attachX: entry.attachX,
      pointX: entry.pointX,
      pointY: entry.pointY,
      side: entry.side
    }));
  }

  function layoutScatterAnnotations(params){
    if(!Array.isArray(params?.requests) || !params.requests.length){
      return [];
    }
    const pointGeometry = Array.isArray(params.pointGeometry) ? params.pointGeometry : [];
    const requestEntries = params.requests.map(entry => {
      const geom = pointGeometry[entry.pointIndex];
      if(!geom){
        return null;
      }
      return {
        ...entry,
        baseY: geom.cy,
        pointX: geom.cx,
        pointY: geom.cy
      };
    }).filter(Boolean);
    if(!requestEntries.length){
      return [];
    }
    if((params?.graphType || '').toLowerCase() === 'volcano'){
      return layoutVolcanoAnnotationsInternal(requestEntries, params);
    }
    const margin = params.margin || { top: 0, left: 0 };
    const plotH = Number.isFinite(params.plotH) ? params.plotH : 0;
    const minY = margin.top;
    const maxY = margin.top + plotH;
    const fontSize = Math.max(6, Number(params.fontSize) || 10);
    const minSpacing = Math.max(fontSize + 4, fontSize * 1.25);
    const plotW = Number.isFinite(params.plotW) ? params.plotW : 0;
    const plotLeft = margin.left;
    const plotRight = margin.left + plotW;
    const leaderPad = Math.max(6, Number(params.leaderPadding) || 10);
    const leaderGap = Math.max(leaderPad, Number(params.leaderGap) || leaderPad);
    const textPad = Math.max(2, Number(params.textPadding) || 4);
    const axisPadding = Math.max(4, Number(params.axisPadding) || 8);
    const verticalPadding = Math.max(4, Number(params.verticalPadding) || 8);
    const innerLeftBound = plotLeft + axisPadding;
    const innerRightBound = plotRight - axisPadding;
    const requiredGapBase = leaderGap + textPad * 2;
    const availableWidth = Math.max(0, plotW - axisPadding * 2);
    const defaultLeaderCap = Math.max(leaderPad * 2.25, availableWidth * 0.25);
    const maxLeaderLength = Number.isFinite(params.maxLeaderLength) && params.maxLeaderLength > 0
      ? params.maxLeaderLength
      : defaultLeaderCap;
    requestEntries.forEach(entry => {
      const approxNeeded = Math.max(entry.textWidth + requiredGapBase, leaderPad * 1.5 + entry.textWidth);
      const availableLeft = entry.pointX - innerLeftBound;
      const availableRight = innerRightBound - entry.pointX;
      if(entry.side === 'left' && availableLeft < approxNeeded && availableRight > availableLeft){
        entry.side = 'right';
      }else if(entry.side === 'right' && availableRight < approxNeeded && availableLeft > availableRight){
        entry.side = 'left';
      }
    });
    const leftEntries = [];
    const rightEntries = [];
    requestEntries.forEach(entry => {
      if(entry.side === 'left'){
        leftEntries.push(entry);
      }else{
        rightEntries.push(entry);
      }
    });
    const results = [];
    if(leftEntries.length){
      const leftLayouts = layoutScatterAnnotationSide(leftEntries, {
        side: 'left',
        minY,
        maxY,
        minSpacing,
        fontSize,
        plotLeft,
        plotRight,
        leaderPad,
        leaderGap,
        textPad,
        axisPadding,
        verticalPadding,
        maxLeaderLength
      });
      results.push(...leftLayouts);
    }
    if(rightEntries.length){
      const rightLayouts = layoutScatterAnnotationSide(rightEntries, {
        side: 'right',
        minY,
        maxY,
        minSpacing,
        fontSize,
        plotLeft,
        plotRight,
        leaderPad,
        leaderGap,
        textPad,
        axisPadding,
        verticalPadding,
        maxLeaderLength
      });
      results.push(...rightLayouts);
    }
    return results;
  }

  function layoutVolcanoAnnotationsInternal(requestEntries, params){
    if(!Array.isArray(requestEntries) || !requestEntries.length){
      return [];
    }
    const margin = params.margin || { top: 0, left: 0 };
    const plotW = Number.isFinite(params.plotW) ? params.plotW : 0;
    const plotH = Number.isFinite(params.plotH) ? params.plotH : 0;
    const minY = margin.top;
    const maxY = margin.top + plotH;
    const fontSize = Math.max(6, Number(params?.fontSize) || 10);
    const textPad = Math.max(2, Number(params?.textPadding) || 4);
    const leaderPad = Math.max(6, Number(params?.leaderPadding) || 10);
    const axisPadding = Math.max(4, Number(params?.axisPadding) || 8);
    const verticalPadding = Math.max(axisPadding, Number(params?.verticalPadding) || axisPadding);
    const labelLineHeight = Math.max(fontSize * SCATTER_LABEL_LINE_HEIGHT, fontSize + 4);
    const labelPadding = Math.max(SCATTER_LABEL_PADDING, textPad * 0.35);
    const clampMinY = Math.min(minY + verticalPadding, maxY - verticalPadding);
    const clampMaxY = Math.max(minY + verticalPadding, maxY - verticalPadding);
    const plotLeft = margin.left;
    const plotRight = margin.left + plotW;
    const labelRegionExtra = Math.max(leaderPad * 3, textPad * 8, 90);
    const circlePadding = Math.max(leaderPad * 0.35, textPad * 1.5, 6);
    const baseContext = {
      fontSize,
      labelLineHeight,
      labelPadding,
      textPad,
      clampMinY,
      clampMaxY,
      minimumLeaderLength: Math.max(leaderPad * 0.6, SCATTER_LEADER_MIN_LENGTH),
      leaderPad,
      extensionStep: Math.max(leaderPad * 0.25, 4),
      maxLeaderScale: 1.5,
      outerLeft: plotLeft - labelRegionExtra,
      outerRight: plotRight + labelRegionExtra,
      labelOffset: Math.max(3, textPad * 0.8)
    };
    const grouped = { left: [], right: [] };
    requestEntries.forEach(entry => {
      const side = entry.side === 'left' ? 'left' : 'right';
      grouped[side].push(entry);
    });
    const layouts = [];
    ['left', 'right'].forEach(side => {
      const group = grouped[side];
      if(!group.length){
        return;
      }
      const circleRaw = computeScatterEnclosingCircle(group.map(item => ({ x: item.pointX, y: item.pointY })));
      const circle = {
        cx: circleRaw.cx,
        cy: circleRaw.cy,
        r: Math.max(0, (circleRaw.r || 0) + circlePadding)
      };
      const context = { ...baseContext, circle, side };
      const sideLayouts = layoutScatterVolcanoCloud(group, context);
      layouts.push(...sideLayouts);
    });
    return layouts;
  }

  function showScatterTooltip(data, evt){
    const tooltip = getScatterTooltipElement();
    if(!tooltip){ return; }
    if(!updateScatterTooltipContent(tooltip, data)){ return; }
    tooltip.style.display = 'block';
    const pos = getScatterEventPagePosition(evt);
    positionScatterTooltipAt(tooltip, pos.x, pos.y);
    scatterDebug('Debug: scatter tooltip show',{
      label: data?.label || null,
      x: data?.x ?? null,
      y: data?.y ?? null,
      graphType: data?.graphType || null
    });
  }

  function handleScatterPointEnter(evt){
    const data = evt?.currentTarget?.__scatterPointData;
    if(!data){ return; }
    showScatterTooltip(data, evt);
  }

  function handleScatterPointMove(evt){
    const tooltip = getScatterTooltipElement();
    if(!tooltip || tooltip.style.display === 'none'){ return; }
    const pos = getScatterEventPagePosition(evt);
    positionScatterTooltipAt(tooltip, pos.x, pos.y);
  }

  function handleScatterPointLeave(){
    hideScatterTooltip('point-leave');
  }

  function handleScatterPlotMouseLeave(){
    hideScatterTooltip('plot-leave');
  }

  function isScatterContextMenuEventSuppressed(target){
    if(!target){
      return false;
    }
    if(target === scatterPointContextMenu){
      return true;
    }
    if(typeof target.closest === 'function'){
      return !!target.closest('.scatter-point-context-menu');
    }
    return false;
  }

  function ensureScatterPointContextMenu(){
    const doc = global.document;
    if(!doc){
      return null;
    }
    if(scatterPointContextMenu && doc.body && doc.body.contains(scatterPointContextMenu)){
      return scatterPointContextMenu;
    }
    const menu = doc.createElement('div');
    menu.className = 'tab-context-menu scatter-point-context-menu';
    menu.hidden = true;
    menu.dataset.scatterContextMenu = '1';
    menu.setAttribute('role', 'menu');
    menu.style.position = 'absolute';
    menu.style.left = '0px';
    menu.style.top = '0px';

    const makeItem = (action, label) => {
      const btn = doc.createElement('button');
      btn.type = 'button';
      btn.className = 'tab-context-menu__item';
      btn.dataset.action = action;
      btn.textContent = label;
      return btn;
    };

    const labelItem = makeItem('toggle-label', 'Add label');
    menu.appendChild(labelItem);

    menu.addEventListener('contextmenu', evt => {
      try{ evt.preventDefault(); }catch(e){}
      try{ evt.stopPropagation(); }catch(e){}
    }, true);

    const hide = (reason) => hideScatterPointContextMenu(reason);
    labelItem.addEventListener('click', evt => {
      try{ evt.preventDefault(); }catch(e){}
      try{ evt.stopPropagation(); }catch(e){}
      const data = menu.__scatterPointData;
      const rowIndex = Number.isInteger(data?.rowIndex) ? data.rowIndex : null;
      if(rowIndex === null){
        hide('no-row-index');
        return;
      }
      const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
      const toggled = toggleScatterRowSelected(hot, rowIndex, { ensureVisible: true });
      storeScatterRowSelection(hot, 'point-context-menu');
      if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
        console.debug('Debug: scatter context menu label toggle', { rowIndex, toggled });
      }
      scheduleScatterViewRefresh('point-context-menu');
      hide('action-complete');
    });

    if(doc.body){
      doc.body.appendChild(menu);
    }
    scatterPointContextMenu = menu;

    if(!scatterPointContextMenuGlobalBound){
      scatterPointContextMenuGlobalBound = true;
      doc.addEventListener('pointerdown', evt => {
        if(!scatterPointContextMenu || scatterPointContextMenu.hidden){
          return;
        }
        const target = evt?.target;
        if(target && scatterPointContextMenu.contains(target)){
          return;
        }
        hideScatterPointContextMenu('outside-click');
      }, true);
      doc.addEventListener('keydown', evt => {
        if(!scatterPointContextMenu || scatterPointContextMenu.hidden){
          return;
        }
        if(evt?.key === 'Escape'){
          hideScatterPointContextMenu('escape');
        }
      }, true);
      global.addEventListener?.('resize', () => hideScatterPointContextMenu('resize'), true);
      global.addEventListener?.('scroll', () => hideScatterPointContextMenu('scroll'), true);
    }

    return scatterPointContextMenu;
  }

  function hideScatterPointContextMenu(reason){
    if(!scatterPointContextMenu || scatterPointContextMenu.hidden){
      return;
    }
    scatterPointContextMenu.hidden = true;
    scatterPointContextMenu.__scatterPointData = null;
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter point context menu hidden', { reason: reason || 'unknown' });
    }
  }

  function positionScatterPointContextMenu(menu, pageX, pageY){
    if(!menu){
      return;
    }
    const x = Number(pageX) || 0;
    const y = Number(pageY) || 0;
    menu.style.left = `${x}px`;
    menu.style.top = `${y}px`;
    const rect = menu.getBoundingClientRect?.();
    const docEl = global.document?.documentElement;
    const viewportW = global.innerWidth || docEl?.clientWidth || 0;
    const viewportH = global.innerHeight || docEl?.clientHeight || 0;
    if(rect && viewportW && viewportH){
      let nextLeft = x;
      let nextTop = y;
      if(rect.right > viewportW - 6){
        nextLeft = Math.max(6, viewportW - rect.width - 6);
      }
      if(rect.bottom > viewportH - 6){
        nextTop = Math.max(6, viewportH - rect.height - 6);
      }
      menu.style.left = `${nextLeft}px`;
      menu.style.top = `${nextTop}px`;
    }
  }

  function isScatterRowSelected(hotInstance, rowIndex){
    const api = hotInstance?.gridApi;
    if(!api || typeof api.forEachNode !== 'function'){
      return false;
    }
    let selected = false;
    api.forEachNode(node => {
      if(selected){
        return;
      }
      const nodeRowIndex = resolveScatterNodeRowIndex(node);
      if(nodeRowIndex !== rowIndex){
        return;
      }
      selected = !!node?.isSelected?.();
    });
    return selected;
  }

  function resolveScatterNodeRowIndex(node){
    if(Number.isInteger(node?.data?.__rowIndex)){
      return node.data.__rowIndex;
    }
    if(Number.isInteger(node?.rowIndex)){
      return node.rowIndex;
    }
    const fallback = node?.data?.__rowIndex ?? node?.rowIndex;
    return Number.isInteger(fallback) ? fallback : null;
  }

  function setScatterRowSelected(hotInstance, rowIndex, desiredSelected, options){
    const api = hotInstance?.gridApi;
    if(!api || typeof api.forEachNode !== 'function'){
      return false;
    }
    const preserveExisting = options?.preserveExisting !== false;
    let matched = false;
    const targetNodes = [];
    api.forEachNode(node => {
      const nodeRowIndex = resolveScatterNodeRowIndex(node);
      if(nodeRowIndex !== rowIndex){
        return;
      }
      matched = true;
      targetNodes.push(node);
    });
    if(matched && targetNodes.length){
      if(typeof api.setNodesSelected === 'function'){
        api.setNodesSelected({
          nodes: targetNodes,
          newValue: !!desiredSelected,
          clearSelection: !preserveExisting
        });
      }else{
        targetNodes.forEach(node => {
          if(typeof node.setSelected === 'function'){
            try{
              node.setSelected(!!desiredSelected, !preserveExisting);
            }catch(err){
              node.setSelected(!!desiredSelected);
            }
          }
        });
      }
    }
    if(matched && desiredSelected && options?.ensureVisible){
      if(typeof api.ensureIndexVisible === 'function'){
        try{ api.ensureIndexVisible(rowIndex, 'middle'); }catch(e){ api.ensureIndexVisible(rowIndex); }
      }else if(typeof api.ensureNodeVisible === 'function'){
        api.forEachNode(node => {
          const nodeRowIndex = Number.isInteger(node?.rowIndex) ? node.rowIndex : node?.data?.__rowIndex;
          if(nodeRowIndex === rowIndex){
            try{ api.ensureNodeVisible(node); }catch(e){}
          }
        });
      }
    }
    return matched;
  }

  function toggleScatterRowSelected(hotInstance, rowIndex, options){
    const selected = isScatterRowSelected(hotInstance, rowIndex);
    return setScatterRowSelected(hotInstance, rowIndex, !selected, options);
  }

  function showScatterPointContextMenu(evt, data){
    const menu = ensureScatterPointContextMenu();
    if(!menu){
      return;
    }
    menu.__scatterPointData = data || null;
    const rowIndex = Number.isInteger(data?.rowIndex) ? data.rowIndex : null;
    const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
    const alreadySelected = rowIndex !== null && hot ? isScatterRowSelected(hot, rowIndex) : false;
    const labelItem = menu.querySelector?.('button[data-action="toggle-label"]');
    if(labelItem){
      labelItem.textContent = alreadySelected ? 'Remove label' : 'Add label';
      labelItem.disabled = rowIndex === null || !hot;
    }
    menu.hidden = false;
    const pos = getScatterEventPagePosition(evt);
    positionScatterPointContextMenu(menu, pos.x, pos.y);
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter point context menu shown', { rowIndex, alreadySelected });
    }
  }

  function handleScatterPointContextMenu(evt){
    const target = evt?.currentTarget;
    const data = target?.__scatterPointData;
    if(!data){
      return;
    }
    try{ evt.preventDefault(); }catch(e){}
    try{ evt.stopPropagation(); }catch(e){}
    hideScatterTooltip('context-menu');
    showScatterPointContextMenu(evt, data);
  }

  function bindScatterPlotContextMenuSuppression(node){
    if(!node || node.__scatterContextMenuSuppressionBound){
      return;
    }
    node.__scatterContextMenuSuppressionBound = true;
    node.addEventListener('contextmenu', evt => {
      const target = evt?.target;
      if(isScatterContextMenuEventSuppressed(target)){
        return;
      }
      try{ evt.preventDefault(); }catch(e){}
    }, true);
  }

  function attachScatterPointTooltip(el, data){
    if(!el || !data){ return; }
    el.__scatterPointData = data;
    if(scatterState.useDelegatedPointEvents){
      return;
    }
    el.addEventListener('mouseenter', handleScatterPointEnter);
    el.addEventListener('mousemove', handleScatterPointMove);
    el.addEventListener('mouseleave', handleScatterPointLeave);
    el.addEventListener('click', handleScatterPointClick);
    el.addEventListener('contextmenu', handleScatterPointContextMenu);
  }

  function resolveScatterPointTarget(node, stopNode){
    let current = node || null;
    while(current && current !== stopNode){
      if(current.__scatterPointData){
        return current;
      }
      current = current.parentNode || null;
    }
    return null;
  }

  function ensureScatterPointDelegation(container){
    if(!container || container.__scatterPointDelegationBound){
      return;
    }
    container.__scatterPointDelegationBound = true;
    let hoverTarget = null;
    const resolveTarget = evt => resolveScatterPointTarget(evt?.target, container);
    const updateHover = (evt, target) => {
      if(target === hoverTarget){
        return;
      }
      hoverTarget = target;
      if(hoverTarget){
        showScatterTooltip(hoverTarget.__scatterPointData, evt);
      }else{
        hideScatterTooltip('point-leave');
      }
    };
    container.addEventListener('mouseover', evt => {
      const target = resolveTarget(evt);
      updateHover(evt, target);
    });
    container.addEventListener('mousemove', evt => {
      if(hoverTarget){
        handleScatterPointMove(evt);
      }
    });
    container.addEventListener('mouseout', evt => {
      if(!hoverTarget){
        return;
      }
      const related = evt?.relatedTarget;
      if(related && hoverTarget.contains && hoverTarget.contains(related)){
        return;
      }
      hoverTarget = null;
      hideScatterTooltip('point-leave');
    });
    container.addEventListener('mouseleave', () => {
      if(hoverTarget){
        hoverTarget = null;
        hideScatterTooltip('point-leave');
      }
    });
    container.addEventListener('click', evt => {
      const clickTarget = evt?.target || null;
      if(clickTarget?.closest && clickTarget.closest('text')){
        return;
      }
      if(clickTarget?.closest && clickTarget.closest('[data-grid-control="1"]')){
        return;
      }
      const target = resolveTarget(evt);
      if(!target){
        const overlayConfig = showScatterOverlayFormatControls({ target: clickTarget });
        if(overlayConfig){
          try{ evt.stopPropagation(); }catch(e){}
        }else{
          scatterDebug('Debug: scatter overlay click bubbled (no overlay panel opened)', {
            reason: 'delegated-click-no-point'
          });
        }
        return;
      }
      try{ evt.stopPropagation(); }catch(e){}
      showScatterFormatControls(target);
    });
    container.addEventListener('contextmenu', evt => {
      const target = resolveTarget(evt);
      if(!target){
        return;
      }
      try{ evt.preventDefault(); }catch(e){}
      try{ evt.stopPropagation(); }catch(e){}
      hideScatterTooltip('context-menu');
      showScatterPointContextMenu(evt, target.__scatterPointData);
    });
  }

  function handleScatterPointClick(evt){
    const target = evt?.currentTarget;
    if(!target){ return; }
    try{ evt.stopPropagation(); }catch(e){}
    showScatterFormatControls(target);
  }

  function registerScatterOverlayControlElement(element, overlayKey){
    if(!element){
      return;
    }
    const safeKey = sanitizeScatterOverlayKey(overlayKey);
    if(!safeKey){
      return;
    }
    element.dataset.scatterOverlay = safeKey;
    element.style.pointerEvents = 'none';
    element.style.cursor = 'default';
    try{
      element.setAttribute('pointer-events', 'none');
    }catch(e){}
  }

  function showScatterOverlayFormatControls(options){
    const opts = options || {};
    const doc = global.document;
    if(!doc){
      return null;
    }
    if(scatterCurrentGraphType !== 'scatter'){
      return null;
    }
    if(!additionalLineControls || typeof additionalLineControls.show !== 'function'){
      return null;
    }
    const appendToHost = opts.appendToHost === true;
    const host = opts.host || resolveScatterToolbarHost(doc);
    if(!isScatterTrendLineEnabled()){
      try{
        if(typeof additionalLineControls.close === 'function'){
          additionalLineControls.close('scatter-trend-disabled');
        }
      }catch(e){}
      if(host && !appendToHost){
        resetScatterDualHostLayout(host);
      }
      return null;
    }
    if(host && !appendToHost){
      clearScatterSymbolPanel(host);
      resetScatterDualHostLayout(host);
    }
    const clickedScopeRaw = opts.target?.dataset?.scatterOverlay;
    const hasClickedScope = typeof clickedScopeRaw === 'string' && clickedScopeRaw.trim() !== '';
    const requestedScope = hasClickedScope
      ? normalizeScatterOverlayToolbarScope(clickedScopeRaw)
      : normalizeScatterOverlayToolbarScope(opts.scope || scatterOverlayToolbarScope);
    scatterOverlayToolbarScope = requestedScope;
    const resolveScope = ctx => normalizeScatterOverlayToolbarScope(ctx?.scope || scatterOverlayToolbarScope);
    const applyOverlayPatch = (scopeValue, patch) => {
      const keys = getScatterOverlayScopeKeys(scopeValue);
      keys.forEach(key => {
        updateScatterOverlayStyle(key, patch);
      });
    };
    const applyOverlayControlLabels = config => {
      if(!config || typeof config !== 'object'){
        return;
      }
      const labels = getScatterOverlayToolbarLabels(config?.scope?.value || scatterOverlayToolbarScope);
      config.panelTitle = 'Overlay';
      config.controls = Object.assign({}, config.controls || {}, {
        colorLabel: labels.colorLabel,
        thicknessLabel: labels.thicknessLabel,
        patternLabel: labels.patternLabel || 'Line pattern',
        transparencyLabel: labels.transparencyLabel
      });
    };
    const overlayConfig = {
      scopeId: 'scatter',
      target: opts.target || null,
      panelTitle: 'Overlay',
      host: host || undefined,
      appendToHost,
      clearHost: appendToHost ? opts.clearHost : true,
      skipHideAll: opts.skipHideAll === true,
      keepOpenWithinHost: opts.keepOpenWithinHost === true,
      keepHostVisible: opts.keepHostVisible === true,
      hostClass: opts.hostClass || undefined,
      hostDisplay: opts.hostDisplay || undefined,
      controls: {
        showSummary: false,
        showScope: true,
        showPattern: true,
        scopeLabel: 'Scope',
        colorLabel: 'Line',
        thicknessLabel: 'Line width',
        patternLabel: 'Line pattern',
        transparencyLabel: 'Line transparency',
        thicknessMin: 0,
        thicknessStep: 0.5,
        thicknessMax: 20
      },
      scope: {
        label: 'Scope',
        options: [
          { value: 'global', label: 'Global', disabled: false },
          { value: 'trend', label: 'Trend line', disabled: false },
          { value: 'confidence', label: 'Confidence interval', disabled: false },
          { value: 'prediction', label: 'Prediction interval', disabled: false }
        ],
        value: requestedScope,
        onChange(nextScope){
          scatterOverlayToolbarScope = normalizeScatterOverlayToolbarScope(nextScope);
          overlayConfig.scope.value = scatterOverlayToolbarScope;
          applyOverlayControlLabels(overlayConfig);
        }
      },
      getSummary: ctx => getScatterOverlaySummary(resolveScope(ctx)),
      getColor: ctx => getScatterOverlayPreviewStyle(resolveScope(ctx))?.color,
      getThickness: ctx => getScatterOverlayPreviewStyle(resolveScope(ctx))?.thickness,
      getPattern: ctx => getScatterOverlayPreviewStyle(resolveScope(ctx))?.pattern || 'solid',
      getTransparency: ctx => getScatterOverlayPreviewStyle(resolveScope(ctx))?.transparency,
      onColorInput: (value, ctx) => {
        applyOverlayPatch(resolveScope(ctx), { color: value });
        scheduleScatterViewRefresh('overlay-color-input');
      },
      onColorChange: (value, ctx) => {
        applyOverlayPatch(resolveScope(ctx), { color: value });
        scheduleScatterViewRefresh('overlay-color-change');
      },
      onThicknessChange: (value, ctx) => {
        const numeric = Number(value);
        applyOverlayPatch(resolveScope(ctx), { thickness: Number.isFinite(numeric) ? Math.max(0, numeric) : 0 });
        scheduleScatterViewRefresh('overlay-thickness-change');
      },
      onPatternChange: (value, ctx) => {
        applyOverlayPatch(resolveScope(ctx), { pattern: value });
        scheduleScatterViewRefresh('overlay-pattern-change');
      },
      onTransparencyChange: (value, ctx) => {
        const numeric = Number(value);
        const bounded = Number.isFinite(numeric) ? Math.min(100, Math.max(0, numeric)) : 0;
        applyOverlayPatch(resolveScope(ctx), { transparency: bounded });
        scheduleScatterViewRefresh('overlay-transparency-change');
      }
    };
    applyOverlayControlLabels(overlayConfig);
    additionalLineControls.show(overlayConfig);
    return overlayConfig;
  }

  function showScatterFormatControls(target){
    const doc = global.document;
    if(!doc){ return; }
    syncScatterSymbolToolbarDotToggles = null;
    try{ if(typeof Shared.hideAllFormatControls === 'function') Shared.hideAllFormatControls({ force: true }); }catch(e){}
    if(Shared.symbolToolbar && typeof Shared.symbolToolbar.show === 'function'){
      const scatterFillInput = doc.getElementById('scatterFill');
      const scatterBorderInput = doc.getElementById('scatterBorder');
      const scatterBorderWidthInput = doc.getElementById('scatterBorderWidth');
      const scatterDotSizeInput = doc.getElementById('scatterDotSize');
      const scatterAlphaInput = doc.getElementById('scatterAlpha');
      const scatterAlphaVal = doc.getElementById('scatterAlphaVal');
      let scatterLabelKey = target?.__scatterPointData?.label || null;
      const resolveAlpha = value => {
        const clamped = clampScatterAlpha(value);
        return clamped != null ? clamped : null;
      };
      const sanitizeCurrentShape = (shape, index = 0) => {
        if(SCATTER_SHAPE_VALUES.has(shape)){
          return shape;
        }
        const safeIndex = Number.isInteger(index) ? index : 0;
        return SCATTER_SHAPE_DEFAULTS[safeIndex % SCATTER_SHAPE_DEFAULTS.length] || 'circle';
      };
      const applyAndDispatch = (inputEl, value, type = 'input') => {
        if(!inputEl){ return; }
        inputEl.value = value;
        inputEl.dispatchEvent(new Event(type, { bubbles: true }));
      };
      const getLabelStyle = () => {
        if(!scatterLabelKey){ return null; }
        const existing = scatterLabelStyles[scatterLabelKey];
        return existing && typeof existing === 'object' ? existing : null;
      };
      const ensureLabelStyle = () => {
        if(!scatterLabelKey){ return null; }
        const existing = scatterLabelStyles[scatterLabelKey];
        if(existing && typeof existing === 'object'){
          return existing;
        }
        scatterLabelStyles[scatterLabelKey] = {};
        return scatterLabelStyles[scatterLabelKey];
      };
      const applyLabelStylePatch = patch => {
        const style = ensureLabelStyle();
        if(!style){ return; }
        Object.assign(style, patch);
        scheduleScatterViewRefresh('label-style-change');
      };
      const applyGlobalStylePatch = (key, value) => {
        Object.keys(scatterLabelStyles).forEach(k => {
          scatterLabelStyles[k] = Object.assign({}, scatterLabelStyles[k], { [key]: value });
        });
        scheduleScatterViewRefresh('label-style-global-change');
      };
      const knownScatterLabelKeys = () => {
        const keys = new Set();
        const addKey = value => {
          const normalized = String(value == null ? '' : value).trim();
          if(normalized){
            keys.add(normalized);
          }
        };
        addKey(scatterLabelKey);
        Object.keys(scatterLabelColors || {}).forEach(addKey);
        Object.keys(scatterLabelShapes || {}).forEach(addKey);
        Object.keys(scatterLabelStyles || {}).forEach(addKey);
        const scatterSvg = doc.getElementById('scatterPlot');
        if(scatterSvg && scatterSvg.querySelectorAll){
          scatterSvg.querySelectorAll('[data-label]').forEach(node => addKey(node.getAttribute('data-label')));
        }
        return Array.from(keys);
      };
      const orderedScatterLabelKeys = () => {
        const keys = knownScatterLabelKeys();
        if(!scatterLabelKey){
          return keys;
        }
        return [scatterLabelKey].concat(keys.filter(key => key !== scatterLabelKey));
      };
      const scatterScopeOptions = (() => {
        const options = [{ value: 'global', label: 'Global', disabled: false }];
        const labelKeys = orderedScatterLabelKeys();
        if(labelKeys.length){
          labelKeys.forEach(labelName => {
            options.push({
              value: 'label',
              label: labelName,
              datasetLabel: labelName,
              scopeDataset: labelName,
              scopeKind: 'label',
              disabled: false
            });
          });
        }else{
          options.push({
            value: 'label',
            label: scatterLabelKey || 'Label',
            datasetLabel: scatterLabelKey || 'Label',
            scopeDataset: scatterLabelKey || '',
            scopeKind: 'label',
            disabled: !scatterLabelKey
          });
        }
        return options;
      })();
      const symbolToolbarState = Shared.symbolToolbar.show({
        document: doc,
        target,
        anchorId: 'scatterFontHost',
        scopeId: 'scatter',
        formClass: 'workspace-toolbar__form workspace-toolbar__form--single scatter-format-controls scatter-point-controls',
        onClose(){
          syncScatterSymbolToolbarDotToggles = null;
        },
        scope: {
          label: 'Scope',
          options: scatterScopeOptions,
          value: scatterLabelKey ? 'label' : 'global',
          onChange(nextScope, ctx){
            if(nextScope === 'label'){
              const scopedLabelKey = String(ctx?.scopeDataset || '').trim();
              if(scopedLabelKey){
                scatterLabelKey = scopedLabelKey;
              }
            }
          }
        },
        fillShape: {
          label: 'Fill/Shape',
          shapeOptions: scatterCurrentGraphType === 'scatter' && scatterState?.viewMode !== 'bubble' ? SCATTER_SHAPE_OPTIONS : [{ value: 'circle', label: 'Circle' }],
          getColor(ctx){
            const labelStyle = getLabelStyle();
            const targetFill = target.getAttribute('fill');
            const targetStroke = target.getAttribute('stroke');
            if(ctx.scope === 'label' && scatterLabelKey){
              return (scatterLabelColors[scatterLabelKey] || labelStyle?.color || targetFill || scatterFillInput?.value || '#0000ff');
            }
            return (targetFill && targetFill !== 'none' ? targetFill : null)
              || (targetStroke && targetStroke !== 'none' ? targetStroke : null)
              || (scatterFillInput?.value || '#0000ff');
          },
          getShape(ctx){
            if(ctx.scope === 'label' && scatterLabelKey){
              return sanitizeCurrentShape(scatterLabelShapes[scatterLabelKey], 0);
            }
            const shapeKeys = Object.keys(scatterLabelShapes || {});
            if(!shapeKeys.length){
              return sanitizeCurrentShape(null, 0);
            }
            const shapes = shapeKeys.map((key, idx) => sanitizeCurrentShape(scatterLabelShapes[key], idx));
            const unique = new Set(shapes);
            return unique.size === 1 ? shapes[0] : sanitizeCurrentShape(null, 0);
          },
          onColorInput(nextColor, ctx){
            if(ctx.scope === 'label' && scatterLabelKey){
              scatterLabelColors[scatterLabelKey] = nextColor;
              scheduleScatterViewRefresh('label-color-input');
              return;
            }
            if(scatterFillInput){
              applyAndDispatch(scatterFillInput, nextColor);
            }
            Object.keys(scatterLabelColors).forEach(k => { scatterLabelColors[k] = nextColor; });
            scheduleScatterViewRefresh('fill-change');
          },
          onColorChange(nextColor, ctx){
            if(ctx.scope === 'label' && scatterLabelKey){
              scatterLabelColors[scatterLabelKey] = nextColor;
              scheduleScatterViewRefresh('label-color-change');
              return;
            }
            if(scatterFillInput){
              applyAndDispatch(scatterFillInput, nextColor);
            }
            Object.keys(scatterLabelColors).forEach(k => { scatterLabelColors[k] = nextColor; });
            scheduleScatterViewRefresh('fill-change');
          },
          onShapeChange(nextShape, ctx){
            if(scatterCurrentGraphType !== 'scatter' || scatterState?.viewMode === 'bubble'){
              return;
            }
            if(ctx.scope === 'label' && scatterLabelKey){
              scatterLabelShapes[scatterLabelKey] = sanitizeCurrentShape(nextShape, 0);
              scheduleScatterViewRefresh('label-shape-change');
              return;
            }
            const sanitized = sanitizeCurrentShape(nextShape, 0);
            const shapeKeys = Object.keys(scatterLabelShapes || {});
            let changed = false;
            shapeKeys.forEach((key, idx) => {
              if(sanitizeCurrentShape(scatterLabelShapes[key], idx) !== sanitized){
                scatterLabelShapes[key] = sanitized;
                changed = true;
              }
            });
            if(changed){
              scheduleScatterViewRefresh('label-shape-global-change');
            }
          }
        },
        border: {
          label: 'Border',
          getColor(ctx){
            const labelStyle = getLabelStyle();
            const targetStroke = target.getAttribute('stroke');
            if(ctx.scope === 'label' && scatterLabelKey){
              return labelStyle?.borderColor || (targetStroke && targetStroke !== 'none' ? targetStroke : null) || scatterBorderInput?.value || '#000000';
            }
            return (targetStroke && targetStroke !== 'none' ? targetStroke : null)
              || (scatterBorderInput?.value || '#000000');
          },
          onColorInput(nextColor, ctx){
            if(ctx.scope === 'label' && scatterLabelKey){
              applyLabelStylePatch({ borderColor: nextColor });
            }else if(scatterBorderInput){
              applyAndDispatch(scatterBorderInput, nextColor);
              Object.keys(scatterLabelStyles).forEach(k => {
                scatterLabelStyles[k] = Object.assign({}, scatterLabelStyles[k], { borderColor: nextColor });
              });
              scheduleScatterViewRefresh('border-color-change');
            }
          },
          onColorChange(nextColor, ctx){
            if(ctx.scope === 'label' && scatterLabelKey){
              applyLabelStylePatch({ borderColor: nextColor });
            }else if(scatterBorderInput){
              applyAndDispatch(scatterBorderInput, nextColor);
              Object.keys(scatterLabelStyles).forEach(k => {
                scatterLabelStyles[k] = Object.assign({}, scatterLabelStyles[k], { borderColor: nextColor });
              });
              scheduleScatterViewRefresh('border-color-change');
            }
          },
          getWidth(ctx){
            const labelStyle = getLabelStyle();
            if(ctx.scope === 'label' && scatterLabelKey && Number.isFinite(Number(labelStyle?.borderWidth))){
              return Number(labelStyle.borderWidth);
            }
            if(Number.isFinite(Number(scatterBorderWidthInput?.value))){
              return Number(scatterBorderWidthInput.value);
            }
            const fromTarget = Number(target.getAttribute('stroke-width'));
            return Number.isFinite(fromTarget) ? fromTarget : 0;
          },
          onWidthChange(nextValue, ctx){
            const next = Math.max(0, Number(nextValue) || 0);
            if(ctx.scope === 'label' && scatterLabelKey){
              applyLabelStylePatch({ borderWidth: next });
            }else{
              if(scatterBorderWidthInput){
                applyAndDispatch(scatterBorderWidthInput, String(next));
              }
              applyGlobalStylePatch('borderWidth', next);
            }
          }
        },
        size: {
          get(ctx){
            const labelStyle = getLabelStyle();
            if(ctx.scope === 'label' && scatterLabelKey && Number.isFinite(Number(labelStyle?.size))){
              return Number(labelStyle.size);
            }
            if(Number.isFinite(Number(scatterDotSizeInput?.value))){
              return Number(scatterDotSizeInput.value);
            }
            const fromTarget = Number(target.getAttribute('r'));
            return Number.isFinite(fromTarget) ? fromTarget : 0;
          },
          onChange(nextValue, ctx){
            const next = Math.max(0, Number(nextValue) || 0);
            if(ctx.scope === 'label' && scatterLabelKey){
              applyLabelStylePatch({ size: next });
            }else{
              if(scatterDotSizeInput){
                applyAndDispatch(scatterDotSizeInput, String(next));
              }
              applyGlobalStylePatch('size', next);
            }
          }
        },
        transparency: {
          label: 'Transparency',
          get(ctx){
            const labelStyle = getLabelStyle();
            if(ctx.scope === 'label' && scatterLabelKey && resolveAlpha(labelStyle?.alpha) != null){
              return resolveAlpha(labelStyle.alpha);
            }
            return resolveAlpha(scatterAlphaInput?.value) || 0;
          },
          onChange(nextValue, ctx){
            const normalized = Math.min(1, Math.max(0, Number(nextValue) || 0));
            if(ctx.scope === 'label' && scatterLabelKey){
              applyLabelStylePatch({ alpha: normalized });
            }else{
              if(scatterAlphaInput){
                applyAndDispatch(scatterAlphaInput, String(normalized));
              }
              if(scatterAlphaVal){
                scatterAlphaVal.textContent = String(normalized);
              }
              applyGlobalStylePatch('alpha', normalized);
            }
          }
        }
      });
      mountScatterSymbolToolbarGroupedControls(symbolToolbarState);
      const toolbarHost = symbolToolbarState?.host || null;
      if(toolbarHost && scatterCurrentGraphType === 'scatter'){
        const overlayState = showScatterOverlayFormatControls({
          host: toolbarHost,
          target,
          skipHideAll: true,
          appendToHost: true,
          clearHost: false,
          keepOpenWithinHost: true,
          keepHostVisible: true,
          hostClass: 'font-toolbar-host--scatter-dual',
          hostDisplay: 'grid'
        });
        if(overlayState){
          toolbarHost.classList.add('font-toolbar-host--scatter-dual');
        }else{
          resetScatterDualHostLayout(toolbarHost);
        }
      }
      return;
    }
    console.debug('Debug: scatter symbol toolbar unavailable; legacy fallback removed');
  }

  function attachScatterSelectAutoSize(select, label){
    if(!select){ return; }
    if(typeof formControls.attachSelectAutoSize === 'function'){
      formControls.attachSelectAutoSize(select, label || 'scatter');
      return;
    }
    const debugEnabled = typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled();
    const watcher = typeof formControls.watchSelectAutoSize === 'function' ? formControls.watchSelectAutoSize : null;
    const autoSizer = typeof formControls.autoSizeSelect === 'function' ? formControls.autoSizeSelect : null;
    try{
      if(watcher){
        watcher(select);
        if(debugEnabled){
          console.debug('Debug: scatter select auto-size watcher attached', {
            id: select.id || null,
            label: label || null
          });
        }
      }else if(autoSizer){
        autoSizer(select);
        if(debugEnabled){
          console.debug('Debug: scatter select auto-size applied without watcher', {
            id: select.id || null,
            label: label || null
          });
        }
      }else if(debugEnabled){
        console.debug('Debug: scatter select auto-size helper unavailable', {
          id: select.id || null,
          label: label || null
        });
      }
    }catch(err){
      if(debugEnabled){
        console.debug('Debug: scatter select auto-size attach error', {
          id: select.id || null,
          label: label || null,
          error: err?.message || String(err)
        });
      }
    }
  }

  function createScatterAxisSettings(){
    return {
      strokeWidth: 1,
      color: DEFAULT_AXIS_COLOR,
      x: { tickInterval: null, minorTicks: false, minorTickSubdivisions: DEFAULT_MINOR_TICK_SUBDIVISIONS, notation: 'decimal', additionalTicks: [], brokenAxis: { enabled: false, segments: [] } },
      y: { tickInterval: null, minorTicks: false, minorTickSubdivisions: DEFAULT_MINOR_TICK_SUBDIVISIONS, notation: 'decimal', additionalTicks: [], brokenAxis: { enabled: false, segments: [] } }
    };
  }

  function sanitizeScatterAxisNotation(value){
    if(value === 'auto' || value === 'decimal' || value === 'scientific'){ return value; }
    return 'decimal';
  }

  let scatterAxisSettings = createScatterAxisSettings();
  let scatterGridStyle = null;

  function createDefaultScatterGridStyle(fallbackThickness){
    const thickness = Number.isFinite(Number(fallbackThickness)) && Number(fallbackThickness) >= 0
      ? Number(fallbackThickness)
      : 1;
    return {
      color: DEFAULT_GRID_COLOR,
      thickness,
      pattern: 'solid',
      transparency: 0
    };
  }

  function sanitizeScatterGridStyle(style, fallbackThickness){
    const fallback = createDefaultScatterGridStyle(fallbackThickness);
    if(gridControls && typeof gridControls.sanitizeStyle === 'function'){
      return gridControls.sanitizeStyle(style, fallback);
    }
    const source = style && typeof style === 'object' ? style : {};
    const color = typeof source.color === 'string' && source.color.trim() ? source.color : fallback.color;
    const thicknessRaw = Number(source.thickness);
    const thickness = Number.isFinite(thicknessRaw) && thicknessRaw >= 0 ? thicknessRaw : fallback.thickness;
    const patternRaw = String(source.pattern || fallback.pattern || 'solid').toLowerCase();
    const pattern = (patternRaw === 'dashed' || patternRaw === 'dotted' || patternRaw === 'solid') ? patternRaw : 'solid';
    const transparencyRaw = Number(source.transparency);
    const transparency = Number.isFinite(transparencyRaw) ? Math.max(0, Math.min(100, transparencyRaw)) : fallback.transparency;
    return { color, thickness, pattern, transparency };
  }

  function ensureScatterGridStyle(fallbackThickness){
    scatterGridStyle = sanitizeScatterGridStyle(scatterGridStyle, fallbackThickness);
    return scatterGridStyle;
  }

  function getScatterGridStyle(fallbackThickness){
    return sanitizeScatterGridStyle(ensureScatterGridStyle(fallbackThickness), fallbackThickness);
  }

  function setScatterGridStyle(style, fallbackThickness){
    scatterGridStyle = sanitizeScatterGridStyle(style, fallbackThickness);
  }

  function ensureScatterAxisSettings(){
    if(!scatterAxisSettings || typeof scatterAxisSettings !== 'object'){
      scatterAxisSettings = createScatterAxisSettings();
    }
    if(!scatterAxisSettings.x || typeof scatterAxisSettings.x !== 'object'){
      scatterAxisSettings.x = { tickInterval: null, minorTickSubdivisions: DEFAULT_MINOR_TICK_SUBDIVISIONS, notation: 'decimal', additionalTicks: [], brokenAxis: { enabled: false, segments: [] } };
    }
    if(!scatterAxisSettings.y || typeof scatterAxisSettings.y !== 'object'){
      scatterAxisSettings.y = { tickInterval: null, minorTickSubdivisions: DEFAULT_MINOR_TICK_SUBDIVISIONS, notation: 'decimal', additionalTicks: [], brokenAxis: { enabled: false, segments: [] } };
    }
    if(typeof scatterAxisSettings.x.minorTicks !== 'boolean'){
      scatterAxisSettings.x.minorTicks = false;
    }
    if(typeof scatterAxisSettings.y.minorTicks !== 'boolean'){
      scatterAxisSettings.y.minorTicks = false;
    }
    if(!scatterAxisSettings.x.brokenAxis || typeof scatterAxisSettings.x.brokenAxis !== 'object'){
      scatterAxisSettings.x.brokenAxis = { enabled: false, segments: [] };
    }
    if(typeof scatterAxisSettings.x.brokenAxis.enabled !== 'boolean'){
      scatterAxisSettings.x.brokenAxis.enabled = false;
    }
    if(!Array.isArray(scatterAxisSettings.x.brokenAxis.segments)){
      scatterAxisSettings.x.brokenAxis.segments = [];
    }
    if(!scatterAxisSettings.y.brokenAxis || typeof scatterAxisSettings.y.brokenAxis !== 'object'){
      scatterAxisSettings.y.brokenAxis = { enabled: false, segments: [] };
    }
    if(typeof scatterAxisSettings.y.brokenAxis.enabled !== 'boolean'){
      scatterAxisSettings.y.brokenAxis.enabled = false;
    }
    if(!Array.isArray(scatterAxisSettings.y.brokenAxis.segments)){
      scatterAxisSettings.y.brokenAxis.segments = [];
    }
    scatterAxisSettings.x.minorTickSubdivisions = clampMinorTickSubdivisions(scatterAxisSettings.x.minorTickSubdivisions);
    scatterAxisSettings.y.minorTickSubdivisions = clampMinorTickSubdivisions(scatterAxisSettings.y.minorTickSubdivisions);
    const strokeNumeric = Number(scatterAxisSettings.strokeWidth);
    scatterAxisSettings.strokeWidth = Number.isFinite(strokeNumeric) && strokeNumeric > 0 ? strokeNumeric : 1;
    if(typeof scatterAxisSettings.color !== 'string' || !scatterAxisSettings.color){
      scatterAxisSettings.color = DEFAULT_AXIS_COLOR;
    }
    scatterAxisSettings.x.notation = sanitizeScatterAxisNotation(scatterAxisSettings.x.notation);
    scatterAxisSettings.y.notation = sanitizeScatterAxisNotation(scatterAxisSettings.y.notation);
    scatterAxisSettings.x.additionalTicks = sanitizeScatterAxisAdditionalTicks(scatterAxisSettings.x.additionalTicks);
    scatterAxisSettings.y.additionalTicks = sanitizeScatterAxisAdditionalTicks(scatterAxisSettings.y.additionalTicks);
    return scatterAxisSettings;
  }

  function getScatterAxisNotation(axis){
    if(axis !== 'x' && axis !== 'y'){ return 'auto'; }
    const settings = ensureScatterAxisSettings();
    return sanitizeScatterAxisNotation(settings[axis]?.notation);
  }

  function updateScatterAxisNotation(axis, value){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    const nextValue = sanitizeScatterAxisNotation(value);
    if(settings[axis].notation === nextValue){ return; }
    settings[axis].notation = nextValue;
    console.debug('Debug: scatter axis notation updated',{ axis, notation: nextValue });
    scheduleScatterViewRefresh(`axis-notation-${axis}`);
  }

  function getScatterAxisTickInterval(axis){
    if(axis !== 'x' && axis !== 'y'){ return null; }
    const settings = ensureScatterAxisSettings();
    const raw = settings[axis]?.tickInterval;
    if(raw === null || raw === undefined || raw === ''){
      return null;
    }
    const numeric = Number(raw);
    return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
  }

  function updateScatterAxisTickInterval(axis, value){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    if(value === null || value === undefined || value === ''){
      settings[axis].tickInterval = null;
    } else {
      const numeric = Number(value);
      settings[axis].tickInterval = Number.isFinite(numeric) && numeric > 0 ? numeric : null;
    }
    console.debug('Debug: scatter axis tick interval updated',{ axis, tickInterval: settings[axis].tickInterval });
    scheduleScatterViewRefresh(`axis-ticks-${axis}`);
  }

  function getScatterAxisMinorTicksEnabled(axis){
    if(axis !== 'x' && axis !== 'y'){ return false; }
    const settings = ensureScatterAxisSettings();
    return !!settings[axis]?.minorTicks;
  }

  function updateScatterAxisMinorTicks(axis, enabled){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    const nextValue = !!enabled;
    if(settings[axis].minorTicks === nextValue){
      return;
    }
    settings[axis].minorTicks = nextValue;
    console.debug('Debug: scatter minor ticks updated',{ axis, enabled: nextValue });
    scheduleScatterViewRefresh(`axis-minor-ticks-${axis}`);
  }

  function getScatterAxisMinorTickSubdivisions(axis){
    if(axis !== 'x' && axis !== 'y'){ return DEFAULT_MINOR_TICK_SUBDIVISIONS; }
    const settings = ensureScatterAxisSettings();
    return clampMinorTickSubdivisions(settings[axis]?.minorTickSubdivisions);
  }

  function updateScatterAxisMinorTickSubdivisions(axis, value){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    const nextValue = clampMinorTickSubdivisions(value);
    if(settings[axis].minorTickSubdivisions === nextValue){
      return;
    }
    settings[axis].minorTickSubdivisions = nextValue;
    console.debug('Debug: scatter minor tick subdivisions updated',{ axis, subdivisions: nextValue });
    scheduleScatterViewRefresh(`axis-minor-subdivisions-${axis}`);
  }

  function getScatterAxisAdditionalTicks(axis){
    if(axis !== 'x' && axis !== 'y'){
      return [];
    }
    const settings = ensureScatterAxisSettings();
    if(axisExtras && typeof axisExtras.getEntries === 'function'){
      return axisExtras.getEntries(settings, axis, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
    }
    return sanitizeScatterAxisAdditionalTicks(settings[axis]?.additionalTicks);
  }

  function updateScatterAxisAdditionalTicks(axis, entries){
    if(axis !== 'x' && axis !== 'y'){
      return;
    }
    const settings = ensureScatterAxisSettings();
    if(axisExtras && typeof axisExtras.setEntries === 'function'){
      axisExtras.setEntries(settings, axis, entries, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
    }else{
      settings[axis].additionalTicks = sanitizeScatterAxisAdditionalTicks(entries);
    }
    scatterDebug('Debug: scatter axis additional ticks updated', {
      axis,
      count: settings[axis].additionalTicks.length
    });
    scheduleScatterViewRefresh(`axis-additional-ticks-${axis}`);
  }

  function updateScatterAxisAdditionalTick(axis, index, entry){
    if(axis !== 'x' && axis !== 'y'){
      return;
    }
    const settings = ensureScatterAxisSettings();
    if(axisExtras && typeof axisExtras.updateEntry === 'function'){
      const currentEntries = axisExtras.getEntries(settings, axis, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
      const currentEntry = Array.isArray(currentEntries) && index >= 0 && index < currentEntries.length
        ? currentEntries[index]
        : null;
      const mergedEntry = (currentEntry && typeof currentEntry === 'object')
        ? { ...currentEntry, ...(entry && typeof entry === 'object' ? entry : {}) }
        : entry;
      const updated = axisExtras.updateEntry(settings, axis, index, mergedEntry, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
      if(!updated){
        return;
      }
      updateScatterAxisAdditionalTicks(axis, settings[axis].additionalTicks);
      return;
    }
    const entries = sanitizeScatterAxisAdditionalTicks(settings[axis].additionalTicks);
    if(!Number.isInteger(index) || index < 0 || index >= entries.length){
      return;
    }
    const sanitized = sanitizeScatterAxisAdditionalTickEntry(entry);
    if(!sanitized){
      return;
    }
    entries[index] = sanitized;
    updateScatterAxisAdditionalTicks(axis, entries);
  }

  function addScatterAxisAdditionalTick(axis){
    if(axis !== 'x' && axis !== 'y'){
      return;
    }
    const settings = ensureScatterAxisSettings();
    if(axisExtras && typeof axisExtras.addEntry === 'function'){
      const added = axisExtras.addEntry(settings, axis, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK, increment: 1 });
      if(!added){
        return;
      }
      updateScatterAxisAdditionalTicks(axis, settings[axis].additionalTicks);
      return;
    }
    const entries = sanitizeScatterAxisAdditionalTicks(settings[axis].additionalTicks);
    const last = entries.length ? entries[entries.length - 1] : null;
    entries.push({
      value: Number.isFinite(last?.value) ? Number(last.value) + 1 : DEFAULT_AXIS_ADDITIONAL_TICK.value,
      showTick: DEFAULT_AXIS_ADDITIONAL_TICK.showTick,
      showLine: DEFAULT_AXIS_ADDITIONAL_TICK.showLine,
      label: DEFAULT_AXIS_ADDITIONAL_TICK.label,
      lineColor: DEFAULT_AXIS_ADDITIONAL_TICK.lineColor,
      lineWidth: DEFAULT_AXIS_ADDITIONAL_TICK.lineWidth,
      linePattern: DEFAULT_AXIS_ADDITIONAL_TICK.linePattern,
      lineTransparency: DEFAULT_AXIS_ADDITIONAL_TICK.lineTransparency
    });
    updateScatterAxisAdditionalTicks(axis, entries);
  }

  function removeScatterAxisAdditionalTick(axis, index){
    if(axis !== 'x' && axis !== 'y'){
      return;
    }
    const settings = ensureScatterAxisSettings();
    if(axisExtras && typeof axisExtras.removeEntry === 'function'){
      const removed = axisExtras.removeEntry(settings, axis, index, { defaults: DEFAULT_AXIS_ADDITIONAL_TICK });
      if(!removed){
        return;
      }
      updateScatterAxisAdditionalTicks(axis, settings[axis].additionalTicks);
      return;
    }
    const entries = sanitizeScatterAxisAdditionalTicks(settings[axis].additionalTicks);
    if(!Number.isInteger(index) || index < 0 || index >= entries.length){
      return;
    }
    entries.splice(index, 1);
    updateScatterAxisAdditionalTicks(axis, entries);
  }

  function getScatterAxisStrokeWidth(){
    const settings = ensureScatterAxisSettings();
    return settings.strokeWidth;
  }

  function updateScatterAxisStrokeWidth(value){
    const settings = ensureScatterAxisSettings();
    if(value === null || value === undefined || value === ''){
      settings.strokeWidth = 1;
    } else {
      const numeric = Number(value);
      settings.strokeWidth = Number.isFinite(numeric) && numeric > 0 ? numeric : 1;
    }
    console.debug('Debug: scatter axis stroke width updated',{ strokeWidth: settings.strokeWidth });
    scheduleScatterViewRefresh('axis-stroke-width');
  }

  function getScatterAxisColor(){
    const settings = ensureScatterAxisSettings();
    return settings.color || DEFAULT_AXIS_COLOR;
  }

  function updateScatterAxisColor(value){
    const settings = ensureScatterAxisSettings();
    settings.color = typeof value === 'string' && value.trim() ? value : DEFAULT_AXIS_COLOR;
    console.debug('Debug: scatter axis color updated',{ color: settings.color });
    scheduleScatterViewRefresh('axis-color');
  }

  function registerScatterGridControlTarget(target, options){
    if(!target || !gridControls || typeof gridControls.registerGraphElement !== 'function'){
      return;
    }
    const opts = options && typeof options === 'object' ? options : {};
    const fallbackThickness = Number.isFinite(Number(opts.fallbackThickness)) ? Number(opts.fallbackThickness) : getScatterAxisStrokeWidth();
    gridControls.registerGraphElement(target, {
      scopeId: 'scatter',
      hostClass: 'font-toolbar-host--scatter-dual',
      getVisible: () => !!scatterShowGrid?.checked,
      onVisibleChange: value => {
        if(scatterShowGrid){
          scatterShowGrid.checked = !!value;
        }
        scheduleScatterViewRefresh('grid-visible');
      },
      getStyle: () => getScatterGridStyle(fallbackThickness),
      onStyleChange: style => {
        setScatterGridStyle(style, fallbackThickness);
        scheduleScatterViewRefresh('grid-style');
      },
      defaults: createDefaultScatterGridStyle(fallbackThickness)
    });
  }

  function getBrokenAxisEnabled(axis){
    if(axis !== 'x' && axis !== 'y'){ return false; }
    const settings = ensureScatterAxisSettings();
    return !!settings[axis]?.brokenAxis?.enabled;
  }

  function updateBrokenAxisEnabled(axis, enabled){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    const previousValue = !!settings[axis].brokenAxis.enabled;
    settings[axis].brokenAxis.enabled = !!enabled;
    console.debug('Debug: scatter broken axis enabled updated',{ axis, enabled: settings[axis].brokenAxis.enabled });
    scheduleScatterViewRefresh(`axis-broken-${axis}`);
    return previousValue;
  }

  function getBrokenAxisSegments(axis){
    if(axis !== 'x' && axis !== 'y'){ return []; }
    const settings = ensureScatterAxisSettings();
    return settings[axis]?.brokenAxis?.segments || [];
  }

  function updateBrokenAxisSegments(axis, segments){
    if(axis !== 'x' && axis !== 'y'){ return; }
    const settings = ensureScatterAxisSettings();
    if(!Array.isArray(segments)){
      settings[axis].brokenAxis.segments = [];
      return;
    }
    settings[axis].brokenAxis.segments = segments.filter(seg => {
      return seg &&
             typeof seg === 'object' &&
             Number.isFinite(seg.start) &&
             Number.isFinite(seg.end) &&
             seg.start < seg.end;
    }).map(seg => ({ start: Number(seg.start), end: Number(seg.end) }));
    console.debug('Debug: scatter broken axis segments updated',{ axis, segments: settings[axis].brokenAxis.segments });
    scheduleScatterViewRefresh(`axis-broken-segments-${axis}`);
  }

  function applyScatterAxisSettings(settings){
    const base = createScatterAxisSettings();
    if(settings && typeof settings === 'object'){
      const strokeCandidate = Number(settings.strokeWidth);
      if(Number.isFinite(strokeCandidate) && strokeCandidate > 0){
        base.strokeWidth = strokeCandidate;
      }
      if(typeof settings.color === 'string' && settings.color.trim()){
        base.color = settings.color;
      }
      const xInterval = settings.tickIntervalX ?? settings.xTickInterval ?? settings?.x?.tickInterval ?? null;
      const yInterval = settings.tickIntervalY ?? settings.yTickInterval ?? settings?.y?.tickInterval ?? null;
      base.x.tickInterval = xInterval === '' ? null : xInterval;
      base.y.tickInterval = yInterval === '' ? null : yInterval;
      base.x.minorTicks = !!(settings.minorTicksX ?? settings.x?.minorTicks ?? false);
      base.y.minorTicks = !!(settings.minorTicksY ?? settings.y?.minorTicks ?? false);
      const xMinorSubdiv = settings.minorTickSubdivisionsX ?? settings.minorSubdivisionsX ?? settings.x?.minorTickSubdivisions ?? settings.x?.minorSubdivisions ?? null;
      const yMinorSubdiv = settings.minorTickSubdivisionsY ?? settings.minorSubdivisionsY ?? settings.y?.minorTickSubdivisions ?? settings.y?.minorSubdivisions ?? null;
      base.x.minorTickSubdivisions = clampMinorTickSubdivisions(xMinorSubdiv);
      base.y.minorTickSubdivisions = clampMinorTickSubdivisions(yMinorSubdiv);
      const xNotation = settings.axisNotationX ?? settings.notationX ?? settings?.x?.notation ?? 'decimal';
      const yNotation = settings.axisNotationY ?? settings.notationY ?? settings?.y?.notation ?? 'decimal';
      base.x.notation = sanitizeScatterAxisNotation(xNotation);
      base.y.notation = sanitizeScatterAxisNotation(yNotation);
      if(settings.additionalTicks !== undefined){
        if(Array.isArray(settings.additionalTicks)){
          base.x.additionalTicks = sanitizeScatterAxisAdditionalTicks(settings.additionalTicksX);
          base.y.additionalTicks = sanitizeScatterAxisAdditionalTicks(settings.additionalTicksY ?? settings.additionalTicks);
        }else{
          base.x.additionalTicks = sanitizeScatterAxisAdditionalTicks(
            settings.additionalTicks.x ?? settings.additionalTicksX ?? settings?.x?.additionalTicks
          );
          base.y.additionalTicks = sanitizeScatterAxisAdditionalTicks(
            settings.additionalTicks.y ?? settings.additionalTicksY ?? settings?.y?.additionalTicks
          );
        }
      }else{
        base.x.additionalTicks = sanitizeScatterAxisAdditionalTicks(settings.additionalTicksX ?? settings?.x?.additionalTicks);
        base.y.additionalTicks = sanitizeScatterAxisAdditionalTicks(settings.additionalTicksY ?? settings?.y?.additionalTicks);
      }
      if(settings.brokenAxis){
        if(settings.brokenAxis.x){
          base.x.brokenAxis = {
            enabled: !!settings.brokenAxis.x.enabled,
            segments: Array.isArray(settings.brokenAxis.x.segments)
              ? settings.brokenAxis.x.segments.filter(seg =>
                  seg &&
                  Number.isFinite(seg.start) &&
                  Number.isFinite(seg.end) &&
                  seg.start < seg.end
                ).map(seg => ({ start: Number(seg.start), end: Number(seg.end) }))
              : []
          };
        }
        if(settings.brokenAxis.y){
          base.y.brokenAxis = {
            enabled: !!settings.brokenAxis.y.enabled,
            segments: Array.isArray(settings.brokenAxis.y.segments)
              ? settings.brokenAxis.y.segments.filter(seg =>
                  seg &&
                  Number.isFinite(seg.start) &&
                  Number.isFinite(seg.end) &&
                  seg.start < seg.end
                ).map(seg => ({ start: Number(seg.start), end: Number(seg.end) }))
              : []
          };
        }
      }
    }
    scatterAxisSettings = base;
    ensureScatterAxisSettings();
    console.debug('Debug: scatter axis settings applied',{ settings: scatterAxisSettings });
  }

  function clampScatterTickTarget(value){
    const axisTicks = chartStyle.axisTicks;
    if(axisTicks && typeof axisTicks.clampTickTarget === 'function'){
      return axisTicks.clampTickTarget(value);
    }
    if(!Number.isFinite(value)){
      return 6;
    }
    const rounded = Math.round(value);
    return Math.max(5, Math.min(8, rounded));
  }

  function buildScatterScale(options){
    const axisTicks = chartStyle.axisTicks;
    if(axisTicks && typeof axisTicks.buildScale === 'function'){
      const scale = axisTicks.buildScale(options);
      scatterDebug('Debug: scatter scale computed', {
        ...options,
        tickCount: Array.isArray(scale?.ticks) ? scale.ticks.length : null,
        step: scale?.step,
        min: scale?.min,
        max: scale?.max
      });
      return scale;
    }
    scatterDebug('Debug: scatter scale fallback invoked', { reason: 'missing axis tick helpers' });
    return {
      min: Number.isFinite(options?.manualMin) ? options.manualMin : Number(options?.dataMin) || 0,
      max: Number.isFinite(options?.manualMax) ? options.manualMax : Number(options?.dataMax) || 1,
      ticks: [Number(options?.manualMin) || 0, Number(options?.manualMax) || 1],
      step: Number(options?.fixedStep) || 1
    };
  }

  function computeBrokenAxisScale(config){
    const { dataMin, dataMax, segments, plotLength, orientation } = config;
    const isHorizontal = orientation === 'horizontal';

    if(!Array.isArray(segments) || segments.length === 0){
      return {
        isBroken: false,
        min: dataMin,
        max: dataMax,
        valueToPixel: (value, basePos, plotLen) => {
          const range = dataMax - dataMin || 1;
          if(isHorizontal){
            return basePos + plotLen * ((value - dataMin) / range);
          }
          return basePos + plotLen * (1 - (value - dataMin) / range);
        },
        segments: []
      };
    }

    const validSegments = segments
      .filter(seg => Number.isFinite(seg.start) && Number.isFinite(seg.end) && seg.start < seg.end)
      .sort((a, b) => a.start - b.start);

    if(validSegments.length === 0){
      return {
        isBroken: false,
        min: dataMin,
        max: dataMax,
        valueToPixel: (value, basePos, plotLen) => {
          const range = dataMax - dataMin || 1;
          if(isHorizontal){
            return basePos + plotLen * ((value - dataMin) / range);
          }
          return basePos + plotLen * (1 - (value - dataMin) / range);
        },
        segments: []
      };
    }

    const mergedSegments = [];
    let current = { ...validSegments[0] };
    for(let i = 1; i < validSegments.length; i++){
      const seg = validSegments[i];
      if(seg.start <= current.end){
        current.end = Math.max(current.end, seg.end);
      }else{
        mergedSegments.push(current);
        current = { ...seg };
      }
    }
    mergedSegments.push(current);

    const totalDataRange = mergedSegments.reduce((sum, seg) => sum + (seg.end - seg.start), 0);
    const gapSizePx = BROKEN_AXIS_GAP_SIZE_PX;
    const numGaps = mergedSegments.length - 1;
    const totalGapLength = numGaps * gapSizePx;
    const availableLength = plotLength - totalGapLength;

    const segmentMeta = mergedSegments.map(seg => {
      const dataRange = seg.end - seg.start;
      const lengthPx = (dataRange / totalDataRange) * availableLength;
      return {
        start: seg.start,
        end: seg.end,
        dataRange,
        lengthPx,
        pixelStart: 0,
        pixelEnd: 0
      };
    });

    let currentPixel = 0;
    for(let i = 0; i < segmentMeta.length; i++){
      segmentMeta[i].pixelStart = currentPixel;
      segmentMeta[i].pixelEnd = currentPixel + segmentMeta[i].lengthPx;
      currentPixel = segmentMeta[i].pixelEnd + gapSizePx;
    }

    const valueToPixel = (value, basePos, plotLen) => {
      const mapPixel = pixel => {
        if(isHorizontal){
          return basePos + pixel;
        }
        return basePos + plotLen - pixel;
      };

      for(let i = 0; i < segmentMeta.length; i++){
        const seg = segmentMeta[i];
        if(value >= seg.start && value <= seg.end){
          const fraction = seg.dataRange > 0 ? (value - seg.start) / seg.dataRange : 0;
          const pixelInSegment = seg.pixelStart + fraction * seg.lengthPx;
          return mapPixel(pixelInSegment);
        }
      }

      if(value < segmentMeta[0].start){
        return mapPixel(segmentMeta[0].pixelStart);
      }
      if(value > segmentMeta[segmentMeta.length - 1].end){
        return mapPixel(segmentMeta[segmentMeta.length - 1].pixelEnd);
      }

      for(let i = 0; i < segmentMeta.length - 1; i++){
        if(value > segmentMeta[i].end && value < segmentMeta[i + 1].start){
          return mapPixel(segmentMeta[i].pixelEnd);
        }
      }

      return mapPixel(segmentMeta[0].pixelStart);
    };

    return {
      isBroken: true,
      min: mergedSegments[0].start,
      max: mergedSegments[mergedSegments.length - 1].end,
      segments: segmentMeta,
      gapSizePx,
      valueToPixel
    };
  }

  let scheduleDrawScatter = () => {};
  let scheduleDrawScatterRaw = () => {};
  let syncScatterSymbolToolbarDotToggles = null;
  let scatterGroupedModeDefaultApplied = false;
  let scatterLayout = null;
  let scatterLayoutWasHidden = true;
  let scatterLayoutDeferredSync = false;
  let scatterCurrentGraphType='scatter';
  let scatterTableFormat = SCATTER_TABLE_FORMAT_SINGLE;
  let scatterReplicates = SCATTER_MIN_REPLICATES;
  let scatterGroupedXReplicates = false;
  let scatterLastGroupedReplicateCount = SCATTER_DEFAULT_GROUPED_REPLICATES;
  let scatterSeriesGroupLabels = [];
  let scatterLastGraphType='scatter';
  let scatterLastRegressionSummary=null;
  const scatterAdvisorState={
    open:false,
    activated:false,
    answers:{},
    lastApplied:null,
    context:null,
    pendingPoints:null
  };
  const scatterOverlayController = Shared.loadingOverlay?.createPendingController?.({
    component: 'scatter',
    message: 'Rendering scatter plot...',
    getHost: () => (
      global.document?.getElementById?.('scatterGraphPanel')?.querySelector?.('.svgbox')
      || global.document?.getElementById?.('scatterGraphPanel')
    )
  });

  function markScatterOverlayPending(reason){
    scatterOverlayController?.markPending(reason);
    scatterDebug('Debug: scatter overlay pending flagged', { reason: reason || 'data-change' });
  }

  function queueScatterOverlay(reason, options = {}){
    return scatterOverlayController?.queue(reason, options) || false;
  }

  function resolveScatterOverlay(reason){
    scatterOverlayController?.resolve(reason);
  }

  function forceScatterOverlay(reason, options = {}){
    return scatterOverlayController?.force(reason, options) || false;
  }

  function formatP(p){
    if(p === undefined || p === null || Number.isNaN(p)) return 'n/a';
    if(!Number.isFinite(p)) return p > 0 ? 'Infinity' : '-Infinity';
    const formatter = Shared.formatters?.formatPValue || Shared.formatPValue;
    if(typeof formatter === 'function'){
      return formatter(p);
    }
    if(p === 0) return '0';
    return Number(p).toExponential(5);
  }
  function getScatterStatsAlpha(){
    const reporting = Shared.statsReporting;
    if(reporting && typeof reporting.getSignificanceThreshold === 'function'){
      const alpha = Number(reporting.getSignificanceThreshold());
      if(Number.isFinite(alpha) && alpha > 0 && alpha < 1){
        return alpha;
      }
    }
    return 0.05;
  }
  function formatScatterAlphaLabel(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return '0.05';
    }
    if(numeric >= 0.01){
      return numeric.toFixed(3).replace(/0+$/, '').replace(/\.$/, '');
    }
    return numeric.toExponential(2);
  }
  function normalizeScatterReportMetric(metric){
    const source = String(metric || '').trim().replace(/^\[[^\]]+\]\s*/, '');
    if(!source){
      return '';
    }
    if(source === 'Intercept'){
      return 'Y-intercept';
    }
    if(source === 'Residual SD'){
      return 'Sy.x';
    }
    if(source === 'Correlation (95% CI, approx)'){
      return 'Correlation (95% CI)';
    }
    if(source === 'N (paired)' || source === 'N (fit)'){
      return 'N';
    }
    return source;
  }
  function formatScatterSummaryNumber(value, digits = 4){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return 'n/a';
    }
    const safeDigits = Number.isFinite(digits) ? digits : 4;
    const absValue = Math.abs(numeric);
    const lowerBound = Math.pow(10, -Math.max(2, safeDigits));
    if(absValue !== 0 && (absValue < lowerBound || absValue >= 1e6)){
      return numeric.toExponential(Math.max(2, safeDigits));
    }
    return numeric.toFixed(safeDigits);
  }
  function pushScatterUniqueMetricRow(rows, seen, metric, value){
    const metricLabel = normalizeScatterReportMetric(metric);
    if(!metricLabel || seen.has(metricLabel)){
      return;
    }
    rows.push({ metric: metricLabel, value: value == null || value === '' ? '—' : value });
    seen.add(metricLabel);
  }
  function buildScatterDisplayRowSets(detail, settings){
    const sourceRows = Array.isArray(detail?.rows) ? detail.rows : [];
    const advancedRows = [];
    const advancedSeen = new Set();
    const summaryRows = [];
    const summarySeen = new Set();
    const metricMap = new Map();
    sourceRows.forEach(row => {
      const normalizedMetric = normalizeScatterReportMetric(row?.metric);
      if(normalizedMetric && !metricMap.has(normalizedMetric)){
        metricMap.set(normalizedMetric, row?.value ?? '—');
      }
    });

    const confidenceLevel = Number(settings?.fitSpec?.confidenceLevel);
    const confidenceLabel = Number.isFinite(confidenceLevel)
      ? `${formatScatterSummaryNumber(confidenceLevel, confidenceLevel % 1 === 0 ? 0 : 2)}%`
      : '95%';
    const alpha = getScatterStatsAlpha();
    const regressionModeValue = String(detail?.regressionModeValue || '').trim().toLowerCase();
    const associationMethod = String(detail?.associationMethod || '').trim().toLowerCase();
    const regressionModel = detail?.regressionModel || null;
    const coefficientRows = Array.isArray(detail?.coefficientRows) ? detail.coefficientRows : [];
    const findCoefficient = term => coefficientRows.find(row => String(row?.term || '').trim().toLowerCase() === term) || null;
    const slopeCoefficient = findCoefficient('slope');
    const interceptCoefficient = findCoefficient('intercept');
    const addSummaryMetric = metric => {
      if(metricMap.has(metric)){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, metric, metricMap.get(metric));
      }
    };
    const addAdvancedMetric = metric => {
      if(metricMap.has(metric)){
        pushScatterUniqueMetricRow(advancedRows, advancedSeen, metric, metricMap.get(metric));
      }
    };

    addSummaryMetric('Regression model');
    addSummaryMetric('N (paired)');
    addSummaryMetric('N (fit)');

    if(associationMethod !== 'none' && regressionModeValue === 'none'){
      addSummaryMetric('r');
      addSummaryMetric('P value');
      addSummaryMetric('Correlation (95% CI)');
    }else{
      addSummaryMetric('Equation');
      addSummaryMetric('Slope');
      addSummaryMetric('Y-intercept');
      if(slopeCoefficient && slopeCoefficient.ciLow !== 'n/a' && slopeCoefficient.ciHigh !== 'n/a'){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, `Slope (${confidenceLabel} CI)`, `${slopeCoefficient.ciLow} to ${slopeCoefficient.ciHigh}`);
      }
      if(interceptCoefficient && interceptCoefficient.ciLow !== 'n/a' && interceptCoefficient.ciHigh !== 'n/a'){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, `Y-intercept (${confidenceLabel} CI)`, `${interceptCoefficient.ciLow} to ${interceptCoefficient.ciHigh}`);
      }
      addSummaryMetric('X-intercept');
      addSummaryMetric(`X-intercept (${confidenceLabel} CI)`);
      addSummaryMetric('1/Slope');
      addSummaryMetric(`1/Slope (${confidenceLabel} CI)`);
      addSummaryMetric('R²');
      addSummaryMetric('Sy.x');

      const slopePValue = Number(regressionModel?.coefficientStats?.find?.(stat => String(stat?.term || '').toLowerCase() === 'slope')?.pValue);
      const fallbackPValue = Number(detail?.stats?.p);
      const reportedPValue = Number.isFinite(slopePValue) ? slopePValue : fallbackPValue;
      const slopeTStatistic = Number(regressionModel?.coefficientStats?.find?.(stat => String(stat?.term || '').toLowerCase() === 'slope')?.tStatistic);
      const residualDf = Number(regressionModel?.metrics?.residualDf);
      if(Number.isFinite(slopeTStatistic)){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, 'F', formatScatterSummaryNumber(slopeTStatistic * slopeTStatistic, 4));
      }
      if(Number.isFinite(residualDf)){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, 'df', `1, ${Math.max(0, Math.round(residualDf))}`);
      }
      if(Number.isFinite(reportedPValue)){
        pushScatterUniqueMetricRow(summaryRows, summarySeen, 'P value', formatP(reportedPValue));
        pushScatterUniqueMetricRow(
          summaryRows,
          summarySeen,
          `Slope significantly non-zero (P < ${formatScatterAlphaLabel(alpha)})?`,
          reportedPValue <= alpha ? 'Yes' : 'No'
        );
      }
    }

    if((!summarySeen.has('Slope') && !summarySeen.has('Y-intercept')) || summaryRows.length <= 3){
      sourceRows
        .filter(row => /^\[Parameters\]/.test(String(row?.metric || '')))
        .slice(0, 3)
        .forEach(row => {
          pushScatterUniqueMetricRow(summaryRows, summarySeen, row?.metric, row?.value);
        });
    }

    sourceRows.forEach(row => {
      const normalizedMetric = normalizeScatterReportMetric(row?.metric);
      if(!normalizedMetric || summarySeen.has(normalizedMetric)){
        return;
      }
      pushScatterUniqueMetricRow(advancedRows, advancedSeen, normalizedMetric, row?.value);
    });

    return { summaryRows, advancedRows };
  }
  function setup(initOptions = {}){
    if(scatter.ready){ console.debug('Debug: Components.scatter.setup skipped'); return; }
    console.debug('Debug: Components.scatter.setup start');
    scheduleDrawScatter = () => {};
    ensureScatterAxisSettings();
    ensureScatterGridStyle(getScatterAxisStrokeWidth());
    const legacyDollar = global.$;
    const $ = (selector) => {
      if(typeof selector !== 'string'){
        return null;
      }
      const trimmed = selector.trim();
      if(!trimmed){
        return null;
      }
      if(trimmed.startsWith('#') && /^#[A-Za-z0-9_-]+$/.test(trimmed)){
        return getScatterNodeById(trimmed.slice(1));
      }
      const scopedNode = queryScatterRoot(trimmed);
      if(scopedNode){
        return scopedNode;
      }
      if(typeof legacyDollar === 'function'){
        return legacyDollar(trimmed);
      }
      return null;
    };
    const document = global.document;
    let scatterTableFormatSelect = null;
    if(!document || typeof Shared?.hot?.createStandardTable !== 'function'){
      console.error('Table factory missing for scatter component');
      return;
    }
    const requestedRoot = initOptions && typeof initOptions === 'object'
      ? (initOptions.root || null)
      : null;
    scatterRoot = requestedRoot || resolveScatterRoot(initOptions?.tabId || null);
    const makeEditableLocal = (el,onChange,options) => {
      const fn = Shared.makeEditable || global.makeEditable;
      if (typeof fn === 'function') {
        return fn(el,onChange,options);
      }
      console.warn('scatter component makeEditable fallback missing');
      return undefined;
    };
    const ensureGraphViewport = Shared.graphViewport?.createEnsurer
      ? Shared.graphViewport.createEnsurer('scatter')
      : (svg, options = {}) => {
        const fn = Shared.ensureGraphViewport || Shared.autoResizeSvg || global.ensureGraphViewport || global.autoResizeSvg;
        if(typeof fn === 'function'){
          fn(svg, { component: 'scatter', debugLabel: 'scatter-viewport-fallback', ...options });
          return;
        }
        console.debug('Debug: scatter ensureGraphViewport helper missing', {
          hasShared: !!Shared,
          hasAutoResize: typeof Shared?.autoResizeSvg === 'function'
        });
      };
    console.debug('Debug: scatter graph viewport helper configured', {
      hasGraphViewport: typeof Shared.graphViewport?.ensure === 'function',
      usesFactory: typeof Shared.graphViewport?.createEnsurer === 'function'
    });
    const serializeSvg = (svgEl, options)=>{
      const fn = Shared.serializeCleanSVG || global.serializeCleanSVG;
      if (typeof fn === 'function') {
        return fn(svgEl, options);
      }
      if (!svgEl) return '';
      const serializer = new (global.XMLSerializer||XMLSerializer)();
      return serializer.serializeToString(svgEl);
    };
    const renderStatsCard=(target,model)=>{
      if(!target) return;
      const hasRenderer=Shared.statsTable && typeof Shared.statsTable.render==='function';
      if(hasRenderer){
        Shared.statsTable.render({ target, ...model });
        console.debug('Debug: scatter renderStatsCard shared',{ caption:model.caption || null, rows:model.rows?.length || 0 });
        return;
      }
      if(!model?.append){
        target.innerHTML='';
      }
      if(model.caption){
        const lead=document.createElement('div');
        lead.className='stats-table-lead';
        lead.textContent=model.caption;
        target.appendChild(lead);
      }
      const table=document.createElement('table');
      const thead=document.createElement('thead');
      const headRow=document.createElement('tr');
      (model.columns||[]).forEach(col=>{
        const th=document.createElement('th');
        th.textContent=col.label;
        headRow.appendChild(th);
      });
      thead.appendChild(headRow);
      table.appendChild(thead);
      const tbody=document.createElement('tbody');
      (model.rows||[]).forEach(row=>{
        const tr=document.createElement('tr');
        (model.columns||[]).forEach(col=>{
          const td=document.createElement('td');
          const value=row?.[col.key];
          td.textContent=value ?? '';
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      target.appendChild(table);
      console.debug('Debug: scatter renderStatsCard fallback',{ caption:model.caption || null, rows:model.rows?.length || 0 });
    };
    const formatMetricValue = (value, digits = 4) => {
      if(!Number.isFinite(value)){
        return 'n/a';
      }
      const absValue = Math.abs(value);
      const lowerBound = Math.pow(10, -Math.max(2, digits));
      if(absValue !== 0 && (absValue < lowerBound || absValue >= 1e6)){
        return value.toExponential(Math.max(2, digits));
      }
      return value.toFixed(digits);
    };
    const SCATTER_ASSOCIATION_METHOD_LABELS = Object.freeze({
      auto: 'Automatic',
      pearson: 'Pearson',
      spearman: 'Spearman',
      none: 'None (model fit only)'
    });
    const SCATTER_FIT_METHOD_LABELS = Object.freeze({
      ols: 'Ordinary least squares',
      wls: 'Weighted least squares',
      wls_y: 'Weighted least squares (1/Y)',
      wls_y2: 'Weighted least squares (1/Y²)',
      wls_x: 'Weighted least squares (1/X)',
      wls_x2: 'Weighted least squares (1/X²)',
      huber: 'Robust (Huber)'
    });
    const SCATTER_CUSTOM_REGRESSION_MODES = Object.freeze(['deming', 'orthogonal', 'lowess']);
    const SCATTER_REGRESSION_METHOD_POLICY = Object.freeze({
      linear: { fitMethods: ['ols', 'wls_y2', 'wls_y', 'wls_x2', 'wls_x', 'huber'], autoAssociation: 'pearson', fitGuidance: 'Closed-form linear least-squares fit with publication-ready diagnostics, influence measures, and model comparison support.' },
      linearThroughOrigin: { fitMethods: ['ols', 'wls_y2', 'wls_y', 'wls_x2', 'wls_x', 'huber'], autoAssociation: 'pearson', fitGuidance: 'Closed-form least-squares fit constrained through origin. Use only when a zero intercept is scientifically required.' },
      deming: { fitMethods: ['ols'], autoAssociation: 'pearson', fitGuidance: 'Errors-in-variables regression for method-comparison data when X and Y both have measurement error.' },
      orthogonal: { fitMethods: ['ols'], autoAssociation: 'pearson', fitGuidance: 'Orthogonal regression is the equal-error special case of Deming regression.' },
      lowess: { fitMethods: ['ols'], autoAssociation: 'none', fitGuidance: 'LOWESS smoother for descriptive trend visualization. Do not interpret it as a mechanistic model.' },
      quadratic: { fitMethods: ['ols'], autoAssociation: 'none', fitGuidance: 'Polynomial least-squares fit (fixed estimator).' },
      cubic: { fitMethods: ['ols'], autoAssociation: 'none', fitGuidance: 'Polynomial least-squares fit (fixed estimator).' },
      logistic: { fitMethods: ['ols'], autoAssociation: 'spearman', fitGuidance: 'Logistic / dose-response routine uses model-specific optimization.' },
      doseResponse3pl: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      doseResponse4pl: { fitMethods: ['ols'], autoAssociation: 'spearman', fitGuidance: '4PL optimizer uses model-specific routine.' },
      doseResponse5pl: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      exponential: { fitMethods: ['ols'], autoAssociation: 'spearman', fitGuidance: 'Model fit uses transformed least-squares routine.' },
      onePhaseAssociation: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      onePhaseDecay: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      gompertz: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      power: { fitMethods: ['ols'], autoAssociation: 'spearman', fitGuidance: 'Model fit uses transformed least-squares routine.' },
      gaussian: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'none', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      spline: { fitMethods: ['ols'], autoAssociation: 'none', fitGuidance: 'Spline fit is deterministic from observed knots.' },
      bindingSaturation: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      bindingCompetitive: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      enzymeKineticsSubstrate: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' },
      enzymeKineticsInhibition: { fitMethods: ['ols', 'wls', 'huber'], autoAssociation: 'spearman', fitGuidance: 'Nonlinear least-squares with optional weighting/robust loss.' }
    });
    const normalizeScatterAssociationSelection = value => {
      const normalized = String(value || '').trim().toLowerCase();
      if(normalized === 'pearson' || normalized === 'spearman' || normalized === 'none' || normalized === 'auto'){
        return normalized;
      }
      return 'auto';
    };
    const normalizeScatterFitMethod = value => {
      const normalized = String(value || '').trim().toLowerCase().replace(/\s+/g, '');
      const aliasMap = {
        'wls(1/y)': 'wls_y',
        'wls(1/y²)': 'wls_y2',
        'wls(1/y^2)': 'wls_y2',
        'wls(1/x)': 'wls_x',
        'wls(1/x²)': 'wls_x2',
        'wls(1/x^2)': 'wls_x2'
      };
      const resolved = aliasMap[normalized] || normalized;
      return (resolved === 'wls' || resolved === 'wls_y' || resolved === 'wls_y2' || resolved === 'wls_x' || resolved === 'wls_x2' || resolved === 'huber' || resolved === 'ols')
        ? resolved
        : 'ols';
    };
    const getScatterFitMethodFamily = method => {
      const normalized = normalizeScatterFitMethod(method);
      if(normalized.indexOf('wls') === 0){
        return 'wls';
      }
      return normalized === 'huber' ? 'huber' : 'ols';
    };
    const isScatterCustomRegressionMode = mode => SCATTER_CUSTOM_REGRESSION_MODES.includes(String(mode || '').trim().toLowerCase());
    const resolveScatterRegressionPolicy = regressionMode => {
      const key = String(regressionMode || '').trim();
      return SCATTER_REGRESSION_METHOD_POLICY[key] || { fitMethods: ['ols'], autoAssociation: 'pearson', fitGuidance: 'Model-specific least-squares fit.' };
    };
    const resolveScatterAssociationMethod = (selection, regressionMode) => {
      const normalizedSelection = normalizeScatterAssociationSelection(selection);
      if(normalizedSelection === 'pearson' || normalizedSelection === 'spearman' || normalizedSelection === 'none'){
        return normalizedSelection;
      }
      const policy = resolveScatterRegressionPolicy(regressionMode);
      return normalizeScatterAssociationSelection(policy.autoAssociation);
    };
    const getScatterAssociationMethodLabel = method => {
      const normalized = normalizeScatterAssociationSelection(method);
      return SCATTER_ASSOCIATION_METHOD_LABELS[normalized] || SCATTER_ASSOCIATION_METHOD_LABELS.pearson;
    };
    const getScatterFitMethodLabel = method => {
      const normalized = normalizeScatterFitMethod(method);
      return SCATTER_FIT_METHOD_LABELS[normalized] || SCATTER_FIT_METHOD_LABELS.ols;
    };
    const getScatterRegressionModeLabel = mode => {
      const safeMode = String(mode || 'linear');
      const info = regressionTools && typeof regressionTools.getModelInfo === 'function'
        ? regressionTools.getModelInfo(safeMode)
        : null;
      if(info?.label){
        return info.label;
      }
      const compact = safeMode.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ');
      return compact.charAt(0).toUpperCase() + compact.slice(1);
    };
    const inferScatterAssociationMethod = stats => {
      const explicit = normalizeScatterAssociationSelection(stats?.associationMethod);
      if(explicit !== 'auto'){
        return explicit;
      }
      const raw = String(stats?.method || '').trim().toLowerCase();
      if(raw === 'pearson'){
        return 'pearson';
      }
      if(raw === 'spearman'){
        return 'spearman';
      }
      if(raw.includes('none') || raw.includes('model fit')){
        return 'none';
      }
      return 'pearson';
    };
    const computeScatterCorrelationConfidenceInterval = (r, n, alpha = 0.05) => {
      const rNum = Number(r);
      const count = Number(n);
      if(!Number.isFinite(rNum) || !Number.isFinite(count) || count <= 3){
        return null;
      }
      const clamped = Math.max(-0.999999999999, Math.min(0.999999999999, rNum));
      const z = 0.5 * Math.log((1 + clamped) / (1 - clamped));
      const se = 1 / Math.sqrt(count - 3);
      if(!Number.isFinite(se) || se <= 0){
        return null;
      }
      const normal = global.jStat?.normal;
      const zCritical = (normal && typeof normal.inv === 'function')
        ? normal.inv(1 - (alpha / 2), 0, 1)
        : 1.959963984540054;
      const loZ = z - (zCritical * se);
      const hiZ = z + (zCritical * se);
      const toR = value => {
        const e2 = Math.exp(2 * value);
        return (e2 - 1) / (e2 + 1);
      };
      return { low: toR(loZ), high: toR(hiZ), method: 'fisher-z' };
    };
    const hasScatterDuplicateValues = values => {
      const seen = new Set();
      for(let i = 0; i < values.length; i += 1){
        const key = String(values[i]);
        if(seen.has(key)){
          return true;
        }
        seen.add(key);
      }
      return false;
    };

    const resolveScatterWeightingKey = (fitMethod, fitSpec = {}) => {
      const normalized = normalizeScatterFitMethod(fitMethod);
      if(normalized === 'wls_y'){
        return '1/y';
      }
      if(normalized === 'wls_y2' || normalized === 'wls'){
        return '1/y^2';
      }
      if(normalized === 'wls_x'){
        return '1/x';
      }
      if(normalized === 'wls_x2'){
        return '1/x^2';
      }
      const raw = String(
        fitSpec?.weighting
        || fitSpec?.parameters?.weighting
        || fitSpec?.initialValues?.weighting
        || ''
      ).trim().toLowerCase();
      if(raw === '1/y' || raw === '1/y^2' || raw === '1/x' || raw === '1/x^2'){
        return raw;
      }
      return null;
    };
    const estimateScatterParameterCount = regressionModel => {
      const explicit = Number(regressionModel?.metrics?.parameterCount);
      if(Number.isFinite(explicit) && explicit > 0){
        return Math.max(1, Math.round(explicit));
      }
      if(Array.isArray(regressionModel?.coefficientStats) && regressionModel.coefficientStats.length){
        return regressionModel.coefficientStats.length;
      }
      if(Array.isArray(regressionModel?.coefficients) && regressionModel.coefficients.length){
        return regressionModel.coefficients.length;
      }
      const params = regressionModel?.summary?.parameters;
      if(params && typeof params === 'object'){
        const count = Object.keys(params).length;
        if(count){
          return count;
        }
      }
      const mode = String(regressionModel?.mode || '').toLowerCase();
      if(mode === 'linear'){
        return 2;
      }
      if(mode === 'linearthroughorigin'){
        return 1;
      }
      if(mode === 'deming' || mode === 'orthogonal'){
        return 2;
      }
      return 2;
    };
    const computeScatterAicMetrics = (sseValue, sampleSize, parameterCount) => {
      const n = Number(sampleSize);
      const k = Number(parameterCount);
      const sse = Number(sseValue);
      if(!Number.isFinite(n) || !Number.isFinite(k) || n <= 0 || k <= 0 || !Number.isFinite(sse) || sse <= 0){
        return { aic: NaN, aicc: NaN, bic: NaN };
      }
      const aic = (n * Math.log(sse / n)) + (2 * k);
      const aicc = (n - k - 1) > 0 ? aic + ((2 * k * (k + 1)) / (n - k - 1)) : NaN;
      const bic = (n * Math.log(sse / n)) + (k * Math.log(n));
      return { aic, aicc, bic };
    };
    const invertScatterMatrix2x2 = matrix => {
      if(!Array.isArray(matrix) || matrix.length < 2 || !Array.isArray(matrix[0]) || !Array.isArray(matrix[1])){
        return null;
      }
      const a = Number(matrix[0][0]);
      const b = Number(matrix[0][1]);
      const c = Number(matrix[1][0]);
      const d = Number(matrix[1][1]);
      const det = (a * d) - (b * c);
      if(!Number.isFinite(det) || Math.abs(det) < 1e-18){
        return null;
      }
      return [
        [d / det, -b / det],
        [-c / det, a / det]
      ];
    };
    const multiplyScatterMatrixVector = (matrix, vector) => {
      if(!Array.isArray(matrix) || !Array.isArray(vector)){
        return [];
      }
      return matrix.map(row => row.reduce((sum, value, idx) => sum + (Number(value) * Number(vector[idx] || 0)), 0));
    };
    const evaluateScatterLinearModel = (intercept, slope, x) => intercept + (slope * x);
    const computeScatterMedian = values => {
      const data = Array.isArray(values) ? values.filter(Number.isFinite).slice().sort((a, b) => a - b) : [];
      if(!data.length){
        return NaN;
      }
      const mid = Math.floor(data.length / 2);
      return (data.length % 2)
        ? data[mid]
        : ((data[mid - 1] + data[mid]) / 2);
    };
    const resolveScatterWeightVector = (points, weightingKey) => {
      const finitePoints = Array.isArray(points) ? points : [];
      const xAbsPositive = finitePoints.map(pt => Math.abs(Number(pt?.x))).filter(value => Number.isFinite(value) && value > 0);
      const yAbsPositive = finitePoints.map(pt => Math.abs(Number(pt?.y))).filter(value => Number.isFinite(value) && value > 0);
      const minPositiveX = xAbsPositive.length ? Math.min(...xAbsPositive) : 1e-6;
      const minPositiveY = yAbsPositive.length ? Math.min(...yAbsPositive) : 1e-6;
      const warnings = [];
      const weights = finitePoints.map((pt, index) => {
        const x = Math.abs(Number(pt?.x));
        const y = Math.abs(Number(pt?.y));
        switch(weightingKey){
          case '1/y':
            if(!(y > 0)){
              warnings.push(`Weighting fallback applied at row ${index + 1} because Y was zero or non-finite.`);
              return 1 / minPositiveY;
            }
            return 1 / y;
          case '1/y^2':
            if(!(y > 0)){
              warnings.push(`Weighting fallback applied at row ${index + 1} because Y was zero or non-finite.`);
              return 1 / (minPositiveY * minPositiveY);
            }
            return 1 / (y * y);
          case '1/x':
            if(!(x > 0)){
              warnings.push(`Weighting fallback applied at row ${index + 1} because X was zero or non-finite.`);
              return 1 / minPositiveX;
            }
            return 1 / x;
          case '1/x^2':
            if(!(x > 0)){
              warnings.push(`Weighting fallback applied at row ${index + 1} because X was zero or non-finite.`);
              return 1 / (minPositiveX * minPositiveX);
            }
            return 1 / (x * x);
          default:
            return 1;
        }
      }).map(value => (Number.isFinite(value) && value > 0 ? value : 1));
      return { weights, warnings };
    };
    const computeScatterRunsTest = residuals => {
      const jStatApi = getScatterJStat();
      const signs = (Array.isArray(residuals) ? residuals : [])
        .map(value => Number(value))
        .filter(value => Number.isFinite(value) && value !== 0)
        .map(value => (value > 0 ? 1 : -1));
      const positives = signs.filter(value => value > 0).length;
      const negatives = signs.filter(value => value < 0).length;
      if(signs.length < 3 || positives === 0 || negatives === 0){
        return null;
      }
      let runs = 1;
      for(let i = 1; i < signs.length; i += 1){
        if(signs[i] !== signs[i - 1]){
          runs += 1;
        }
      }
      const mean = ((2 * positives * negatives) / (positives + negatives)) + 1;
      const variance = (
        (2 * positives * negatives) * ((2 * positives * negatives) - positives - negatives)
      ) / (
        Math.pow(positives + negatives, 2) * Math.max(1, positives + negatives - 1)
      );
      const z = variance > 0 ? (runs - mean) / Math.sqrt(variance) : NaN;
      const pValue = (jStatApi?.normal && Number.isFinite(z))
        ? (2 * (1 - jStatApi.normal.cdf(Math.abs(z), 0, 1)))
        : NaN;
      return { runs, z, pValue };
    };
    const computeScatterBreuschPagan = (fitted, residuals) => {
      const jStatApi = getScatterJStat();
      const data = [];
      for(let i = 0; i < Math.min(fitted.length, residuals.length); i += 1){
        const fit = Number(fitted[i]);
        const resid = Number(residuals[i]);
        if(Number.isFinite(fit) && Number.isFinite(resid)){
          data.push({ fit, resid2: resid * resid });
        }
      }
      if(data.length < 4){
        return null;
      }
      const n = data.length;
      const meanFit = data.reduce((sum, entry) => sum + entry.fit, 0) / n;
      const meanResid2 = data.reduce((sum, entry) => sum + entry.resid2, 0) / n;
      let sxx = 0;
      let sxy = 0;
      let sst = 0;
      data.forEach(entry => {
        const dx = entry.fit - meanFit;
        const dy = entry.resid2 - meanResid2;
        sxx += dx * dx;
        sxy += dx * dy;
        sst += dy * dy;
      });
      if(!(sxx > 0) || !(sst > 0)){
        return null;
      }
      const slope = sxy / sxx;
      const intercept = meanResid2 - (slope * meanFit);
      let sse = 0;
      data.forEach(entry => {
        const pred = intercept + (slope * entry.fit);
        const resid = entry.resid2 - pred;
        sse += resid * resid;
      });
      const r2 = 1 - (sse / sst);
      const statistic = Math.max(0, n * Math.max(0, r2));
      const pValue = (jStatApi?.chisquare && Number.isFinite(statistic))
        ? (1 - jStatApi.chisquare.cdf(statistic, 1))
        : NaN;
      return { statistic, pValue, df: 1 };
    };
    const computeScatterResetDiagnostic = (points, fitted, residuals) => {
      const jStatApi = getScatterJStat();
      const data = [];
      for(let i = 0; i < points.length; i += 1){
        const x = Number(points[i]?.x);
        const y = Number(points[i]?.y);
        const fit = Number(fitted[i]);
        if(Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(fit)){
          data.push({ x, y, fit });
        }
      }
      if(data.length < 8){
        return null;
      }
      const fitLinear = entries => {
        const n = entries.length;
        let sum1 = n;
        let sumX = 0;
        let sumX2 = 0;
        let sumY = 0;
        let sumXY = 0;
        entries.forEach(entry => {
          sumX += entry.x;
          sumX2 += entry.x * entry.x;
          sumY += entry.y;
          sumXY += entry.x * entry.y;
        });
        const det = (sum1 * sumX2) - (sumX * sumX);
        if(!(Math.abs(det) > 1e-18)){
          return null;
        }
        const intercept = ((sumY * sumX2) - (sumX * sumXY)) / det;
        const slope = ((sum1 * sumXY) - (sumX * sumY)) / det;
        let sse = 0;
        entries.forEach(entry => {
          const resid = entry.y - intercept - (slope * entry.x);
          sse += resid * resid;
        });
        return { sse, df: n - 2 };
      };
      const base = fitLinear(data);
      if(!base || !(base.df > 0)){
        return null;
      }
      const design = data.map(entry => [1, entry.x, Math.pow(entry.fit, 2), Math.pow(entry.fit, 3)]);
      const xtx = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
      ];
      const xty = [0, 0, 0, 0];
      for(let i = 0; i < design.length; i += 1){
        const row = design[i];
        for(let a = 0; a < 4; a += 1){
          xty[a] += row[a] * data[i].y;
          for(let b = 0; b < 4; b += 1){
            xtx[a][b] += row[a] * row[b];
          }
        }
      }
      const invert = matrix => {
        const n = matrix.length;
        const a = matrix.map((row, rowIdx) => row.concat(Array.from({ length: n }, (_, idx) => (idx === rowIdx ? 1 : 0))));
        for(let col = 0; col < n; col += 1){
          let pivot = col;
          for(let row = col + 1; row < n; row += 1){
            if(Math.abs(a[row][col]) > Math.abs(a[pivot][col])){
              pivot = row;
            }
          }
          if(Math.abs(a[pivot][col]) < 1e-12){
            return null;
          }
          if(pivot !== col){
            const tmp = a[col];
            a[col] = a[pivot];
            a[pivot] = tmp;
          }
          const divisor = a[col][col];
          for(let j = 0; j < (2 * n); j += 1){
            a[col][j] /= divisor;
          }
          for(let row = 0; row < n; row += 1){
            if(row === col){
              continue;
            }
            const factor = a[row][col];
            for(let j = 0; j < (2 * n); j += 1){
              a[row][j] -= factor * a[col][j];
            }
          }
        }
        return a.map(row => row.slice(n));
      };
      const xtxInv = invert(xtx);
      if(!xtxInv){
        return null;
      }
      const beta = multiplyScatterMatrixVector(xtxInv, xty);
      let fullSse = 0;
      for(let i = 0; i < data.length; i += 1){
        const pred = design[i].reduce((sum, value, idx) => sum + (value * beta[idx]), 0);
        const resid = data[i].y - pred;
        fullSse += resid * resid;
      }
      const df1 = 2;
      const df2 = data.length - 4;
      if(!(df2 > 0) || !(base.sse > fullSse)){
        return null;
      }
      const fStatistic = ((base.sse - fullSse) / df1) / (fullSse / df2);
      const pValue = (jStatApi?.centralF && Number.isFinite(fStatistic))
        ? (1 - jStatApi.centralF.cdf(fStatistic, df1, df2))
        : NaN;
      return { fStatistic, pValue, df1, df2 };
    };
    const computeScatterInfluenceDiagnostics = (points, regressionModel) => {
      const mode = String(regressionModel?.mode || '').toLowerCase();
      if(mode !== 'linear' && mode !== 'linearthroughorigin' && mode !== 'deming' && mode !== 'orthogonal'){
        return null;
      }
      const finitePoints = Array.isArray(points) ? points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)) : [];
      const n = finitePoints.length;
      const p = (mode === 'linearthroughorigin') ? 1 : 2;
      if(n <= p + 1){
        return null;
      }
      const residuals = finitePoints.map(pt => Number(pt.y) - Number(predictScatterRegressionValue(regressionModel, Number(pt.x))));
      const sse = residuals.reduce((sum, value) => sum + (value * value), 0);
      const mse = sse / Math.max(1, n - p);
      if(!(mse > 0)){
        return null;
      }
      const xValues = finitePoints.map(pt => Number(pt.x));
      const xBar = xValues.reduce((sum, value) => sum + value, 0) / n;
      const sxx = xValues.reduce((sum, value) => sum + Math.pow(value - xBar, 2), 0);
      const leverage = finitePoints.map(pt => {
        const x = Number(pt.x);
        if(mode === 'linearthroughorigin'){
          const denom = xValues.reduce((sum, value) => sum + (value * value), 0);
          return denom > 0 ? ((x * x) / denom) : NaN;
        }
        return (1 / n) + ((sxx > 0 ? Math.pow(x - xBar, 2) / sxx : 0));
      });
      let maxAbsStudentized = 0;
      let maxLeverage = 0;
      let maxCook = 0;
      let maxDffits = 0;
      let influentialCount = 0;
      const leverageThreshold = (2 * p) / n;
      const cooksThreshold = 4 / n;
      const dffitsThreshold = 2 * Math.sqrt(p / n);
      const rows = [];
      for(let i = 0; i < n; i += 1){
        const resid = residuals[i];
        const h = leverage[i];
        if(!Number.isFinite(resid) || !Number.isFinite(h) || h >= 1){
          continue;
        }
        const studentized = resid / Math.sqrt(mse * Math.max(1e-12, 1 - h));
        const deletedVariance = ((sse - ((resid * resid) / Math.max(1e-12, 1 - h))) / Math.max(1, n - p - 1));
        const externalStudentized = deletedVariance > 0
          ? (resid / Math.sqrt(deletedVariance * Math.max(1e-12, 1 - h)))
          : studentized;
        const cook = (resid * resid / (p * mse)) * (h / Math.max(1e-12, Math.pow(1 - h, 2)));
        const dffits = externalStudentized * Math.sqrt(h / Math.max(1e-12, 1 - h));
        if(Math.abs(externalStudentized) > maxAbsStudentized){ maxAbsStudentized = Math.abs(externalStudentized); }
        if(h > maxLeverage){ maxLeverage = h; }
        if(cook > maxCook){ maxCook = cook; }
        if(Math.abs(dffits) > maxDffits){ maxDffits = Math.abs(dffits); }
        if((Math.abs(externalStudentized) > 3) || (cook > cooksThreshold) || (h > leverageThreshold) || (Math.abs(dffits) > dffitsThreshold)){
          influentialCount += 1;
        }
        rows.push({
          index: i,
          leverage: h,
          studentized: externalStudentized,
          cooksDistance: cook,
          dffits
        });
      }
      return {
        leverageThreshold,
        cooksThreshold,
        dffitsThreshold,
        maxAbsStudentized,
        maxLeverage,
        maxCooksDistance: maxCook,
        maxDffits,
        influentialCount,
        rows
      };
    };
    const computeScatterResidualQqSeries = (points, regressionModel, options = {}) => {
      const finitePoints = Array.isArray(points) ? points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)) : [];
      if(!finitePoints.length || !regressionModel){
        return [];
      }
      const sortedResiduals = finitePoints.map((pt, index) => ({
        label: pt.label != null ? String(pt.label) : `Point ${index + 1}`,
        residual: Number(pt.y) - Number(predictScatterRegressionValue(regressionModel, Number(pt.x)))
      })).filter(entry => Number.isFinite(entry.residual)).sort((a, b) => a.residual - b.residual);
      const jStatApi = getScatterJStat();
      return sortedResiduals.map((entry, index) => {
        const prob = (index + 0.375) / (sortedResiduals.length + 0.25);
        const theoretical = (jStatApi?.normal && typeof jStatApi.normal.inv === 'function')
          ? jStatApi.normal.inv(prob, 0, 1)
          : NaN;
        return {
          label: entry.label,
          theoretical,
          residual: entry.residual,
          group: options.group || null
        };
      });
    };
    const summarizeScatterResidualDiagnostics = (points, regressionModel) => {
      const finitePoints = Array.isArray(points) ? points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)) : [];
      if(!finitePoints.length || !regressionModel){
        return null;
      }
      const residuals = [];
      const fitted = [];
      const pointsSortedByX = finitePoints.slice().sort((a, b) => Number(a.x) - Number(b.x));
      for(let i = 0; i < finitePoints.length; i += 1){
        const pt = finitePoints[i];
        const predicted = Number(predictScatterRegressionValue(regressionModel, Number(pt.x)));
        if(Number.isFinite(predicted)){
          fitted.push(predicted);
          residuals.push(Number(pt.y) - predicted);
        }
      }
      if(residuals.length < 3){
        return null;
      }
      const n = residuals.length;
      const mean = residuals.reduce((sum, value) => sum + value, 0) / n;
      const centered = residuals.map(value => value - mean);
      const variance = centered.reduce((sum, value) => sum + (value * value), 0) / Math.max(1, n - 1);
      const sd = Math.sqrt(Math.max(variance, 0));
      let skewness = NaN;
      let kurtosis = NaN;
      if(sd > 0){
        const m3 = centered.reduce((sum, value) => sum + Math.pow(value, 3), 0) / n;
        const m4 = centered.reduce((sum, value) => sum + Math.pow(value, 4), 0) / n;
        skewness = m3 / Math.pow(sd, 3);
        kurtosis = (m4 / Math.pow(sd, 4)) - 3;
      }
      const jb = (Number.isFinite(skewness) && Number.isFinite(kurtosis))
        ? (n / 6) * (Math.pow(skewness, 2) + (Math.pow(kurtosis, 2) / 4))
        : NaN;
      const jStatApi = getScatterJStat();
      const jarqueBeraP = (jStatApi?.chisquare && Number.isFinite(jb))
        ? (1 - jStatApi.chisquare.cdf(jb, 2))
        : NaN;
      const runsResiduals = pointsSortedByX
        .map(pt => Number(pt.y) - Number(predictScatterRegressionValue(regressionModel, Number(pt.x))))
        .filter(Number.isFinite);
      const runsTest = computeScatterRunsTest(runsResiduals);
      const bp = computeScatterBreuschPagan(fitted, residuals);
      const reset = computeScatterResetDiagnostic(finitePoints, fitted, residuals);
      const influence = computeScatterInfluenceDiagnostics(finitePoints, regressionModel);
      return {
        skewness,
        kurtosis,
        jarqueBera: jb,
        jarqueBeraP,
        runsTest,
        heteroscedasticity: bp,
        reset,
        influence
      };
    };
    const computeScatterObservedAuc = points => {
      const finitePoints = Array.isArray(points)
        ? points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)).slice().sort((a, b) => Number(a.x) - Number(b.x))
        : [];
      if(finitePoints.length < 2){
        return null;
      }
      let auc = 0;
      for(let i = 1; i < finitePoints.length; i += 1){
        const prev = finitePoints[i - 1];
        const curr = finitePoints[i];
        const dx = Number(curr.x) - Number(prev.x);
        if(!Number.isFinite(dx)){
          continue;
        }
        auc += dx * ((Number(prev.y) + Number(curr.y)) / 2);
      }
      const xRange = Number(finitePoints[finitePoints.length - 1].x) - Number(finitePoints[0].x);
      return {
        auc,
        normalizedAuc: xRange !== 0 ? (auc / xRange) : NaN,
        xMin: Number(finitePoints[0].x),
        xMax: Number(finitePoints[finitePoints.length - 1].x)
      };
    };
    const computeScatterInversePredictions = (regressionModel, fitSpec = {}) => {
      const rawTargets = fitSpec?.inversePredictY
        ?? fitSpec?.parameters?.inversePredictY
        ?? fitSpec?.parameters?.interpolateY
        ?? fitSpec?.initialValues?.inversePredictY
        ?? fitSpec?.initialValues?.interpolateY
        ?? null;
      const targetArray = Array.isArray(rawTargets) ? rawTargets : (rawTargets == null ? [] : [rawTargets]);
      const targets = targetArray.map(Number).filter(Number.isFinite);
      if(!targets.length || !regressionModel){
        return [];
      }
      const summary = regressionModel.summary && typeof regressionModel.summary === 'object'
        ? regressionModel.summary
        : {};
      const slope = Number(summary.slope);
      const intercept = Number(summary.intercept);
      const direct = Number.isFinite(slope) && Math.abs(slope) > 1e-12
        ? targets.map(value => ({ targetY: value, x: (value - intercept) / slope, method: 'analytic' }))
        : null;
      if(direct && direct.every(entry => Number.isFinite(entry.x))){
        return direct;
      }
      const samples = Array.isArray(regressionModel.curveSamples) && regressionModel.curveSamples.length > 1
        ? regressionModel.curveSamples
            .map(sample => ({ x: Number(sample?.x), y: Number(sample?.y) }))
            .filter(sample => Number.isFinite(sample.x) && Number.isFinite(sample.y))
            .sort((a, b) => a.x - b.x)
        : [];
      if(samples.length < 2){
        return [];
      }
      let monotonic = 0;
      for(let i = 1; i < samples.length; i += 1){
        const diff = samples[i].y - samples[i - 1].y;
        if(diff > 0){ monotonic = monotonic || 1; }
        else if(diff < 0){ monotonic = monotonic || -1; }
        if((monotonic === 1 && diff < 0) || (monotonic === -1 && diff > 0)){
          return [];
        }
      }
      return targets.map(targetY => {
        let xValue = NaN;
        for(let i = 1; i < samples.length; i += 1){
          const a = samples[i - 1];
          const b = samples[i];
          const minY = Math.min(a.y, b.y);
          const maxY = Math.max(a.y, b.y);
          if(targetY < minY || targetY > maxY){
            continue;
          }
          const span = b.y - a.y;
          if(Math.abs(span) < 1e-12){
            xValue = a.x;
            break;
          }
          const t = (targetY - a.y) / span;
          xValue = a.x + (t * (b.x - a.x));
          break;
        }
        return { targetY, x: xValue, method: 'curve-interpolation' };
      });
    };
    const buildScatterCurveSamples = (regressionModel, options = {}) => {
      const sampleCount = Math.max(20, Number(options.sampleCount) || 160);
      const domain = regressionModel?.domain || {};
      let minX = Number.isFinite(options.minX) ? options.minX : Number(domain.minX);
      let maxX = Number.isFinite(options.maxX) ? options.maxX : Number(domain.maxX);
      if(!Number.isFinite(minX) || !Number.isFinite(maxX) || minX === maxX){
        const observedX = Array.isArray(options.points) ? options.points.map(pt => Number(pt?.x)).filter(Number.isFinite) : [];
        if(observedX.length){
          minX = Math.min(...observedX);
          maxX = Math.max(...observedX);
        }
      }
      if(!Number.isFinite(minX) || !Number.isFinite(maxX)){
        return [];
      }
      if(minX === maxX){
        return [{ x: minX, y: Number(predictScatterRegressionValue(regressionModel, minX)) }];
      }
      const samples = [];
      for(let i = 0; i < sampleCount; i += 1){
        const ratio = i / Math.max(1, sampleCount - 1);
        const x = minX + ((maxX - minX) * ratio);
        const y = Number(predictScatterRegressionValue(regressionModel, x));
        if(Number.isFinite(x) && Number.isFinite(y)){
          samples.push({ x, y });
        }
      }
      return samples;
    };
    const computeScatterLinearCoefficientStats = (labels, beta, covariance, df, alpha = 0.05) => {
      const jStatApi = getScatterJStat();
      const tCritical = (jStatApi?.studentt && Number.isFinite(df) && df > 0)
        ? jStatApi.studentt.inv(1 - (alpha / 2), df)
        : NaN;
      return labels.map((label, index) => {
        const estimate = Number(beta[index]);
        const variance = Array.isArray(covariance) && Array.isArray(covariance[index]) ? Number(covariance[index][index]) : NaN;
        const standardError = variance >= 0 ? Math.sqrt(variance) : NaN;
        const tStatistic = (Number.isFinite(estimate) && Number.isFinite(standardError) && standardError > 0)
          ? (estimate / standardError)
          : NaN;
        const pValue = (jStatApi?.studentt && Number.isFinite(tStatistic) && Number.isFinite(df) && df > 0)
          ? (2 * (1 - jStatApi.studentt.cdf(Math.abs(tStatistic), df)))
          : NaN;
        return {
          term: label,
          estimate,
          standardError,
          tStatistic,
          pValue,
          ciLow: (Number.isFinite(tCritical) && Number.isFinite(standardError)) ? (estimate - (tCritical * standardError)) : NaN,
          ciHigh: (Number.isFinite(tCritical) && Number.isFinite(standardError)) ? (estimate + (tCritical * standardError)) : NaN
        };
      });
    };
    const fitScatterLinearLikeRegression = (inputPoints, options = {}) => {
      const mode = String(options.mode || 'linear').toLowerCase();
      const throughOrigin = mode === 'linearthroughorigin';
      const family = getScatterFitMethodFamily(options.method || 'ols');
      const fitSpec = options.fitSpec && typeof options.fitSpec === 'object' ? options.fitSpec : {};
      const points = (Array.isArray(inputPoints) ? inputPoints : [])
        .filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y))
        .map(pt => ({ ...pt, x: Number(pt.x), y: Number(pt.y) }));
      const n = points.length;
      const warnings = [];
      if(n < (throughOrigin ? 2 : 3)){
        return null;
      }
      const weightingKey = resolveScatterWeightingKey(options.method, fitSpec);
      const weightProfile = resolveScatterWeightVector(points, family === 'wls' ? weightingKey : null);
      const baseWeights = weightProfile.weights;
      if(weightProfile.warnings.length){
        warnings.push(...weightProfile.warnings);
      }
      const xValues = points.map(pt => pt.x);
      const yValues = points.map(pt => pt.y);
      const fitWeightedLinear = weights => {
        if(throughOrigin){
          let sumWX2 = 0;
          let sumWXY = 0;
          for(let i = 0; i < n; i += 1){
            sumWX2 += weights[i] * xValues[i] * xValues[i];
            sumWXY += weights[i] * xValues[i] * yValues[i];
          }
          if(!(sumWX2 > 0)){
            return null;
          }
          const slope = sumWXY / sumWX2;
          const intercept = 0;
          const xtxInv = [[1 / sumWX2]];
          return { intercept, slope, xtxInv };
        }
        let sw = 0;
        let sx = 0;
        let sy = 0;
        let sxx = 0;
        let sxy = 0;
        for(let i = 0; i < n; i += 1){
          const w = weights[i];
          sw += w;
          sx += w * xValues[i];
          sy += w * yValues[i];
          sxx += w * xValues[i] * xValues[i];
          sxy += w * xValues[i] * yValues[i];
        }
        const det = (sw * sxx) - (sx * sx);
        if(!(Math.abs(det) > 1e-18)){
          return null;
        }
        const intercept = ((sy * sxx) - (sx * sxy)) / det;
        const slope = ((sw * sxy) - (sx * sy)) / det;
        const xtxInv = [
          [sxx / det, -sx / det],
          [-sx / det, sw / det]
        ];
        return { intercept, slope, xtxInv };
      };
      let finalWeights = baseWeights.slice();
      let fit = null;
      if(family === 'huber'){
        const initial = fitWeightedLinear(baseWeights);
        if(!initial){
          return null;
        }
        fit = initial;
        let currentWeights = baseWeights.slice();
        for(let iter = 0; iter < 20; iter += 1){
          const residuals = points.map(pt => pt.y - evaluateScatterLinearModel(fit.intercept, fit.slope, pt.x));
          const medianResidual = computeScatterMedian(residuals);
          const mad = computeScatterMedian(residuals.map(value => Math.abs(value - medianResidual)));
          const scale = Math.max(1e-9, (mad > 0 ? (1.4826 * mad) : Math.sqrt(residuals.reduce((sum, value) => sum + (value * value), 0) / Math.max(1, residuals.length - 2))));
          const nextWeights = residuals.map((resid, index) => {
            const u = Math.abs(resid) / (1.345 * scale);
            const huberWeight = u <= 1 ? 1 : (1 / u);
            return baseWeights[index] * huberWeight;
          });
          const nextFit = fitWeightedLinear(nextWeights);
          if(!nextFit){
            break;
          }
          const delta = Math.abs(nextFit.intercept - fit.intercept) + Math.abs(nextFit.slope - fit.slope);
          fit = nextFit;
          currentWeights = nextWeights;
          if(delta < 1e-10){
            break;
          }
        }
        finalWeights = currentWeights;
      }else{
        fit = fitWeightedLinear(finalWeights);
      }
      if(!fit){
        return null;
      }
      const fitted = points.map(pt => evaluateScatterLinearModel(fit.intercept, fit.slope, pt.x));
      const residuals = points.map((pt, index) => pt.y - fitted[index]);
      const sse = residuals.reduce((sum, value) => sum + (value * value), 0);
      const weightedSse = residuals.reduce((sum, value, index) => sum + ((finalWeights[index] || 1) * value * value), 0);
      const mae = residuals.reduce((sum, value) => sum + Math.abs(value), 0) / n;
      const yMean = yValues.reduce((sum, value) => sum + value, 0) / n;
      const tss = yValues.reduce((sum, value) => sum + Math.pow(value - yMean, 2), 0);
      const parameterCount = throughOrigin ? 1 : 2;
      const residualDf = n - parameterCount;
      const mse = residualDf > 0 ? (weightedSse / residualDf) : NaN;
      const covariance = Array.isArray(fit.xtxInv)
        ? fit.xtxInv.map(row => row.map(value => value * (Number.isFinite(mse) ? mse : NaN)))
        : null;
      const alpha = 1 - ((Math.max(1, Math.min(99.9, Number(fitSpec?.confidenceLevel) || 95))) / 100);
      const coefficientStats = computeScatterLinearCoefficientStats(
        throughOrigin ? ['Slope'] : ['Intercept', 'Slope'],
        throughOrigin ? [fit.slope] : [fit.intercept, fit.slope],
        covariance,
        residualDf,
        alpha
      );
      const infoCriteria = computeScatterAicMetrics(family === 'wls' ? weightedSse : sse, n, parameterCount);
      const jStatApi = getScatterJStat();
      const tCritical = (jStatApi?.studentt && residualDf > 0)
        ? jStatApi.studentt.inv(1 - (alpha / 2), residualDf)
        : NaN;
      const domain = (() => {
        const range = fitSpec?.range || {};
        const minObserved = Math.min(...xValues);
        const maxObserved = Math.max(...xValues);
        return {
          minX: Number.isFinite(Number(range.minX)) ? Number(range.minX) : minObserved,
          maxX: Number.isFinite(Number(range.maxX)) ? Number(range.maxX) : maxObserved
        };
      })();
      const model = {
        mode: throughOrigin ? 'linearThroughOrigin' : 'linear',
        fitMethod: normalizeScatterFitMethod(options.method || 'ols'),
        fitSpec,
        domain,
        coefficients: throughOrigin ? [fit.slope] : [fit.intercept, fit.slope],
        coefficientCovariance: covariance,
        coefficientStats,
        predict: xValue => evaluateScatterLinearModel(fit.intercept, fit.slope, Number(xValue)),
        summary: {
          intercept: fit.intercept,
          slope: fit.slope,
          parameters: throughOrigin
            ? { Slope: fit.slope }
            : { Intercept: fit.intercept, Slope: fit.slope },
          equation: throughOrigin
            ? `y = ${formatMetricValue(fit.slope)}x`
            : `y = ${formatMetricValue(fit.intercept)} ${fit.slope >= 0 ? '+' : '-'} ${formatMetricValue(Math.abs(fit.slope))}x`
        },
        metrics: {
          sampleSize: n,
          parameterCount,
          residualDf,
          sse,
          weightedSSE: weightedSse,
          r2: tss > 0 ? (1 - (sse / tss)) : NaN,
          adjR2: (tss > 0 && residualDf > 0)
            ? (1 - (((sse / residualDf)) / (tss / Math.max(1, n - 1))))
            : NaN,
          rmse: Math.sqrt(sse / n),
          mae,
          aic: infoCriteria.aic,
          aicc: infoCriteria.aicc,
          bic: infoCriteria.bic
        },
        residuals: {
          mean: residuals.reduce((sum, value) => sum + value, 0) / n,
          sd: residualDf > 0 ? Math.sqrt(sse / residualDf) : NaN,
          min: Math.min(...residuals),
          max: Math.max(...residuals)
        },
        warnings
      };
      const curveSamples = buildScatterCurveSamples(model, { points, minX: domain.minX, maxX: domain.maxX, sampleCount: mode === 'linear' ? 60 : 160 });
      model.curveSamples = curveSamples;
      if(Array.isArray(covariance) && Number.isFinite(tCritical)){
        const intervalSamples = curveSamples.map(sample => {
          const x = Number(sample.x);
          const basis = throughOrigin ? [x] : [1, x];
          const meanVariance = basis.reduce((sumRow, aValue, rowIdx) => sumRow + basis.reduce((sumCol, bValue, colIdx) => {
            const cov = Array.isArray(covariance[rowIdx]) ? Number(covariance[rowIdx][colIdx]) : NaN;
            return sumCol + (Number.isFinite(cov) ? (aValue * cov * bValue) : 0);
          }, 0), 0);
          const meanSe = meanVariance >= 0 ? Math.sqrt(meanVariance) : NaN;
          const predSe = Number.isFinite(mse) && mse >= 0 && Number.isFinite(meanSe)
            ? Math.sqrt(meanSe * meanSe + mse)
            : NaN;
          const y = Number(sample.y);
          return {
            x,
            y,
            ciLow: Number.isFinite(meanSe) ? y - (tCritical * meanSe) : NaN,
            ciHigh: Number.isFinite(meanSe) ? y + (tCritical * meanSe) : NaN,
            piLow: Number.isFinite(predSe) ? y - (tCritical * predSe) : NaN,
            piHigh: Number.isFinite(predSe) ? y + (tCritical * predSe) : NaN
          };
        });
        model.intervals = {
          confidenceLevel: 100 * (1 - alpha),
          tCritical,
          samples: intervalSamples,
          summary: {
            ciMin: Math.min(...intervalSamples.map(sample => sample.ciLow).filter(Number.isFinite)),
            ciMax: Math.max(...intervalSamples.map(sample => sample.ciHigh).filter(Number.isFinite)),
            piMin: Math.min(...intervalSamples.map(sample => sample.piLow).filter(Number.isFinite)),
            piMax: Math.max(...intervalSamples.map(sample => sample.piHigh).filter(Number.isFinite))
          }
        };
      }
      return model;
    };
    const fitScatterDemingRegression = (inputPoints, options = {}) => {
      const mode = String(options.mode || 'deming').toLowerCase();
      const fitSpec = options.fitSpec && typeof options.fitSpec === 'object' ? options.fitSpec : {};
      const points = (Array.isArray(inputPoints) ? inputPoints : [])
        .filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y))
        .map(pt => ({ ...pt, x: Number(pt.x), y: Number(pt.y) }));
      const n = points.length;
      if(n < 3){
        return null;
      }
      const xValues = points.map(pt => pt.x);
      const yValues = points.map(pt => pt.y);
      const xMean = xValues.reduce((sum, value) => sum + value, 0) / n;
      const yMean = yValues.reduce((sum, value) => sum + value, 0) / n;
      let sxx = 0;
      let syy = 0;
      let sxy = 0;
      for(let i = 0; i < n; i += 1){
        const dx = xValues[i] - xMean;
        const dy = yValues[i] - yMean;
        sxx += dx * dx;
        syy += dy * dy;
        sxy += dx * dy;
      }
      if(!(Math.abs(sxy) > 1e-18)){
        return null;
      }
      const explicitRatio = Number(
        fitSpec?.errorRatio
        ?? fitSpec?.parameters?.errorRatio
        ?? fitSpec?.initialValues?.errorRatio
      );
      const errorRatio = (mode === 'orthogonal')
        ? 1
        : (Number.isFinite(explicitRatio) && explicitRatio > 0 ? explicitRatio : 1);
      const discriminant = Math.pow(syy - (errorRatio * sxx), 2) + (4 * errorRatio * sxy * sxy);
      const slope = ((syy - (errorRatio * sxx)) + Math.sqrt(Math.max(0, discriminant))) / (2 * sxy);
      const intercept = yMean - (slope * xMean);
      const predict = x => intercept + (slope * x);
      const residuals = points.map(pt => pt.y - predict(pt.x));
      const sse = residuals.reduce((sum, value) => sum + (value * value), 0);
      const orthSse = residuals.reduce((sum, value) => sum + (value * value) / Math.max(1e-12, 1 + (slope * slope)), 0);
      const rmse = Math.sqrt(sse / n);
      const bootstrapSamples = Math.min(250, Math.max(100, 40 + (n * 3)));
      const bootSlope = [];
      const bootIntercept = [];
      for(let iter = 0; iter < bootstrapSamples; iter += 1){
        const sample = [];
        for(let i = 0; i < n; i += 1){
          sample.push(points[Math.floor(Math.random() * n)]);
        }
        const sx = sample.reduce((sum, pt) => sum + pt.x, 0) / n;
        const sy = sample.reduce((sum, pt) => sum + pt.y, 0) / n;
        let bsxx = 0;
        let bsyy = 0;
        let bsxy = 0;
        sample.forEach(pt => {
          const dx = pt.x - sx;
          const dy = pt.y - sy;
          bsxx += dx * dx;
          bsyy += dy * dy;
          bsxy += dx * dy;
        });
        if(!(Math.abs(bsxy) > 1e-18)){
          continue;
        }
        const bDisc = Math.pow(bsyy - (errorRatio * bsxx), 2) + (4 * errorRatio * bsxy * bsxy);
        const bSlope = ((bsyy - (errorRatio * bsxx)) + Math.sqrt(Math.max(0, bDisc))) / (2 * bsxy);
        const bIntercept = sy - (bSlope * sx);
        if(Number.isFinite(bSlope) && Number.isFinite(bIntercept)){
          bootSlope.push(bSlope);
          bootIntercept.push(bIntercept);
        }
      }
      const quantile = (values, q) => {
        const sorted = values.filter(Number.isFinite).slice().sort((a, b) => a - b);
        if(!sorted.length){
          return NaN;
        }
        const pos = (sorted.length - 1) * q;
        const lower = Math.floor(pos);
        const upper = Math.ceil(pos);
        if(lower === upper){
          return sorted[lower];
        }
        const weight = pos - lower;
        return sorted[lower] + ((sorted[upper] - sorted[lower]) * weight);
      };
      const alpha = 1 - ((Math.max(1, Math.min(99.9, Number(fitSpec?.confidenceLevel) || 95))) / 100);
      const slopeSe = bootSlope.length > 1 ? Math.sqrt(bootSlope.reduce((sum, value) => sum + Math.pow(value - (bootSlope.reduce((s, v) => s + v, 0) / bootSlope.length), 2), 0) / (bootSlope.length - 1)) : NaN;
      const interceptSe = bootIntercept.length > 1 ? Math.sqrt(bootIntercept.reduce((sum, value) => sum + Math.pow(value - (bootIntercept.reduce((s, v) => s + v, 0) / bootIntercept.length), 2), 0) / (bootIntercept.length - 1)) : NaN;
      const jStatApi = getScatterJStat();
      const tCritical = (jStatApi?.studentt && n > 2)
        ? jStatApi.studentt.inv(1 - (alpha / 2), n - 2)
        : NaN;
      const coefficientStats = [
        {
          term: 'Intercept',
          estimate: intercept,
          standardError: interceptSe,
          tStatistic: (Number.isFinite(interceptSe) && interceptSe > 0) ? (intercept / interceptSe) : NaN,
          pValue: (jStatApi?.studentt && Number.isFinite(interceptSe) && interceptSe > 0)
            ? (2 * (1 - jStatApi.studentt.cdf(Math.abs(intercept / interceptSe), Math.max(1, n - 2))))
            : NaN,
          ciLow: bootIntercept.length ? quantile(bootIntercept, alpha / 2) : NaN,
          ciHigh: bootIntercept.length ? quantile(bootIntercept, 1 - (alpha / 2)) : NaN
        },
        {
          term: 'Slope',
          estimate: slope,
          standardError: slopeSe,
          tStatistic: (Number.isFinite(slopeSe) && slopeSe > 0) ? (slope / slopeSe) : NaN,
          pValue: (jStatApi?.studentt && Number.isFinite(slopeSe) && slopeSe > 0)
            ? (2 * (1 - jStatApi.studentt.cdf(Math.abs(slope / slopeSe), Math.max(1, n - 2))))
            : NaN,
          ciLow: bootSlope.length ? quantile(bootSlope, alpha / 2) : NaN,
          ciHigh: bootSlope.length ? quantile(bootSlope, 1 - (alpha / 2)) : NaN
        }
      ];
      const domain = {
        minX: Number.isFinite(Number(fitSpec?.range?.minX)) ? Number(fitSpec.range.minX) : Math.min(...xValues),
        maxX: Number.isFinite(Number(fitSpec?.range?.maxX)) ? Number(fitSpec.range.maxX) : Math.max(...xValues)
      };
      const model = {
        mode: mode === 'orthogonal' ? 'orthogonal' : 'deming',
        fitMethod: 'ols',
        fitSpec,
        domain,
        coefficients: [intercept, slope],
        coefficientStats,
        predict,
        summary: {
          intercept,
          slope,
          parameters: {
            Intercept: intercept,
            Slope: slope,
            ErrorRatio: errorRatio
          },
          equation: `y = ${formatMetricValue(intercept)} ${slope >= 0 ? '+' : '-'} ${formatMetricValue(Math.abs(slope))}x`
        },
        metrics: {
          sampleSize: n,
          parameterCount: 2,
          residualDf: n - 2,
          sse,
          orthogonalSSE: orthSse,
          r2: NaN,
          adjR2: NaN,
          rmse,
          mae: residuals.reduce((sum, value) => sum + Math.abs(value), 0) / n,
          ...computeScatterAicMetrics(orthSse > 0 ? orthSse : sse, n, 2)
        },
        residuals: {
          mean: residuals.reduce((sum, value) => sum + value, 0) / n,
          sd: n > 2 ? Math.sqrt(sse / Math.max(1, n - 2)) : NaN,
          min: Math.min(...residuals),
          max: Math.max(...residuals)
        },
        warnings: [
          Number.isFinite(explicitRatio) && explicitRatio > 0
            ? `Deming regression used an X:Y error-variance ratio of ${formatMetricValue(errorRatio, 3)}.`
            : 'Deming regression used the default X:Y error-variance ratio of 1. Set errorRatio in the fit-spec JSON to override this.'
        ]
      };
      model.curveSamples = buildScatterCurveSamples(model, { points, minX: domain.minX, maxX: domain.maxX, sampleCount: 60 });
      model.intervals = {
        confidenceLevel: 100 * (1 - alpha),
        tCritical,
        samples: [],
        summary: {}
      };
      return model;
    };
    scatterFitDemingRegressionForTests = fitScatterDemingRegression;
    const fitScatterLowessRegression = (inputPoints, options = {}) => fitScatterLowessRegressionCore(inputPoints, {
      ...(options || {}),
      formatSpanLabel: value => formatMetricValue(value, 3)
    });
    scatterFitLowessRegressionForTests = fitScatterLowessRegression;
    const enrichScatterRegressionModel = (points, regressionModel, options = {}) => {
      const model = regressionModel && typeof regressionModel === 'object' ? regressionModel : null;
      const finitePoints = Array.isArray(points) ? points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)) : [];
      if(!model || !finitePoints.length){
        return model;
      }
      if(options.fitSpec && typeof options.fitSpec === 'object' && !model.fitSpec){
        model.fitSpec = options.fitSpec;
      }
      if(options.domain && !model.domain){
        model.domain = { ...options.domain };
      }
      const fitted = [];
      const residuals = [];
      finitePoints.forEach(pt => {
        const predicted = Number(predictScatterRegressionValue(model, Number(pt.x)));
        if(Number.isFinite(predicted)){
          fitted.push(predicted);
          residuals.push(Number(pt.y) - predicted);
        }
      });
      const n = residuals.length;
      if(!n){
        return model;
      }
      const sse = residuals.reduce((sum, value) => sum + (value * value), 0);
      const mae = residuals.reduce((sum, value) => sum + Math.abs(value), 0) / n;
      const parameterCount = estimateScatterParameterCount(model);
      const residualDf = n - parameterCount;
      const yValues = finitePoints.map(pt => Number(pt.y));
      const yMean = yValues.reduce((sum, value) => sum + value, 0) / n;
      const tss = yValues.reduce((sum, value) => sum + Math.pow(value - yMean, 2), 0);
      const metrics = model.metrics && typeof model.metrics === 'object' ? model.metrics : {};
      if(!Number.isFinite(metrics.sampleSize)){ metrics.sampleSize = n; }
      if(!Number.isFinite(metrics.parameterCount)){ metrics.parameterCount = parameterCount; }
      if(!Number.isFinite(metrics.residualDf)){ metrics.residualDf = residualDf; }
      if(!Number.isFinite(metrics.sse)){ metrics.sse = sse; }
      if(!Number.isFinite(metrics.rmse)){ metrics.rmse = Math.sqrt(sse / n); }
      if(!Number.isFinite(metrics.mae)){ metrics.mae = mae; }
      if(!Number.isFinite(metrics.r2) && tss > 0 && String(model.mode || '').toLowerCase() !== 'deming' && String(model.mode || '').toLowerCase() !== 'orthogonal'){
        metrics.r2 = 1 - (sse / tss);
      }
      if(!Number.isFinite(metrics.adjR2) && Number.isFinite(metrics.r2) && residualDf > 0 && n > 1){
        metrics.adjR2 = 1 - (((sse / residualDf)) / (tss / Math.max(1, n - 1)));
      }
      const infoCriteria = computeScatterAicMetrics(Number.isFinite(metrics.weightedSSE) ? metrics.weightedSSE : sse, n, parameterCount);
      if(!Number.isFinite(metrics.aic)){ metrics.aic = infoCriteria.aic; }
      if(!Number.isFinite(metrics.aicc)){ metrics.aicc = infoCriteria.aicc; }
      if(!Number.isFinite(metrics.bic)){ metrics.bic = infoCriteria.bic; }
      model.metrics = metrics;
      if(!model.residuals || typeof model.residuals !== 'object'){
        model.residuals = {};
      }
      if(!Number.isFinite(model.residuals.mean)){ model.residuals.mean = residuals.reduce((sum, value) => sum + value, 0) / n; }
      if(!Number.isFinite(model.residuals.sd)){ model.residuals.sd = residualDf > 0 ? Math.sqrt(sse / residualDf) : NaN; }
      if(!Number.isFinite(model.residuals.min)){ model.residuals.min = Math.min(...residuals); }
      if(!Number.isFinite(model.residuals.max)){ model.residuals.max = Math.max(...residuals); }
      const diagnostics = summarizeScatterResidualDiagnostics(finitePoints, model);
      if(diagnostics){
        model.diagnostics = { ...(model.diagnostics || {}), ...diagnostics };
      }
      const auc = computeScatterObservedAuc(finitePoints);
      if(auc){
        model.derived = { ...(model.derived || {}), auc, inversePredictions: computeScatterInversePredictions(model, model.fitSpec || options.fitSpec || {}) };
      }else{
        model.derived = { ...(model.derived || {}), inversePredictions: computeScatterInversePredictions(model, model.fitSpec || options.fitSpec || {}) };
      }
      if((!Array.isArray(model.curveSamples) || !model.curveSamples.length) && typeof model.predict === 'function'){
        model.curveSamples = buildScatterCurveSamples(model, { points: finitePoints, sampleCount: String(model.mode || '').toLowerCase() === 'linear' ? 60 : 160 });
      }
      if(!Array.isArray(model.warnings)){
        model.warnings = [];
      }
      return model;
    };
    const fitScatterRegressionModel = (points, options = {}) => {
      const mode = String(options.mode || 'linear').toLowerCase();
      let regressionModel = null;
      if(mode === 'linear' || mode === 'linearthroughorigin'){
        regressionModel = fitScatterLinearLikeRegression(points, options);
      }else if(mode === 'deming' || mode === 'orthogonal'){
        regressionModel = fitScatterDemingRegression(points, options);
      }else if(mode === 'lowess'){
        regressionModel = fitScatterLowessRegression(points, options);
      }else if(regressionTools && typeof regressionTools.fitRegression === 'function'){
        try{
          regressionModel = regressionTools.fitRegression(points, {
            ...options,
            method: getScatterFitMethodFamily(options.method || 'ols')
          });
        }catch(err){
          console.error('scatter fitScatterRegressionModel fallback failed', err);
        }
      }
      if(regressionModel){
        enrichScatterRegressionModel(points, regressionModel, options);
        scatterDebug('Debug: scatter regression fit resolved', {
          mode,
          fitMethod: options.method || 'ols',
          sampleSize: regressionModel?.metrics?.sampleSize || points?.length || 0
        });
      }
      return regressionModel;
    };
    scatterFitRegressionModelForTests = fitScatterRegressionModel;
    const computeScatterExtraSumSquaresF = (simplerSse, simplerDf, complexSse, complexDf) => {
      const jStatApi = getScatterJStat();
      if(
        !Number.isFinite(simplerSse) || !Number.isFinite(simplerDf)
        || !Number.isFinite(complexSse) || !Number.isFinite(complexDf)
        || simplerDf <= complexDf || complexDf <= 0 || simplerSse < complexSse
      ){
        return null;
      }
      const df1 = simplerDf - complexDf;
      const df2 = complexDf;
      const numerator = (simplerSse - complexSse) / df1;
      const denominator = complexSse / df2;
      if(!(denominator > 0) || !(numerator >= 0)){
        return null;
      }
      const fStatistic = numerator / denominator;
      const pValue = (jStatApi?.centralF && Number.isFinite(fStatistic))
        ? (1 - jStatApi.centralF.cdf(fStatistic, df1, df2))
        : NaN;
      return { fStatistic, pValue, df1, df2 };
    };
    const resolveScatterComparisonAlpha = options => {
      const explicitAlpha = Number(options?.alpha);
      if(Number.isFinite(explicitAlpha) && explicitAlpha > 0 && explicitAlpha < 1){
        return explicitAlpha;
      }
      const confidenceLevel = Number(options?.confidenceLevel);
      if(Number.isFinite(confidenceLevel) && confidenceLevel > 0 && confidenceLevel < 100){
        return 1 - (confidenceLevel / 100);
      }
      return 0.05;
    };
    const normalizeScatterGroupedComparisonInput = groupedSeriesStats => {
      return (Array.isArray(groupedSeriesStats) ? groupedSeriesStats : [])
        .map((entry, index) => ({
          label: (entry?.label != null && String(entry.label).trim() !== '') ? String(entry.label).trim() : `Series ${index + 1}`,
          points: Array.isArray(entry?.points)
            ? entry.points
              .filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y))
              .map(pt => ({ x: Number(pt.x), y: Number(pt.y) }))
            : []
        }))
        .filter(entry => entry.points.length >= 3);
    };
    const computeScatterGroupedLinearModelComparison = groupedSeriesStats => {
      const groups = normalizeScatterGroupedComparisonInput(groupedSeriesStats);
      if(groups.length < 2){
        return null;
      }
      const separateFits = groups.map(group => fitScatterLinearLikeRegression(group.points, { mode: 'linear', method: 'ols', fitSpec: {} }));
      if(separateFits.some(fit => !fit || !Number.isFinite(fit.metrics?.sse))){
        return null;
      }
      const allPoints = groups.flatMap(group => group.points.map(pt => ({ ...pt })));
      const commonFit = fitScatterLinearLikeRegression(allPoints, { mode: 'linear', method: 'ols', fitSpec: {} });
      if(!commonFit || !Number.isFinite(commonFit.metrics?.sse)){
        return null;
      }
      const nTotal = allPoints.length;
      const groupCount = groups.length;
      const means = groups.map(group => {
        const xMean = group.points.reduce((sum, pt) => sum + pt.x, 0) / group.points.length;
        const yMean = group.points.reduce((sum, pt) => sum + pt.y, 0) / group.points.length;
        return { xMean, yMean };
      });
      let numerator = 0;
      let denominator = 0;
      groups.forEach((group, idx) => {
        group.points.forEach(pt => {
          numerator += (pt.x - means[idx].xMean) * (pt.y - means[idx].yMean);
          denominator += Math.pow(pt.x - means[idx].xMean, 2);
        });
      });
      if(!(Math.abs(denominator) > 1e-18)){
        return null;
      }
      const commonSlope = numerator / denominator;
      const parallelIntercepts = means.map(mean => mean.yMean - (commonSlope * mean.xMean));
      let parallelSse = 0;
      groups.forEach((group, idx) => {
        group.points.forEach(pt => {
          const resid = pt.y - parallelIntercepts[idx] - (commonSlope * pt.x);
          parallelSse += resid * resid;
        });
      });
      const separateSse = separateFits.reduce((sum, fit) => sum + Number(fit.metrics?.sse || 0), 0);
      const separateDf = nTotal - (2 * groupCount);
      const parallelDf = nTotal - (groupCount + 1);
      const commonDf = nTotal - 2;
      const slopesTest = computeScatterExtraSumSquaresF(parallelSse, parallelDf, separateSse, separateDf);
      const interceptTest = computeScatterExtraSumSquaresF(commonFit.metrics.sse, commonDf, parallelSse, parallelDf);
      const commonLineTest = computeScatterExtraSumSquaresF(commonFit.metrics.sse, commonDf, separateSse, separateDf);
      const modelMetrics = {
        common: computeScatterAicMetrics(commonFit.metrics.sse, nTotal, 2),
        parallel: computeScatterAicMetrics(parallelSse, nTotal, groupCount + 1),
        separate: computeScatterAicMetrics(separateSse, nTotal, 2 * groupCount)
      };
      return {
        groups,
        nTotal,
        groupCount,
        slopesTest,
        interceptTest,
        commonLineTest,
        modelMetrics
      };
    };
    const computeScatterHolmAdjustedPValues = pValues => {
      const values = Array.isArray(pValues) ? pValues : [];
      const resolved = new Array(values.length).fill(NaN);
      const valid = values
        .map((value, index) => ({ index, p: Number(value) }))
        .filter(entry => Number.isFinite(entry.p) && entry.p >= 0 && entry.p <= 1)
        .sort((a, b) => a.p - b.p);
      if(!valid.length){
        return resolved;
      }
      let runningMax = 0;
      const m = valid.length;
      valid.forEach((entry, rank) => {
        const scaled = Math.min(1, (m - rank) * entry.p);
        runningMax = Math.max(runningMax, scaled);
        resolved[entry.index] = runningMax;
      });
      return resolved;
    };
    const classifyScatterGroupedLineDifference = (slopesP, interceptP, alpha) => {
      const threshold = Number.isFinite(alpha) ? alpha : 0.05;
      if(Number.isFinite(slopesP) && slopesP < threshold){
        return {
          code: 'different-slopes',
          text: `Slopes differ (P = ${formatP(slopesP)}).`
        };
      }
      if(Number.isFinite(interceptP) && interceptP < threshold){
        return {
          code: 'different-intercepts',
          text: `Slopes are not detectably different; intercepts differ (P = ${formatP(interceptP)}).`
        };
      }
      return {
        code: 'not-different',
        text: 'No statistically significant line difference detected.'
      };
    };
    const buildScatterGroupedComparisonReport = (groupedSeriesStats, options = {}) => {
      const alpha = resolveScatterComparisonAlpha(options);
      const overall = computeScatterGroupedLinearModelComparison(groupedSeriesStats);
      if(!overall){
        return null;
      }
      const slopesDecisionP = Number(overall?.slopesTest?.pValue);
      const canEvaluateIntercepts = Number.isFinite(slopesDecisionP) ? !(slopesDecisionP < alpha) : true;
      const interceptDecisionP = canEvaluateIntercepts ? Number(overall?.interceptTest?.pValue) : NaN;
      const overallDecision = classifyScatterGroupedLineDifference(slopesDecisionP, interceptDecisionP, alpha);
      const rows = [];
      const addTestRows = (prefix, test) => {
        if(!test){
          return;
        }
        rows.push({ metric: `${prefix} F`, value: formatMetricValue(test.fStatistic, 4) });
        rows.push({ metric: `${prefix} p`, value: formatP(test.pValue) });
      };
      rows.push({ metric: '[GraphPad-style] Decision threshold (alpha)', value: formatMetricValue(alpha, 4) });
      addTestRows('[Step 1] Equal slopes across groups', overall.slopesTest);
      if(canEvaluateIntercepts){
        addTestRows('[Step 2] Equal intercepts given equal slopes', overall.interceptTest);
      }else{
        rows.push({ metric: '[Step 2] Equal intercepts', value: 'Skipped because slopes were significantly different.' });
      }
      addTestRows('[Overall] One common line for all groups', overall.commonLineTest);
      rows.push({ metric: '[GraphPad-style] Overall interpretation', value: overallDecision.text });
      rows.push({ metric: '[Group comparison] AICc common line', value: formatMetricValue(overall.modelMetrics.common.aicc, 4) });
      rows.push({ metric: '[Group comparison] AICc parallel lines', value: formatMetricValue(overall.modelMetrics.parallel.aicc, 4) });
      rows.push({ metric: '[Group comparison] AICc separate lines', value: formatMetricValue(overall.modelMetrics.separate.aicc, 4) });
      const preferred = [
        ['Common line', overall.modelMetrics.common.aicc],
        ['Parallel lines', overall.modelMetrics.parallel.aicc],
        ['Separate lines', overall.modelMetrics.separate.aicc]
      ].filter(entry => Number.isFinite(entry[1])).sort((a, b) => a[1] - b[1])[0];
      if(preferred){
        rows.push({ metric: '[Group comparison] Preferred model by AICc', value: preferred[0] });
      }
      const pairwise = [];
      for(let left = 0; left < overall.groups.length; left += 1){
        for(let right = left + 1; right < overall.groups.length; right += 1){
          const comparison = computeScatterGroupedLinearModelComparison([overall.groups[left], overall.groups[right]]);
          if(!comparison){
            continue;
          }
          pairwise.push({
            leftLabel: overall.groups[left].label,
            rightLabel: overall.groups[right].label,
            pairLabel: `${overall.groups[left].label} vs ${overall.groups[right].label}`,
            slopesTest: comparison.slopesTest || null,
            interceptTest: comparison.interceptTest || null,
            commonLineTest: comparison.commonLineTest || null
          });
        }
      }
      const slopeAdjusted = computeScatterHolmAdjustedPValues(pairwise.map(entry => entry?.slopesTest?.pValue));
      const interceptAdjusted = new Array(pairwise.length).fill(NaN);
      const interceptCandidates = [];
      pairwise.forEach((entry, index) => {
        const slopeRaw = Number(entry?.slopesTest?.pValue);
        const slopeAdj = Number(slopeAdjusted[index]);
        const slopeDecisionP = Number.isFinite(slopeAdj) ? slopeAdj : slopeRaw;
        const slopeDifferent = Number.isFinite(slopeDecisionP) && slopeDecisionP < alpha;
        if(!slopeDifferent){
          interceptCandidates.push({ index, p: Number(entry?.interceptTest?.pValue) });
        }
      });
      const interceptSubsetAdjusted = computeScatterHolmAdjustedPValues(interceptCandidates.map(entry => entry.p));
      interceptCandidates.forEach((entry, idx) => {
        interceptAdjusted[entry.index] = interceptSubsetAdjusted[idx];
      });
      const pairwiseRows = pairwise.map((entry, index) => {
        const slopeRaw = Number(entry?.slopesTest?.pValue);
        const slopeAdj = Number(slopeAdjusted[index]);
        const slopeDecisionP = Number.isFinite(slopeAdj) ? slopeAdj : slopeRaw;
        const slopeDifferent = Number.isFinite(slopeDecisionP) && slopeDecisionP < alpha;
        const interceptRawP = Number(entry?.interceptTest?.pValue);
        const interceptAdjP = Number(interceptAdjusted[index]);
        const interceptDecisionP = (!slopeDifferent && Number.isFinite(interceptAdjP)) ? interceptAdjP : (!slopeDifferent ? interceptRawP : NaN);
        const decision = classifyScatterGroupedLineDifference(slopeDecisionP, interceptDecisionP, alpha);
        return {
          pair: entry.pairLabel,
          slopesP: formatP(slopeRaw),
          slopesAdjP: Number.isFinite(slopeAdj) ? formatP(slopeAdj) : '—',
          interceptsP: slopeDifferent ? 'Skipped (slopes differ)' : formatP(interceptRawP),
          interceptsAdjP: slopeDifferent ? 'Skipped' : (Number.isFinite(interceptAdjP) ? formatP(interceptAdjP) : '—'),
          overallP: formatP(Number(entry?.commonLineTest?.pValue)),
          conclusion: decision.text,
          decisionCode: decision.code
        };
      });
      if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
        scatterDebug('Debug: scatter grouped GraphPad-style line comparison computed', {
          groupCount: overall.groupCount,
          pairCount: pairwiseRows.length,
          alpha,
          overallDecision: overallDecision.code
        });
      }
      return {
        alpha,
        overall,
        overallDecision,
        rows,
        pairwiseRows
      };
    };


    const SCATTER_GROUPED_GLOBAL_UNSUPPORTED_MODES = new Set(['deming', 'orthogonal', 'lowess', 'spline']);
    const canScatterUseGroupedGlobalFit = mode => {
      const normalized = String(mode || '').trim().toLowerCase();
      return !!normalized && !SCATTER_GROUPED_GLOBAL_UNSUPPORTED_MODES.has(normalized) && !!(regressionTools && typeof regressionTools.fitRegression === 'function');
    };
    const fitScatterCoreRegressionModel = (points, options = {}) => {
      const mode = String(options.mode || 'linear').toLowerCase();
      if((mode === 'linear' || mode === 'linearthroughorigin') && typeof fitScatterLinearLikeRegression === 'function'){
        return fitScatterLinearLikeRegression(points, options);
      }
      if((mode === 'deming' || mode === 'orthogonal') && typeof fitScatterDemingRegression === 'function'){
        return fitScatterDemingRegression(points, options);
      }
      if(mode === 'lowess' && typeof fitScatterLowessRegression === 'function'){
        return fitScatterLowessRegression(points, options);
      }
      if(regressionTools && typeof regressionTools.fitRegression === 'function'){
        try{
          return regressionTools.fitRegression(points, {
            ...options,
            fitSpec: stripScatterGlobalFitSpec(options.fitSpec || {}),
            method: getScatterFitMethodFamily(options.method || 'ols')
          });
        }catch(err){
          console.error('scatter fitScatterCoreRegressionModel failed', err);
        }
      }
      return null;
    };
    const extractScatterRegressionParameters = model => {
      const values = {};
      const order = [];
      const add = (name, value) => {
        const key = String(name || '').trim();
        if(!key || !Number.isFinite(value) || Object.prototype.hasOwnProperty.call(values, key)){
          return;
        }
        values[key] = Number(value);
        order.push(key);
      };
      const coeffRows = Array.isArray(model?.coefficientStats) ? model.coefficientStats : [];
      coeffRows.forEach(stat => add(stat?.term, stat?.estimate));
      const params = model?.summary?.parameters;
      if(params && typeof params === 'object'){
        Object.entries(params).forEach(([name, value]) => add(name, value));
      }
      add('Slope', model?.summary?.slope);
      add('Intercept', model?.summary?.intercept);
      return { order, values };
    };
    const resolveScatterParameterName = (requestedName, availableNames) => {
      const target = String(requestedName || '').trim();
      if(!target){
        return '';
      }
      const names = Array.isArray(availableNames) ? availableNames : [];
      if(names.includes(target)){
        return target;
      }
      const lowerTarget = target.toLowerCase();
      const ciMatch = names.find(name => String(name || '').trim().toLowerCase() === lowerTarget);
      return ciMatch || '';
    };
    const buildScatterFixedConstraintSpec = (baseConstraints, fixedValues) => {
      const merged = cloneScatterJsonValue(baseConstraints || {});
      Object.entries(fixedValues || {}).forEach(([name, value]) => {
        const current = merged[name] && typeof merged[name] === 'object' ? merged[name] : {};
        merged[name] = {
          ...current,
          value,
          lower: value,
          upper: value,
          fixed: true
        };
        delete merged[name].shared;
        delete merged[name].share;
        delete merged[name].global;
      });
      return merged;
    };
    const buildScatterFixedInitialValues = (baseInitialValues, fallbackValues, fixedValues) => {
      return {
        ...cloneScatterJsonValue(baseInitialValues || {}),
        ...cloneScatterJsonValue(fallbackValues || {}),
        ...(fixedValues || {})
      };
    };
    const countScatterFreeParameters = (parameterNames, sharedNameSet) => {
      const names = Array.isArray(parameterNames) ? parameterNames : [];
      const shared = sharedNameSet instanceof Set ? sharedNameSet : new Set();
      return names.reduce((sum, name) => sum + (shared.has(name) ? 0 : 1), 0);
    };
    const clampScatterValue = (value, lower, upper) => {
      let next = Number(value);
      if(!Number.isFinite(next)){
        next = 0;
      }
      if(Number.isFinite(lower) && next < lower){
        next = lower;
      }
      if(Number.isFinite(upper) && next > upper){
        next = upper;
      }
      return next;
    };
    const optimizeScatterSharedParameters = (startVector, evaluate, bounds, options = {}) => {
      const dims = Array.isArray(startVector) ? startVector.length : 0;
      if(!dims){
        return { bestVector: [], evaluation: evaluate([]), iterations: 0, converged: true };
      }
      const tolerance = Number.isFinite(options?.tolerance) ? Math.max(1e-9, Number(options.tolerance)) : 1e-6;
      const maxIterations = Number.isFinite(options?.maxIterations) ? Math.max(10, Math.round(Number(options.maxIterations))) : 80;
      const clampVector = vector => vector.map((value, index) => clampScatterValue(value, bounds[index]?.lower, bounds[index]?.upper));
      let current = clampVector(startVector);
      let currentEval = evaluate(current);
      let steps = current.map((value, index) => {
        const lower = bounds[index]?.lower;
        const upper = bounds[index]?.upper;
        const width = Number.isFinite(lower) && Number.isFinite(upper) && upper > lower ? (upper - lower) : NaN;
        if(Number.isFinite(width) && width > 0){
          return Math.max(width * 0.2, tolerance * 10);
        }
        const magnitude = Math.abs(Number(value));
        return Math.max(magnitude * 0.2, 0.1, tolerance * 10);
      });
      let iterations = 0;
      while(iterations < maxIterations){
        let improved = false;
        for(let dim = 0; dim < dims; dim += 1){
          const baseValue = current[dim];
          const deltas = [steps[dim], -steps[dim]];
          for(let j = 0; j < deltas.length; j += 1){
            const candidate = current.slice();
            candidate[dim] = clampScatterValue(baseValue + deltas[j], bounds[dim]?.lower, bounds[dim]?.upper);
            if(Math.abs(candidate[dim] - baseValue) <= tolerance){
              continue;
            }
            const candidateEval = evaluate(candidate);
            if(candidateEval && Number.isFinite(candidateEval.objective) && candidateEval.objective + tolerance < currentEval.objective){
              current = candidate;
              currentEval = candidateEval;
              improved = true;
              break;
            }
          }
        }
        if(!improved){
          steps = steps.map(step => step * 0.5);
          if(steps.every(step => step <= tolerance * 4)){
            break;
          }
        }
        iterations += 1;
      }
      return {
        bestVector: current,
        evaluation: currentEval,
        iterations,
        converged: steps.every(step => step <= tolerance * 4)
      };
    };
    const adaptRegressionGroupedFitForScatter = (groupedFitResult, groups) => {
      if(!groupedFitResult || !Array.isArray(groups)){
        return null;
      }
      const mergeSeries = (seriesList) => (Array.isArray(seriesList) ? seriesList : []).map((entry, index) => ({
        label: entry?.label || groups[index]?.label || `Series ${index + 1}`,
        points: Array.isArray(entry?.points) ? entry.points : (groups[index]?.points || []),
        stats: {
          ...(groups[index]?.stats || {}),
          regression: entry?.model || null,
          derived: entry?.model ? computeScatterDerivedRegressionStats(entry.model) : null
        }
      }));
      return {
        mode: groupedFitResult.mode,
        fitMethod: groupedFitResult.fitMethod,
        globalSpec: groupedFitResult.globalSpec || null,
        activeKind: groupedFitResult.activeKind === 'shared' ? 'shared' : 'separate',
        separate: groupedFitResult.separate ? {
          ...groupedFitResult.separate,
          seriesStats: mergeSeries(groupedFitResult.separate.series)
        } : null,
        commonCurve: groupedFitResult.commonCurve || null,
        sharedFit: groupedFitResult.sharedFit ? {
          ...groupedFitResult.sharedFit,
          seriesStats: mergeSeries(groupedFitResult.sharedFit.series)
        } : null,
        activeSeriesStats: mergeSeries(groupedFitResult.activeSeries),
        warnings: Array.isArray(groupedFitResult.warnings) ? groupedFitResult.warnings.slice() : []
      };
    };
    const buildScatterGroupedGlobalFitAnalysis = (groupedSeriesStats, options = {}) => {
      const groups = (Array.isArray(groupedSeriesStats) ? groupedSeriesStats : [])
        .map((entry, index) => ({
          label: (entry?.label != null && String(entry.label).trim() !== '') ? String(entry.label).trim() : `Series ${index + 1}`,
          points: Array.isArray(entry?.points) ? entry.points.filter(pt => Number.isFinite(pt?.x) && Number.isFinite(pt?.y)).map(pt => ({ x: Number(pt.x), y: Number(pt.y) })) : [],
          stats: entry?.stats || null
        }))
        .filter(entry => entry.points.length >= 3 && entry?.stats?.regression);
      const mode = String(options?.regressionModeValue || '').trim();
      const fitMethod = String(options?.fitMethodValue || 'ols').trim();
      const baseFitSpec = stripScatterGlobalFitSpec(options?.fitSpec || {});
      const globalSpecNormalized = normalizeScatterGlobalFitSpec(options?.fitSpec?.globalFit || null, baseFitSpec.parameters);
      const globalSpec = globalSpecNormalized.value || null;
      if(groups.length < 2 || !canScatterUseGroupedGlobalFit(mode)){
        return null;
      }
      if(regressionTools && typeof regressionTools.fitGroupedRegression === 'function'){
        try{
          const groupedFitResult = regressionTools.fitGroupedRegression(
            groups.map(group => ({ label: group.label, points: group.points })),
            {
              mode,
              method: getScatterFitMethodFamily(fitMethod),
              fitSpec: options?.fitSpec || {},
              domain: options?.domain || null
            }
          );
          const adapted = adaptRegressionGroupedFitForScatter(groupedFitResult, groups);
          if(adapted){
            return adapted;
          }
        }catch(err){
          console.error('scatter grouped global fit shared-regression path failed', err);
        }
      }
      const warnings = [];
      const separateSeriesStats = groups.map(group => ({
        label: group.label,
        points: group.points,
        stats: group.stats
      }));
      const separateSse = separateSeriesStats.reduce((sum, entry) => sum + Number(entry?.stats?.regression?.metrics?.sse || 0), 0);
      const totalN = groups.reduce((sum, group) => sum + group.points.length, 0);
      const separateParamInfo = separateSeriesStats.map(entry => extractScatterRegressionParameters(entry?.stats?.regression || null));
      const separateParamCounts = separateParamInfo.map(info => info.order.length);
      const separateParameterCount = separateParamCounts.reduce((sum, count) => sum + count, 0);
      const separateDf = totalN - separateParameterCount;
      const pooledPoints = groups.flatMap(group => group.points.map(pt => ({ x: pt.x, y: pt.y })));
      let commonCurve = null;
      if(globalSpec?.compareCommonCurve !== false){
        const pooledModel = fitScatterRegressionModel(pooledPoints, {
          mode,
          method: fitMethod,
          fitSpec: baseFitSpec,
          domain: options?.domain || null
        });
        if(pooledModel && Number.isFinite(pooledModel.metrics?.sse)){
          const pooledParams = extractScatterRegressionParameters(pooledModel);
          const pooledK = pooledParams.order.length || Number(pooledModel.metrics?.parameterCount) || 0;
          const pooledDf = totalN - pooledK;
          const commonStats = groups.map(group => {
            const clonedModel = typeof cloneScatterRegressionModel === 'function'
              ? cloneScatterRegressionModel(pooledModel)
              : pooledModel;
            return {
              label: group.label,
              points: group.points,
              stats: {
                ...(group.stats || {}),
                regression: clonedModel,
                derived: computeScatterDerivedRegressionStats(clonedModel)
              }
            };
          });
          commonCurve = {
            label: 'Common curve',
            model: pooledModel,
            seriesStats: commonStats,
            sse: Number(pooledModel.metrics?.sse),
            parameterCount: pooledK,
            df: pooledDf,
            infoCriteria: computeScatterAicMetrics(Number(pooledModel.metrics?.sse), totalN, pooledK),
            versusSeparate: computeScatterExtraSumSquaresF(Number(pooledModel.metrics?.sse), pooledDf, separateSse, separateDf)
          };
        }else{
          warnings.push('Common-curve pooled fit did not converge, so only separate fits are reported.');
        }
      }
      let sharedFit = null;
      const rawRequestedShared = Array.isArray(globalSpec?.sharedParameters) ? globalSpec.sharedParameters.slice() : [];
      const availableNames = Array.from(new Set(separateParamInfo.flatMap(info => info.order)));
      let requestedShared = rawRequestedShared.map(name => resolveScatterParameterName(name, availableNames) || String(name || '').trim()).filter(Boolean);
      if(requestedShared.includes('__all__')){
        requestedShared = availableNames.slice();
      }
      requestedShared = Array.from(new Set(requestedShared.map(name => resolveScatterParameterName(name, availableNames) || name).filter(name => availableNames.includes(name))));
      const ignoredShared = rawRequestedShared.filter(name => {
        const resolved = resolveScatterParameterName(name, availableNames);
        return name !== '__all__' && !resolved;
      });
      if(ignoredShared.length){
        warnings.push(`Shared parameters not recognized and ignored: ${ignoredShared.join(', ')}.`);
      }
      if(globalSpec?.enabled && requestedShared.length){
        const sharedSet = new Set(requestedShared);
        const startVector = requestedShared.map(name => {
          const estimates = separateParamInfo.map(info => Number(info.values?.[name])).filter(Number.isFinite);
          if(!estimates.length && commonCurve?.model){
            const commonParams = extractScatterRegressionParameters(commonCurve.model);
            if(Number.isFinite(commonParams.values?.[name])){
              estimates.push(Number(commonParams.values[name]));
            }
          }
          if(!estimates.length){
            return 0;
          }
          return estimates.reduce((sum, value) => sum + value, 0) / estimates.length;
        });
        const bounds = requestedShared.map(name => {
          const rule = baseFitSpec?.parameters?.[name];
          return {
            lower: Number.isFinite(Number(rule?.lower)) ? Number(rule.lower) : NaN,
            upper: Number.isFinite(Number(rule?.upper)) ? Number(rule.upper) : NaN
          };
        });
        const evalCache = new Map();
        const evaluate = vector => {
          const key = vector.map(value => Number(value).toPrecision(12)).join('|');
          if(evalCache.has(key)){
            return evalCache.get(key);
          }
          const fixedValues = Object.fromEntries(requestedShared.map((name, index) => [name, vector[index]]));
          let totalSse = 0;
          let parameterCount = requestedShared.length;
          const seriesStats = [];
          for(let i = 0; i < groups.length; i += 1){
            const fallbackValues = separateParamInfo[i]?.values || {};
            const fitSpec = {
              ...baseFitSpec,
              initialValues: buildScatterFixedInitialValues(baseFitSpec?.initialValues, fallbackValues, fixedValues),
              parameters: buildScatterFixedConstraintSpec(baseFitSpec?.parameters, fixedValues)
            };
            const model = fitScatterCoreRegressionModel(groups[i].points, {
              mode,
              method: fitMethod,
              fitSpec,
              domain: options?.domain || null
            });
            const sse = Number(model?.metrics?.sse);
            if(!model || !Number.isFinite(sse)){
              const failed = { objective: Number.POSITIVE_INFINITY, totalSse: Number.POSITIVE_INFINITY, seriesStats: [], parameterCount: Number.POSITIVE_INFINITY };
              evalCache.set(key, failed);
              return failed;
            }
            totalSse += sse;
            const paramInfo = extractScatterRegressionParameters(model);
            parameterCount += countScatterFreeParameters(paramInfo.order, sharedSet);
            seriesStats.push({
              label: groups[i].label,
              points: groups[i].points,
              stats: {
                ...(groups[i].stats || {}),
                regression: model,
                derived: computeScatterDerivedRegressionStats(model)
              }
            });
          }
          const result = { objective: totalSse, totalSse, seriesStats, parameterCount };
          evalCache.set(key, result);
          return result;
        };
        const optimization = optimizeScatterSharedParameters(startVector, evaluate, bounds, {
          maxIterations: globalSpec?.maxIterations,
          tolerance: globalSpec?.tolerance
        });
        const bestVector = Array.isArray(optimization.bestVector) ? optimization.bestVector : startVector;
        const bestFixedValues = Object.fromEntries(requestedShared.map((name, index) => [name, bestVector[index]]));
        const finalSeriesStats = groups.map((group, index) => {
          const fallbackValues = separateParamInfo[index]?.values || {};
          const fitSpec = {
            ...baseFitSpec,
            initialValues: buildScatterFixedInitialValues(baseFitSpec?.initialValues, fallbackValues, bestFixedValues),
            parameters: buildScatterFixedConstraintSpec(baseFitSpec?.parameters, bestFixedValues)
          };
          const model = fitScatterRegressionModel(group.points, {
            mode,
            method: fitMethod,
            fitSpec,
            domain: options?.domain || null
          });
          return {
            label: group.label,
            points: group.points,
            stats: {
              ...(group.stats || {}),
              regression: model,
              derived: computeScatterDerivedRegressionStats(model)
            }
          };
        });
        const finalSse = finalSeriesStats.reduce((sum, entry) => sum + Number(entry?.stats?.regression?.metrics?.sse || 0), 0);
        const finalParamCount = requestedShared.length + finalSeriesStats.reduce((sum, entry) => {
          const paramInfo = extractScatterRegressionParameters(entry?.stats?.regression || null);
          return sum + countScatterFreeParameters(paramInfo.order, sharedSet);
        }, 0);
        const finalDf = totalN - finalParamCount;
        sharedFit = {
          sharedParameters: requestedShared,
          fixedValues: bestFixedValues,
          seriesStats: finalSeriesStats,
          sse: finalSse,
          parameterCount: finalParamCount,
          df: finalDf,
          infoCriteria: computeScatterAicMetrics(finalSse, totalN, finalParamCount),
          optimizer: {
            iterations: optimization.iterations,
            converged: !!optimization.converged,
            tolerance: globalSpec?.tolerance,
            maxIterations: globalSpec?.maxIterations
          },
          versusSeparate: computeScatterExtraSumSquaresF(finalSse, finalDf, separateSse, separateDf),
          versusCommon: commonCurve ? computeScatterExtraSumSquaresF(commonCurve.sse, commonCurve.df, finalSse, finalDf) : null
        };
        if(!sharedFit.seriesStats.every(entry => entry?.stats?.regression && Number.isFinite(entry.stats.regression.metrics?.sse))){
          warnings.push('Shared-parameter global fit did not converge cleanly for every group; separate fits remain available for comparison.');
        }
      }
      const activeSeriesStats = (sharedFit && globalSpec?.useSharedFitForRendering !== false)
        ? sharedFit.seriesStats
        : separateSeriesStats;
      return {
        mode,
        fitMethod,
        globalSpec,
        activeKind: sharedFit && globalSpec?.useSharedFitForRendering !== false ? 'shared' : 'separate',
        separate: {
          label: 'Separate curves',
          seriesStats: separateSeriesStats,
          sse: separateSse,
          parameterCount: separateParameterCount,
          df: separateDf,
          infoCriteria: computeScatterAicMetrics(separateSse, totalN, separateParameterCount)
        },
        commonCurve,
        sharedFit,
        activeSeriesStats,
        warnings
      };
    };
    const buildScatterGroupedCurveComparisonRows = groupedGlobalFit => {
      if(!groupedGlobalFit){
        return null;
      }
      const rows = [];
      rows.push({ metric: '[Global fit] Active plotted grouped fit', value: groupedGlobalFit.activeKind === 'shared' ? 'Shared-parameter fit' : 'Separate curves' });
      const addModelRows = (prefix, model) => {
        if(!model || !Number.isFinite(model.sse)){
          return;
        }
        rows.push({ metric: `${prefix} SSE`, value: formatMetricValue(model.sse, 4) });
        if(Number.isFinite(model.infoCriteria?.aic)){
          rows.push({ metric: `${prefix} AIC`, value: formatMetricValue(model.infoCriteria.aic, 4) });
        }
        if(Number.isFinite(model.infoCriteria?.aicc)){
          rows.push({ metric: `${prefix} AICc`, value: formatMetricValue(model.infoCriteria.aicc, 4) });
        }
        if(Number.isFinite(model.infoCriteria?.bic)){
          rows.push({ metric: `${prefix} BIC`, value: formatMetricValue(model.infoCriteria.bic, 4) });
        }
      };
      addModelRows('[Curve comparison] Separate curves', groupedGlobalFit.separate);
      addModelRows('[Curve comparison] Common curve', groupedGlobalFit.commonCurve);
      addModelRows('[Curve comparison] Shared-parameter fit', groupedGlobalFit.sharedFit);
      if(groupedGlobalFit.sharedFit?.sharedParameters?.length){
        rows.push({ metric: '[Global fit] Shared parameters', value: groupedGlobalFit.sharedFit.sharedParameters.join(', ') });
        Object.entries(groupedGlobalFit.sharedFit.fixedValues || {}).forEach(([name, value]) => {
          rows.push({ metric: `[Global fit] Shared ${name}`, value: formatMetricValue(value, 4) });
        });
      }
      const addTestRows = (prefix, test) => {
        if(!test){
          return;
        }
        rows.push({ metric: `${prefix} F`, value: formatMetricValue(test.fStatistic, 4) });
        rows.push({ metric: `${prefix} p`, value: formatP(test.pValue) });
      };
      addTestRows('[Curve comparison] Common curve vs separate curves', groupedGlobalFit.commonCurve?.versusSeparate);
      addTestRows('[Curve comparison] Shared-parameter fit vs separate curves', groupedGlobalFit.sharedFit?.versusSeparate);
      addTestRows('[Curve comparison] Common curve vs shared-parameter fit', groupedGlobalFit.sharedFit?.versusCommon);
      if(groupedGlobalFit.sharedFit?.optimizer){
        rows.push({ metric: '[Global fit] Optimizer iterations', value: String(Math.max(0, Math.round(groupedGlobalFit.sharedFit.optimizer.iterations || 0))) });
        rows.push({ metric: '[Global fit] Optimizer converged', value: groupedGlobalFit.sharedFit.optimizer.converged ? 'Yes' : 'Stopped before tolerance was reached' });
      }
      const preferred = [
        ['Separate curves', groupedGlobalFit.separate?.infoCriteria?.aicc],
        ['Common curve', groupedGlobalFit.commonCurve?.infoCriteria?.aicc],
        ['Shared-parameter fit', groupedGlobalFit.sharedFit?.infoCriteria?.aicc]
      ].filter(entry => Number.isFinite(entry[1])).sort((a, b) => a[1] - b[1])[0];
      if(preferred){
        rows.push({ metric: '[Curve comparison] Preferred model by AICc', value: preferred[0] });
      }
      if(Array.isArray(groupedGlobalFit.warnings) && groupedGlobalFit.warnings.length){
        rows.push({ metric: '[Warnings] Grouped curve comparison', value: groupedGlobalFit.warnings.join('; ') });
      }
      return rows.length ? rows : null;
    };

    const computeScatterSpearmanExactP = (rho, n) => {
      const size = Number(n);
      const observed = Math.abs(Number(rho));
      if(!Number.isFinite(size) || !Number.isFinite(observed) || size < 3 || size > 9){
        return null;
      }
      const permutation = Array.from({ length: size }, (_, idx) => idx + 1);
      const denom = size * (Math.pow(size, 2) - 1);
      let total = 0;
      let extreme = 0;
      const tolerance = 1e-12;
      const permute = index => {
        if(index >= size){
          let d2 = 0;
          for(let i = 0; i < size; i += 1){
            const d = (i + 1) - permutation[i];
            d2 += d * d;
          }
          const rhoPerm = 1 - ((6 * d2) / denom);
          total += 1;
          if(Math.abs(rhoPerm) >= observed - tolerance){
            extreme += 1;
          }
          return;
        }
        for(let i = index; i < size; i += 1){
          const tmp = permutation[index];
          permutation[index] = permutation[i];
          permutation[i] = tmp;
          permute(index + 1);
          permutation[i] = permutation[index];
          permutation[index] = tmp;
        }
      };
      permute(0);
      return total ? (extreme / total) : null;
    };
    const computeScatterCorrelationStats = (method, x, y) => {
      const resolvedMethod = normalizeScatterAssociationSelection(method);
      const n = x.length;
      const statsApi = getScatterJStat();
      let pearson = NaN;
      if(statsApi && typeof statsApi.corrcoeff === 'function'){
        pearson = Number(statsApi.corrcoeff(x, y));
      }else{
        const meanX = x.reduce((sum, value) => sum + value, 0) / Math.max(1, n);
        const meanY = y.reduce((sum, value) => sum + value, 0) / Math.max(1, n);
        let num = 0;
        let denX = 0;
        let denY = 0;
        for(let i = 0; i < n; i += 1){
          const dx = x[i] - meanX;
          const dy = y[i] - meanY;
          num += dx * dy;
          denX += dx * dx;
          denY += dy * dy;
        }
        const denom = Math.sqrt(Math.max(0, denX * denY));
        pearson = denom > 0 ? (num / denom) : NaN;
      }
      const studentTCdf = (statsApi && statsApi.studentt && typeof statsApi.studentt.cdf === 'function')
        ? statsApi.studentt.cdf.bind(statsApi.studentt)
        : null;
      if(resolvedMethod === 'none'){
        return {
          methodCode: 'none',
          methodLabel: 'None (model fit only)',
          r: NaN,
          p: NaN,
          pMethod: 'not computed',
          ci: null,
          ciApproximate: false
        };
      }
      if(resolvedMethod === 'pearson'){
        const bounded = Math.max(-0.999999999999, Math.min(0.999999999999, pearson));
        const t = bounded * Math.sqrt((n - 2) / Math.max(1e-12, 1 - (bounded * bounded)));
        const p = studentTCdf ? (2 * (1 - studentTCdf(Math.abs(t), n - 2))) : NaN;
        return {
          methodCode: 'pearson',
          methodLabel: 'Pearson',
          r: pearson,
          p,
          pMethod: 'Student t approximation',
          ci: computeScatterCorrelationConfidenceInterval(pearson, n, 0.05),
          ciApproximate: false
        };
      }
      const spearman = (statsApi && typeof statsApi.spearmancoeff === 'function')
        ? Number(statsApi.spearmancoeff(x, y))
        : pearson;
      const hasTies = hasScatterDuplicateValues(x) || hasScatterDuplicateValues(y);
      let p = NaN;
      let pMethod = 't approximation';
      if(!hasTies && n <= 9){
        const exact = computeScatterSpearmanExactP(spearman, n);
        if(Number.isFinite(exact)){
          p = exact;
          pMethod = 'exact permutation';
        }
      }
      if(!Number.isFinite(p)){
        const bounded = Math.max(-0.999999999999, Math.min(0.999999999999, spearman));
        const t = bounded * Math.sqrt((n - 2) / Math.max(1e-12, 1 - (bounded * bounded)));
        p = studentTCdf ? (2 * (1 - studentTCdf(Math.abs(t), n - 2))) : NaN;
      }
      return {
        methodCode: 'spearman',
        methodLabel: 'Spearman',
        r: spearman,
        p,
        pMethod,
        ci: computeScatterCorrelationConfidenceInterval(spearman, n, 0.05),
        ciApproximate: true
      };
    };
    const computeScatterDerivedRegressionStats = regressionModel => {
      const mode = String(regressionModel?.mode || '').toLowerCase();
      if(mode !== 'linear' && mode !== 'linearthroughorigin'){
        return null;
      }
      const coefficientStats = Array.isArray(regressionModel?.coefficientStats) ? regressionModel.coefficientStats : [];
      const interceptStat = coefficientStats.find(stat => String(stat?.term || '').toLowerCase() === 'intercept') || null;
      const slopeStat = coefficientStats.find(stat => String(stat?.term || '').toLowerCase() === 'slope') || null;
      const intercept = Number.isFinite(interceptStat?.estimate)
        ? interceptStat.estimate
        : Number(regressionModel?.summary?.intercept);
      const slope = Number.isFinite(slopeStat?.estimate)
        ? slopeStat.estimate
        : Number(regressionModel?.summary?.slope);
      if(!Number.isFinite(slope) || slope === 0){
        return null;
      }
      const reciprocalSlope = 1 / slope;
      let reciprocalSlopeCi = null;
      if(Number.isFinite(slopeStat?.ciLow) && Number.isFinite(slopeStat?.ciHigh) && slopeStat.ciLow !== 0 && slopeStat.ciHigh !== 0){
        const lo = 1 / slopeStat.ciLow;
        const hi = 1 / slopeStat.ciHigh;
        reciprocalSlopeCi = { low: Math.min(lo, hi), high: Math.max(lo, hi) };
      }
      let xIntercept = null;
      let xInterceptCi = null;
      if(Number.isFinite(intercept)){
        xIntercept = -intercept / slope;
        const covariance = Array.isArray(regressionModel?.coefficientCovariance) ? regressionModel.coefficientCovariance : null;
        const tCritical = Number(regressionModel?.intervals?.tCritical);
        if(covariance && Number.isFinite(tCritical) && covariance.length >= 2){
          const varIntercept = Number(covariance?.[0]?.[0]);
          const varSlope = Number(covariance?.[1]?.[1]);
          const covInterceptSlope = Number(covariance?.[0]?.[1]);
          if(Number.isFinite(varIntercept) && Number.isFinite(varSlope) && Number.isFinite(covInterceptSlope)){
            const variance = (varIntercept / (slope * slope))
              + ((intercept * intercept * varSlope) / Math.pow(slope, 4))
              - ((2 * intercept * covInterceptSlope) / Math.pow(slope, 3));
            if(Number.isFinite(variance) && variance >= 0){
              const se = Math.sqrt(variance);
              xInterceptCi = {
                low: xIntercept - (tCritical * se),
                high: xIntercept + (tCritical * se)
              };
            }
          }
        }
      }
      return {
        xIntercept,
        xInterceptCi,
        reciprocalSlope,
        reciprocalSlopeCi
      };
    };
    const predictScatterRegressionValue = (regressionModel, xValue) => {
      const x = Number(xValue);
      if(!Number.isFinite(x) || !regressionModel){
        return NaN;
      }
      if(typeof regressionModel.predict === 'function'){
        const direct = Number(regressionModel.predict(x));
        return Number.isFinite(direct) ? direct : NaN;
      }
      const mode = String(regressionModel.mode || '').toLowerCase();
      const summary = regressionModel.summary && typeof regressionModel.summary === 'object'
        ? regressionModel.summary
        : null;
      const coefficients = Array.isArray(regressionModel.coefficients)
        ? regressionModel.coefficients.map(Number)
        : [];
      if(mode === 'linear'){
        const slope = Number(summary?.slope);
        const intercept = Number(summary?.intercept);
        if(Number.isFinite(slope) && Number.isFinite(intercept)){
          return intercept + (slope * x);
        }
        if(coefficients.length >= 2 && Number.isFinite(coefficients[0]) && Number.isFinite(coefficients[1])){
          return coefficients[0] + (coefficients[1] * x);
        }
      }
      if(mode === 'linearthroughorigin'){
        const slope = Number(summary?.slope);
        if(Number.isFinite(slope)){
          return slope * x;
        }
        if(coefficients.length >= 1 && Number.isFinite(coefficients[0])){
          return coefficients[0] * x;
        }
      }
      if(mode === 'quadratic' || mode === 'cubic' || mode === 'polynomial'){
        if(coefficients.length){
          const value = coefficients.reduce((acc, coeff, idx) => acc + (coeff * Math.pow(x, idx)), 0);
          return Number.isFinite(value) ? value : NaN;
        }
      }
      return NaN;
    };
    const resolveScatterResidualDataViewManager = () => {
      const hot = scatter.__ensureHotForActiveTab?.() || scatterHot || scatterRefs.hot;
      if(!hot || typeof hot.getData !== 'function'){
        return null;
      }
      const manager = ensureScatterDataViewsForHot(hot, {
        wrapper: scatterHotWrapper,
        container: hot.__scatterHostContainer || scatterHotContainer
      });
      if(!manager || typeof manager.createDerivedView !== 'function'){
        return null;
      }
      return manager;
    };
    const removeScatterResidualDataViews = (manager) => {
      const staleResidualViews = (manager.getViews?.() || [])
        .filter(view => view && view.kind !== 'raw' && String(view?.summary?.transform || '').toLowerCase() === 'residuals');
      staleResidualViews.forEach(view => manager.removeView?.(view.id, { silent: true, reason: 'replace-residuals' }));
    };
    const createScatterResidualDataView = (manager, rows, options = {}) => {
      if(!manager || !Array.isArray(rows) || rows.length <= 1){
        return false;
      }
      removeScatterResidualDataViews(manager);
      manager.createDerivedView({
        title: options.title || 'Residuals',
        data: rows,
        sourceViewId: manager.getActiveViewId?.() || null,
        transformSpec: { type: 'residuals' },
        summary: {
          transform: 'residuals',
          rows: rows.length - 1,
          cols: rows[0].length,
          generatedAt: Date.now()
        },
        activate: options.activate === true,
        reason: options.reason || 'scatter-residuals'
      });
      manager.refresh?.();
      scatterDebug('Debug: scatter residuals data view updated', { rows: rows.length - 1, cols: rows[0].length });
      return true;
    };
    const upsertScatterResidualsDataView = (context, regressionModel, options = {}) => {
      const manager = resolveScatterResidualDataViewManager();
      if(!manager){
        return false;
      }
      const points = Array.isArray(context?.points) ? context.points : [];
      if(!points.length || !regressionModel){
        return false;
      }
      const rows = [['Label', 'X', 'Residual']];
      points.forEach((point, index) => {
        const x = Number(point?.x);
        const y = Number(point?.y);
        if(!Number.isFinite(x) || !Number.isFinite(y)){
          return;
        }
        const predicted = predictScatterRegressionValue(regressionModel, x);
        if(!Number.isFinite(predicted)){
          return;
        }
        const residual = y - predicted;
        const label = point?.label != null && String(point.label).trim() !== ''
          ? String(point.label)
          : `Point ${index + 1}`;
        rows.push([label, x, residual]);
      });
      return createScatterResidualDataView(manager, rows, options);
    };
    const upsertScatterGroupedResidualsDataView = (context, groupedSeriesStats, options = {}) => {
      const manager = resolveScatterResidualDataViewManager();
      if(!manager){
        return false;
      }
      const points = Array.isArray(context?.points) ? context.points : [];
      const seriesStats = Array.isArray(groupedSeriesStats) ? groupedSeriesStats : [];
      if(!points.length || !seriesStats.length){
        return false;
      }
      const modelsByLabel = new Map();
      seriesStats.forEach((entry, index) => {
        const label = (entry?.label != null && String(entry.label).trim() !== '')
          ? String(entry.label).trim()
          : `Series ${index + 1}`;
        const regressionModel = entry?.stats?.regression;
        if(regressionModel){
          modelsByLabel.set(label, regressionModel);
        }
      });
      if(!modelsByLabel.size){
        return false;
      }
      const rows = [['Label', 'X', 'Residual', 'Group']];
      points.forEach((point, index) => {
        const x = Number(point?.x);
        const y = Number(point?.y);
        if(!Number.isFinite(x) || !Number.isFinite(y)){
          return;
        }
        const groupLabel = (point?.series != null && String(point.series).trim() !== '')
          ? String(point.series).trim()
          : ((point?.label != null && String(point.label).trim() !== '')
            ? String(point.label).trim()
            : '');
        const model = modelsByLabel.get(groupLabel);
        if(!model){
          return;
        }
        const predicted = predictScatterRegressionValue(model, x);
        if(!Number.isFinite(predicted)){
          return;
        }
        const residual = y - predicted;
        const label = point?.pointName != null && String(point.pointName).trim() !== ''
          ? String(point.pointName).trim()
          : `Point ${index + 1}`;
        rows.push([label, x, residual, groupLabel || `Series ${index + 1}`]);
      });
      return createScatterResidualDataView(manager, rows, options);
    };
    const removeScatterResidualQqDataViews = manager => {
      const staleViews = (manager.getViews?.() || [])
        .filter(view => view && view.kind !== 'raw' && String(view?.summary?.transform || '').toLowerCase() === 'qq-residuals');
      staleViews.forEach(view => manager.removeView?.(view.id, { silent: true, reason: 'replace-qq-residuals' }));
    };
    const createScatterResidualQqDataView = (manager, rows, options = {}) => {
      if(!manager || !Array.isArray(rows) || rows.length <= 1){
        return false;
      }
      removeScatterResidualQqDataViews(manager);
      manager.createDerivedView({
        title: options.title || 'Residual QQ',
        data: rows,
        sourceViewId: manager.getActiveViewId?.() || null,
        transformSpec: { type: 'qq-residuals' },
        summary: {
          transform: 'qq-residuals',
          rows: rows.length - 1,
          cols: rows[0].length,
          generatedAt: Date.now()
        },
        activate: options.activate === true,
        reason: options.reason || 'scatter-qq-residuals'
      });
      manager.refresh?.();
      scatterDebug('Debug: scatter residual QQ data view updated', { rows: rows.length - 1, cols: rows[0].length });
      return true;
    };
    const upsertScatterResidualQqDataView = (context, regressionModel, options = {}) => {
      const manager = resolveScatterResidualDataViewManager();
      if(!manager || !regressionModel){
        return false;
      }
      const qqSeries = computeScatterResidualQqSeries(Array.isArray(context?.points) ? context.points : [], regressionModel);
      if(!qqSeries.length){
        return false;
      }
      const rows = [['Label', 'Theoretical quantile', 'Residual']];
      qqSeries.forEach(entry => {
        rows.push([entry.label, entry.theoretical, entry.residual]);
      });
      return createScatterResidualQqDataView(manager, rows, options);
    };
    const upsertScatterGroupedResidualQqDataView = (groupedSeriesStats, options = {}) => {
      const manager = resolveScatterResidualDataViewManager();
      if(!manager){
        return false;
      }
      const rows = [['Label', 'Theoretical quantile', 'Residual', 'Group']];
      (Array.isArray(groupedSeriesStats) ? groupedSeriesStats : []).forEach((entry, index) => {
        const label = (entry?.label != null && String(entry.label).trim() !== '')
          ? String(entry.label).trim()
          : `Series ${index + 1}`;
        const model = entry?.stats?.regression || null;
        const qqSeries = computeScatterResidualQqSeries(Array.isArray(entry?.points) ? entry.points : [], model, { group: label });
        qqSeries.forEach(item => {
          rows.push([item.label, item.theoretical, item.residual, label]);
        });
      });
      return createScatterResidualQqDataView(manager, rows, options);
    };
    console.debug('Debug: scatter component DOM helpers resolved', {
      hasSharedEditable: typeof Shared.makeEditable === 'function',
      hasSharedResize: typeof Shared.autoResizeSvg === 'function',
      hasSharedSerialize: typeof Shared.serializeCleanSVG === 'function'
    }); // Debug: helper availability summary
    const markFontEditable = (node, role, key) => {
      if (!node) { return; }
      const payload = { role: role || null, key: key || role || null, text: node?.textContent || null };
      if (fontControls && typeof fontControls.markText === 'function') {
        fontControls.markText(node, { scopeId: 'scatter', role, key });
      }
      if (node.dataset) {
        node.dataset.fontEditable = '1';
        node.dataset.fontScope = 'scatter';
        if (role) node.dataset.fontRole = role;
        if (key || role) node.dataset.fontKey = key || role;
      }
      if (!role || role.indexOf('Tick') === -1) {
        console.debug('Debug: scatter markFontEditable', payload); // Debug: font target tagging summary
      }
    };
  let scatterHot = null;
  let scatterDataViewsManager = null;
  let scatterDataToolbarBound = false;
  let scatterDataToolbarLastActivation = 0;
  let scatterLegendChangeInternal = false;
      // Scatter plot setup
      const scatterHotContainer=getScatterNodeById('scatterHot');
      const scatterHotWrapper=getScatterNodeById('scatterHotWrapper');
      const scatterTablePanel=getScatterNodeById('scatterTablePanel');
      const scatterGraphPanel=getScatterNodeById('scatterGraphPanel');
      const scatterPanelResizer=getScatterNodeById('scatterPanelResizer');
      let scatterSvgBox=scatterGraphPanel?.querySelector('.svgbox');
      bindScatterPlotContextMenuSuppression(scatterSvgBox);
      const scatterConfigPanel=scatterGraphPanel?.querySelector('.config-panel');

      const activateScatterDataToolbar = (reason) => {
        const now = Date.now();
        if(now - scatterDataToolbarLastActivation < 80){
          return false;
        }
        scatterDataToolbarLastActivation = now;
        const activated = !!Shared.workspaceToolbar?.activateSection?.('scatter', 'Data');
        if(activated){
          scatterDebug('Debug: scatter data toolbar activated', { reason: reason || 'unknown' });
        }
        return activated;
      };

      const ensureScatterDataViewsForHot = (hotInstance, options = {}) => {
        if(!hotInstance || typeof hotInstance.getData !== 'function'){
          return null;
        }
        if(typeof Shared.dataViews?.createManager !== 'function'){
          return null;
        }
        if(!hotInstance.__scatterDataViewsManager){
          hotInstance.__scatterDataViewsManager = Shared.dataViews.createManager({
            componentKey: 'scatter',
            maxViews: SCATTER_DATA_VIEW_MAX,
            initialData: hotInstance.getData() || [],
            onActiveViewChanged(view){
              if(!view || !hotInstance || typeof hotInstance.loadData !== 'function'){
                return;
              }
              const nextData = Array.isArray(view.data) ? view.data : [];
              hotInstance.loadData(nextData);
              if(view.exclusions){
                hotInstance.applyExclusions?.(view.exclusions);
              }
              if(view.filters){
                hotInstance.applyFilters?.(view.filters, { schedule: false });
              }
              ensureScatterHeaderTitles(hotInstance, {
                graphType: scatterCurrentGraphType,
                tableFormat: getScatterReplicateMode()
              });
              if(isGroupedScatterModeActive()){
                normalizeScatterGroupedHeaderRow(hotInstance, { source: 'scatter-grouped-header-normalize' });
              }
              updateScatterNestedHeaders(hotInstance, {
                graphType: scatterCurrentGraphType,
                tableFormat: getScatterReplicateMode()
              });
              markScatterOverlayPending('data-view-switch');
              scheduleDrawScatter({ reason: 'data-view-switch' });
            },
            onInteraction(){
              activateScatterDataToolbar('data-tab-interaction');
            }
          });
          scatterDebug('Debug: scatter data views manager created', {
            tabId: hotInstance.__scatterTabId || null
          });
        }
        const manager = hotInstance.__scatterDataViewsManager;
        const hostWrapper = options.wrapper || scatterHotWrapper || getScatterNodeById('scatterHotWrapper');
        const hostContainer = options.container || hotInstance.__scatterHostContainer || scatterHotContainer || getScatterNodeById('scatterHot');
        if(hostWrapper && hostContainer){
          manager.mount({
            wrapper: hostWrapper,
            tableContainer: hostContainer
          });
          manager.refresh?.();
        }
        scatterDataViewsManager = manager;
        return manager;
      };

      const syncScatterActiveDataViewFromHot = (hotInstance, reason) => {
        const hot = hotInstance || scatterHot || scatterRefs.hot;
        if(!hot || typeof hot.getData !== 'function'){
          return;
        }
        const manager = hot.__scatterDataViewsManager || scatterDataViewsManager;
        if(!manager){
          return;
        }
        manager.updateActiveData(hot.getData() || []);
        manager.updateActiveExclusions(hot?.exportExclusions?.() || null);
        manager.updateActiveFilters?.(hot?.exportFilters?.() || null);
        if(reason === 'afterLoadData'){
          manager.refresh?.();
        }
      };

      const applyScatterTransformToNewView = (transformSpec, options = {}) => {
        const hot = scatter.__ensureHotForActiveTab?.() || scatterHot || scatterRefs.hot;
        if(!hot){
          return false;
        }
        const manager = ensureScatterDataViewsForHot(hot, {
          wrapper: scatterHotWrapper || getScatterNodeById('scatterHotWrapper') || null,
          container: hot.__scatterHostContainer || scatterHotContainer || getScatterNodeById('scatterHot') || null
        });
        if(!manager || typeof manager.applyTransform !== 'function'){
          console.warn('scatter data transform skipped: Shared.dataViews unavailable');
          return false;
        }
        syncScatterActiveDataViewFromHot(hot, 'transform-before');
        const result = manager.applyTransform(transformSpec, {
          title: options.title,
          reason: options.reason || 'toolbar-transform',
          transformOptions: Object.assign({}, SCATTER_TRANSFORM_SCOPE_DEFAULT, options.transformOptions || {})
        });
        if(!result?.ok){
          const message = result?.error || 'Transformation failed.';
          if(typeof global.alert === 'function'){
            global.alert(`Unable to transform data: ${message}`);
          }
          scatterDebug('Debug: scatter transform failed', {
            message,
            transform: transformSpec?.type || null
          });
          return false;
        }
        activateScatterDataToolbar('transform-applied');
        scatterDebug('Debug: scatter transform created view', {
          title: result?.view?.title || null,
          summary: result?.result?.summary || null
        });
        return true;
      };

      const SCATTER_TRANSFORM_OPTION_MAP = Object.freeze({
        cpm: { spec: { type: 'cpm', orientation: 'column' }, title: 'CPM' },
        log2p1: { spec: { type: 'log', base: 2, pseudoCount: 1 }, title: 'log2(x+1)' },
        centerRowsMean: { spec: { type: 'centerRows', method: 'mean' }, title: 'Center rows (mean)' },
        centerRowsMedian: { spec: { type: 'centerRows', method: 'median' }, title: 'Center rows (median)' },
        centerColsMean: { spec: { type: 'centerColumns', method: 'mean' }, title: 'Center cols (mean)' },
        centerColsMedian: { spec: { type: 'centerColumns', method: 'median' }, title: 'Center cols (median)' },
        normalizeRows: { spec: { type: 'normalizeRows' }, title: 'Normalize rows (z)' },
        normalizeCols: { spec: { type: 'normalizeColumns' }, title: 'Normalize cols (z)' }
      });

      const promptScatterCustomExpression = () => {
        const toolbarApi = Shared.workspaceToolbar || null;
        const expression = String(toolbarApi?.getCustomTransformExpression?.('scatter') || '').trim();
        if(expression){
          return expression;
        }
        toolbarApi?.openCustomTransformEditor?.('scatter');
        if(typeof global.alert === 'function'){
          global.alert('Enter a custom transformation formula using x, then click "Apply custom".');
        }
        return null;
      };

      const resolveScatterToolbarTransformOption = (optionKey, customExpression) => {
        const key = String(optionKey || '').trim();
        if(!key){
          return null;
        }
        if(key === 'custom'){
          const normalized = String(customExpression || '').trim();
          if(!normalized){
            return null;
          }
          return {
            spec: { type: 'custom', expression: normalized },
            title: `Custom: ${normalized.slice(0, 24)}${normalized.length > 24 ? '...' : ''}`
          };
        }
        const preset = SCATTER_TRANSFORM_OPTION_MAP[key];
        if(!preset){
          return null;
        }
        return {
          spec: Object.assign({}, preset.spec),
          title: preset.title
        };
      };

      const applyScatterTransformPipelineToNewView = (transformSpecs, options = {}) => {
        const hot = scatter.__ensureHotForActiveTab?.() || scatterHot || scatterRefs.hot;
        if(!hot){
          return false;
        }
        const manager = ensureScatterDataViewsForHot(hot, {
          wrapper: scatterHotWrapper,
          container: hot.__scatterHostContainer || scatterHotContainer
        });
        if(!manager || typeof manager.applyPipeline !== 'function'){
          console.warn('scatter data transform pipeline skipped: Shared.dataViews unavailable');
          return false;
        }
        const specs = Array.isArray(transformSpecs) ? transformSpecs.filter(Boolean) : [];
        if(!specs.length){
          return false;
        }
        syncScatterActiveDataViewFromHot(hot, 'transform-before');
        const result = manager.applyPipeline(specs, {
          title: options.title,
          reason: options.reason || 'toolbar-transform-pipeline',
          transformOptions: Object.assign({}, SCATTER_TRANSFORM_SCOPE_DEFAULT, options.transformOptions || {})
        });
        if(!result?.ok){
          const message = result?.error || 'Transformation failed.';
          if(typeof global.alert === 'function'){
            global.alert(`Unable to transform data: ${message}`);
          }
          scatterDebug('Debug: scatter transform pipeline failed', {
            message,
            stepCount: specs.length
          });
          return false;
        }
        activateScatterDataToolbar('transform-pipeline-applied');
        scatterDebug('Debug: scatter transform pipeline created view', {
          title: result?.view?.title || null,
          stepCount: Array.isArray(result?.result?.steps) ? result.result.steps.length : specs.length
        });
        return true;
      };

      const applyScatterSelectedTransforms = () => {
        const toolbarApi = Shared.workspaceToolbar || null;
        const selected = toolbarApi?.getSelectedTransforms?.('scatter') || [];
        if(!Array.isArray(selected) || !selected.length){
          return false;
        }
        const resolved = [];
        for(let i = 0; i < selected.length; i += 1){
          const optionKey = selected[i];
          if(optionKey === 'custom'){
            const customExpression = promptScatterCustomExpression();
            if(!customExpression){
              return false;
            }
            const customTransform = resolveScatterToolbarTransformOption('custom', customExpression);
            if(customTransform){
              resolved.push(customTransform);
            }
            continue;
          }
          const next = resolveScatterToolbarTransformOption(optionKey);
          if(next){
            resolved.push(next);
          }
        }
        if(!resolved.length){
          return false;
        }
        const ok = resolved.length === 1
          ? applyScatterTransformToNewView(resolved[0].spec, {
            title: resolved[0].title,
            reason: 'toolbar-transform-multi-single'
          })
          : applyScatterTransformPipelineToNewView(
            resolved.map(item => item.spec),
            { reason: 'toolbar-transform-multi' }
          );
        if(ok){
          toolbarApi?.clearSelectedTransforms?.('scatter');
        }
        return ok;
      };

      const bindScatterDataToolbar = () => {
        if(scatterDataToolbarBound || !document){
          return;
        }
        document.addEventListener('click', event => {
          const button = event.target?.closest?.(
            '#scatterTransformApplySelected, #scatterTransformCustomApply, #scatterTransformCpm, #scatterTransformLog2p1, #scatterTransformCenterRowsMean, #scatterTransformCenterRowsMedian, #scatterTransformCenterColsMean, #scatterTransformCenterColsMedian, #scatterTransformNormalizeRows, #scatterTransformNormalizeCols, #scatterTransformCustom'
          );
          if(!button){
            return;
          }
          const transformSection = button.closest?.('.workspace-toolbar__section[data-transform-section="1"]');
          if(button.id === 'scatterTransformApplySelected'){
            applyScatterSelectedTransforms();
            return;
          }
          if(button.id === 'scatterTransformCustomApply'){
            const customExpression = promptScatterCustomExpression();
            if(!customExpression){
              return;
            }
            const customTransform = resolveScatterToolbarTransformOption('custom', customExpression);
            if(!customTransform){
              return;
            }
            if(transformSection?.dataset?.transformMultiMode === '1'){
              const selected = Shared.workspaceToolbar?.getSelectedTransforms?.('scatter') || [];
              if(Array.isArray(selected) && selected.includes('custom')){
                applyScatterSelectedTransforms();
              }else{
                applyScatterTransformToNewView(customTransform.spec, { title: customTransform.title });
              }
              return;
            }
            applyScatterTransformToNewView(customTransform.spec, { title: customTransform.title });
            return;
          }
          if(!transformSection){
            return;
          }
          if(transformSection?.dataset?.transformMultiMode === '1'){
            return;
          }
          const optionKey = String(button.dataset?.transformOption || '').trim();
          if(!optionKey){
            return;
          }
          if(optionKey === 'custom'){
            const customExpression = promptScatterCustomExpression();
            if(!customExpression){
              return;
            }
            const customTransform = resolveScatterToolbarTransformOption(optionKey, customExpression);
            if(customTransform){
              applyScatterTransformToNewView(customTransform.spec, { title: customTransform.title });
            }
            return;
          }
          const resolved = resolveScatterToolbarTransformOption(optionKey);
          if(resolved){
            applyScatterTransformToNewView(resolved.spec, { title: resolved.title });
          }
        }, true);
        if(scatterHotWrapper && !scatterHotWrapper.__scatterDataToolbarFocusBound){
          scatterHotWrapper.addEventListener('mousedown', () => {
            activateScatterDataToolbar('table-mousedown');
          }, true);
          scatterHotWrapper.__scatterDataToolbarFocusBound = true;
        }
        scatterDataToolbarBound = true;
      };

      const scatterShowLegend=$('#scatterShowLegend');
      scatterLegendControl = scatterShowLegend?.closest('label') || null;
      scatterLayout = Shared.componentLayout?.createStandardPanels({
        componentName: 'scatter',
        selectors: {
          tablePanel: '#scatterTablePanel',
          graphPanel: '#scatterGraphPanel',
          configPanel: () => scatterGraphPanel?.querySelector('.config-panel') || scatterGraphPanel?.querySelector('.config-panel'),
          panelResizer: '#scatterPanelResizer',
          hotWrapper: '#scatterHotWrapper',
          hotContainer: '#scatterHot',
          svgBox: () => scatterGraphPanel?.querySelector('.svgbox'),
          resizeTarget: () => scatterGraphPanel?.querySelector('.svgbox')
        },
        scheduleDraw: () => scheduleDrawScatter(),
        preserveGraphContent: false,
        panelSyncOptions: {
          disableAutoWidthClamp: true,
          lockGraphPanelWidth: false
        },
        resizableBoxOptions: {
          onResize: () => {
            console.debug('Debug: scatter layout onResize schedule trigger');
            scheduleDrawScatter({ viewOnly: true, reason: 'resize' });
          }
        }
      });
      if(scatterLayout?.elements?.svgBox){
        scatterSvgBox = scatterLayout.elements.svgBox;
        bindScatterPlotContextMenuSuppression(scatterSvgBox);
      }
      scatterSvgBoxRef = scatterSvgBox;
      scatterLayout?.setScheduleDraw?.(() => scheduleDrawScatter());
      scatterLayout?.syncPanels?.();
      ensureScatterResizerControls();
      const scheduleLegendPlacement=typeof Shared.debounceFrame==='function'
        ? Shared.debounceFrame(()=>ensureScatterResizerControls())
        : null;
      if(scheduleLegendPlacement){
        scheduleLegendPlacement();
      }else if(typeof global.requestAnimationFrame==='function'){
        global.requestAnimationFrame(()=>ensureScatterResizerControls());
      }
      if(scatterLayout && typeof scatterLayout.updateSvgBox==='function'){
        const originalUpdateSvgBox=scatterLayout.updateSvgBox.bind(scatterLayout);
        scatterLayout.updateSvgBox=node=>{
          originalUpdateSvgBox(node);
          if(node){
            scatterSvgBox=node;
          }else if(scatterLayout.elements?.svgBox){
            scatterSvgBox=scatterLayout.elements.svgBox;
          }
          scatterSvgBoxRef = scatterSvgBox;
          bindScatterPlotContextMenuSuppression(scatterSvgBox);
          ensureScatterResizerControls();
        };
      }
      console.debug('Debug: scatter initHot using shared factory', { hasFactory: typeof Shared.hot?.createStandardTable === 'function' });
      if(typeof Shared.hot?.createStandardTable !== 'function'){
        console.error('scatter initHot missing Shared.hot.createStandardTable');
        return;
      }
      const data = Shared.createEmptyData(DEFAULT_ROWS, DEFAULT_COLS);
      if(Array.isArray(data?.[0])){
        data[0][0] = '';
        data[0][1] = 'X title';
        data[0][2] = 'Y title';
        data[0][3] = 'Z title';
      }
      const scheduleDrawScatterProxy = (payload) => {
        const meta = payload && typeof payload === 'object'
          ? payload
          : (typeof payload === 'string' ? { reason: payload } : {});
        const headerOnlyChange = isScatterHeaderScheduleSource(meta.source);
        const invalidate = typeof meta.invalidate === 'string'
          ? meta.invalidate
          : (headerOnlyChange ? 'layout' : 'data');
        if(invalidate === 'data'){
          scatterState.dataDirty = true;
          scatterState.cachedCollect = null;
          scatterState.cachedGeometry = null;
        }
        const scheduleMeta = headerOnlyChange
          ? Object.assign({}, meta, {
              invalidate,
              viewOnly: true,
              reason: meta.reason || 'axis-header-sync'
            })
          : (meta.invalidate === invalidate ? meta : Object.assign({}, meta, { invalidate }));
        scheduleDrawScatter(scheduleMeta);
      };

        const createScatterTable = (container) => {
          let lastKeyDownAt = 0;
          let hotInstance = null;
        hotInstance = Shared.hot.createStandardTable(container,{ rows: DEFAULT_ROWS, cols: DEFAULT_COLS },scheduleDrawScatterProxy,{
          debugLabel: 'scatter',
          data,
          pinFirstRow: true,
          colDefEnhancer(def, meta){
            const colIndex = Number(meta?.colIndex);
            if(!Number.isInteger(colIndex) || !def || typeof def !== 'object'){
              return def;
            }
            const existingColSpan = def.colSpan;
            def.colSpan = params => {
              const physicalRow = params?.data?.__rowIndex;
              if(physicalRow === 0 && isGroupedScatterModeActive()){
                const role = getScatterGroupedHeaderCellRole(colIndex);
                if(role === 'xAnchor'){
                  return getScatterGroupedXReplicateCount(scatterReplicates, { xReplicatesEnabled: scatterGroupedXReplicates });
                }
                if(role === 'groupAnchor'){
                  return clampScatterReplicateCount(scatterReplicates);
                }
              }
              if(typeof existingColSpan === 'function'){
                return existingColSpan(params);
              }
              return Number.isFinite(existingColSpan) && existingColSpan > 0
                ? Math.floor(existingColSpan)
                : 1;
            };
            const existingCellStyle = def.cellStyle;
            def.cellStyle = params => {
              let baseStyle = {};
              if(typeof existingCellStyle === 'function'){
                const resolved = existingCellStyle(params);
                if(resolved && typeof resolved === 'object'){
                  baseStyle = Object.assign({}, resolved);
                }
              }else if(existingCellStyle && typeof existingCellStyle === 'object'){
                baseStyle = Object.assign({}, existingCellStyle);
              }
              const physicalRow = params?.data?.__rowIndex;
              if(physicalRow === 0 && isGroupedScatterModeActive()){
                const role = getScatterGroupedHeaderCellRole(colIndex);
                if(role === 'xAnchor' || role === 'groupAnchor'){
                  baseStyle.textAlign = 'center';
                  baseStyle.justifyContent = 'center';
                  baseStyle.fontWeight = '600';
                }else if(role === 'xFollower' || role === 'groupFollower'){
                  baseStyle.textAlign = 'center';
                  baseStyle.justifyContent = 'center';
                }
              }
              return baseStyle;
            };
            const existingHeaderClass = def.headerClass;
            def.headerClass = params => {
              const classes = [];
              const pushClass = value => {
                if(!value){
                  return;
                }
                if(Array.isArray(value)){
                  value.forEach(pushClass);
                  return;
                }
                if(typeof value === 'string'){
                  value.split(/\s+/).filter(Boolean).forEach(token => classes.push(token));
                }
              };
              if(typeof existingHeaderClass === 'function'){
                pushClass(existingHeaderClass(params));
              }else{
                pushClass(existingHeaderClass);
              }
              if(isGroupedScatterModeActive()){
                const role = getScatterGroupedHeaderCellRole(colIndex);
                if(role === 'groupAnchor' || role === 'groupFollower'){
                  classes.push('scatter-group-colheader');
                  const segment = getScatterGroupedHeaderMergeSegment(colIndex);
                  if(segment === 'start'){
                    classes.push('scatter-group-colheader-merge-start');
                  }else if(segment === 'middle'){
                    classes.push('scatter-group-colheader-merge-middle');
                  }else if(segment === 'end'){
                    classes.push('scatter-group-colheader-merge-end');
                  }
                }
              }
              return classes;
            };
            const existingEditable = def.editable;
            def.editable = params => {
              const physicalRow = params?.data?.__rowIndex;
              if(physicalRow === 0){
                const role = getScatterGroupedHeaderCellRole(colIndex);
                if(role === 'xFollower' || role === 'groupFollower'){
                  return false;
                }
              }
              return typeof existingEditable === 'function'
                ? existingEditable(params)
                : existingEditable !== false;
            };
            const existingRules = def.cellClassRules && typeof def.cellClassRules === 'object'
              ? Object.assign({}, def.cellClassRules)
              : {};
            existingRules['scatter-grouped-header-anchor'] = params => {
              if(params?.data?.__rowIndex !== 0){
                return false;
              }
              const role = getScatterGroupedHeaderCellRole(colIndex);
              return role === 'xAnchor' || role === 'groupAnchor';
            };
            existingRules['scatter-grouped-header-follower'] = params => {
              if(params?.data?.__rowIndex !== 0){
                return false;
              }
              const role = getScatterGroupedHeaderCellRole(colIndex);
              return role === 'xFollower' || role === 'groupFollower';
            };
            existingRules['scatter-grouped-header-merge-start'] = params => {
              if(params?.data?.__rowIndex !== 0){
                return false;
              }
              return getScatterGroupedHeaderMergeSegment(colIndex) === 'start';
            };
            existingRules['scatter-grouped-header-merge-middle'] = params => {
              if(params?.data?.__rowIndex !== 0){
                return false;
              }
              return getScatterGroupedHeaderMergeSegment(colIndex) === 'middle';
            };
            existingRules['scatter-grouped-header-merge-end'] = params => {
              if(params?.data?.__rowIndex !== 0){
                return false;
              }
              return getScatterGroupedHeaderMergeSegment(colIndex) === 'end';
            };
            def.cellClassRules = existingRules;
            return def;
          },
          hotOptions: {
            colHeaders: true,
            beforeKeyDown(){
              lastKeyDownAt = Date.now();
            },
            // Configure checkbox selection for row selection
            rowSelection: 'multiple',
            checkboxSelection: true,
            // Remove the column 5 selection handler completely
            // Row selection checkboxes now control point labeling exclusively
            afterChange(changes,source){
              if(!changes||source==='loadData') return;
              scatterLog('scatter afterChange', {count:changes.length, source});
              if(isGroupedScatterModeActive()){
                const headerTouched = changes.some(change => Number(change?.[0]) === 0);
                if(headerTouched && source !== 'scatter-grouped-header-normalize'){
                  normalizeScatterGroupedHeaderRow(hotInstance, { source: 'scatter-grouped-header-normalize' });
                  persistTabState('scatter-grouped-header-row-edit');
                }
                updateScatterNestedHeaders(hotInstance);
              }
              revalidateActiveScatterLogAxis('x','data-edit');
              revalidateActiveScatterLogAxis('y','data-edit');
              syncScatterActiveDataViewFromHot(hotInstance, 'afterChange');
              const graphType = scatterGraphTypeSelect?.value || scatterCurrentGraphType || 'scatter';
              if(graphType === 'volcano' && scatterShowSignificantLabels?.checked){
                markScatterThresholdSelectionPending('data-edit');
              }
            },
            afterLoadData(){
              ensureScatterHeaderTitles(hotInstance, {
                graphType: scatterCurrentGraphType,
                tableFormat: getScatterReplicateMode()
              });
              if(isGroupedScatterModeActive()){
                normalizeScatterGroupedHeaderRow(hotInstance, { source: 'scatter-grouped-header-normalize' });
              }
              updateScatterNestedHeaders(hotInstance, {
                graphType: scatterCurrentGraphType,
                tableFormat: getScatterReplicateMode()
              });
              syncScatterActiveDataViewFromHot(hotInstance, 'afterLoadData');
              const graphType = scatterGraphTypeSelect?.value || scatterCurrentGraphType || 'scatter';
              if(graphType === 'volcano' && scatterShowSignificantLabels?.checked){
                markScatterThresholdSelectionPending('data-load');
              }
            },
            afterSelectionEnd(){
              activateScatterDataToolbar('table-selection');
            },
            afterUndo(){
              scatterLog('scatter undo');
            },
            afterRedo(){
              scatterLog('scatter redo');
            }
          }
        });
        if(hotInstance){
          hotInstance.__scatterHostContainer = container || null;
          scatterRefs.hot = hotInstance;
        }
        if(hotInstance && !hotInstance.__scatterSelectionListenerBound){
          let attempts = 0;
          const tryBind = () => {
            attempts += 1;
            const api = hotInstance?.gridApi;
            if(api && typeof api.addEventListener === 'function'){
              const handler = () => {
                if(scatterSelectionSyncInProgress){
                  return;
                }
                if(scatterSelectionEventSuppressUntil){
                  const now = (global.performance && typeof global.performance.now === 'function')
                    ? global.performance.now()
                    : Date.now();
                  if(now < scatterSelectionEventSuppressUntil){
                    return;
                  }
                }
                storeScatterRowSelection(hotInstance, 'row-selection');
                scheduleScatterViewRefresh('row-selection');
              };
              api.addEventListener('selectionChanged', handler);
              api.addEventListener('rowSelected', handler);
              hotInstance.__scatterSelectionListenerBound = true;
              if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
                console.debug('Debug: scatter selection listener bound');
              }
              return;
            }
            if(attempts < 10){
              setTimeout(tryBind, 120);
            }
          };
          setTimeout(tryBind, 0);
        }
        return hotInstance;
      };
      const ensureScatterHotForActiveTab = () => {
        const wrapper = scatterHotWrapper || getScatterNodeById('scatterHotWrapper');
        const baseContainer = scatterHotContainer || getScatterNodeById('scatterHot');
        if(typeof Shared.hot?.ensureTableForTab !== 'function' || !wrapper || !baseContainer){
          if(!scatterHot){
            scatterHot = createScatterTable(baseContainer);
          }
          const activeTabId = Shared.hot.resolveActiveTabId?.() || 'scatter-default';
          if(scatterHot){
            scatterHot.__scatterHostContainer = baseContainer;
            scatterHot.__scatterTabId = activeTabId;
            scheduleScatterSelectionRestore(scatterHot, activeTabId);
            scatterRefs.hot = scatterHot;
            ensureScatterHeaderTitles(scatterHot, {
              graphType: scatterCurrentGraphType,
              tableFormat: getScatterReplicateMode()
            });
            if(isGroupedScatterModeActive()){
              normalizeScatterGroupedHeaderRow(scatterHot, { source: 'scatter-grouped-header-normalize' });
            }
            updateScatterNestedHeaders(scatterHot, {
              graphType: scatterCurrentGraphType,
              tableFormat: getScatterReplicateMode()
            });
            ensureScatterDataViewsForHot(scatterHot, {
              wrapper,
              container: baseContainer
            });
            syncScatterActiveDataViewFromHot(scatterHot, 'ensure-active-tab');
          }
          return scatterHot;
        }
        const entry = Shared.hot.ensureTableForTab({
          type: 'scatter',
          tabId: Shared.hot.resolveActiveTabId?.() || 'scatter-default',
          wrapper,
          container: baseContainer,
          createInstance: createScatterTable
        });
        if(entry?.instance){
          scatterHot = entry.instance;
          scatterRefs.hot = scatterHot;
        }
        if(scatterHot){
          scatterHot.__scatterHostContainer = entry?.container || baseContainer;
        }
        const activeTabId = entry?.tabId || Shared.hot.resolveActiveTabId?.() || 'scatter-default';
        if(scatterHot){
          scatterHot.__scatterTabId = activeTabId;
          scheduleScatterSelectionRestore(scatterHot, activeTabId);
          scatterRefs.hot = scatterHot;
          ensureScatterHeaderTitles(scatterHot, {
            graphType: scatterCurrentGraphType,
            tableFormat: getScatterReplicateMode()
          });
          if(isGroupedScatterModeActive()){
            normalizeScatterGroupedHeaderRow(scatterHot, { source: 'scatter-grouped-header-normalize' });
          }
          updateScatterNestedHeaders(scatterHot, {
            graphType: scatterCurrentGraphType,
            tableFormat: getScatterReplicateMode()
          });
          ensureScatterDataViewsForHot(scatterHot, {
            wrapper,
            container: entry?.container || baseContainer
          });
          syncScatterActiveDataViewFromHot(scatterHot, 'ensure-active-tab');
        }

        return scatterHot;
      };
      scatterHot = ensureScatterHotForActiveTab();
      if(scatterHot){
        scatterRefs.hot = scatterHot;
      }
      scatter.__ensureHotForActiveTab = ensureScatterHotForActiveTab;
      bindScatterDataToolbar();
      if(typeof global.DEBUG_SCATTER === 'undefined') global.DEBUG_SCATTER = false;
      const scatterExamples={
        scatter:[
          ['','X title','Y title','Z title',''],
          ['Cat',4.5,23,'',''],
          ['Dog',20,45,'',''],
          ['Rabbit',2.5,35,'',''],
          ['Cat',5,25,'',''],
          ['Dog',22,50,'',''],
          ['Rabbit',3,40,'',''],
          ['Cat',4.8,24,'',''],
          ['Dog',24,55,'','']
        ],
        scatter3d:[
          ['','X title','Y title','Z title',''],
          ['Orion',2.5,18,4.5,''],
          ['Lyra',6.2,25,9.1,''],
          ['Cygnus',4.1,14,6.8,''],
          ['Andromeda',8.6,32,12.4,''],
          ['Cassiopeia',5.4,28,10.2,''],
          ['Phoenix',7.9,20,7.3,''],
          ['Delphinus',3.2,12,3.9,''],
          ['Vela',9.4,36,13.6,'']
        ],
        scatterBubble:[
          ['','X title','Y title','Z title',''],
          ['Comet A',1.8,12,25,''],
          ['Comet B',4.2,18,40,''],
          ['Comet C',2.5,22,55,''],
          ['Comet D',5.7,28,70,''],
          ['Comet E',3.9,16,35,''],
          ['Comet F',6.4,24,90,''],
          ['Comet G',4.8,30,65,''],
          ['Comet H',7.1,26,80,'']
        ],
        grouped:[
          ['Labels','X title','Control','','','Treatment','',''],
          ['Week 1',1,10.2,10.6,10.8,14.2,14.5,14.8],
          ['Week 2',2,10.8,11.0,11.2,14.9,15.2,15.5],
          ['Week 3',3,11.3,11.5,11.9,15.7,16.0,16.4],
          ['Week 4',4,11.9,12.2,12.4,16.6,16.9,17.2],
          ['Week 5',5,12.5,12.8,13.1,17.3,17.7,18.1]
        ],
        groupedXY:[
          ['Labels','X title','','','Control','','','Treatment','',''],
          ['Week 1',0.95,1.02,1.05,10.2,10.6,10.8,14.2,14.5,14.8],
          ['Week 2',1.93,2.00,2.08,10.8,11.0,11.2,14.9,15.2,15.5],
          ['Week 3',2.92,3.01,3.07,11.3,11.5,11.9,15.7,16.0,16.4],
          ['Week 4',3.91,4.03,4.09,11.9,12.2,12.4,16.6,16.9,17.2],
          ['Week 5',4.88,5.00,5.11,12.5,12.8,13.1,17.3,17.7,18.1]
        ],
        volcano:[
          ['Gene','log2FoldChange','pValue','',''],
          ['GeneA',1.6,0.0005,'',''],
          ['GeneB',-1.2,0.002,'',''],
          ['GeneC',0.2,0.8,'',''],
          ['GeneD',-2.1,0.0001,'',''],
          ['GeneE',0.5,0.4,'',''],
          ['GeneF',1.1,0.03,'',''],
          ['GeneG',-1.8,0.0008,'','']
        ],
        ma:[
          ['Gene','MeanExpression','log2FoldChange','pValue',''],
          ['GeneA',8.5,1.4,0.0005,''],
          ['GeneB',5.3,-1.1,0.002,''],
          ['GeneC',3.9,0.1,0.4,''],
          ['GeneD',9.2,-2.0,0.00005,''],
          ['GeneE',6.1,0.3,0.2,''],
          ['GeneF',7.4,1.2,0.015,''],
          ['GeneG',4.8,-1.5,0.0009,''],
          ['GeneH',2.7,0.0,0.9,'']
        ]
      };
      if(global.DEBUG_SCATTER) scatterLog('scatter example dataset map', scatterExamples);
      getScatterNodeById('scatterLoadExample').addEventListener('click',()=>{
        const type=scatterGraphTypeSelect?.value || 'scatter';
        const rawViewMode = type==='scatter' ? (scatterViewMode && typeof scatterViewMode.value === 'string' ? scatterViewMode.value : null) : null;
        const viewMode = type==='scatter'
          ? (rawViewMode || scatterState.requestedViewMode || scatterState.viewMode || '2d')
          : '2d';
        const normalizedMode = typeof viewMode === 'string' ? viewMode.toLowerCase() : '2d';
        const groupedModeActive = type === 'scatter' && normalizedMode === '2d' && isGroupedScatterModeActive();
        let dataset;
        if(groupedModeActive){
          const exampleReplicates = 3;
          const exampleLabels = ['Control', 'Treatment'];
          scatterReplicates = exampleReplicates;
          if(scatterReplicatesInput){
            scatterReplicatesInput.value = String(exampleReplicates);
          }
          scatterSeriesGroupLabels = exampleLabels.slice();
          if(scatterGroupedXReplicatesInput){
            scatterGroupedXReplicatesInput.checked = !!scatterGroupedXReplicates;
          }
          dataset = scatterGroupedXReplicates ? scatterExamples.groupedXY : scatterExamples.grouped;
        }else if(type==='scatter' && normalizedMode==='3d'){
          dataset = scatterExamples.scatter3d;
        }else if(type==='scatter' && normalizedMode==='bubble'){
          dataset = scatterExamples.scatterBubble;
        }else{
          dataset = scatterExamples[type] || scatterExamples.scatter;
        }
        markScatterOverlayPending('example-data');
        scatterHot.loadData(dataset, {
          source: 'example-load',
          recordUndo: true,
          undoLabel: 'table:scatter:example-load'
        });
        if(groupedModeActive){
          ensureScatterHeaderTitles(scatterHot, {
            graphType: 'scatter',
            tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
            xReplicatesEnabled: scatterGroupedXReplicates
          });
          normalizeScatterGroupedHeaderRow(scatterHot, {
            graphType: 'scatter',
            tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
            xReplicatesEnabled: scatterGroupedXReplicates,
            source: 'scatter-grouped-header-normalize'
          });
          updateScatterNestedHeaders(scatterHot, {
            graphType: 'scatter',
            tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
            xReplicatesEnabled: scatterGroupedXReplicates
          });
          updateScatterReplicateModeControls(SCATTER_TABLE_FORMAT_GROUPED);
        }
        const significanceColors = getScatterSignificanceColors();
        if(type!=='scatter' && scatterFill && scatterFill.value && scatterFill.value.toLowerCase()===getScatterPrimaryFillColor()){
          scatterFill.value=significanceColors.neutral;
        }
        scatterLog('scatter example loaded',{type,viewMode,rows:dataset.length});
        syncScatterGraphTypeUI();
        syncScatterAspectControls('payload');
        scheduleDrawScatter();
      });
      const scatterImportBtn=getScatterNodeById('scatterImport');
      const scatterFileInput=getScatterNodeById('scatterFile');
      const tableImport = Shared.tableImport;
      scatterImportBtn.addEventListener('click',()=>{ scatterFileInput.value=''; scatterFileInput.click(); });
      scatterFileInput.addEventListener('change',()=>{
        if(!tableImport || typeof tableImport.openFile !== 'function'){
          console.warn('scatter import skipped: Shared.tableImport.openFile unavailable');
          return;
        }
        const hasFile = !!(scatterFileInput?.files && scatterFileInput.files[0]);
        let forcedOverlay = false;
        if(hasFile){
          forcedOverlay = !!forceScatterOverlay('file-import', { message: 'Importing table data...' });
          markScatterOverlayPending('file-import');
        }
        const importPromise = tableImport.openFile(scatterFileInput, {
          hot: scatterHot,
          minCols: 4,
          minRows: DEFAULT_ROWS,
          scheduleDraw: () => {
            markScatterOverlayPending('file-import');
            scheduleDrawScatter({ force: true, reason: 'import-load' });
          },
          debugLabel: 'scatter',
          onPrismStyle: style => {
            if(!style || typeof style !== 'object'){
              return;
            }
            const title = style.title != null ? String(style.title).trim() : '';
            const xLabel = style.xLabel != null ? String(style.xLabel).trim() : '';
            const yLabel = style.yLabel != null ? String(style.yLabel).trim() : '';
            const fontFamily = style.fontFamily != null ? String(style.fontFamily).trim() : '';
            const fontColor = style.fontColor != null ? String(style.fontColor).trim() : '';
            const axisColor = style.axisColor != null ? String(style.axisColor).trim() : '';
            const fontSizeValue = Number(style.fontSize);
            if(title){
              scatterTitleText = title;
            }
            if(xLabel){
              scatterXLabelText = xLabel;
              scatterState.xLabelText = xLabel;
            }
            if(yLabel){
              scatterYLabelText = yLabel;
              scatterState.yLabelText = yLabel;
            }
            if(Number.isFinite(fontSizeValue) && fontSizeValue > 0 && scatterFontSize){
              scatterFontSize.value = String(fontSizeValue);
              if(scatterFontSize.dataset){
                scatterFontSize.dataset.fontBasePt = String(fontSizeValue);
              }
              chartStyle.renderFontSizeLabel({ element: scatterFontSizeVal, pt: fontSizeValue, input: scatterFontSize, manual: true });
            }
            if(axisColor){
              updateScatterAxisColor(axisColor);
            }
            if(fontFamily || fontColor){
              const graphStyle = {};
              if(fontFamily){
                graphStyle.fontFamily = fontFamily;
              }
              if(fontColor){
                graphStyle.fill = fontColor;
              }
              importFontStyles('scatter', { __graph__: graphStyle });
            }
            if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
              console.debug('Debug: scatter prism style applied', { title, xLabel, yLabel, fontFamily, fontSize: fontSizeValue, fontColor, axisColor });
            }
            scheduleDrawScatter({ force: true, reason: 'import-prism-style' });
          },
          onProcessed: info => scatterLog('scatter data imported',{rows: info?.rows, cols: info?.cols}),
          onCompleted: () => {
            const renderReason = 'import-load';
            markScatterOverlayPending(renderReason);
            forceScatterOverlay(renderReason, { message: 'Rendering scatter plot...' });
            // Do not resolve here; final resolve happens after draw completes.
          }
        });
        Promise.resolve(importPromise).then(result => {
          const fitRangeCleared = clearScatterFitRangeInputs('file-import');
          if(fitRangeCleared){
            requestScatterStatsContextRefresh('fit-range-cleared-import');
            persistTabState('scatter-fit-range-cleared-import');
          }
          const prismMeta = result?.prismMeta;
          if(prismMeta?.kind === 'line'){
            const replicateCount = clampScatterReplicateCount(prismMeta.replicatesCount || SCATTER_MIN_REPLICATES);
            const groupLabels = Array.isArray(prismMeta.groupLabels)
              ? prismMeta.groupLabels.map((label, idx) => sanitizeScatterGroupLabel(label, idx))
              : [];
            const importedMatrix = scatterHot?.getData?.() || [];
            scatterGroupedXReplicates = false;
            const groupedMatrix = convertScatterLineImportToGroupedMatrix(importedMatrix, {
              replicates: replicateCount,
              xReplicatesEnabled: false
            });
            if(scatterHot && typeof scatterHot.loadData === 'function'){
              scatterHot.loadData(groupedMatrix);
              syncScatterActiveDataViewFromHot(scatterHot, 'import-prism-line');
            }
            if(scatterGraphTypeSelect){
              scatterGraphTypeSelect.value = 'scatter';
            }
            scatterCurrentGraphType = 'scatter';
            scatterTableFormat = SCATTER_TABLE_FORMAT_GROUPED;
            if(scatterTableFormatSelect){
              scatterTableFormatSelect.value = SCATTER_TABLE_FORMAT_GROUPED;
            }
            scatterReplicates = replicateCount;
            if(scatterReplicates > SCATTER_MIN_REPLICATES){
              scatterLastGroupedReplicateCount = Math.min(
                SCATTER_MAX_REPLICATES,
                Math.max(2, scatterReplicates)
              );
            }
            if(groupLabels.length){
              scatterSeriesGroupLabels = groupLabels.slice();
            }
            if(scatterReplicatesInput){
              scatterReplicatesInput.value = String(scatterReplicates);
            }
            if(scatterGroupedXReplicatesInput){
              scatterGroupedXReplicatesInput.checked = false;
            }
            ensureScatterHeaderTitles(scatterHot, {
              graphType: 'scatter',
              tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
              xReplicatesEnabled: false
            });
            normalizeScatterGroupedHeaderRow(scatterHot, {
              graphType: 'scatter',
              tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
              xReplicatesEnabled: false,
              source: 'scatter-grouped-header-normalize'
            });
            updateScatterNestedHeaders(scatterHot, {
              graphType: 'scatter',
              tableFormat: SCATTER_TABLE_FORMAT_GROUPED,
              xReplicatesEnabled: false
            });
            updateScatterReplicateModeControls(SCATTER_TABLE_FORMAT_GROUPED);
            syncScatterGraphTypeUI();
            scheduleDrawScatter({ force: true, reason: 'import-prism-grouped' });
            console.debug('Debug: scatter prism grouped import applied',{
              replicateCount,
              groupCount: groupLabels.length || Math.max(
                1,
                getScatterGroupedSeriesCount(groupedMatrix?.[0]?.length || 0, replicateCount, { xReplicatesEnabled: false })
              )
            });
          }
          if(!result && forcedOverlay){
            resolveScatterOverlay('file-import-empty');
          }
        }).catch(err => {
          if(forcedOverlay){
            resolveScatterOverlay('file-import-error');
          }
          console.error('scatter import failed', err);
        });
      });

      const scatterGraphTypeSelect=$('#scatterGraphType');
      const scatterThresholdControls=$('#scatterThresholdControls');
        const scatterSignificantOptions=$('#scatterSignificantOptions');
        const scatterShowSignificantLabels=$('#scatterShowSignificantLabels');
      scatterTableFormatSelect=$('#scatterTableFormat');
      const scatterGroupedControls=$('#scatterGroupedControls');
      const scatterGroupedControlsExtra=$('#scatterGroupedControlsExtra');
      const scatterReplicatesInput=$('#scatterReplicates');
      const scatterGroupedXReplicatesInput=$('#scatterGroupedXReplicates');
      const scatterLog2FCThreshold=$('#scatterLog2FCThreshold');
      const scatterNegLogPThreshold=$('#scatterNegLogPThreshold');
      const scatterFill=$('#scatterFill'), scatterBorder=$('#scatterBorder'), scatterBorderWidth=$('#scatterBorderWidth'), scatterDotSize=$('#scatterDotSize'), scatterShowLine=$('#scatterShowLine'), scatterShowPlotStats=$('#scatterShowPlotStats'), scatterAlpha=$('#scatterAlpha');
      scatter.__domSentinel = scatterShowLine || null;
      const scatterShowErrorBars=$('#scatterShowErrorBars');
      const scatterShowGroupedReplicates=$('#scatterShowGroupedReplicates');
      const scatterShowGroupedReplicatesRow=$('#scatterShowGroupedReplicatesRow');
      const scatterErrorBarWidth=$('#scatterErrorBarWidth');
      const scatterColorMode=$('#scatterColorMode');
      const scatterDensityPalette=$('#scatterDensityPalette');
      const scatterDensityPaletteRow=$('#scatterDensityPaletteRow');
      const scatterColorModeRow=$('#scatterColorModeRow');
      if(scatterShowErrorBars){
        scatterShowErrorBars.checked = false;
        scatterShowErrorBars.defaultChecked = false;
      }
      if(scatterShowGroupedReplicates){
        scatterShowGroupedReplicates.checked = true;
        scatterShowGroupedReplicates.defaultChecked = true;
      }
      scatterGroupedModeDefaultApplied = !!scatterShowGroupedReplicates?.checked;
      let scatterColorModeApplied = 'solid';
      let scatterColorModeDesired = SCATTER_DENSITY_MODE_DEFAULT;
      const scatterShowCI = $('#scatterShowCI');
      const scatterShowPI = $('#scatterShowPI');
      const scatterStatsRegressionOptionsRow=getScatterNodeById('scatterGraphRegressionOptionsGrid')
        || (scatterShowLine)?.closest('.config-panel__line--checkboxes')
        || null;
      const isScatterDiagnosticsEnabled = () => true;
      const scatterAlphaVal=$('#scatterAlphaVal');
      const scatterFontSize=$('#scatterFontSize'), scatterFontSizeVal=$('#scatterFontSizeVal');
      if(scatterFontSize?.dataset){
        scatterFontSize.dataset.fontBasePt = String(scatterFontSize.value);
        console.debug('Debug: scatter font size base initialized',{ value: scatterFontSize.value }); // Debug: initial base
      }
      chartStyle.renderFontSizeLabel({ element: scatterFontSizeVal, pt: Number(scatterFontSize.value), input: scatterFontSize, manual: true });
      if(scatterColorMode){
        const normalizedMode = normalizeScatterColorMode(scatterColorMode.value);
        scatterColorMode.value = normalizedMode;
        scatterColorModeDesired = normalizedMode;
      }
      if(scatterDensityPalette){
        const paletteKey = normalizeScatterDensityPalette(scatterDensityPalette.value);
        scatterDensityPalette.value = paletteKey;
      }
      const scatterShowGrid=$('#scatterShowGrid'), scatterShowFrame=$('#scatterShowFrame'), scatterLogX=$('#scatterLogX'), scatterLogY=$('#scatterLogY');
      const scatterXMin=$('#scatterXMin'), scatterXMax=$('#scatterXMax'), scatterYMin=$('#scatterYMin'), scatterYMax=$('#scatterYMax');
      const scatterOriginMode=$('#scatterOriginMode'), scatterOriginX=$('#scatterOriginX'), scatterOriginY=$('#scatterOriginY');
      const scatterStatType=$('#scatterStatType');
      const scatterRegressionMode=$('#scatterRegressionMode');
      const scatterFitMethod=$('#scatterFitMethod');
      const scatterFitRangeMinX=$('#scatterFitRangeMinX');
      const scatterFitRangeMaxX=$('#scatterFitRangeMaxX');
      const scatterConfidenceLevel=$('#scatterConfidenceLevel');
      const scatterInitialValuesJson=$('#scatterInitialValuesJson');
      const scatterParameterConstraintsJson=$('#scatterParameterConstraintsJson');
      const scatterFitSpecBadge=$('#scatterFitSpecBadge');
      const scatterFitSpecStatus=$('#scatterFitSpecStatus');
      const scatterInitialValuesJsonError=$('#scatterInitialValuesJsonError');
      const scatterParameterConstraintsJsonError=$('#scatterParameterConstraintsJsonError');
      function ensureScatterGlobalFitControls(){
        const existingTextarea = getScatterNodeById('scatterGlobalFitJson');
        const existingError = getScatterNodeById('scatterGlobalFitJsonError');
        if(existingTextarea || existingError){
          return { textarea: existingTextarea, error: existingError };
        }
        const fitBody = queryScatterRoot('#scatterFitSpecControls .fit-specification-body');
        if(!fitBody){
          return { textarea: null, error: null };
        }
        const line = document.createElement('div');
        line.className = 'config-panel__line fit-textarea-line';
        const label = document.createElement('span');
        label.className = 'config-panel__label';
        label.textContent = 'Grouped global-fit JSON';
        const textarea = document.createElement('textarea');
        textarea.id = 'scatterGlobalFitJson';
        textarea.rows = 2;
        textarea.className = 'fit-textarea';
        textarea.placeholder = '{"enabled":true,"sharedParameters":["Top","Bottom"],"compareCommonCurve":true}';
        line.appendChild(label);
        line.appendChild(textarea);
        const error = document.createElement('div');
        error.id = 'scatterGlobalFitJsonError';
        error.className = 'fit-spec-status fit-spec-status--inline';
        error.setAttribute('aria-live', 'polite');
        const constraintsError = getScatterNodeById('scatterParameterConstraintsJsonError');
        if(constraintsError && constraintsError.parentNode === fitBody){
          fitBody.insertBefore(line, constraintsError.nextSibling);
          fitBody.insertBefore(error, line.nextSibling);
        }else{
          fitBody.appendChild(line);
          fitBody.appendChild(error);
        }
        return { textarea, error };
      }
      const scatterGlobalFitControls = ensureScatterGlobalFitControls();
      const scatterGlobalFitJson = scatterGlobalFitControls?.textarea || $('#scatterGlobalFitJson');
      const scatterGlobalFitJsonError = scatterGlobalFitControls?.error || $('#scatterGlobalFitJsonError');
      const scatterViewMode=$('#scatterViewMode');
      const scatterViewControls=$('#scatterViewControls');
      scatterViewModeInput = scatterViewMode;
      const scatterStatsResults=getScatterNodeById('scatterStatsResults');
      const scatterStatsButton=getScatterNodeById('scatterComputeStats');
      const scatterStatsStatus=getScatterNodeById('scatterStatsStatus');
      const scatterStatsPlaceholder='Statistics will appear after calculation.';
      function ensureScatterStatsReportHost(){
        const reporting = Shared.statsReporting;
        if(!scatterStatsResults || !reporting || typeof reporting.ensureReportHost !== 'function'){
          return scatterStatsResults?.__statsReportHost || null;
        }
        return reporting.ensureReportHost(scatterStatsResults, {
          id: 'scatterStatsReportHost',
          className: 'stats-report-host',
          attachToTarget: true,
          position: 'last'
        });
      }
      function clearScatterStatsReportHost(){
        const reporting = Shared.statsReporting;
        if(reporting && typeof reporting.clearReportHost === 'function'){
          reporting.clearReportHost(scatterStatsResults);
        }
      }
      ensureScatterStatsReportHost();

      function ensureScatterSelectOption(selectEl, value, label, options = {}){
        if(!selectEl){
          return;
        }
        const existing = Array.from(selectEl.options || []).find(option => String(option.value) === String(value));
        if(existing){
          if(label && existing.textContent !== label){
            existing.textContent = label;
          }
          if(options.title){
            existing.title = options.title;
          }
          return;
        }
        const option = document.createElement('option');
        option.value = value;
        option.textContent = label;
        if(options.title){
          option.title = options.title;
        }
        selectEl.appendChild(option);
      }

      function ensureScatterStatsSelectOptions(){
        ensureScatterSelectOption(scatterRegressionMode, 'deming', 'Deming regression');
        ensureScatterSelectOption(scatterRegressionMode, 'orthogonal', 'Orthogonal regression');
        ensureScatterSelectOption(scatterRegressionMode, 'lowess', 'LOWESS smoothing');
        ensureScatterSelectOption(scatterFitMethod, 'wls_y2', getScatterFitMethodLabel('wls_y2'));
        ensureScatterSelectOption(scatterFitMethod, 'wls_y', getScatterFitMethodLabel('wls_y'));
        ensureScatterSelectOption(scatterFitMethod, 'wls_x2', getScatterFitMethodLabel('wls_x2'));
        ensureScatterSelectOption(scatterFitMethod, 'wls_x', getScatterFitMethodLabel('wls_x'));
      }

      function getScatterReplicateMode(){
        return normalizeScatterTableFormat(scatterTableFormatSelect?.value || scatterTableFormat);
      }

      function isGroupedScatterModeActive(){
        return isScatterGroupedMode({
          graphType: scatterCurrentGraphType,
          tableFormat: getScatterReplicateMode()
        });
      }

      function updateScatterGroupedControlsVisibility(mode){
        const groupedActive = mode === SCATTER_TABLE_FORMAT_GROUPED && scatterCurrentGraphType === 'scatter';
        if(scatterGroupedControls){
          scatterGroupedControls.style.display = groupedActive ? '' : 'none';
          scatterGroupedControls.setAttribute('aria-hidden', groupedActive ? 'false' : 'true');
        }
        if(scatterGroupedControlsExtra){
          scatterGroupedControlsExtra.style.display = groupedActive ? '' : 'none';
          scatterGroupedControlsExtra.setAttribute('aria-hidden', groupedActive ? 'false' : 'true');
        }
      }

      function buildScatterAgColHeaders(hotInstance, options = {}){
        const hot = hotInstance || scatterHot || scatterRefs.hot;
        const colCount = hot && typeof hot.countCols === 'function'
          ? hot.countCols()
          : SCATTER_SINGLE_FIXED_COLS;
        if(typeof Shared.hot?.buildExcelColHeaders === 'function'){
          return Shared.hot.buildExcelColHeaders(Math.max(colCount, SCATTER_SINGLE_FIXED_COLS));
        }
        const headers = new Array(Math.max(colCount, SCATTER_SINGLE_FIXED_COLS)).fill('');
        for(let col = 0; col < headers.length; col += 1){
          let n = col;
          let label = '';
          while(n >= 0){
            label = String.fromCharCode((n % 26) + 65) + label;
            n = Math.floor(n / 26) - 1;
          }
          headers[col] = label || 'A';
        }
        return headers;
      }

      function buildScatterGroupedColumnDragGroups(hotInstance, options = {}){
        const hot = hotInstance || scatterHot || scatterRefs.hot;
        const colCount = hot && typeof hot.countCols === 'function'
          ? hot.countCols()
          : SCATTER_SINGLE_FIXED_COLS;
        const groupedActive = options.forceGrouped === true
          ? true
          : isScatterGroupedMode({
              graphType: options.graphType || scatterCurrentGraphType,
              tableFormat: options.tableFormat || getScatterReplicateMode()
            });
        if(!groupedActive || colCount <= 0){
          return null;
        }
        const replicates = clampScatterReplicateCount(options.replicates ?? scatterReplicates);
        const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
        const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
        const baseCols = getScatterGroupedBaseCols(replicates, { xReplicatesEnabled });
        const groups = [];
        if(xReplicateCount > 1 && colCount > 1){
          groups.push({
            startCol: 1,
            span: Math.min(xReplicateCount, colCount - 1)
          });
        }
        if(replicates > 1 && colCount > baseCols){
          const seriesCount = Math.max(1, Math.ceil((colCount - baseCols) / Math.max(replicates, 1)));
          for(let seriesIndex = 0; seriesIndex < seriesCount; seriesIndex += 1){
            const startCol = getScatterGroupedSeriesStartCol(seriesIndex, replicates, { xReplicatesEnabled });
            if(startCol >= colCount){
              break;
            }
            groups.push({
              startCol,
              span: Math.min(replicates, colCount - startCol)
            });
          }
        }
        return groups.length ? groups : null;
      }

      function updateScatterNestedHeaders(hotInstance, options = {}){
        const hot = hotInstance || scatterHot || scatterRefs.hot;
        if(!hot || typeof hot.updateSettings !== 'function'){
          return;
        }
        const groupedActive = options.forceGrouped === true
          ? true
          : isScatterGroupedMode({
              graphType: options.graphType || scatterCurrentGraphType,
              tableFormat: options.tableFormat || getScatterReplicateMode()
            });
        const hotRoot = hot.rootElement
          || hot.__scatterHostContainer
          || scatterHotContainer
          || getScatterNodeById('scatterHot');
        if(hotRoot && hotRoot.classList){
          hotRoot.classList.toggle('scatter-grouped-header-merge', !!groupedActive);
        }
        const replicates = clampScatterReplicateCount(scatterReplicates);
        const xReplicatesEnabled = isScatterGroupedXReplicatesEnabled(options);
        const xReplicateCount = getScatterGroupedXReplicateCount(replicates, { xReplicatesEnabled });
        if(hotRoot?.style){
          if(groupedActive){
            hotRoot.style.setProperty('--scatter-group-span', String(replicates));
          }else{
            hotRoot.style.removeProperty('--scatter-group-span');
          }
        }
        if(!groupedActive){
          hot.updateSettings({
            nestedHeaders: false,
            colHeaders: buildScatterAgColHeaders(hot, options),
            columnDragGroups: null
          });
          return;
        }
        hot.updateSettings({
          nestedHeaders: false,
          colHeaders: buildScatterAgColHeaders(hot, options),
          columnDragGroups: buildScatterGroupedColumnDragGroups(hot, options)
        });
        scatterDebug('Debug: scatter grouped col headers restored', {
          replicates,
          xReplicateCount
        });
        return;
      }

      function updateScatterReplicateModeControls(modeOverride){
        const mode = normalizeScatterTableFormat(modeOverride || getScatterReplicateMode());
        updateScatterGroupedControlsVisibility(mode);
        const groupedActive = mode === SCATTER_TABLE_FORMAT_GROUPED && scatterCurrentGraphType === 'scatter';
        if(scatterReplicatesInput){
          scatterReplicatesInput.disabled = !groupedActive;
          scatterReplicatesInput.value = String(clampScatterReplicateCount(scatterReplicates));
        }
        if(scatterGroupedXReplicatesInput){
          scatterGroupedXReplicatesInput.disabled = !groupedActive || scatterReplicates <= SCATTER_MIN_REPLICATES;
          scatterGroupedXReplicatesInput.checked = !!scatterGroupedXReplicates;
        }
        syncScatterErrorBarControls(mode);
        syncScatterGroupedReplicatePointControls(mode);
      }

      function syncScatterErrorBarControls(modeOverride){
        const mode = normalizeScatterTableFormat(modeOverride || getScatterReplicateMode());
        const groupedActive = mode === SCATTER_TABLE_FORMAT_GROUPED && scatterCurrentGraphType === 'scatter';
        const errorBarsAvailable = groupedActive && scatterReplicates > 1;
        if(scatterShowErrorBars){
          scatterShowErrorBars.disabled = !errorBarsAvailable;
        }
        if(scatterErrorBarWidth){
          const enabled = errorBarsAvailable && !!scatterShowErrorBars?.checked;
          scatterErrorBarWidth.disabled = !enabled;
        }
        if(typeof syncScatterSymbolToolbarDotToggles === 'function'){
          syncScatterSymbolToolbarDotToggles();
        }
      }

      function syncScatterGroupedReplicatePointControls(modeOverride){
        const mode = normalizeScatterTableFormat(modeOverride || getScatterReplicateMode());
        const groupedActive = mode === SCATTER_TABLE_FORMAT_GROUPED && scatterCurrentGraphType === 'scatter';
        const allowGroupedReplicatePoints = groupedActive && !scatterGroupedXReplicates;
        if(scatterShowGroupedReplicatesRow){
          scatterShowGroupedReplicatesRow.style.display = allowGroupedReplicatePoints ? '' : 'none';
          scatterShowGroupedReplicatesRow.setAttribute('aria-hidden', allowGroupedReplicatePoints ? 'false' : 'true');
        }
        if(scatterShowGroupedReplicates){
          scatterShowGroupedReplicates.disabled = !allowGroupedReplicatePoints;
        }
        if(typeof syncScatterSymbolToolbarDotToggles === 'function'){
          syncScatterSymbolToolbarDotToggles();
        }
      }

      function applyScatterReplicateChange(newCount, options = {}){
        const targetReplicates = clampScatterReplicateCount(newCount);
        const sourceReplicates = clampScatterReplicateCount(options.sourceReplicates ?? scatterReplicates);
        const sourceFormat = normalizeScatterTableFormat(options.sourceFormat || getScatterReplicateMode());
        const sourceXReplicatesEnabled = normalizeScatterGroupedXReplicates(options.sourceXReplicatesEnabled ?? scatterGroupedXReplicates);
        const targetXReplicatesEnabled = normalizeScatterGroupedXReplicates(options.xReplicatesEnabled ?? scatterGroupedXReplicates);
        const hot = scatterHot || scatterRefs.hot;
        const matrix = Array.isArray(options.dataOverride)
          ? options.dataOverride
          : (hot?.getData?.() || []);
        const structure = buildScatterReplicateMatrix(matrix, sourceReplicates, targetReplicates, {
          sourceFormat,
          sourceXReplicatesEnabled,
          xReplicatesEnabled: targetXReplicatesEnabled,
          minSeriesCount: options.minSeriesCount,
          groupLabels: options.groupLabels
        });
        scatterGroupedXReplicates = targetXReplicatesEnabled;
        scatterReplicates = targetReplicates;
        if(scatterReplicates > SCATTER_MIN_REPLICATES){
          scatterLastGroupedReplicateCount = Math.min(
            SCATTER_MAX_REPLICATES,
            Math.max(2, scatterReplicates)
          );
        }
        if(scatterReplicatesInput){
          scatterReplicatesInput.value = String(scatterReplicates);
        }
        if(hot && typeof hot.loadData === 'function'){
          hot.loadData(structure.data);
          normalizeScatterGroupedHeaderRow(hot, { forceGrouped: true, source: 'scatter-grouped-header-normalize' });
          updateScatterNestedHeaders(hot, { forceGrouped: true });
          syncScatterActiveDataViewFromHot(hot, 'replicate-change');
        }
        updateScatterReplicateModeControls(SCATTER_TABLE_FORMAT_GROUPED);
        if(!options.skipDraw){
          scheduleDrawScatter();
        }
        scatterDebug('Debug: scatter replicate change applied', {
          sourceReplicates,
          targetReplicates,
          sourceXReplicatesEnabled,
          targetXReplicatesEnabled,
          seriesCount: structure.seriesCount
        });
        return structure;
      }

      function applyScatterTableFormatMode(requestedMode, options = {}){
        const previousMode = normalizeScatterTableFormat(scatterTableFormat);
        const previousXReplicatesEnabled = !!scatterGroupedXReplicates;
        const graphType = String(options.graphType || scatterCurrentGraphType || 'scatter').toLowerCase();
        let nextMode = normalizeScatterTableFormat(requestedMode);
        if(graphType !== 'scatter'){
          nextMode = SCATTER_TABLE_FORMAT_SINGLE;
        }
        scatterTableFormat = nextMode;
        if(scatterTableFormatSelect && scatterTableFormatSelect.value !== nextMode){
          scatterTableFormatSelect.value = nextMode;
        }
        const hot = scatterHot || scatterRefs.hot;
        if(nextMode === SCATTER_TABLE_FORMAT_GROUPED){
          const matrix = hot?.getData ? (hot.getData() || []) : [];
          const shouldResetGroups = isScatterMatrixEmpty(matrix);
          const targetReplicates = scatterReplicates > SCATTER_MIN_REPLICATES
            ? scatterReplicates
            : Math.max(2, clampScatterReplicateCount(scatterLastGroupedReplicateCount || SCATTER_DEFAULT_GROUPED_REPLICATES));
          applyScatterReplicateChange(targetReplicates, {
            sourceReplicates: previousMode === SCATTER_TABLE_FORMAT_GROUPED ? scatterReplicates : SCATTER_MIN_REPLICATES,
            sourceFormat: previousMode,
            sourceXReplicatesEnabled: previousMode === SCATTER_TABLE_FORMAT_GROUPED ? previousXReplicatesEnabled : false,
            xReplicatesEnabled: options.xReplicatesEnabled ?? scatterGroupedXReplicates,
            minSeriesCount: shouldResetGroups ? SCATTER_DEFAULT_GROUP_COUNT : undefined,
            skipDraw: true
          });
          if(scatterColorMode && normalizeScatterColorMode(scatterColorMode.value) === 'density'){
            scatterColorMode.value = 'solid';
            scatterColorModeDesired = 'solid';
          }
          scatterState.supports3d = false;
          scatterState.supportsBubble = false;
          applyScatterViewMode('2d', { allow3d: false, allowBubble: false, skipSchedule: true, forceUpdate: true, persistRequest: true });
        }else{
          if(previousMode === SCATTER_TABLE_FORMAT_GROUPED && hot){
            const groupedMatrix = hot.getData ? (hot.getData() || []) : [];
            const converted = buildScatterSingleMatrixFromGrouped(groupedMatrix, scatterReplicates, {
              groupLabels: scatterSeriesGroupLabels,
              xReplicatesEnabled: previousXReplicatesEnabled
            });
            scatterReplicates = SCATTER_MIN_REPLICATES;
            if(scatterReplicatesInput){
              scatterReplicatesInput.value = String(scatterReplicates);
            }
            hot.loadData(converted.data);
            hot.updateSettings({ nestedHeaders: false });
            ensureScatterHeaderTitles(hot, { graphType });
            syncScatterActiveDataViewFromHot(hot, 'table-format-single');
          }else if(hot){
            hot.updateSettings({ nestedHeaders: false });
          }
        }
        updateScatterReplicateModeControls(nextMode);
        updateScatterNestedHeaders(hot, { graphType, tableFormat: nextMode });
        syncScatterColorModeUI(scatterColorModeApplied);
        if(!options.skipDraw){
          scheduleDrawScatter();
        }
        scatterDebug('Debug: scatter table format applied', {
          previousMode,
          nextMode,
          replicates: scatterReplicates,
          graphType
        });
      }

      function persistTabState(reason){
        try{
          const sess = (window && window.Main && window.Main.session) ? window.Main.session : null;
          if(sess && typeof sess.persistActiveTabState === 'function'){
            sess.persistActiveTabState(undefined, { reason: reason || 'scatter-stats-change' });
          }
        }catch(e){
          console.debug('Debug: persistTabState failed', { err: e?.message || String(e) });
        }
      }

      function setScatterStatsStatus(message){
        if(scatterStatsStatus){
          scatterStatsStatus.textContent = message || '';
        }
      }

      function clearScatterStatsOutputs(message = scatterStatsPlaceholder){
        if(!scatterStatsResults){
          return;
        }
        clearScatterStatsReportHost();
        scatterStatsResults.innerHTML='';
        if(message){
          const note=document.createElement('div');
          note.className='stats-placeholder';
          note.textContent=message;
          scatterStatsResults.appendChild(note);
        }
      }

      function updateScatterStatsButtonState(config){
        if(!scatterStatsButton){
          return;
        }
        if(config && Object.prototype.hasOwnProperty.call(config,'disabled')){
          scatterStatsButton.disabled=!!config.disabled;
        }
        if(config && typeof config.label==='string' && config.label){
          scatterStatsButton.textContent=config.label;
        }
      }

      function resolveScatterSelectDefaultValue(select, fallback){
        if(!select){
          return fallback;
        }
        const options = Array.from(select.options || []);
        const defaultOption = options.find(option => option.defaultSelected);
        if(defaultOption){
          return String(defaultOption.value);
        }
        const fromAttribute = select.getAttribute && select.getAttribute('value')
          ? String(select.getAttribute('value'))
          : '';
        if(fromAttribute && options.some(option => String(option.value) === fromAttribute)){
          return fromAttribute;
        }
        if(options.length){
          return String(options[0].value);
        }
        return fallback;
      }

      function resetScatterStatsRuntimeState(options = {}){
        const placeholder = Object.prototype.hasOwnProperty.call(options, 'placeholder')
          ? options.placeholder
          : scatterStatsPlaceholder;
        scatterState.statsContext = null;
        scatterState.statsContextSignature = null;
        scatterState.statsContextVersion = 0;
        scatterState.statsLastRunVersion = 0;
        scatterState.statsComputationPending = false;
        scatterState.statsRestorePending = null;
        clearScatterStatsOutputs(placeholder);
        setScatterStatsStatus('');
        updateScatterStatsButtonState({ disabled:true, label:'Calculate statistics' });
        syncScatterRegressionOptionVisibility();
      }

      function scatterHasComputedStats(){
        const context = scatterState.statsContext;
        if(!context || context.graphType!=='scatter'){
          return false;
        }
        if(!context.precomputedStats){
          return false;
        }
        if(scatterState.statsComputationPending){
          return false;
        }
        return scatterState.statsContextVersion>0
          && scatterState.statsLastRunVersion===scatterState.statsContextVersion;
      }

      function scatterStatsPanelHasRenderedResults(){
        if(!scatterStatsResults || typeof scatterStatsResults.querySelector !== 'function'){
          return false;
        }
        return !!scatterStatsResults.querySelector('.stats-table-card, .stats-report-panel, table');
      }

      function buildScatterStatsRenderSettings(){
        const methodSelection = scatterStatType?.value || 'auto';
        const regressionModeValue = scatterRegressionMode ? (scatterRegressionMode.value || 'linear') : 'linear';
        const resolvedAssociationMethod = resolveScatterAssociationMethod(methodSelection, regressionModeValue);
        const fitMethodValue = scatterFitMethod ? (scatterFitMethod.value || 'ols') : 'ols';
        const fitSpec = buildScatterFitSpec();
        const showLineMaster = !!(scatterShowLine && scatterShowLine.checked);
        const showCI = !!(showLineMaster && scatterShowCI && scatterShowCI.checked);
        const showPI = !!(showLineMaster && scatterShowPI && scatterShowPI.checked);
        const showDiagnostics = isScatterDiagnosticsEnabled();
        const controlSignature = getScatterStatsControlSignature();
        return {
          regressionModeValue,
          fitMethodValue,
          fitSpec,
          showLineMaster,
          showCI,
          showPI,
          showDiagnostics,
          controlSignature,
          associationSelection: methodSelection,
          associationMethod: resolvedAssociationMethod
        };
      }

      function restoreScatterStatsPanelFromContext(context, reason){
        if(!context || !scatterStatsResults){
          return false;
        }
        if(context.graphType === 'scatter'){
          if(!context.precomputedStats){
            return false;
          }
          const settings = buildScatterStatsRenderSettings();
          applyScatterStatsResults(context, context.precomputedStats, settings);
          scatterDebug('Debug: scatter stats panel restored from context', {
            reason: reason || 'context-restore',
            signature: scatterState.statsContextSignature || null,
            grouped: !!context.precomputedStats?.grouped
          });
          return true;
        }
        renderScatterSignificanceSummary(context);
        scatterDebug('Debug: scatter significance panel restored from context', {
          reason: reason || 'context-restore',
          graphType: context.graphType
        });
        return true;
      }

      function syncScatterRegressionOptionVisibility(){
        if(!scatterStatsRegressionOptionsRow){
          return;
        }
        const shouldShow=true;
        scatterStatsRegressionOptionsRow.hidden=!shouldShow;
        scatterStatsRegressionOptionsRow.style.display=shouldShow?'':'none';
        scatterStatsRegressionOptionsRow.setAttribute('aria-hidden', shouldShow ? 'false' : 'true');
        const regressionModeValue = scatterRegressionMode?.value || 'linear';
        const policy = resolveScatterRegressionPolicy(regressionModeValue);
        const allowedFitMethods = Array.isArray(policy?.fitMethods) && policy.fitMethods.length
          ? policy.fitMethods.slice()
          : ['ols'];
        const allowedFitSet = new Set(allowedFitMethods.map(normalizeScatterFitMethod));
        let fitValueChanged = false;
        if(scatterFitMethod){
          const currentValue = normalizeScatterFitMethod(scatterFitMethod.value || 'ols');
          const options = Array.from(scatterFitMethod.options || []);
          options.forEach(option => {
            const optionValue = normalizeScatterFitMethod(option.value);
            option.disabled = !allowedFitSet.has(optionValue);
          });
          const fitSelectDisabled = scatterCurrentGraphType !== 'scatter' || allowedFitSet.size <= 1;
          scatterFitMethod.disabled = fitSelectDisabled;
          const preferredFitValue = allowedFitSet.has(currentValue)
            ? currentValue
            : normalizeScatterFitMethod(allowedFitMethods[0] || 'ols');
          if(scatterFitMethod.value !== preferredFitValue){
            scatterFitMethod.value = preferredFitValue;
            fitValueChanged = true;
          }
          scatterFitMethod.title = policy?.fitGuidance || '';
        }
        if(scatterStatType){
          const normalizedSelection = normalizeScatterAssociationSelection(scatterStatType.value);
          if(normalizedSelection !== scatterStatType.value){
            scatterStatType.value = normalizedSelection;
          }
          const autoOption = Array.from(scatterStatType.options || [])
            .find(option => normalizeScatterAssociationSelection(option.value) === 'auto');
          if(autoOption){
            const recommended = getScatterAssociationMethodLabel(policy?.autoAssociation || 'pearson');
            autoOption.textContent = `Automatic (recommended: ${recommended})`;
          }
          scatterStatType.title = 'Association summary is optional and does not change the fitted regression model.';
        }
        if(fitValueChanged && typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
          console.debug('Debug: scatter fit method adjusted for regression mode', {
            regressionMode: regressionModeValue,
            fitMethod: scatterFitMethod?.value || null,
            allowedFitMethods
          });
        }
      }

      function summarizeScatterPoints(points){
        const summary={ count:0, sumX:0, sumY:0, sumXX:0, sumYY:0, sumXY:0 };
        if(!Array.isArray(points) || !points.length){
          return summary;
        }
        for(let i=0;i<points.length;i+=1){
          const x=Number(points[i]?.x) || 0;
          const y=Number(points[i]?.y) || 0;
          summary.count+=1;
          summary.sumX+=x;
          summary.sumY+=y;
          summary.sumXX+=x*x;
          summary.sumYY+=y*y;
          summary.sumXY+=x*y;
        }
        return summary;
      }

      function collectScatterStatPairs(points){
        return collectScatterStatPairsCore(points, { preservePointFields: true });
      }

      function formatScatterSignatureNumber(value){
        return Number.isFinite(value)?value.toFixed(4):'NaN';
      }

      function getScatterStatsControlSignature(){
        return [
          scatterStatType?.value || 'auto',
          scatterRegressionMode?.value || 'linear',
          scatterFitMethod?.value || 'ols',
          scatterFitRangeMinX?.value || '',
          scatterFitRangeMaxX?.value || '',
          scatterConfidenceLevel?.value || '95',
          scatterInitialValuesJson?.value || '',
          scatterParameterConstraintsJson?.value || '',
          scatterGlobalFitJson?.value || ''
        ].join('|');
      }

      function parseScatterJsonWithError(rawValue){
        const raw = typeof rawValue === 'string' ? rawValue.trim() : '';
        if(!raw){
          return { value: null, error: null, empty: true };
        }
        try{
          return { value: JSON.parse(raw), error: null, empty: false };
        }catch(err){
          return {
            value: null,
            error: err?.message || 'Invalid JSON.',
            empty: false
          };
        }
      }

      function cloneScatterJsonValue(value){
        if(!value || typeof value !== 'object'){
          return {};
        }
        try{
          return JSON.parse(JSON.stringify(value));
        }catch(err){
          console.debug('Debug: scatter JSON clone fallback', { message: err?.message || String(err) });
          return Object.assign({}, value);
        }
      }

      function stripScatterGlobalFitSpec(fitSpec){
        const cloned = cloneScatterJsonValue(fitSpec || {});
        if(cloned && typeof cloned === 'object'){
          delete cloned.globalFit;
        }
        return cloned;
      }

      function collectScatterSharedParametersFromConstraints(parameters){
        if(!parameters || typeof parameters !== 'object'){
          return [];
        }
        return Object.entries(parameters)
          .filter(([, rule]) => {
            if(!rule || typeof rule !== 'object'){
              return false;
            }
            const sharedValue = rule.shared ?? rule.share ?? rule.global ?? null;
            if(typeof sharedValue === 'boolean'){
              return sharedValue;
            }
            const normalized = String(sharedValue || '').trim().toLowerCase();
            return normalized === 'true' || normalized === 'shared' || normalized === 'global' || normalized === 'yes';
          })
          .map(([name]) => String(name || '').trim())
          .filter(Boolean);
      }

      function normalizeScatterGlobalFitSpec(rawValue, fallbackParameters){
        const fallbackShared = collectScatterSharedParametersFromConstraints(fallbackParameters);
        const raw = rawValue && typeof rawValue === 'object' ? rawValue : null;
        if(!raw && !fallbackShared.length){
          return { value: null, error: null };
        }
        if(rawValue != null && (!raw || Array.isArray(raw))){
          return { value: null, error: 'Grouped global-fit JSON must be an object.' };
        }
        const rawShared = raw?.sharedParameters ?? raw?.shared ?? raw?.parameters ?? fallbackShared;
        const normalizeNames = input => {
          if(Array.isArray(input)){
            return input.map(item => String(item || '').trim()).filter(Boolean);
          }
          if(typeof input === 'string'){
            const trimmed = input.trim();
            if(!trimmed){
              return [];
            }
            if(trimmed === '*' || /^all$/i.test(trimmed)){
              return ['__all__'];
            }
            return trimmed.split(',').map(item => item.trim()).filter(Boolean);
          }
          return [];
        };
        const sharedParameters = Array.from(new Set(normalizeNames(rawShared))).filter(Boolean);
        const enabled = raw
          ? (typeof raw.enabled === 'boolean'
            ? raw.enabled
            : (sharedParameters.length > 0))
          : (sharedParameters.length > 0);
        const compareCommonCurve = raw && Object.prototype.hasOwnProperty.call(raw, 'compareCommonCurve')
          ? !!raw.compareCommonCurve
          : true;
        const useSharedFitForRendering = raw && Object.prototype.hasOwnProperty.call(raw, 'useSharedFitForRendering')
          ? !!raw.useSharedFitForRendering
          : true;
        const maxIterationsRaw = Number(raw?.maxIterations);
        const toleranceRaw = Number(raw?.tolerance);
        const maxIterations = Number.isFinite(maxIterationsRaw) ? Math.max(20, Math.min(300, Math.round(maxIterationsRaw))) : 80;
        const tolerance = Number.isFinite(toleranceRaw) ? Math.max(1e-9, Math.min(1, toleranceRaw)) : 1e-6;
        return {
          value: {
            enabled,
            sharedParameters,
            compareCommonCurve,
            useSharedFitForRendering,
            maxIterations,
            tolerance
          },
          error: null
        };
      }

      function parseScatterOptionalNumberInput(value){
        const raw = value == null ? '' : String(value).trim();
        if(raw === ''){
          return NaN;
        }
        const parsed = Number(raw);
        return Number.isFinite(parsed) ? parsed : NaN;
      }

      function clearScatterFitRangeInputs(reason){
        let changed = false;
        if(scatterFitRangeMinX && String(scatterFitRangeMinX.value || '').trim() !== ''){
          scatterFitRangeMinX.value = '';
          changed = true;
        }
        if(scatterFitRangeMaxX && String(scatterFitRangeMaxX.value || '').trim() !== ''){
          scatterFitRangeMaxX.value = '';
          changed = true;
        }
        if(changed){
          validateScatterFitSpecControls();
          if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
            console.debug('Debug: scatter fit range inputs cleared', { reason: reason || null });
          }
        }
        return changed;
      }

      function setScatterFitSpecMessage(target, message, state){
        if(!target){
          return;
        }
        target.textContent = message || '';
        if(state){
          target.dataset.state = state;
        }else{
          target.removeAttribute('data-state');
        }
      }

      function validateScatterFitSpecControls(){
        const minX = parseScatterOptionalNumberInput(scatterFitRangeMinX?.value);
        const maxX = parseScatterOptionalNumberInput(scatterFitRangeMaxX?.value);
        const hasMin = Number.isFinite(minX);
        const hasMax = Number.isFinite(maxX);
        const confidence = parseScatterOptionalNumberInput(scatterConfidenceLevel?.value);
        const initialParse = parseScatterJsonWithError(scatterInitialValuesJson?.value);
        const constraintParse = parseScatterJsonWithError(scatterParameterConstraintsJson?.value);
        const globalParse = parseScatterJsonWithError(scatterGlobalFitJson?.value);
        const normalizedGlobal = normalizeScatterGlobalFitSpec(globalParse.error ? null : globalParse.value, constraintParse.error ? null : constraintParse.value);
        const issues = [];
        if(hasMin && hasMax && minX > maxX){
          issues.push('Fit range min X cannot exceed max X.');
        }
        if(hasMin && hasMax && minX === maxX){
          issues.push('Fit range min X and max X cannot be equal.');
        }
        if(Number.isFinite(confidence) && (confidence < 1 || confidence >= 100)){
          issues.push('Confidence level must be between 1 and 99.9.');
        }
        if(initialParse.error){
          issues.push(`Initial values JSON: ${initialParse.error}`);
        }
        if(constraintParse.error){
          issues.push(`Parameter constraints JSON: ${constraintParse.error}`);
        }
        if(globalParse.error){
          issues.push(`Grouped global-fit JSON: ${globalParse.error}`);
        }else if(normalizedGlobal.error){
          issues.push(`Grouped global-fit JSON: ${normalizedGlobal.error}`);
        }
        if(initialParse.error){
          setScatterFitSpecMessage(scatterInitialValuesJsonError, `Invalid JSON: ${initialParse.error}`, 'invalid');
        }else if(!initialParse.empty){
          setScatterFitSpecMessage(scatterInitialValuesJsonError, 'Initial values JSON is valid.', 'valid');
        }else{
          setScatterFitSpecMessage(scatterInitialValuesJsonError, '', null);
        }
        if(constraintParse.error){
          setScatterFitSpecMessage(scatterParameterConstraintsJsonError, `Invalid JSON: ${constraintParse.error}`, 'invalid');
        }else if(!constraintParse.empty){
          setScatterFitSpecMessage(scatterParameterConstraintsJsonError, 'Parameter constraints JSON is valid.', 'valid');
        }else{
          setScatterFitSpecMessage(scatterParameterConstraintsJsonError, '', null);
        }
        if(globalParse.error || normalizedGlobal.error){
          setScatterFitSpecMessage(scatterGlobalFitJsonError, `Invalid JSON: ${globalParse.error || normalizedGlobal.error}`, 'invalid');
        }else if(!globalParse.empty || Array.isArray(normalizedGlobal.value?.sharedParameters) && normalizedGlobal.value.sharedParameters.length){
          setScatterFitSpecMessage(scatterGlobalFitJsonError, 'Grouped global-fit JSON is valid.', 'valid');
        }else{
          setScatterFitSpecMessage(scatterGlobalFitJsonError, '', null);
        }
        if(issues.length){
          setScatterFitSpecMessage(scatterFitSpecStatus, issues[0], 'invalid');
          if(scatterFitSpecBadge){
            scatterFitSpecBadge.textContent = 'Invalid';
            scatterFitSpecBadge.dataset.state = 'invalid';
          }
          return false;
        }
        const hasGlobal = !globalParse.empty || Array.isArray(normalizedGlobal.value?.sharedParameters) && normalizedGlobal.value.sharedParameters.length;
        const hint = (!initialParse.empty || !constraintParse.empty || hasMin || hasMax || hasGlobal)
          ? 'Fit specification is valid.'
          : 'Using default fit specification.';
        setScatterFitSpecMessage(scatterFitSpecStatus, hint, 'valid');
        if(scatterFitSpecBadge){
          scatterFitSpecBadge.textContent = 'Valid';
          scatterFitSpecBadge.dataset.state = 'valid';
        }
        return true;
      }

      function buildScatterFitSpec(){
        const minX = parseScatterOptionalNumberInput(scatterFitRangeMinX?.value);
        const maxX = parseScatterOptionalNumberInput(scatterFitRangeMaxX?.value);
        const confidenceLevel = parseScatterOptionalNumberInput(scatterConfidenceLevel?.value);
        const hasRange = Number.isFinite(minX) || Number.isFinite(maxX);
        const initialParsed = parseScatterJsonWithError(scatterInitialValuesJson?.value);
        const constraintsParsed = parseScatterJsonWithError(scatterParameterConstraintsJson?.value);
        const globalParsed = parseScatterJsonWithError(scatterGlobalFitJson?.value);
        const initialValues = initialParsed.error ? null : initialParsed.value;
        const parameters = constraintsParsed.error ? null : constraintsParsed.value;
        const normalizedGlobal = normalizeScatterGlobalFitSpec(globalParsed.error ? null : globalParsed.value, parameters);
        const fitSpec = {};
        if(hasRange){
          fitSpec.range = {
            minX: Number.isFinite(minX) ? minX : null,
            maxX: Number.isFinite(maxX) ? maxX : null
          };
        }
        if(Number.isFinite(confidenceLevel)){
          fitSpec.confidenceLevel = Math.max(1, Math.min(99.9, confidenceLevel));
        }
        if(initialValues && typeof initialValues === 'object'){
          fitSpec.initialValues = initialValues;
        }
        if(parameters && typeof parameters === 'object'){
          fitSpec.parameters = parameters;
        }
        if(normalizedGlobal.value){
          fitSpec.globalFit = normalizedGlobal.value;
        }
        return fitSpec;
      }

      function applyScatterFitSpecControls(spec){
        const fitSpec = spec && typeof spec === 'object' ? spec : {};
        let minX = parseScatterOptionalNumberInput(fitSpec?.range?.minX);
        let maxX = parseScatterOptionalNumberInput(fitSpec?.range?.maxX);
        const looksLegacyZeroRange = Number.isFinite(minX)
          && Number.isFinite(maxX)
          && minX === 0
          && maxX === 0;
        if(looksLegacyZeroRange){
          minX = NaN;
          maxX = NaN;
          if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
            console.debug('Debug: scatter fit range legacy zero-range cleared', { fitSpecRange: fitSpec?.range || null });
          }
        }
        if(scatterFitRangeMinX){
          scatterFitRangeMinX.value = Number.isFinite(minX) ? String(minX) : '';
        }
        if(scatterFitRangeMaxX){
          scatterFitRangeMaxX.value = Number.isFinite(maxX) ? String(maxX) : '';
        }
        if(scatterConfidenceLevel){
          const confidence = parseScatterOptionalNumberInput(fitSpec?.confidenceLevel);
          scatterConfidenceLevel.value = Number.isFinite(confidence) ? String(confidence) : '95';
        }
        if(scatterInitialValuesJson){
          const initial = fitSpec?.initialValues;
          scatterInitialValuesJson.value = (initial && typeof initial === 'object')
            ? JSON.stringify(initial)
            : '';
        }
        if(scatterParameterConstraintsJson){
          const constraints = fitSpec?.parameters;
          scatterParameterConstraintsJson.value = (constraints && typeof constraints === 'object')
            ? JSON.stringify(constraints)
            : '';
        }
        if(scatterGlobalFitJson){
          const globalFit = fitSpec?.globalFit;
          scatterGlobalFitJson.value = (globalFit && typeof globalFit === 'object')
            ? JSON.stringify(globalFit)
            : '';
        }
        validateScatterFitSpecControls();
      }

      const SCATTER_STATS_CACHE_LIMIT = 24;

      function resolveScatterStatsCacheTabId(context){
        const raw = context?.tabId
          || scatterState.statsContext?.tabId
          || resolveScatterTabId(scatterHot)
          || Shared.hot?.resolveActiveTabId?.()
          || null;
        if(raw == null){
          return null;
        }
        const text = String(raw).trim();
        return text || null;
      }

      function buildScatterStatsCacheKey(signature, context){
        if(!signature){
          return null;
        }
        const tabId = resolveScatterStatsCacheTabId(context);
        if(!tabId){
          return null;
        }
        return `${tabId}::${signature}`;
      }

      function readScatterStatsCache(signature, context){
        if(!(scatterState.statsCacheBySignature instanceof Map)){
          return null;
        }
        const cacheKey = buildScatterStatsCacheKey(signature, context);
        if(!cacheKey){
          return null;
        }
        const cached = scatterState.statsCacheBySignature.get(cacheKey);
        if(!cached || !cached.stats){
          return null;
        }
        return cached;
      }

      function writeScatterStatsCache(signature, stats, controlSignature, context){
        if(!signature || !stats){
          return;
        }
        if(!(scatterState.statsCacheBySignature instanceof Map)){
          scatterState.statsCacheBySignature = new Map();
        }
        const cacheMap = scatterState.statsCacheBySignature;
        const cacheKey = buildScatterStatsCacheKey(signature, context);
        if(!cacheKey){
          scatterDebug('Debug: scatter stats cache skipped', { reason: 'missing-tab-id', signature });
          return;
        }
        if(cacheMap.has(cacheKey)){
          cacheMap.delete(cacheKey);
        }
        cacheMap.set(cacheKey, {
          stats,
          controlSignature: controlSignature || null,
          tabId: resolveScatterStatsCacheTabId(context),
          savedAt: Date.now()
        });
        while(cacheMap.size > SCATTER_STATS_CACHE_LIMIT){
          const oldestKey = cacheMap.keys().next().value;
          if(oldestKey == null){
            break;
          }
          cacheMap.delete(oldestKey);
        }
      }

      function cloneScatterStatsForPayload(stats){
        if(!stats || typeof stats !== 'object'){
          return null;
        }
        try{
          return JSON.parse(JSON.stringify(stats));
        }catch(err){
          scatterDebug('Debug: scatter stats payload clone skipped', { err: err?.message || String(err) });
          return null;
        }
      }

      function getScatterPersistedStatsSnapshot(){
        const context = scatterState.statsContext;
        let stats = context?.precomputedStats || null;
        let controlSignature = context?.precomputedSignature || null;
        if(!stats && scatterState.statsContextSignature){
          const cached = readScatterStatsCache(scatterState.statsContextSignature, context);
          if(cached?.stats){
            stats = cached.stats;
            controlSignature = cached.controlSignature || controlSignature;
          }
        }
        return {
          precomputedStats: cloneScatterStatsForPayload(stats),
          precomputedSignature: controlSignature || null
        };
      }

      function buildScatterGroupedSignatureSeed(seriesList){
        const series = Array.isArray(seriesList) ? seriesList : [];
        if(!series.length){
          return '';
        }
        const parts = series
          .map((entry, index) => {
            const label = (entry?.label != null && String(entry.label).trim() !== '')
              ? String(entry.label).trim()
              : `Series ${index + 1}`;
            const summary = summarizeScatterPoints(entry?.points);
            return [
              label,
              summary.count,
              formatScatterSignatureNumber(summary.sumX),
              formatScatterSignatureNumber(summary.sumY),
              formatScatterSignatureNumber(summary.sumXX),
              formatScatterSignatureNumber(summary.sumYY),
              formatScatterSignatureNumber(summary.sumXY)
            ].join('|');
          })
          .sort();
        return `grouped:${parts.join('||')}`;
      }

      function buildScatterStatsSignature(context){
        if(!context){
          return 'empty';
        }
        let pointsKey='none';
        if(typeof context.signatureSeed==='string'){
          pointsKey=context.signatureSeed;
        }else{
          const summary=context.pointSummary || summarizeScatterPoints(context.points);
          pointsKey=[
            summary.count,
            formatScatterSignatureNumber(summary.sumX),
            formatScatterSignatureNumber(summary.sumY),
            formatScatterSignatureNumber(summary.sumXX),
            formatScatterSignatureNumber(summary.sumYY),
            formatScatterSignatureNumber(summary.sumXY)
          ].join('|');
        }
        const thresholdKey=context.thresholds
          ? [
              formatScatterSignatureNumber(context.thresholds.log2fc ?? 0),
              formatScatterSignatureNumber(context.thresholds.negLogP ?? 0),
              context.thresholds.negLabel || ''
            ].join('|')
          : 'threshold:none';
        const significanceKey=context.significance
          ? [
              context.significance.totalPoints ?? 'na',
              context.significance.significantCount ?? 'na',
              context.significance.nonSignificantCount ?? 'na',
              context.significance.missingP ?? 0
            ].join('|')
          : 'significance:none';
        const domainKey=context.domain
          ? [
              formatScatterSignatureNumber(context.domain.minX ?? NaN),
              formatScatterSignatureNumber(context.domain.maxX ?? NaN)
            ].join('|')
          : 'domain:none';
        const controlKey=getScatterStatsControlSignature();
        const graphKey=context.graphType || 'scatter';
        const groupedKey=Array.isArray(context.groupedSeries) && context.groupedSeries.length
          ? buildScatterGroupedSignatureSeed(context.groupedSeries)
          : 'grouped:none';
        return [graphKey,pointsKey,groupedKey,thresholdKey,significanceKey,domainKey,controlKey].join('::');
      }

      function resolveScatterCachedVisualStatsForContext(context){
        const signature = buildScatterStatsSignature(context);
        const cachedContext = scatterState.statsContext;
        const canReuseActiveContext = scatterHasComputedStats()
          && typeof scatterState.statsContextSignature === 'string'
          && scatterState.statsContextSignature === signature
          && !!cachedContext?.precomputedStats;
        if(canReuseActiveContext){
          return {
            signature,
            stats: cachedContext.precomputedStats,
            controlSignature: cachedContext.precomputedSignature || getScatterStatsControlSignature()
          };
        }
        const signatureCache = readScatterStatsCache(signature, context);
        if(signatureCache?.stats){
          return {
            signature,
            stats: signatureCache.stats,
            controlSignature: signatureCache.controlSignature || getScatterStatsControlSignature()
          };
        }
        return {
          signature,
          stats: null,
          controlSignature: getScatterStatsControlSignature()
        };
      }

      function collectScatterIntervalYBounds(stats, options = {}){
        const includeConfidence = !!options.includeConfidence;
        const includePrediction = !!options.includePrediction;
        if(!stats || (!includeConfidence && !includePrediction)){
          return null;
        }
        const groupedStats = Array.isArray(stats?.groupedSeriesStats) ? stats.groupedSeriesStats : [];
        const models = groupedStats.length
          ? groupedStats.map(entry => entry?.stats?.regression).filter(Boolean)
          : [stats?.regression].filter(Boolean);
        if(!models.length){
          return null;
        }
        const logX = !!options.logX;
        const logY = !!options.logY;
        const minX = Number.isFinite(options.minX) ? options.minX : null;
        const maxX = Number.isFinite(options.maxX) ? options.maxX : null;
        let minY = Infinity;
        let maxY = -Infinity;
        let modelCount = 0;
        let sampleCount = 0;
        const includeValue = value => {
          if(!Number.isFinite(value)){
            return false;
          }
          if(logY && value <= 0){
            return false;
          }
          if(value < minY){ minY = value; }
          if(value > maxY){ maxY = value; }
          sampleCount += 1;
          return true;
        };
        models.forEach(model => {
          const samples = Array.isArray(model?.intervals?.samples) ? model.intervals.samples : [];
          if(!samples.length){
            return;
          }
          modelCount += 1;
          samples.forEach(sample => {
            const xRaw = Number(sample?.x);
            if(!Number.isFinite(xRaw)){
              return;
            }
            if(logX && xRaw <= 0){
              return;
            }
            if(minX !== null && xRaw < minX){
              return;
            }
            if(maxX !== null && xRaw > maxX){
              return;
            }
            if(includeConfidence){
              includeValue(Number(sample?.ciLow));
              includeValue(Number(sample?.ciHigh));
            }
            if(includePrediction){
              includeValue(Number(sample?.piLow));
              includeValue(Number(sample?.piHigh));
            }
          });
        });
        if(!Number.isFinite(minY) || !Number.isFinite(maxY)){
          return null;
        }
        return { minY, maxY, modelCount, sampleCount };
      }

      function shouldUseScatterStatsWorker(points, regressionMode, fitMethod){
        const workerApi = Shared.Workers;
        if(!workerApi || typeof workerApi.isSupported !== 'function' || !workerApi.isSupported()){
          return false;
        }
        const mode = String(regressionMode || 'linear').toLowerCase();
        if(isScatterCustomRegressionMode(mode) || normalizeScatterFitMethod(fitMethod || 'ols') !== getScatterFitMethodFamily(fitMethod || 'ols')){
          return false;
        }
        const count = Array.isArray(points) ? points.length : 0;
        if(count >= SCATTER_STATS_WORKER.minPoints){
          return true;
        }
        const isComplex = mode && mode !== 'linear';
        return isComplex && count >= Math.max(300, Math.round(SCATTER_STATS_WORKER.minPoints * 0.5));
      }

      function runScatterStatsWorker(payload){
        const workerApi = Shared.Workers;
        if(!workerApi || typeof workerApi.runTask !== 'function'){
          return Promise.reject(new Error('Scatter stats worker unavailable'));
        }
        return workerApi.runTask({
          name: 'scatter-stats',
          url: SCATTER_STATS_WORKER.url,
          action: 'scatter-stats',
          payload,
          timeoutMs: SCATTER_STATS_WORKER.timeoutMs,
          fallback: (data) => computeScatterStats(data.points, data.method, {
            regressionMode: data.regressionMode,
            fitMethod: data.fitMethod || 'ols',
            fitSpec: data.fitSpec || {},
            domain: data.domain || null
          })
        });
      }

      function shouldUseScatterRenderWorker(pointCount, options){
        const workerApi = Shared.Workers;
        if(!workerApi || typeof workerApi.isSupported !== 'function' || !workerApi.isSupported()){
          return false;
        }
        const count = Number(pointCount) || 0;
        if(count < SCATTER_RENDER_WORKER.minPoints){
          return false;
        }
        const brokenX = !!options?.brokenX;
        const brokenY = !!options?.brokenY;
        if(brokenX || brokenY){
          return false;
        }
        return true;
      }

      function runScatterRenderWorker(payload){
        const workerApi = Shared.Workers;
        if(!workerApi || typeof workerApi.runTask !== 'function'){
          return Promise.reject(new Error('Scatter render worker unavailable'));
        }
        return workerApi.runTask({
          name: 'scatter-render',
          url: SCATTER_RENDER_WORKER.url,
          action: 'scatter-render',
          payload,
          timeoutMs: SCATTER_RENDER_WORKER.timeoutMs
        });
      }

      function primeScatterStatsContext(context,options={}){
        if(!context || (context.graphType==='scatter' && (!Array.isArray(context.points) || !context.points.length))){
          resetScatterStatsRuntimeState({ placeholder: options.placeholder || 'Add data to enable statistics.' });
          return;
        }
        const signature=buildScatterStatsSignature(context);
        const pendingRestore = scatterState.statsRestorePending;
        let autoComputeRestoredStats = false;
        let redrawRestoredStats = false;
        if(pendingRestore && context.graphType === 'scatter'){
          scatterState.statsRestorePending = null;
          if(pendingRestore.precomputedStats){
            const precomputedSignature = pendingRestore.precomputedSignature || getScatterStatsControlSignature();
            context = {
              ...context,
              precomputedStats: pendingRestore.precomputedStats,
              precomputedSignature
            };
            writeScatterStatsCache(signature, pendingRestore.precomputedStats, precomputedSignature, context);
            redrawRestoredStats = true;
            scatterDebug('Debug: scatter stats restored model adopted', {
              savedSignature: pendingRestore.contextSignature || null,
              currentSignature: signature
            });
          }else if(pendingRestore.autoCompute === true){
            autoComputeRestoredStats = true;
            scatterDebug('Debug: scatter stats restore scheduled recompute', {
              savedSignature: pendingRestore.contextSignature || null,
              currentSignature: signature
            });
          }
        }
        const changed=signature!==scatterState.statsContextSignature;
        const hasPrecomputed = context.graphType==='scatter' && !!context.precomputedStats;
        if(changed){
          scatterState.statsContextVersion=(scatterState.statsContextVersion||0)+1;
          scatterState.statsLastRunVersion=0;
        }else if(!scatterState.statsContextVersion){
          scatterState.statsContextVersion=1;
        }
        scatterState.statsContextSignature=signature;
        scatterState.statsContext={ ...context, version: scatterState.statsContextVersion };
        if(hasPrecomputed){
          scatterState.statsLastRunVersion = scatterState.statsContextVersion;
        }else if(!changed && context.graphType==='scatter' && !context.precomputedStats){
          scatterState.statsLastRunVersion=0;
        }
        if(changed){
          if(hasPrecomputed){
            restoreScatterStatsPanelFromContext(scatterState.statsContext, 'signature-change-precomputed');
            setScatterStatsStatus('Statistics up to date.');
            updateScatterStatsButtonState({ disabled:false, label:'Recalculate statistics' });
          }else{
            clearScatterStatsOutputs(options.placeholder || scatterStatsPlaceholder);
            setScatterStatsStatus('Statistics ready to calculate.');
            updateScatterStatsButtonState({ disabled:false, label:'Calculate statistics' });
          }
        }else if(scatterState.statsLastRunVersion===scatterState.statsContextVersion){
          if(hasPrecomputed && !scatterStatsPanelHasRenderedResults()){
            restoreScatterStatsPanelFromContext(scatterState.statsContext, 'panel-empty-precomputed');
          }
          setScatterStatsStatus('Statistics up to date.');
          updateScatterStatsButtonState({ disabled:false, label:'Recalculate statistics' });
        }else if(!scatterState.statsComputationPending){
          setScatterStatsStatus('Statistics ready to calculate.');
          updateScatterStatsButtonState({ disabled:false, label:'Calculate statistics' });
        }
        syncScatterRegressionOptionVisibility();
        if(autoComputeRestoredStats && !scatterState.statsComputationPending){
          handleScatterStatsComputeClick();
        }else if(redrawRestoredStats){
          scheduleScatterViewRefresh('scatter-stats-restore');
        }
      }

      function requestScatterStatsContextRefresh(reason){
        const ctx=scatterState.statsContext;
        if(!ctx){
          resetScatterStatsRuntimeState({ placeholder: scatterStatsPlaceholder });
          console.debug('Debug: scatter stats context refresh skipped',{ reason, hasContext:false });
          return false;
        }
        console.debug('Debug: scatter stats context refresh requested',{ reason, graphType:ctx.graphType, pointCount:ctx.points?.length || ctx.significance?.totalPoints || 0 });
        primeScatterStatsContext({
          ...ctx,
          precomputedStats:null,
          precomputedSignature:null
        });
        return true;
      }

      function handleScatterStatsComputeClick(){
        if(scatterState.statsComputationPending){
          return;
        }
        const context=scatterState.statsContext;
        if(!context){
          setScatterStatsStatus('Statistics unavailable until data is loaded.');
          return;
        }
        const sessionMeta = buildScatterSessionMeta({ reason: 'scatter-stats-compute' });
        scatterState.statsComputationPending=true;
        updateScatterStatsButtonState({ disabled:true, label:'Calculating…' });
        setScatterStatsStatus('Calculating statistics…');
        runScatterStatsComputation(context)
          .then(() => {
            const stillCurrent = isCurrentScatterSessionMeta(sessionMeta) && scatterState.statsContext === context && scatterState.statsContextVersion === context.version;
            if(!stillCurrent){
              scatterDebug('Debug: scatter stats update skipped',{ reason:'stale-context', contextVersion: context.version, current: scatterState.statsContextVersion });
              return;
            }
            scatterState.statsLastRunVersion=context.version;
            setScatterStatsStatus('Statistics up to date.');
            updateScatterStatsButtonState({ disabled:false, label:'Recalculate statistics' });
            if(typeof scheduleDrawScatter === 'function'){
              scheduleScatterViewRefresh('scatter-stats-updated');
            }
          })
          .catch(err => {
            const stillCurrent = isCurrentScatterSessionMeta(sessionMeta) && scatterState.statsContext === context && scatterState.statsContextVersion === context.version;
            if(!stillCurrent){
              scatterDebug('Debug: scatter stats error ignored',{ reason:'stale-context', message: err?.message || String(err) });
              return;
            }
            console.error('scatter stats computation failed',err);
            if(scatterStatsResults){
              scatterStatsResults.textContent='Unable to compute statistics. See console for details.';
            }
            setScatterStatsStatus('Failed to compute statistics.');
            updateScatterStatsButtonState({ disabled:false, label:'Calculate statistics' });
          })
          .finally(() => {
            const finalCurrent = isCurrentScatterSessionMeta(sessionMeta) && scatterState.statsContext === context && scatterState.statsContextVersion === context.version;
            if(!finalCurrent){
              scatterState.statsComputationPending=false;
              scatterDebug('Debug: scatter stats finalization skipped',{ reason:'stale-session', contextVersion: context.version, current: scatterState.statsContextVersion });
              return;
            }
            scatterState.statsComputationPending=false;
            syncScatterRegressionOptionVisibility();
            try{
              if(scatterState.statsLastRunVersion === context.version){
                const sess = (window && window.Main && window.Main.session) ? window.Main.session : null;
                if(sess && typeof sess.persistActiveTabState === 'function'){
                  sess.persistActiveTabState(undefined, { reason: 'scatter-stats-computed' });
                }
              }
            }catch(e){
              console.debug('Debug: persistActiveTabState after scatter compute failed', { err: e?.message || String(e) });
            }
          });
      }

      function renderScatterSignificanceSummary(context){
        if(!scatterStatsResults){
          return;
        }
        const summary=context?.significance;
        if(!summary){
          scatterStatsResults.textContent='Statistics unavailable.';
          return;
        }
        const rows=[
          { metric:'Total points', value:String(summary.totalPoints || 0) },
          { metric:'Significant', value:String(summary.significantCount || 0) },
          { metric:'Not significant', value:String(summary.nonSignificantCount || 0) },
          { metric:'|log₂FC| ≥', value:Number.isFinite(summary.log2fcThreshold)?summary.log2fcThreshold.toFixed(2):'—' },
          { metric:`${summary.negLabel || '-log10(p-value)'} ≥`, value:Number.isFinite(summary.negLogPThreshold)?summary.negLogPThreshold.toFixed(2):'—' }
        ];
        if(Number(summary.missingP)>0){
          rows.push({ metric:'Missing p-values', value:String(summary.missingP) });
        }
        renderStatsCard(scatterStatsResults,{
          caption: context.graphType==='ma' ? 'Differential expression summary' : 'Significance summary',
          columns:[
            {key:'metric',label:'Metric',align:'left'},
            {key:'value',label:'Value',align:'right'}
          ],
          rows,
          options:{
            fileName:'scatter-threshold-summary',
            contextLabel:'scatter-threshold'
          }
        });
      }

      function cacheScatterStats(context, stats, controlSignature){
        if(!context){
          return;
        }
        context.precomputedStats = stats || null;
        context.precomputedSignature = controlSignature || null;
        scatterState.statsContext = context;
        const signature = buildScatterStatsSignature(context);
        if(signature && stats){
          writeScatterStatsCache(signature, stats, controlSignature, context);
        }
      }

      function hasScatterRegressionReportData(model){
        if(!model || typeof model !== 'object'){
          return false;
        }
        const summary = (model.summary && typeof model.summary === 'object') ? model.summary : null;
        const metrics = (model.metrics && typeof model.metrics === 'object') ? model.metrics : null;
        const residuals = (model.residuals && typeof model.residuals === 'object') ? model.residuals : null;
        const hasSummary = !!summary && (
          (typeof summary.equation === 'string' && summary.equation.trim() !== '')
          || Number.isFinite(summary.slope)
          || Number.isFinite(summary.intercept)
          || (summary.parameters && typeof summary.parameters === 'object' && Object.keys(summary.parameters).length > 0)
        );
        const hasMetrics = !!metrics && (
          Number.isFinite(metrics.r2)
          || Number.isFinite(metrics.rmse)
          || Number.isFinite(metrics.mae)
          || Number.isFinite(metrics.sampleSize)
        );
        const hasResiduals = !!residuals && (
          Number.isFinite(residuals.mean)
          || Number.isFinite(residuals.sd)
          || Number.isFinite(residuals.min)
          || Number.isFinite(residuals.max)
        );
        const hasCoefficients = Array.isArray(model.coefficients)
          && model.coefficients.some(value => Number.isFinite(Number(value)));
        return hasSummary || hasMetrics || hasResiduals || hasCoefficients;
      }

      function summarizeScatterResiduals(points, regressionModel){
        const source = Array.isArray(points) ? points : [];
        if(!source.length || !regressionModel){
          return null;
        }
        let count = 0;
        let sum = 0;
        let sumSquares = 0;
        let min = Infinity;
        let max = -Infinity;
        for(let i = 0; i < source.length; i += 1){
          const point = source[i] || {};
          const x = Number(point.x);
          const y = Number(point.y);
          if(!Number.isFinite(x) || !Number.isFinite(y)){
            continue;
          }
          const predicted = predictScatterRegressionValue(regressionModel, x);
          if(!Number.isFinite(predicted)){
            continue;
          }
          const residual = y - predicted;
          count += 1;
          sum += residual;
          sumSquares += residual * residual;
          if(residual < min){
            min = residual;
          }
          if(residual > max){
            max = residual;
          }
        }
        if(!count){
          return null;
        }
        const mean = sum / count;
        const variance = count > 1
          ? Math.max((sumSquares - ((sum * sum) / count)) / (count - 1), 0)
          : 0;
        return {
          mean,
          sd: Math.sqrt(variance),
          min,
          max
        };
      }

      function formatScatterEquationFallback(regressionModel, stats){
        const summary = regressionModel?.summary && typeof regressionModel.summary === 'object'
          ? regressionModel.summary
          : null;
        const summaryEquation = typeof summary?.equation === 'string' ? summary.equation.trim() : '';
        if(summaryEquation){
          return summaryEquation;
        }
        const mode = String(regressionModel?.mode || '').toLowerCase();
        const slope = Number(summary?.slope);
        const intercept = Number(summary?.intercept);
        if((mode === 'linear' || !mode) && Number.isFinite(slope) && Number.isFinite(intercept)){
          const sign = slope >= 0 ? '+' : '-';
          return `y = ${formatMetricValue(intercept)} ${sign} ${formatMetricValue(Math.abs(slope))}x`;
        }
        if(mode === 'linearthroughorigin' && Number.isFinite(slope)){
          return `y = ${formatMetricValue(slope)}x`;
        }
        if(Array.isArray(regressionModel?.coefficients) && regressionModel.coefficients.length){
          const terms = [];
          regressionModel.coefficients.forEach((value, index) => {
            const coefficient = Number(value);
            if(!Number.isFinite(coefficient)){
              return;
            }
            if(index === 0){
              terms.push(formatMetricValue(coefficient));
              return;
            }
            const abs = formatMetricValue(Math.abs(coefficient));
            const power = index === 1 ? 'x' : `x^${index}`;
            terms.push(`${coefficient >= 0 ? '+ ' : '- '}${abs}${power}`);
          });
          if(terms.length){
            return `y = ${terms.join(' ')}`;
          }
        }
        const fallbackSlope = Number(stats?.m);
        const fallbackIntercept = Number(stats?.b);
        if(Number.isFinite(fallbackSlope) && Number.isFinite(fallbackIntercept)){
          const sign = fallbackSlope >= 0 ? '+' : '-';
          return `y = ${formatMetricValue(fallbackIntercept)} ${sign} ${formatMetricValue(Math.abs(fallbackSlope))}x`;
        }
        return '';
      }

      function ensureScatterRegressionForStats(context, stats, settings){
        const normalized = (stats && typeof stats === 'object') ? stats : {};
        if(Array.isArray(normalized?.groupedSeriesStats) && normalized.groupedSeriesStats.length){
          return normalized;
        }
        const regressionModeValue = settings?.regressionModeValue || 'linear';
        const fitMethodValue = settings?.fitMethodValue || 'ols';
        const fitSpec = settings?.fitSpec && typeof settings.fitSpec === 'object'
          ? settings.fitSpec
          : {};
        let regressionModel = normalized?.regression && typeof normalized.regression === 'object'
          ? normalized.regression
          : null;
        if((!hasScatterRegressionReportData(regressionModel) || isScatterCustomRegressionMode(regressionModeValue))
          && Array.isArray(context?.points)
          && context.points.length >= 2){
          try{
            regressionModel = fitScatterRegressionModel(context.points,{
              mode: regressionModeValue,
              method: fitMethodValue,
              fitSpec,
              domain: context?.domain || null,
              preferDoseResponse: regressionModeValue === 'logistic'
            });
            if(regressionModel){
              if(context?.domain && !regressionModel.domain){
                regressionModel.domain = { ...context.domain };
              }
              normalized.regression = regressionModel;
              scatterDebug('Debug: scatter stats regression rebuilt', {
                mode: regressionModel.mode || regressionModeValue,
                sampleSize: regressionModel?.metrics?.sampleSize || context.points.length
              });
            }
          }catch(err){
            console.error('scatter stats regression rebuild failed', err);
          }
        }
        regressionModel = normalized?.regression && typeof normalized.regression === 'object'
          ? normalized.regression
          : null;
        if(!regressionModel){
          return normalized;
        }
        enrichScatterRegressionModel(context?.points || [], regressionModel, {
          mode: regressionModeValue,
          method: fitMethodValue,
          fitSpec,
          domain: context?.domain || null
        });
        const summary = regressionModel.summary && typeof regressionModel.summary === 'object'
          ? regressionModel.summary
          : {};
        regressionModel.summary = summary;
        if(!Number.isFinite(normalized.r2) && Number.isFinite(regressionModel?.metrics?.r2)){
          normalized.r2 = regressionModel.metrics.r2;
        }
        if(!Number.isFinite(normalized.m) && Number.isFinite(summary.slope)){
          normalized.m = summary.slope;
        }
        if(!Number.isFinite(normalized.b) && Number.isFinite(summary.intercept)){
          normalized.b = summary.intercept;
        }
        const residualSummary = summarizeScatterResiduals(context?.points, regressionModel);
        if(residualSummary){
          const residuals = regressionModel.residuals && typeof regressionModel.residuals === 'object'
            ? regressionModel.residuals
            : null;
          const missingResiduals = !residuals
            || (!Number.isFinite(residuals.mean) && !Number.isFinite(residuals.sd));
          if(missingResiduals){
            regressionModel.residuals = residualSummary;
          }
        }
        const equation = formatScatterEquationFallback(regressionModel, normalized);
        if(equation){
          summary.equation = equation;
        }
        normalized.derived = {
          ...(normalized.derived || {}),
          ...(regressionModel.derived || {})
        };
        return normalized;
      }

      function buildScatterStatsDetailReport(context, stats, settings){
        const regressionModeValue = settings?.regressionModeValue || 'linear';
        const showCI = !!settings?.showCI;
        const showPI = !!settings?.showPI;
        const showDiagnostics = isScatterDiagnosticsEnabled();
        const normalizedStats = ensureScatterRegressionForStats(context, stats, settings);
        const regressionModel = normalizedStats?.regression || null;
        const fitMethodValue = normalizeScatterFitMethod(regressionModel?.fitMethod || settings?.fitMethodValue || 'ols');
        const fitSpecValue = regressionModel?.fitSpec && typeof regressionModel.fitSpec === 'object'
          ? regressionModel.fitSpec
          : (settings?.fitSpec && typeof settings.fitSpec === 'object' ? settings.fitSpec : null);
        const associationSelection = normalizeScatterAssociationSelection(
          normalizedStats?.associationSelection
          || settings?.associationSelection
          || settings?.associationMethod
          || 'auto'
        );
        const associationMethod = resolveScatterAssociationMethod(
          normalizedStats?.associationMethod || settings?.associationMethod || associationSelection,
          regressionModeValue
        );
        const associationLabel = getScatterAssociationMethodLabel(associationMethod);
        const associationDisplay = associationSelection === 'auto'
          ? `${associationLabel} (automatic)`
          : associationLabel;
        const regressionLabel = getScatterRegressionModeLabel(regressionModeValue);
        const fitMethodLabel = getScatterFitMethodLabel(fitMethodValue);
        const regressionPolicy = resolveScatterRegressionPolicy(regressionModeValue);
        if(regressionModel && Array.isArray(normalizedStats?.curveSamples) && !Array.isArray(regressionModel.curveSamples)){
          regressionModel.curveSamples = normalizedStats.curveSamples;
        }
        const tablePointCount = Number(context?.pointSummary?.count);
        const pairedPointCount = Number(normalizedStats?.pointCount);
        const regressionSampleCount = Number(regressionModel?.metrics?.sampleSize);
        const correlationSampleSize = Number.isFinite(pairedPointCount) && pairedPointCount > 0
          ? pairedPointCount
          : (Number.isFinite(tablePointCount) && tablePointCount > 0
            ? tablePointCount
            : (Number(context?.points?.length) || 0));
        const fitSampleSize = Number.isFinite(regressionSampleCount) && regressionSampleCount > 0
          ? regressionSampleCount
          : correlationSampleSize;
        const rows = [
          { metric:'[Analysis] Regression model', value:regressionLabel },
          { metric:'[Analysis] Fit method', value:fitMethodLabel },
          { metric:'[Analysis] Association metric', value:associationDisplay }
        ];
        const weightingKey = resolveScatterWeightingKey(fitMethodValue, fitSpecValue || {});
        if(weightingKey){
          rows.push({ metric:'[Analysis] Weighting scheme', value:weightingKey });
        }
        if(regressionPolicy?.fitGuidance){
          rows.push({ metric:'[Analysis] Fit method scope', value:regressionPolicy.fitGuidance });
        }
        if(fitSpecValue?.range){
          const minLabel = Number.isFinite(Number(fitSpecValue.range.minX)) ? formatMetricValue(Number(fitSpecValue.range.minX)) : 'Auto';
          const maxLabel = Number.isFinite(Number(fitSpecValue.range.maxX)) ? formatMetricValue(Number(fitSpecValue.range.maxX)) : 'Auto';
          rows.push({ metric:'[Analysis] Fit range X', value:`${minLabel} to ${maxLabel}` });
        }
        if(Number.isFinite(Number(fitSpecValue?.confidenceLevel))){
          rows.push({ metric:'[Analysis] Confidence level', value:`${formatMetricValue(Number(fitSpecValue.confidenceLevel), 2)}%` });
        }
        if(Number.isFinite(correlationSampleSize)){
          rows.push({ metric:'[Analysis] N (paired)', value:String(Math.max(0, Math.round(correlationSampleSize))) });
        }
        if(Number.isFinite(fitSampleSize) && Math.round(fitSampleSize) !== Math.round(correlationSampleSize)){
          rows.push({ metric:'[Analysis] N (fit)', value:String(Math.max(0, Math.round(fitSampleSize))) });
        }
        if(associationMethod !== 'none'){
          const correlationCi = normalizedStats?.correlationCI || computeScatterCorrelationConfidenceInterval(normalizedStats?.r, correlationSampleSize, 0.05);
          const pMethod = normalizedStats?.pMethod || (normalizedStats?.method === 'Spearman' ? 't approximation' : 'Student t approximation');
          rows.push({ metric:'[Association] r', value:formatMetricValue(normalizedStats?.r) });
          rows.push({ metric:'[Association] P value', value:formatP(normalizedStats?.p) });
          rows.push({ metric:'[Association] P calculation', value:pMethod });
          rows.push({
            metric:normalizedStats?.correlationCiApproximate ? '[Association] Correlation (95% CI, approx)' : '[Association] Correlation (95% CI)',
            value:(correlationCi && Number.isFinite(correlationCi.low) && Number.isFinite(correlationCi.high))
              ? `${formatMetricValue(correlationCi.low)} to ${formatMetricValue(correlationCi.high)}`
              : 'n/a'
          });
        }else{
          rows.push({ metric:'[Association] Status', value:'Not computed (model-fit only mode).' });
        }
        if(regressionModel?.metrics){
          rows.push({ metric:'[Fit] RMSE', value:formatMetricValue(regressionModel.metrics.rmse) });
          rows.push({ metric:'[Fit] MAE', value:formatMetricValue(regressionModel.metrics.mae) });
          if(Number.isFinite(regressionModel.metrics.aic)){
            rows.push({ metric:'[Fit] AIC', value:formatMetricValue(regressionModel.metrics.aic,4) });
          }
          if(Number.isFinite(regressionModel.metrics.aicc)){
            rows.push({ metric:'[Fit] AICc', value:formatMetricValue(regressionModel.metrics.aicc,4) });
          }
          if(Number.isFinite(regressionModel.metrics.bic)){
            rows.push({ metric:'[Fit] BIC', value:formatMetricValue(regressionModel.metrics.bic,4) });
          }
          if(Number.isFinite(regressionModel.metrics.r2)){
            rows.push({ metric:'[Fit] R²', value:formatMetricValue(regressionModel.metrics.r2) });
          }else if(String(regressionModel?.mode || '').toLowerCase() === 'deming' || String(regressionModel?.mode || '').toLowerCase() === 'orthogonal'){
            rows.push({ metric:'[Fit] R²', value:'Not reported for errors-in-variables regression.' });
          }
          if(Number.isFinite(regressionModel.metrics.adjR2)){
            rows.push({ metric:'[Fit] Adjusted R²', value:formatMetricValue(regressionModel.metrics.adjR2) });
          }
          if(Number.isFinite(regressionModel.metrics.logLoss)){
            rows.push({ metric:'[Fit] Log loss', value:formatMetricValue(regressionModel.metrics.logLoss,6) });
          }
        }else{
          rows.push({ metric:'[Fit] R²', value:formatMetricValue(normalizedStats?.r2) });
        }
        if(regressionModel?.summary){
          const summary = regressionModel.summary;
          if(summary.parameters && typeof summary.parameters === 'object'){
            Object.entries(summary.parameters).forEach(([label,value]) => {
              if(Number.isFinite(value)){
                rows.push({ metric:`[Parameters] ${label}`, value:formatMetricValue(value) });
              }else if(value != null && value !== ''){
                rows.push({ metric:`[Parameters] ${label}`, value:String(value) });
              }
            });
          }
          if(summary.primaryParameter && summary.primaryParameter.label && Number.isFinite(summary.primaryParameter.value)){
            const duplicate = summary.parameters && Object.prototype.hasOwnProperty.call(summary.parameters,summary.primaryParameter.label);
            if(!duplicate){
              rows.push({ metric:`[Parameters] ${summary.primaryParameter.label}`, value:formatMetricValue(summary.primaryParameter.value) });
            }
          }
          if(!summary.parameters && Number.isFinite(summary.slope)){
            rows.push({ metric:'[Parameters] Slope', value:formatMetricValue(summary.slope) });
          }
          if(!summary.parameters && Number.isFinite(summary.intercept)){
            rows.push({ metric:'[Parameters] Intercept', value:formatMetricValue(summary.intercept) });
          }
          const equationValue = formatScatterEquationFallback(regressionModel, normalizedStats);
          if(equationValue){
            rows.push({ metric:'[Parameters] Equation', value:equationValue });
          }
        }else{
          rows.push({ metric:'[Parameters] Slope', value:formatMetricValue(normalizedStats?.m) });
          rows.push({ metric:'[Parameters] Intercept', value:formatMetricValue(normalizedStats?.b) });
        }
        if(regressionModel?.mode === 'doseResponse4pl' && Array.isArray(regressionModel?.coefficientStats)){
          const logIc50Stat = regressionModel.coefficientStats.find(stat => stat?.term === 'LogIC50') || null;
          const ic50Stat = regressionModel.coefficientStats.find(stat => stat?.term === 'IC50') || null;
          if(Number.isFinite(ic50Stat?.standardError)){
            rows.push({ metric:'[Intervals] IC50 Std. Error', value:formatMetricValue(ic50Stat.standardError) });
          }
          if(Number.isFinite(logIc50Stat?.ciLow) && Number.isFinite(logIc50Stat?.ciHigh)){
            rows.push({
              metric:'[Intervals] LogIC50 (95% CI)',
              value:`${formatMetricValue(logIc50Stat.ciLow)} – ${formatMetricValue(logIc50Stat.ciHigh)}`
            });
          }
          if(Number.isFinite(ic50Stat?.ciLow) && Number.isFinite(ic50Stat?.ciHigh)){
            rows.push({
              metric:'[Intervals] IC50 (95% CI)',
              value:`${formatMetricValue(ic50Stat.ciLow)} – ${formatMetricValue(ic50Stat.ciHigh)}`
            });
          }
        }
        if(regressionModel?.residuals){
          rows.push({ metric:'[Diagnostics] Residual mean', value:formatMetricValue(regressionModel.residuals.mean) });
          rows.push({ metric:'[Diagnostics] Residual SD', value:formatMetricValue(regressionModel.residuals.sd) });
        }
        if((showCI || showPI) && regressionModel?.intervals?.summary){
          const intervalSummary = regressionModel.intervals.summary;
          if(showCI && Number.isFinite(intervalSummary.ciMin) && Number.isFinite(intervalSummary.ciMax)){
            rows.push({ metric:'[Intervals] Confidence interval of mean fit (y)', value:`${formatMetricValue(intervalSummary.ciMin)} – ${formatMetricValue(intervalSummary.ciMax)}` });
          }
          if(showPI && Number.isFinite(intervalSummary.piMin) && Number.isFinite(intervalSummary.piMax)){
            rows.push({ metric:'[Intervals] Prediction interval for new observation (y)', value:`${formatMetricValue(intervalSummary.piMin)} – ${formatMetricValue(intervalSummary.piMax)}` });
          }
        }
        if(showDiagnostics && regressionModel?.diagnostics){
          rows.push({ metric:'[Diagnostics] Residual skewness', value:formatMetricValue(regressionModel.diagnostics.skewness,3) });
          rows.push({ metric:'[Diagnostics] Residual kurtosis', value:formatMetricValue(regressionModel.diagnostics.kurtosis,3) });
          if(Number.isFinite(regressionModel.diagnostics.jarqueBera)){
            rows.push({ metric:'[Diagnostics] Jarque-Bera', value:formatMetricValue(regressionModel.diagnostics.jarqueBera,3) });
          }
          if(Number.isFinite(regressionModel.diagnostics.jarqueBeraP)){
            rows.push({ metric:'[Diagnostics] Jarque-Bera p', value:formatP(regressionModel.diagnostics.jarqueBeraP) });
          }
          const runs = regressionModel.diagnostics.runsTest || null;
          if(Number.isFinite(runs?.z)){
            rows.push({ metric:'[Diagnostics] Runs test z', value:formatMetricValue(runs.z,3) });
          }
          if(Number.isFinite(runs?.pValue)){
            rows.push({ metric:'[Diagnostics] Runs test p', value:formatP(runs.pValue) });
          }
          const bp = regressionModel.diagnostics.heteroscedasticity || null;
          if(Number.isFinite(bp?.statistic)){
            rows.push({ metric:'[Diagnostics] Breusch-Pagan', value:formatMetricValue(bp.statistic,3) });
          }
          if(Number.isFinite(bp?.pValue)){
            rows.push({ metric:'[Diagnostics] Breusch-Pagan p', value:formatP(bp.pValue) });
          }
          const reset = regressionModel.diagnostics.reset || null;
          if(Number.isFinite(reset?.fStatistic)){
            rows.push({ metric:'[Diagnostics] RESET F', value:formatMetricValue(reset.fStatistic,3) });
          }
          if(Number.isFinite(reset?.pValue)){
            rows.push({ metric:'[Diagnostics] RESET p', value:formatP(reset.pValue) });
          }
          const influence = regressionModel.diagnostics.influence || null;
          if(Number.isFinite(influence?.maxAbsStudentized)){
            rows.push({ metric:'[Influence] Max |studentized residual|', value:formatMetricValue(influence.maxAbsStudentized,3) });
          }
          if(Number.isFinite(influence?.maxLeverage)){
            rows.push({ metric:'[Influence] Max leverage', value:formatMetricValue(influence.maxLeverage,3) });
          }
          if(Number.isFinite(influence?.maxCooksDistance)){
            rows.push({ metric:'[Influence] Max Cook\'s distance', value:formatMetricValue(influence.maxCooksDistance,3) });
          }
          if(Number.isFinite(influence?.maxDffits)){
            rows.push({ metric:'[Influence] Max DFFITS', value:formatMetricValue(influence.maxDffits,3) });
          }
          if(Number.isFinite(influence?.influentialCount)){
            rows.push({ metric:'[Influence] Flagged influential points', value:String(Math.max(0, Math.round(influence.influentialCount))) });
          }
          const lackOfFit = regressionModel.diagnostics.lackOfFit || null;
          if(Number.isFinite(lackOfFit?.fStatistic)){
            rows.push({ metric:'[Diagnostics] Lack-of-fit F', value:formatMetricValue(lackOfFit.fStatistic,3) });
          }
          if(Number.isFinite(lackOfFit?.pValue)){
            rows.push({ metric:'[Diagnostics] Lack-of-fit p', value:formatP(lackOfFit.pValue) });
          }
          rows.push({ metric:'[Diagnostics] Residual views', value:'Residuals and Residual QQ derived views were generated for plot-based checking.' });
        }
        const derived = normalizedStats?.derived || computeScatterDerivedRegressionStats(regressionModel);
        if(derived){
          if(Number.isFinite(derived.xIntercept)){
            rows.push({ metric:'[Parameters] X-intercept', value:formatMetricValue(derived.xIntercept) });
          }
          if(Number.isFinite(derived.xInterceptCi?.low) && Number.isFinite(derived.xInterceptCi?.high)){
            rows.push({
              metric:'[Intervals] X-intercept (95% CI)',
              value:`${formatMetricValue(derived.xInterceptCi.low)} to ${formatMetricValue(derived.xInterceptCi.high)}`
            });
          }
          if(Number.isFinite(derived.reciprocalSlope)){
            rows.push({ metric:'[Parameters] 1/Slope', value:formatMetricValue(derived.reciprocalSlope) });
          }
          if(Number.isFinite(derived.reciprocalSlopeCi?.low) && Number.isFinite(derived.reciprocalSlopeCi?.high)){
            rows.push({
              metric:'[Intervals] 1/Slope (95% CI)',
              value:`${formatMetricValue(derived.reciprocalSlopeCi.low)} to ${formatMetricValue(derived.reciprocalSlopeCi.high)}`
            });
          }
          const auc = derived.auc || null;
          if(Number.isFinite(auc?.auc)){
            rows.push({ metric:'[Area] Trapezoidal AUC', value:formatMetricValue(auc.auc,4) });
          }
          if(Number.isFinite(auc?.normalizedAuc)){
            rows.push({ metric:'[Area] Mean response over X range', value:formatMetricValue(auc.normalizedAuc,4) });
          }
          const inversePredictions = Array.isArray(derived.inversePredictions) ? derived.inversePredictions : [];
          inversePredictions.forEach(entry => {
            if(Number.isFinite(entry?.targetY) && Number.isFinite(entry?.x)){
              rows.push({
                metric:`[Interpolation] X at Y = ${formatMetricValue(entry.targetY,4)}`,
                value:formatMetricValue(entry.x,4)
              });
            }
          });
        }
        {
          const contextWarnings = [];
          const pointXs = Array.isArray(context?.points) ? context.points.map(pt => Number(pt?.x)).filter(Number.isFinite) : [];
          if(pointXs.length > 1 && !pointXs.every((value, index) => index === 0 || value >= pointXs[index - 1])){
            contextWarnings.push('X values were unsorted; order-sensitive diagnostics and AUC were computed after sorting by X.');
          }
          if(hasScatterDuplicateValues(pointXs.map(value => value.toFixed(10)))){
            contextWarnings.push('Replicate X values were detected; interpret lack-of-fit and interpolation diagnostics with replicate structure in mind.');
          }
          const warnings = [
            ...(Array.isArray(regressionModel?.warnings) ? regressionModel.warnings : []),
            ...contextWarnings
          ].filter(msg => typeof msg === 'string' && msg.trim());
          const visibleWarnings = warnings.filter(msg => !/^Fit range excluded too many points \(\d+ retained of \d+\); using full dataset\.?$/i.test(msg));
          if(visibleWarnings.length){
            rows.push({ metric:'[Warnings] Model warnings', value:visibleWarnings.join('; ') });
          }else if(warnings.length && typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
            console.debug('Debug: scatter warnings row suppressed (fit-range fallback only)', { warnings });
          }
        }
        const coefficientRows = Array.isArray(regressionModel?.coefficientStats)
          ? regressionModel.coefficientStats.map(stat => ({
              term: stat?.term ?? '—',
              estimate: formatMetricValue(stat?.estimate),
              se: formatMetricValue(stat?.standardError),
              t: formatMetricValue(stat?.tStatistic, 3),
              p: formatP(stat?.pValue),
              ciLow: formatMetricValue(stat?.ciLow),
              ciHigh: formatMetricValue(stat?.ciHigh)
            }))
          : [];
        const displayRows = buildScatterDisplayRowSets({
          rows,
          coefficientRows,
          regressionModel,
          regressionModeValue,
          associationMethod,
          stats: normalizedStats
        }, settings);
        return {
          stats: normalizedStats,
          regressionModel,
          rows,
          summaryRows: displayRows.summaryRows,
          advancedRows: displayRows.advancedRows,
          coefficientRows,
          regressionModeValue,
          regressionLabel,
          associationMethod
        };
      }



      function buildScatterAnalysisSpec(context, stats, settings, extra){
        const regressionModeValue = settings?.regressionModeValue || scatterRegressionMode?.value || 'linear';
        const fitMethodValue = settings?.fitMethodValue || scatterFitMethod?.value || 'ols';
        const fitSpec = settings?.fitSpec && typeof settings.fitSpec === 'object' ? settings.fitSpec : buildScatterFitSpec();
        const globalFit = fitSpec?.globalFit && typeof fitSpec.globalFit === 'object' ? fitSpec.globalFit : null;
        const range = fitSpec?.range && typeof fitSpec.range === 'object' ? fitSpec.range : null;
        return {
          schemaVersion: 'scatter-stats-spec-v1',
          component: 'scatter',
          xLabel: scatterState.xLabelText || 'X',
          yLabel: scatterState.yLabelText || 'Y',
          pointCount: Number.isFinite(stats?.pointCount) ? stats.pointCount : (Array.isArray(context?.points) ? context.points.length : 0),
          grouped: !!stats?.grouped,
          groupLabels: Array.isArray(stats?.groupedSeriesStats)
            ? stats.groupedSeriesStats.map((entry, idx) => entry?.label || `Series ${idx + 1}`)
            : null,
          associationSelection: stats?.associationSelection || (scatterStatType?.value || 'auto'),
          associationMethod: stats?.associationMethod || null,
          regressionMode: regressionModeValue,
          fitMethod: fitMethodValue,
          fitRange: range,
          confidenceLevel: fitSpec?.confidenceLevel || null,
          fitSpec: {
            initialValues: fitSpec?.initialValues || null,
            parameters: fitSpec?.parameters || null
          },
          globalFit,
          groupedLinearComparison: stats?.groupedLinearComparison
            ? {
                alpha: Number(stats.groupedLinearComparison?.alpha),
                overallDecision: stats.groupedLinearComparison?.overallDecision?.code || null,
                significantPairs: Array.isArray(stats.groupedLinearComparison?.pairwiseRows)
                  ? stats.groupedLinearComparison.pairwiseRows
                    .filter(entry => entry?.decisionCode === 'different-slopes' || entry?.decisionCode === 'different-intercepts')
                    .map(entry => entry?.pair)
                    .filter(Boolean)
                  : []
              }
            : null,
          overlays: {
            showLine: !!settings?.showLineMaster,
            showCI: !!settings?.showCI,
            showPI: !!settings?.showPI,
            showDiagnostics: isScatterDiagnosticsEnabled()
          },
          generatedAt: new Date().toISOString(),
          extra: extra || null
        };
      }

      function buildScatterReportingText(context, stats, settings){
        const xLabel = scatterState.xLabelText || 'X';
        const yLabel = scatterState.yLabelText || 'Y';
        const regressionModeValue = settings?.regressionModeValue || scatterRegressionMode?.value || 'linear';
        const fitMethodValue = settings?.fitMethodValue || scatterFitMethod?.value || 'ols';
        const fitSpec = settings?.fitSpec && typeof settings.fitSpec === 'object' ? settings.fitSpec : buildScatterFitSpec();
        const confidence = Number.isFinite(Number(fitSpec?.confidenceLevel)) ? Number(fitSpec.confidenceLevel) : 95;
        const associationLabel = typeof stats?.method === 'string' && stats.method.trim()
          ? stats.method.trim()
          : getScatterAssociationMethodLabel(resolveScatterAssociationMethod(stats?.associationMethod || 'auto', regressionModeValue));
        const regressionLabel = getScatterRegressionModeLabel(regressionModeValue);
        const fitLabel = getScatterFitMethodLabel(fitMethodValue);

        const methodsParts = [];
        const resultsParts = [];

        if(stats?.grouped){
          const groupCount = Array.isArray(stats?.groupedSeriesStats) ? stats.groupedSeriesStats.length : 0;
          methodsParts.push(`Scatter data (${xLabel} vs ${yLabel}) were analyzed across ${groupCount} group${groupCount === 1 ? '' : 's'}.`);
        }else{
          const n = Number.isFinite(stats?.pointCount) ? stats.pointCount : (Array.isArray(context?.points) ? context.points.length : 0);
          methodsParts.push(`Scatter data (${xLabel} vs ${yLabel}) were analyzed using ${associationLabel} association (n = ${n}).`);
        }

        if(stats?.associationMethod && stats.associationMethod !== 'none'){
          methodsParts.push(`Association P values used the ${stats.pMethod || 'standard'} method.`);
          if(stats.correlationCI && Number.isFinite(stats.correlationCI.low) && Number.isFinite(stats.correlationCI.high)){
            methodsParts.push(`${confidence}% confidence intervals were reported for the association estimate${stats.correlationCiApproximate ? ' (approximate)' : ''}.`);
          }
        }

        if(regressionModeValue && regressionModeValue !== 'none'){
          methodsParts.push(`${regressionLabel} was fit using ${fitLabel}.`);
          if(fitSpec?.range && (Number.isFinite(Number(fitSpec.range.minX)) || Number.isFinite(Number(fitSpec.range.maxX)))){
            const minX = Number.isFinite(Number(fitSpec.range.minX)) ? Number(fitSpec.range.minX) : null;
            const maxX = Number.isFinite(Number(fitSpec.range.maxX)) ? Number(fitSpec.range.maxX) : null;
            methodsParts.push(`Fits were restricted to ${minX != null ? `X >= ${formatMetricValue(minX, 4)}` : ''}${minX != null && maxX != null ? ' and ' : ''}${maxX != null ? `X <= ${formatMetricValue(maxX, 4)}` : ''}.`);
          }
          methodsParts.push(`${confidence}% confidence intervals were used for coefficient and prediction summaries when available.`);
        }

        if(stats?.groupedGlobalFit){
          const gf = stats.groupedGlobalFit;
          if(gf.sharedFit && Array.isArray(gf.sharedFit.sharedParameters) && gf.sharedFit.sharedParameters.length){
            methodsParts.push(`Grouped curve fitting used shared parameters (${gf.sharedFit.sharedParameters.join(', ')}) with separate remaining parameters per group.`);
          }
          if(gf.commonCurve){
            methodsParts.push('Common versus separate curve families were compared using information criteria and extra sum-of-squares F tests where applicable.');
          }
        }
        if(stats?.groupedLinearComparison){
          methodsParts.push('Linear grouped datasets were compared using a GraphPad-style sequence: slopes first, then intercepts only when slopes were not significantly different.');
          if(Number.isFinite(Number(stats.groupedLinearComparison.alpha))){
            methodsParts.push(`Grouped line-comparison decisions used alpha = ${formatMetricValue(Number(stats.groupedLinearComparison.alpha), 4)}.`);
          }
        }

        if(!stats?.grouped){
          if(Number.isFinite(stats?.r)){
            const ci = stats.correlationCI;
            const ciText = ci && Number.isFinite(ci.low) && Number.isFinite(ci.high)
              ? `, ${formatMetricValue(ci.low, 4)} to ${formatMetricValue(ci.high, 4)}`
              : '';
            resultsParts.push(`${associationLabel} association: r = ${formatMetricValue(stats.r, 4)}${ciText}, P = ${formatP(stats.p)}.`);
          }
          const model = stats?.regression || stats?.regressionModel || null;
          const slope = model?.summary?.slope;
          const intercept = model?.summary?.intercept;
          const r2 = model?.metrics?.r2;
          const rmse = model?.metrics?.rmse;
          if(Number.isFinite(slope) && Number.isFinite(intercept)){
            resultsParts.push(`Fitted model: ${yLabel} = ${formatMetricValue(intercept, 4)} + ${formatMetricValue(slope, 4)} * ${xLabel}.`);
          }
          if(Number.isFinite(r2)){
            resultsParts.push(`R² = ${formatMetricValue(r2, 4)}${Number.isFinite(rmse) ? `, RMSE = ${formatMetricValue(rmse, 4)}` : ''}.`);
          }
          const primary = model?.summary?.primaryParameter;
          if(primary && typeof primary.label === 'string' && Number.isFinite(primary.value)){
            resultsParts.push(`${primary.label} = ${formatMetricValue(primary.value, 4)}.`);
          }
        }else{
          const gf = stats?.groupedGlobalFit || null;
          if(gf){
            const candidates = [
              ['Separate curves', gf.separate?.infoCriteria?.aicc],
              ['Common curve', gf.commonCurve?.infoCriteria?.aicc],
              ['Shared-parameter fit', gf.sharedFit?.infoCriteria?.aicc]
            ].filter(entry => Number.isFinite(entry[1])).sort((a, b) => a[1] - b[1]);
            if(candidates.length){
              resultsParts.push(`Preferred grouped model by AICc: ${candidates[0][0]}.`);
            }
            const sharedTest = gf.sharedFit?.versusSeparate;
            if(sharedTest && Number.isFinite(sharedTest.pValue)){
              resultsParts.push(`Shared-parameter versus separate curves: F = ${formatMetricValue(sharedTest.fStatistic, 4)}, P = ${formatP(sharedTest.pValue)}.`);
            }
            const commonTest = gf.commonCurve?.versusSeparate;
            if(commonTest && Number.isFinite(commonTest.pValue)){
              resultsParts.push(`Common versus separate curves: F = ${formatMetricValue(commonTest.fStatistic, 4)}, P = ${formatP(commonTest.pValue)}.`);
            }
          }
          const groupedLinearComparison = stats?.groupedLinearComparison || null;
          if(groupedLinearComparison?.overallDecision?.text){
            resultsParts.push(`GraphPad-style grouped linear comparison: ${groupedLinearComparison.overallDecision.text}`);
          }
          const significantPairs = Array.isArray(groupedLinearComparison?.pairwiseRows)
            ? groupedLinearComparison.pairwiseRows
              .filter(entry => entry?.decisionCode === 'different-slopes' || entry?.decisionCode === 'different-intercepts')
              .map(entry => entry?.pair)
              .filter(Boolean)
            : [];
          if(significantPairs.length){
            resultsParts.push(`Pairwise differences after Holm correction: ${significantPairs.join('; ')}.`);
          }
        }

        return {
          methodsText: methodsParts.filter(Boolean).join(' '),
          resultsText: resultsParts.filter(Boolean).join(' ')
        };
      }

      function appendScatterReportPanel(target, report, analysisSpec){
        const reporting = Shared.statsReporting;
        if(reporting && typeof reporting.appendReportPanel === 'function'){
          reporting.appendReportPanel(target, {
            methodsText: report?.methodsText || '',
            resultsText: report?.resultsText || '',
            analysisSpec: analysisSpec || null
          }, {
            title: 'Reporting and reproducibility'
          });
          return;
        }
        // Fallback if shared reporting helper is missing.
        if(!target || !document || !document.createElement){
          return;
        }
        const panel = document.createElement('details');
        panel.className = 'stats-report-panel';
        const summary = document.createElement('summary');
        summary.textContent = 'Reporting and reproducibility';
        panel.appendChild(summary);
        const pre = document.createElement('pre');
        pre.textContent = (report?.methodsText || '') + (report?.resultsText ? `

${report.resultsText}` : '') + (analysisSpec ? `

Technical analysis record (advanced)\n${JSON.stringify(analysisSpec, null, 2)}` : '');
        panel.appendChild(pre);
        target.appendChild(panel);
      }
      function applyScatterStatsResults(context, stats, settings){
        if(!scatterStatsResults){
          return;
        }
        const regressionModeValue = settings?.regressionModeValue || 'linear';
        const showLineMaster = !!settings?.showLineMaster;
        const showCI = !!settings?.showCI;
        const showPI = !!settings?.showPI;
        const showDiagnostics = isScatterDiagnosticsEnabled();
        const controlSignature = settings?.controlSignature || null;
        stats = ensureScatterRegressionForStats(context, stats, settings);
        cacheScatterStats(context, stats, controlSignature);
        const groupedSeriesStats = Array.isArray(stats?.groupedSeriesStats)
          ? stats.groupedSeriesStats
          : [];
        if(groupedSeriesStats.length){
          const groupedReports = groupedSeriesStats.map((entry, index) => {
            const label = (entry?.label != null && String(entry.label).trim() !== '')
              ? String(entry.label).trim()
              : `Series ${index + 1}`;
            const points = Array.isArray(entry?.points) ? entry.points : [];
            const pointSummary = summarizeScatterPoints(points);
            const detail = buildScatterStatsDetailReport(
              { ...context, points, pointSummary },
              entry?.stats || {},
              settings
            );
            return {
              label,
              detail
            };
          });
          const reportRegressionLabel = groupedReports
            .map(entry => entry?.detail?.regressionLabel)
            .find(label => typeof label === 'string' && label.trim())
            || getScatterRegressionModeLabel(regressionModeValue);
          const metricOrder = [];
          const metricSet = new Set();
          groupedReports.forEach(entry => {
            const detailRows = Array.isArray(entry?.detail?.summaryRows) ? entry.detail.summaryRows : [];
            detailRows.forEach(row => {
              const metric = String(row?.metric || '').trim();
              if(!metric || metricSet.has(metric)){
                return;
              }
              metricSet.add(metric);
              metricOrder.push(metric);
            });
          });
          const groupedColumns = groupedReports.map((entry, index) => ({
            key: `group_${index}`,
            label: entry.label,
            align: 'right'
          }));
          const valueLookup = groupedReports.map(entry => {
            const map = new Map();
            const rows = Array.isArray(entry?.detail?.summaryRows) ? entry.detail.summaryRows : [];
            rows.forEach(row => {
              const metric = String(row?.metric || '').trim();
              if(metric){
                map.set(metric, row?.value ?? '—');
              }
            });
            return map;
          });
          const summaryRows = metricOrder.map(metric => {
            const row = { metric };
            groupedColumns.forEach((col, index) => {
              row[col.key] = valueLookup[index].has(metric) ? valueLookup[index].get(metric) : '—';
            });
            return row;
          });
          renderStatsCard(scatterStatsResults,{
            caption:`Overall test summary by group (${reportRegressionLabel})` ,
            columns:[{ key:'metric', label:'Metric', align:'left' }, ...groupedColumns],
            rows:summaryRows,
            options:{
              fileName:'scatter-grouped-report',
              contextLabel:'scatter-grouped-report'
            }
          });
          const coefficientFields = [
            { key:'estimate', label:'Estimate' },
            { key:'se', label:'Std Error' },
            { key:'t', label:'t-stat' },
            { key:'p', label:'p-value' },
            { key:'ciLow', label:'CI Low' },
            { key:'ciHigh', label:'CI High' }
          ];
          const coefficientTermOrder = [];
          const coefficientTermSet = new Set();
          groupedReports.forEach(entry => {
            const coeffRows = Array.isArray(entry?.detail?.coefficientRows) ? entry.detail.coefficientRows : [];
            coeffRows.forEach(row => {
              const term = String(row?.term || '').trim();
              if(!term || coefficientTermSet.has(term)){
                return;
              }
              coefficientTermSet.add(term);
              coefficientTermOrder.push(term);
            });
          });
          if(coefficientTermOrder.length){
            const coefficientLookup = groupedReports.map(entry => {
              const termMap = new Map();
              const coeffRows = Array.isArray(entry?.detail?.coefficientRows) ? entry.detail.coefficientRows : [];
              coeffRows.forEach(row => {
                const term = String(row?.term || '').trim();
                if(term){
                  termMap.set(term, row);
                }
              });
              return termMap;
            });
            const coefficientRows = [];
            coefficientTermOrder.forEach(term => {
              coefficientFields.forEach(field => {
                const row = { metric: `${term} · ${field.label}` };
                groupedColumns.forEach((col, index) => {
                  const termRow = coefficientLookup[index].get(term);
                  row[col.key] = termRow && Object.prototype.hasOwnProperty.call(termRow, field.key)
                    ? termRow[field.key]
                    : '—';
                });
                coefficientRows.push(row);
              });
            });
            renderStatsCard(scatterStatsResults,{
              caption:'Coefficient diagnostics',
              columns:[{ key:'metric', label:'Metric', align:'left' }, ...groupedColumns],
              rows:coefficientRows,
              options:{
                fileName:'scatter-grouped-coefficients',
                contextLabel:'scatter-grouped-coefficients'
              },
              advanced:true,
              append:true
            });
          }
          const groupedAdvancedMetricOrder = [];
          const groupedAdvancedMetricSet = new Set();
          groupedReports.forEach(entry => {
            const detailRows = Array.isArray(entry?.detail?.advancedRows) ? entry.detail.advancedRows : [];
            detailRows.forEach(row => {
              const metric = String(row?.metric || '').trim();
              if(!metric || groupedAdvancedMetricSet.has(metric)){
                return;
              }
              groupedAdvancedMetricSet.add(metric);
              groupedAdvancedMetricOrder.push(metric);
            });
          });
          if(groupedAdvancedMetricOrder.length){
            const groupedAdvancedLookup = groupedReports.map(entry => {
              const map = new Map();
              const rows = Array.isArray(entry?.detail?.advancedRows) ? entry.detail.advancedRows : [];
              rows.forEach(row => {
                const metric = String(row?.metric || '').trim();
                if(metric){
                  map.set(metric, row?.value ?? '—');
                }
              });
              return map;
            });
            const groupedAdvancedRows = groupedAdvancedMetricOrder.map(metric => {
              const row = { metric };
              groupedColumns.forEach((col, index) => {
                row[col.key] = groupedAdvancedLookup[index].has(metric) ? groupedAdvancedLookup[index].get(metric) : '—';
              });
              return row;
            });
            renderStatsCard(scatterStatsResults,{
              caption:'Model details by group',
              columns:[{ key:'metric', label:'Metric', align:'left' }, ...groupedColumns],
              rows:groupedAdvancedRows,
              options:{
                fileName:'scatter-grouped-report-details',
                contextLabel:'scatter-grouped-report-details'
              },
              advanced:true,
              append:true
            });
          }
          const groupedGlobalFitRows = buildScatterGroupedCurveComparisonRows(stats?.groupedGlobalFit || null);
          if(Array.isArray(groupedGlobalFitRows) && groupedGlobalFitRows.length){
            renderStatsCard(scatterStatsResults,{
              caption:'Comparison of fitted curves',
              columns:[
                { key:'metric', label:'Metric', align:'left' },
                { key:'value', label:'Value', align:'right' }
              ],
              rows:groupedGlobalFitRows,
              options:{
                fileName:'scatter-grouped-curve-comparison',
                contextLabel:'scatter-grouped-curve-comparison'
              },
              append:true
            });
          }
          const groupedComparisonReport = stats?.groupedLinearComparison
            || (
              String(regressionModeValue || '').trim().toLowerCase() === 'linear'
                ? buildScatterGroupedComparisonReport(
                    Array.isArray(stats?.groupedSeriesStatsSeparate) && stats.groupedSeriesStatsSeparate.length
                      ? stats.groupedSeriesStatsSeparate
                      : groupedSeriesStats,
                    { confidenceLevel: settings?.fitSpec?.confidenceLevel }
                  )
                : null
            );
          if(groupedComparisonReport && !stats?.groupedLinearComparison){
            stats = {
              ...stats,
              groupedLinearComparison: groupedComparisonReport
            };
          }
          const groupedComparisonRows = Array.isArray(groupedComparisonReport?.rows) ? groupedComparisonReport.rows : [];
          if(groupedComparisonRows.length){
            renderStatsCard(scatterStatsResults,{
              caption:'Compare linear regressions (GraphPad-style)',
              columns:[
                { key:'metric', label:'Metric', align:'left' },
                { key:'value', label:'Value', align:'right' }
              ],
              rows:groupedComparisonRows,
              options:{
                fileName:'scatter-grouped-linear-comparison',
                contextLabel:'scatter-grouped-linear-comparison'
              },
              append:true
            });
          }else if(!Array.isArray(groupedGlobalFitRows) || !groupedGlobalFitRows.length){
            const fallbackRows = buildScatterGroupedComparisonReport(groupedSeriesStats, {
              confidenceLevel: settings?.fitSpec?.confidenceLevel
            });
            if(Array.isArray(fallbackRows?.rows) && fallbackRows.rows.length){
              renderStatsCard(scatterStatsResults,{
                caption:'Comparison of fitted lines',
                columns:[
                  { key:'metric', label:'Metric', align:'left' },
                  { key:'value', label:'Value', align:'right' }
                ],
                rows:fallbackRows.rows,
                options:{
                  fileName:'scatter-grouped-comparison',
                  contextLabel:'scatter-grouped-comparison'
                },
                append:true
              });
            }
          }
          const pairwiseComparisonRows = Array.isArray(groupedComparisonReport?.pairwiseRows) ? groupedComparisonReport.pairwiseRows : [];
          if(pairwiseComparisonRows.length){
            renderStatsCard(scatterStatsResults,{
              caption:'Pairwise line comparisons (Holm-adjusted)',
              columns:[
                { key:'pair', label:'Pair', align:'left' },
                { key:'slopesP', label:'Slope p', align:'right' },
                { key:'slopesAdjP', label:'Slope p (Holm)', align:'right' },
                { key:'interceptsP', label:'Intercept p*', align:'right' },
                { key:'interceptsAdjP', label:'Intercept p* (Holm)', align:'right' },
                { key:'overallP', label:'Any-difference p', align:'right' },
                { key:'conclusion', label:'Conclusion', align:'left' }
              ],
              rows:pairwiseComparisonRows,
              options:{
                fileName:'scatter-grouped-pairwise-line-comparison',
                contextLabel:'scatter-grouped-pairwise-line-comparison'
              },
              append:true
            });
            renderStatsCard(scatterStatsResults,{
              caption:'Pairwise comparison notes',
              columns:[
                { key:'metric', label:'Metric', align:'left' },
                { key:'value', label:'Value', align:'left' }
              ],
              rows:[
                { metric:'Interpretation order', value:'GraphPad-style: test slope first; only evaluate intercept when slope is not significantly different.' },
                { metric:'*Intercept p', value:'Computed only when slope was not significant for that pair after Holm adjustment.' }
              ],
              options:{
                fileName:'scatter-grouped-pairwise-notes',
                contextLabel:'scatter-grouped-pairwise-notes'
              },
              append:true
            });
          }
          scatterLastRegressionSummary = {
            grouped: true,
            series: groupedReports.map(entry => {
              const regression = entry?.detail?.regressionModel || null;
              return {
                label: entry.label,
                summary: regression?.summary || null
              };
            })
          };
          if(settings?.createResidualView !== false){
            try{
              upsertScatterGroupedResidualsDataView(context, groupedSeriesStats, {
                title: 'Residuals',
                activate: false,
                reason: 'scatter-grouped-residuals'
              });
              upsertScatterGroupedResidualQqDataView(groupedSeriesStats, {
                title: 'Residual QQ',
                activate: false,
                reason: 'scatter-grouped-residual-qq'
              });
            }catch(err){
              console.error('scatter grouped residual data view update failed', err);
            }
          }
          const groupedReportText = buildScatterReportingText(context, { ...stats, grouped: true }, settings);
          const groupedAnalysisSpec = buildScatterAnalysisSpec(context, { ...stats, grouped: true }, settings, { controlSignature });
          appendScatterReportPanel(scatterStatsResults, groupedReportText, groupedAnalysisSpec);

          scatterDebug('Debug: scatter grouped stats computed', {
            groupCount: groupedSeriesStats.length,
            regression: reportRegressionLabel,
            showCI,
            showPI,
            showDiagnostics,
            showLineMaster
          });
          return;
        }
        const detail = buildScatterStatsDetailReport(context, stats, settings);
        const regressionModel = detail?.regressionModel || null;
        scatterLastRegressionSummary = typeof regressionTools.createSummary==='function'
          ? regressionTools.createSummary(regressionModel)
          : null;
        renderStatsCard(scatterStatsResults,{
          caption:`Overall test summary (${detail?.regressionLabel || getScatterRegressionModeLabel(regressionModeValue)})` ,
          columns:[
            {key:'metric',label:'Metric',align:'left'},
            {key:'value',label:'Value',align:'right'}
          ],
          rows: Array.isArray(detail?.summaryRows) ? detail.summaryRows : [],
          options:{
            fileName:'scatter-report',
            contextLabel:'scatter-report'
          }
        });
        if(Array.isArray(detail?.advancedRows) && detail.advancedRows.length){
          renderStatsCard(scatterStatsResults,{
            caption:'Model details',
            columns:[
              {key:'metric',label:'Metric',align:'left'},
              {key:'value',label:'Value',align:'right'}
            ],
            rows:detail.advancedRows,
            options:{
              fileName:'scatter-report-details',
              contextLabel:'scatter-report-details'
            },
            advanced:true,
            append:true
          });
        }
        if(Array.isArray(detail?.coefficientRows) && detail.coefficientRows.length){
          renderStatsCard(scatterStatsResults,{
            caption:'Coefficient diagnostics',
            columns:[
              { key:'term', label:'Term', align:'left' },
              { key:'estimate', label:'Estimate', align:'right' },
              { key:'se', label:'Std Error', align:'right' },
              { key:'t', label:'t-stat', align:'right' },
              { key:'p', label:'p-value', align:'right' },
              { key:'ciLow', label:'CI Low', align:'right' },
              { key:'ciHigh', label:'CI High', align:'right' }
            ],
            rows:detail.coefficientRows,
            options:{
              fileName:'scatter-coefficients',
              contextLabel:'scatter-coefficients'
            },
            advanced:true,
            append:true
          });
        }
        if(regressionModel && settings?.createResidualView !== false){
          try{
            upsertScatterResidualsDataView(context, regressionModel, {
              title: 'Residuals',
              activate: false,
              reason: 'scatter-stats-residuals'
            });
            upsertScatterResidualQqDataView(context, regressionModel, {
              title: 'Residual QQ',
              activate: false,
              reason: 'scatter-stats-residual-qq'
            });
          }catch(err){
            console.error('scatter residual data view update failed', err);
          }
        }
        const reportText = buildScatterReportingText(context, stats, settings);
        const analysisSpec = buildScatterAnalysisSpec(context, stats, settings, { controlSignature });
        appendScatterReportPanel(scatterStatsResults, reportText, analysisSpec);

        scatterDebug('Debug: scatter manual stats computed',{ stats, regressionSummary: scatterLastRegressionSummary });
      }

      function runScatterStatsComputation(context){
        const perfApi = Shared.Performance;
        const statsPerf = perfApi && typeof perfApi.start === 'function'
          ? perfApi.start('scatter.stats', { component: 'scatter', graphType: context?.graphType || null })
          : null;
        const finishStatsPerf = meta => {
          if(perfApi && statsPerf){
            perfApi.end(statsPerf, meta);
          }
        };
        if(!scatterStatsResults){
          finishStatsPerf({ outcome: 'no-target' });
          return Promise.resolve(false);
        }
        clearScatterStatsReportHost();
        scatterStatsResults.innerHTML='';
        if(context.graphType==='scatter'){
          if(!validateScatterFitSpecControls()){
            scatterStatsResults.textContent='Fix fit specification errors before computing statistics.';
            finishStatsPerf({ outcome: 'fit-spec-invalid', pointCount: context.points?.length || 0 });
            return Promise.resolve(false);
          }
          if(!Array.isArray(context.points) || context.points.length<3){
            scatterStatsResults.textContent='Select at least three paired values to compute regression statistics.';
            finishStatsPerf({ outcome: 'insufficient-points', pointCount: context.points?.length || 0 });
            return Promise.resolve(false);
          }
          const methodSelection = scatterStatType?.value || 'auto';
          const regressionModeValue=scatterRegressionMode ? (scatterRegressionMode.value || 'linear') : 'linear';
          const resolvedAssociationMethod = resolveScatterAssociationMethod(methodSelection, regressionModeValue);
          const fitMethodValue=scatterFitMethod ? (scatterFitMethod.value || 'ols') : 'ols';
          const fitSpec = buildScatterFitSpec();
          const showLineMaster = !!(scatterShowLine && scatterShowLine.checked);
          const showCI = !!(showLineMaster && scatterShowCI && scatterShowCI.checked);
          const showPI = !!(showLineMaster && scatterShowPI && scatterShowPI.checked);
          const showDiagnostics=isScatterDiagnosticsEnabled();
          const controlSignature=getScatterStatsControlSignature();
          const settings = {
            regressionModeValue,
            fitMethodValue,
            fitSpec,
            showLineMaster,
            showCI,
            showPI,
            showDiagnostics,
            controlSignature,
            associationSelection: methodSelection,
            associationMethod: resolvedAssociationMethod
          };
          const groupedSeries = Array.isArray(context.groupedSeries) ? context.groupedSeries : [];
          const groupedRegressionMode = groupedSeries.length > 1;
          if(groupedRegressionMode){
            let groupedStats = context.precomputedStats;
            const canReuseGroupedStats = !!groupedStats
              && context.precomputedSignature === controlSignature
              && Array.isArray(groupedStats?.groupedSeriesStats);
            if(!canReuseGroupedStats){
              const groupedSeriesStatsSeparate = groupedSeries.map((series, index) => {
                const label = (series?.label != null && String(series.label).trim() !== '')
                  ? String(series.label).trim()
                  : `Series ${index + 1}`;
                const seriesPoints = Array.isArray(series?.points) ? series.points : [];
                const computed = computeScatterStats(seriesPoints, resolvedAssociationMethod, {
                  associationSelection: methodSelection,
                  regressionMode: regressionModeValue,
                  fitMethod: fitMethodValue,
                  fitSpec,
                  domain: context.domain || null
                });
                return {
                  label,
                  points: seriesPoints,
                  stats: computed
                };
              });
              const groupedGlobalFit = buildScatterGroupedGlobalFitAnalysis(groupedSeriesStatsSeparate, {
                regressionModeValue,
                fitMethodValue,
                fitSpec,
                domain: context.domain || null
              });
              const groupedSeriesStats = Array.isArray(groupedGlobalFit?.activeSeriesStats) && groupedGlobalFit.activeSeriesStats.length
                ? groupedGlobalFit.activeSeriesStats
                : groupedSeriesStatsSeparate;
              const groupedLinearComparison = String(regressionModeValue || '').trim().toLowerCase() === 'linear'
                ? buildScatterGroupedComparisonReport(groupedSeriesStatsSeparate, {
                    confidenceLevel: fitSpec?.confidenceLevel
                  })
                : null;
              const methodLabel = groupedSeriesStats
                .map(entry => entry?.stats?.method)
                .find(value => typeof value === 'string' && value.trim())
                || getScatterAssociationMethodLabel(resolvedAssociationMethod);
              groupedStats = {
                method: methodLabel,
                groupedSeriesStats,
                groupedSeriesStatsSeparate,
                groupedGlobalFit,
                groupedLinearComparison,
                grouped: true,
                pointCount: context.points.length,
                regression: null
              };
            }
            applyScatterStatsResults(context, groupedStats, settings);
            finishStatsPerf({ outcome: canReuseGroupedStats ? 'sync-grouped-cached' : 'sync-grouped', pointCount: context.points.length, groupCount: groupedSeries.length });
            return Promise.resolve(true);
          }
          let stats=context.precomputedStats;
          if(!stats || context.precomputedSignature!==controlSignature){
            const canUseWorkerForAssociation = resolvedAssociationMethod === 'pearson' || resolvedAssociationMethod === 'spearman';
            const useWorker = canUseWorkerForAssociation && shouldUseScatterStatsWorker(context.points, regressionModeValue, fitMethodValue);
            if(useWorker){
              const contextVersion = context.version;
              const payload = {
                points: context.points,
                method: resolvedAssociationMethod,
                regressionMode: regressionModeValue,
                fitMethod: fitMethodValue,
                fitSpec,
                domain: context.domain || null,
                sampleCount: regressionModeValue === 'linear' ? 60 : 160,
                debug: (typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled())
              };
              scatterDebug('Debug: scatter stats worker scheduled',{ pointCount: context.points.length, regressionMode: regressionModeValue });
              return runScatterStatsWorker(payload)
                .then(result => {
                  if(scatterState.statsContext !== context || scatterState.statsContextVersion !== contextVersion){
                    scatterDebug('Debug: scatter stats worker result ignored',{ reason:'stale-context', contextVersion, current: scatterState.statsContextVersion });
                    return false;
                  }
                  if(!result || typeof result !== 'object'){
                    throw new Error('Scatter stats worker returned empty result');
                  }
                  result.associationSelection = methodSelection;
                  result.associationMethod = resolvedAssociationMethod;
                  stats = result;
                  applyScatterStatsResults(context, stats, settings);
                  scatterDebug('Debug: scatter stats worker applied',{ pointCount: context.points.length, regressionMode: regressionModeValue });
                  return true;
                })
                .catch(err => {
                  scatterDebug('Debug: scatter stats worker failed',{ message: err?.message || String(err) });
                  stats = computeScatterStats(context.points, resolvedAssociationMethod, {
                    associationSelection: methodSelection,
                    regressionMode: regressionModeValue,
                    fitMethod: fitMethodValue,
                    fitSpec,
                    domain: context.domain || null
                  });
                  applyScatterStatsResults(context, stats, settings);
                  return true;
                })
                .finally(() => {
                  finishStatsPerf({ outcome: 'worker', pointCount: context.points.length });
                });
            }
            stats = computeScatterStats(context.points, resolvedAssociationMethod, {
              associationSelection: methodSelection,
              regressionMode: regressionModeValue,
              fitMethod: fitMethodValue,
              fitSpec,
              domain: context.domain || null
            });
          }
          applyScatterStatsResults(context, stats, settings);
          finishStatsPerf({ outcome: 'sync', pointCount: context.points.length });
        }else{
          renderScatterSignificanceSummary(context);
          scatterLastRegressionSummary=null;
          finishStatsPerf({ outcome: 'summary-only' });
        }
        return Promise.resolve(true);
      }

      if(scatterStatsButton){
        scatterStatsButton.addEventListener('click',handleScatterStatsComputeClick);
      }
      ensureScatterStatsSelectOptions();
      clearScatterStatsOutputs(scatterStatsPlaceholder);
      setScatterStatsStatus('');
      updateScatterStatsButtonState({ disabled:true, label:'Calculate statistics' });
      syncScatterRegressionOptionVisibility();

      const scatterSelects=[
        scatterGraphTypeSelect,
        scatterTableFormatSelect,
        scatterViewMode,
        scatterOriginMode,
        scatterStatType,
        scatterRegressionMode,
        scatterFitMethod
      ].filter(Boolean);
      scatterSelects.forEach(select=>{
        attachScatterSelectAutoSize(select, 'scatter');
      });
      function updateScatterViewModeOptionVisibility(){
        if(!scatterViewMode){
          return;
        }
        const groupedActive = isGroupedScatterModeActive();
        const typeIsScatter = scatterCurrentGraphType === 'scatter';
        const option3d = scatterViewMode.querySelector('option[value="3d"]');
        if(option3d){
          option3d.disabled = groupedActive || !typeIsScatter;
        }
        const optionBubble = scatterViewMode.querySelector('option[value="bubble"]');
        if(optionBubble){
          optionBubble.disabled = groupedActive || !typeIsScatter;
        }
        scatterViewMode.disabled = !typeIsScatter;
        if(groupedActive && (scatterViewMode.value === '3d' || scatterViewMode.value === 'bubble')){
          scatterViewMode.value = '2d';
        }
      }
      function applyScatterViewMode(mode, options = {}){
        const graphAllowsAdvanced = scatterCurrentGraphType === 'scatter' && !isGroupedScatterModeActive();
        const allow3d = options.allow3d !== false && graphAllowsAdvanced;
        const allowBubble = options.allowBubble !== false && graphAllowsAdvanced;
        const forceUpdate = options.forceUpdate === true;
        const skipSchedule = options.skipSchedule === true;
        const persistRequest = options.persistRequest === true;
        let requested = typeof mode === 'string'
          ? mode.toLowerCase()
          : (scatterState.requestedViewMode || scatterState.viewMode || '2d');
        if(requested !== '3d' && requested !== 'bubble'){
          requested = '2d';
        }
        if(persistRequest || !scatterState.requestedViewMode){
          scatterState.requestedViewMode = requested;
        }
        let normalized = requested;
        if(normalized === '3d' && !allow3d){
          normalized = '2d';
        }else if(normalized === 'bubble' && !allowBubble){
          normalized = '2d';
        }
        const changed = forceUpdate || scatterState.viewMode !== normalized;
        scatterState.viewMode = normalized;
        if(scatterViewMode){
          const displayValue = scatterState.requestedViewMode || normalized;
          if(scatterViewMode.value !== displayValue){
            scatterViewMode.value = displayValue;
          }
        }
        const disableLog = normalized === '3d' || scatterCurrentGraphType !== 'scatter';
        [scatterLogX, scatterLogY].forEach(cb => {
          if(!cb){ return; }
          cb.disabled = disableLog;
          if(disableLog && cb.checked){
            cb.checked = false;
          }
        });
        const disableRegression = normalized === '3d' || scatterCurrentGraphType !== 'scatter';
        if(scatterShowLine){
          scatterShowLine.disabled = disableRegression;
          if(disableRegression && scatterShowLine.checked){
            scatterShowLine.checked = false;
          }
        }
        if(scatterShowPlotStats){
          scatterShowPlotStats.disabled = disableRegression;
          if(disableRegression && scatterShowPlotStats.checked){
            scatterShowPlotStats.checked = false;
          }
        }
        // Update CI/PI enabled state and visual class
        try{ updateCIEnabled(); }catch(e){
          if(scatterShowCI){ scatterShowCI.disabled = disableRegression; if(disableRegression && scatterShowCI.checked){ scatterShowCI.checked = false; } }
          if(scatterShowPI){ scatterShowPI.disabled = disableRegression; if(disableRegression && scatterShowPI.checked){ scatterShowPI.checked = false; } }
        }
        if(normalized === '3d' && scatterShowFrame && !scatterShowFrame.checked){
          scatterShowFrame.checked = true;
        }
        updateScatterViewModeOptionVisibility();
        syncScatterAspectControls('view-mode-change');
        if(changed && !skipSchedule){
          scheduleScatterViewRefresh('view-mode-change');
        }
        if(normalized === '3d'){
          ensureScatterHeaderTitles(scatterRefs.hot || scatterHot, {
            graphType: scatterCurrentGraphType,
            tableFormat: getScatterReplicateMode(),
            viewMode: normalized
          });
        }
        return normalized;
      }
      function scheduleScatterRotationRedraw(){
        if(scatterState.rotationPending){
          if(!scatterState.rotationPendingLogged && typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
            console.debug('Debug: scatter rotation redraw skipped',{ reason: 'pending' });
          }
          scatterState.rotationPendingLogged = true;
          return;
        }
        scatterState.rotationPending = true;
        scatterState.rotationPendingLogged = false;
        if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
          console.debug('Debug: scatter rotation redraw scheduled');
        }
        scheduleDrawScatter({ viewOnly: true, reason: 'rotation' });
      }
      if(scatterViewMode){
        scatterViewMode.value = scatterState.viewMode;
        scatterViewMode.addEventListener('change', event => {
          const requested = scatterViewMode.value;
          const next = requested === '3d' ? '3d' : (requested === 'bubble' ? 'bubble' : '2d');
          if(event?.isTrusted && next === '3d' && scatterState.viewMode !== '3d'){
            resetScatterRotation('view-mode-change');
          }
          const applied = applyScatterViewMode(next, {
            allow3d: scatterCurrentGraphType === 'scatter',
            allowBubble: scatterCurrentGraphType === 'scatter',
            persistRequest: true
          });
          if(applied !== next){
            scatterViewMode.value = applied;
          }
          syncScatterColorModeUI(scatterColorModeApplied);
        });
      }
      let scatterLogWarningEl=null;
      const scatterDebugEnabled=()=>typeof Shared.isDebugEnabled==='function'&&Shared.isDebugEnabled();
      function ensureScatterLogWarningElement(){
        if(scatterLogWarningEl&&scatterLogWarningEl.isConnected){
          return scatterLogWarningEl;
        }
        const host=(scatterLogY?.closest('.config-panel__fieldset'))||(scatterLogX?.closest('fieldset'));
        if(!host){
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log warning host unavailable');
          }
          return null;
        }
        const el=global.document.createElement('div');
        el.className='config-panel__warning';
        el.setAttribute('role','alert');
        el.setAttribute('aria-live','polite');
        el.hidden=true;
        host.appendChild(el);
        scatterLogWarningEl=el;
        if(scatterDebugEnabled()){
          console.debug('Debug: scatter log warning element created');
        }
        return scatterLogWarningEl;
      }
      function showScatterLogWarning(message){
        const el=ensureScatterLogWarningElement();
        if(!el){
          return;
        }
        el.textContent=message;
        el.hidden=false;
        if(scatterDebugEnabled()){
          console.debug('Debug: scatter log warning shown',{ message });
        }
      }
      function clearScatterLogWarning(){
        if(!scatterLogWarningEl){
          return;
        }
        scatterLogWarningEl.textContent='';
        scatterLogWarningEl.hidden=true;
        if(scatterDebugEnabled()){
          console.debug('Debug: scatter log warning cleared');
        }
      }
      function applyScatterLogValidationFailure(axis, validation, context){
        if(!validation || validation.allowed !== false){
          return;
        }
        const checkbox = axis === 'x' ? scatterLogX : scatterLogY;
        if(checkbox){
          checkbox.checked = false;
        }
        const warningMessage = validation.message || `Cannot enable log scale on the ${axis === 'x' ? 'X' : 'Y'} axis while non-positive values are present.`;
        showScatterLogWarning(warningMessage);
        if(scatterDebugEnabled()){
          console.debug('Debug: scatter log axis auto-disabled',{ axis, context, reason: validation.reason, value: validation.value });
        }
        scheduleScatterViewRefresh(`log-validation-${axis}`);
      }
      function revalidateActiveScatterLogAxis(axis, context){
        const checkbox = axis === 'x' ? scatterLogX : scatterLogY;
        if(!checkbox?.checked){
          return true;
        }
        const validation = validateScatterLogAxis(axis);
        if(!validation.allowed){
          applyScatterLogValidationFailure(axis, validation, context);
          console.warn('scatter log axis disabled',{ axis, context, reason: validation.reason, value: validation.value });
          return false;
        }
        clearScatterLogWarning();
        return true;
      }
      function isScatterLogAxisInputInProgress(inputEl){
        if(!inputEl){
          return false;
        }
        const doc = inputEl.ownerDocument || global.document;
        if(doc.activeElement !== inputEl){
          return false;
        }
        const raw = String(inputEl.value ?? '').trim();
        if(raw === '' || raw === '-' || raw === '+'){
          return true;
        }
        if(/[.,]$/.test(raw)){
          return true;
        }
        if(/[eE]$/.test(raw) || /[eE][+-]$/.test(raw)){
          return true;
        }
        if(/^[-+]?0+(?:[.,]0*)?(?:[eE][+-]?\d*)?$/.test(raw)){
          return true;
        }
        return false;
      }
      function validateScatterLogAxis(axis){
        const axisLabel=axis==='x'?'X':'Y';
        const minInput=axis==='x'?scatterXMin:scatterYMin;
        const maxInput=axis==='x'?scatterXMax:scatterYMax;
        const originInput=axis==='x'?scatterOriginX:scatterOriginY;
        const manualMin=parseFloat(minInput?.value);
        if(Number.isFinite(manualMin)&&manualMin<=0){
          const message=`Cannot enable log scale on the ${axisLabel} axis because the minimum value (${manualMin}) is not positive.`;
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis blocked by manual minimum',{ axis, value: manualMin });
          }
          return{allowed:false,reason:'axis-limit',value:manualMin,message,hasZeros:manualMin===0,hasNegatives:manualMin<0};
        }
        const manualMax=parseFloat(maxInput?.value);
        if(Number.isFinite(manualMax)&&manualMax<=0){
          const message=`Cannot enable log scale on the ${axisLabel} axis because the maximum value (${manualMax}) is not positive.`;
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis blocked by manual maximum',{ axis, value: manualMax });
          }
          return{allowed:false,reason:'axis-limit',value:manualMax,message,hasZeros:manualMax===0,hasNegatives:manualMax<0};
        }
        const originModeValue=scatterOriginMode?.value;
        if(originModeValue==='custom'){
          const originVal=parseFloat(originInput?.value);
          if(Number.isFinite(originVal)&&originVal<=0){
            const message=`Cannot enable log scale on the ${axisLabel} axis because the custom origin (${originVal}) is not positive.`;
            if(scatterDebugEnabled()){
              console.debug('Debug: scatter log axis blocked by custom origin',{ axis, value: originVal });
            }
            return{allowed:false,reason:'origin',value:originVal,message,hasZeros:originVal===0,hasNegatives:originVal<0};
          }
        }
        const analysis=scatterHot?.getAnalysisData?.()||Shared.hot.getAnalysisData(scatterHot);
        const rowCount=analysis?.rowCount||0;
        const colCount=analysis?.colCount||0;
        const layout = resolveScatterColumnLayout(analysis?.data, colCount);
        const groupedScatterActiveY = axis === 'y' && isScatterGroupedMode({
          graphType: scatterCurrentGraphType,
          tableFormat: getScatterReplicateMode()
        }) && !!layout?.grouped;
        const groupedScatterActiveX = axis === 'x' && isScatterGroupedMode({
          graphType: scatterCurrentGraphType,
          tableFormat: getScatterReplicateMode()
        }) && !!layout?.grouped;
        const candidateCols = axis === 'x'
          ? (groupedScatterActiveX ? (layout?.xCols || [layout?.xCol]) : [layout?.xCol])
          : (groupedScatterActiveY
            ? (layout.groups || []).reduce((acc, group) => {
                for(let col = group.startCol; col <= group.endCol; col += 1){
                  acc.push(col);
                }
                return acc;
              }, [])
            : [layout?.yCol]);
        const axisColumns = candidateCols
          .filter(col => Number.isInteger(col) && col >= 0 && col < colCount)
          .filter((col, idx, list) => list.indexOf(col) === idx);
        if(!analysis||!axisColumns.length){
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis validation skipped due to missing analysis',{
              axis,
              hasAnalysis:!!analysis,
              axisColumns,
              colCount
            });
          }
          return{allowed:true};
        }
        const includedAxisColumns = axisColumns.filter(col => !analysis.isColumnExcluded?.(col));
        if(!includedAxisColumns.length){
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis validation blocked because all axis columns are excluded',{
              axis,
              axisColumns
            });
          }
          const message = axis === 'y' && groupedScatterActiveY
            ? `Restore at least one grouped ${axisLabel} axis column before enabling log scale.`
            : axis === 'x' && groupedScatterActiveX
              ? `Restore at least one grouped ${axisLabel} axis column before enabling log scale.`
            : `Restore the ${axisLabel} axis column before enabling log scale.`;
          return{allowed:false,reason:'excluded',message};
        }
        let hasZeros=false;
        let hasNegatives=false;
        let firstZeroRow=null;
        let firstNegativeRow=null;
        let firstNegativeValue=null;
        let firstNegativeCol=null;
        let firstZeroCol=null;
        for(let r=1;r<rowCount;r+=1){
          if(analysis.isRowExcluded?.(r)){
            continue;
          }
          for(let colIdx = 0; colIdx < includedAxisColumns.length; colIdx += 1){
            const colIndex = includedAxisColumns[colIdx];
            const raw=analysis.data?.[r]?.[colIndex];
            if(raw===null||typeof raw==='undefined'||raw===''){
              continue;
            }
            const value=parseFloat(raw);
            if(Number.isFinite(value)){
              if(value<0){
                hasNegatives=true;
                if(firstNegativeRow===null){
                  firstNegativeRow=r;
                  firstNegativeCol=colIndex;
                  firstNegativeValue=value;
                }
              }else if(value===0){
                hasZeros=true;
                if(firstZeroRow===null){
                  firstZeroRow=r;
                  firstZeroCol=colIndex;
                }
              }
            }
          }
        }
        if(hasNegatives){
          const formatted=firstNegativeValue.toPrecision(4);
          const groupedColumnDetail = ((axis === 'y' && groupedScatterActiveY) || (axis === 'x' && groupedScatterActiveX)) && Number.isInteger(firstNegativeCol)
            ? ` (column ${firstNegativeCol + 1})`
            : '';
          const message=`Cannot enable log scale on the ${axisLabel} axis because data includes ${formatted} at row ${firstNegativeRow+1}${groupedColumnDetail}.`;
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis blocked by negative data',{
              axis,
              row:firstNegativeRow,
              col:firstNegativeCol,
              value:firstNegativeValue
            });
          }
          return{allowed:false,reason:'data',value:firstNegativeValue,message,hasZeros,hasNegatives:true};
        }
        if(hasZeros){
          const message=`Data contains zero values on the ${axisLabel} axis. Would you like to use log(x+1) transform instead?`;
          if(scatterDebugEnabled()){
            console.debug('Debug: scatter log axis has zeros',{ axis, row:firstZeroRow, col:firstZeroCol });
          }
          return{allowed:false,reason:'zeros',value:0,message,hasZeros:true,hasNegatives:false,canUsePlusOne:true};
        }
        if(scatterDebugEnabled()){
          console.debug('Debug: scatter log axis validation passed',{ axis });
        }
        return{allowed:true};
      }
      const scatterUndoManager = Shared.undoManager || null;
      function recordScatterChange(label, previous, next, apply){
        if(!scatterUndoManager || typeof scatterUndoManager.recordStateChange !== 'function'){
          return;
        }
        if(typeof apply !== 'function'){
          return;
        }
        scatterUndoManager.recordStateChange({
          label,
          scope: 'scatterGraphPanel',
          from: previous,
          to: next,
          apply(value){
            apply(value);
            return true;
          }
        });
      }
      function syncScatterColorModeUI(appliedMode = scatterColorModeApplied){
        const type = scatterGraphTypeSelect?.value || 'scatter';
        const isScatter = type === 'scatter';
        const viewMode = scatterState?.viewMode || '2d';
        if(scatterColorMode){
          const normalizedMode = normalizeScatterColorMode(scatterColorMode.value);
          if(scatterColorMode.value !== normalizedMode){
            scatterColorMode.value = normalizedMode;
          }
          scatterColorMode.disabled = !isScatter;
        }
        if(scatterDensityPalette){
          const paletteKey = normalizeScatterDensityPalette(scatterDensityPalette.value);
          if(scatterDensityPalette.value !== paletteKey){
            scatterDensityPalette.value = paletteKey;
          }
          scatterDensityPalette.disabled = !isScatter;
        }
        const paletteRow = scatterDensityPaletteRow || scatterDensityPalette?.closest('.config-panel__item');
        const desiredMode = scatterColorMode ? normalizeScatterColorMode(scatterColorMode.value) : SCATTER_DENSITY_MODE_DEFAULT;
        const paletteVisible = isScatter && viewMode !== '3d' && (desiredMode === 'density' || desiredMode === 'auto');
        if(paletteRow){
          paletteRow.style.display = paletteVisible ? '' : 'none';
        }
        if(scatterColorModeRow){
          scatterColorModeRow.style.display = isScatter ? '' : 'none';
        }
        if(scatterFill){
          const disableFill = isScatter && appliedMode === 'density' && viewMode !== '3d';
          scatterFill.disabled = disableFill;
          scatterFill.title = disableFill ? 'Fill color is controlled by density in this mode.' : '';
        }
      }
      function syncScatterGraphTypeUI(){
        const graphTypeControl = getScatterNodeById('scatterGraphType') || scatterGraphTypeSelect;
        const showLineControl = getScatterNodeById('scatterShowLine') || scatterShowLine;
        const showPlotStatsControl = getScatterNodeById('scatterShowPlotStats') || scatterShowPlotStats;
        const showCIControl = getScatterNodeById('scatterShowCI') || scatterShowCI;
        const showPIControl = getScatterNodeById('scatterShowPI') || scatterShowPI;
        const statTypeControl = getScatterNodeById('scatterStatType') || scatterStatType;
        const regressionModeControl = getScatterNodeById('scatterRegressionMode') || scatterRegressionMode;
        const type=graphTypeControl?.value || 'scatter';
        scatterCurrentGraphType=type;
        const requestedTableFormat = normalizeScatterTableFormat((getScatterNodeById('scatterTableFormat') || scatterTableFormatSelect)?.value || scatterTableFormat);
        const effectiveTableFormat = type === 'scatter' ? requestedTableFormat : SCATTER_TABLE_FORMAT_SINGLE;
        if(scatterTableFormat !== effectiveTableFormat){
          applyScatterTableFormatMode(effectiveTableFormat, { graphType: type, skipDraw: true, keepCollapsed: true });
        }else{
          scatterTableFormat = effectiveTableFormat;
          if(scatterTableFormatSelect && scatterTableFormatSelect.value !== effectiveTableFormat){
            scatterTableFormatSelect.value = effectiveTableFormat;
          }
          updateScatterReplicateModeControls(effectiveTableFormat);
          updateScatterNestedHeaders(scatterHot || scatterRefs.hot, {
            graphType: type,
            tableFormat: effectiveTableFormat
          });
        }
        const showThresholds=type!=='scatter';
        if(showThresholds){
          clearScatterLogWarning();
        }
        if(scatterThresholdControls){
          scatterThresholdControls.style.display=showThresholds?'flex':'none';
        }
        if(scatterSignificantOptions){
          scatterSignificantOptions.style.display = (type === 'volcano' || type === 'ma') ? 'flex' : 'none';
        }
        if(scatterShowSignificantLabels){
          scatterShowSignificantLabels.disabled = type !== 'volcano' && type !== 'ma';
        }
        if((type === 'volcano' || type === 'ma') && scatterShowSignificantLabels?.checked){
          markScatterThresholdSelectionPending('graph-type-ui');
        }
        if(scatterViewControls){
          scatterViewControls.style.display = type === 'scatter' ? 'flex' : 'none';
        }
        [scatterLogX,scatterLogY].forEach(el=>{
          if(!el) return;
          el.disabled=type!=='scatter';
          if(type!=='scatter' && el.checked){
            el.checked=false;
          }
        });
        if(statTypeControl){
          statTypeControl.disabled=type!=='scatter';
        }
        if(regressionModeControl){
          regressionModeControl.disabled=type!=='scatter';
        }
        const disableRegressionControls = type !== 'scatter';
        if(showLineControl){
          showLineControl.disabled=disableRegressionControls;
          if(disableRegressionControls && showLineControl.checked){
            showLineControl.checked=false;
          }
        }
        if(showPlotStatsControl){
          showPlotStatsControl.disabled=disableRegressionControls;
          if(disableRegressionControls && showPlotStatsControl.checked){
            showPlotStatsControl.checked=false;
          }
        }
        // Update CI/PI enabled state and visual class
        try{ updateCIEnabled(); }catch(e){
          if(showCIControl){ showCIControl.disabled = disableRegressionControls; if(disableRegressionControls && showCIControl.checked){ showCIControl.checked = false; } }
          if(showPIControl){ showPIControl.disabled = disableRegressionControls; if(disableRegressionControls && showPIControl.checked){ showPIControl.checked = false; } }
        }
        const significanceColors = getScatterSignificanceColors();
        if(type!=='scatter' && scatterFill && scatterFill.value && scatterFill.value.toLowerCase()===getScatterPrimaryFillColor()){
          scatterFill.value=significanceColors.neutral;
        }
        if(type!==scatterLastGraphType){
          const defaults=GRAPH_TYPE_DEFAULTS[type];
          if(defaults && defaults.title){
            scatterTitleText=defaults.title;
          }
          scatterLastGraphType=type;
        }
        renderScatterStatsAdvisor(null, buildScatterAdvisorContext([]));
        syncScatterRegressionOptionVisibility();
        syncScatterColorModeUI(scatterColorModeApplied);
        console.debug('Debug: syncScatterGraphTypeUI complete',{type,showThresholds});
        if(scatterViewMode){
          if(type !== 'scatter'){
            scatterState.supports3d = false;
            scatterState.supportsBubble = false;
            applyScatterViewMode('2d', { allow3d: false, allowBubble: false, skipSchedule: true, forceUpdate: true });
          } else {
            updateScatterViewModeOptionVisibility();
            const targetMode = scatterState.requestedViewMode || scatterState.viewMode || '2d';
            applyScatterViewMode(targetMode, {
              skipSchedule: true,
              forceUpdate: true,
              allow3d: true,
              allowBubble: true,
              persistRequest: true
            });
          }
        }
        syncScatterColorModeUI(scatterColorModeApplied);
        syncScatterErrorBarControls(effectiveTableFormat);
      }

      function buildScatterAdvisorContext(points, overrides){
        const context={
          graphType: scatterCurrentGraphType,
          statsMethod: scatterStatType?.value || 'auto',
          regressionMode: scatterRegressionMode?.value || 'linear',
          fitMethod: scatterFitMethod?.value || 'ols',
          showLine: !!scatterShowLine?.checked,
          showLineStats: !!scatterShowPlotStats?.checked,
          showCI: !!(scatterShowLine && scatterShowCI && scatterShowCI.checked),
          showPI: !!(scatterShowLine && scatterShowPI && scatterShowPI.checked),
          showIntervals: !!(scatterShowLine && ((scatterShowCI && scatterShowCI.checked) || (scatterShowPI && scatterShowPI.checked))),
          showDiagnostics: isScatterDiagnosticsEnabled(),
          logX: !!scatterLogX?.checked,
          logY: !!scatterLogY?.checked
        };
        const finitePoints=Array.isArray(points)?points.filter(pt=>Number.isFinite(pt?.x)&&Number.isFinite(pt?.y)):[];
        context.pointCount=finitePoints.length;
        const xUnique=new Set();
        const yUnique=new Set();
        const monotonicSigns=new Set();
        let approxBinary=true;
        let bounded01=true;
        let prevPoint=null;
        const yValues=[];
        const xValues=[];
        let xMin=Infinity,xMax=-Infinity,yMin=Infinity,yMax=-Infinity;
        finitePoints.forEach(pt=>{
          const x=pt.x;
          const y=pt.y;
          if(x<xMin) xMin=x;
          if(x>xMax) xMax=x;
          if(y<yMin) yMin=y;
          if(y>yMax) yMax=y;
          if(xUnique.size<400 && Number.isFinite(x)){
            xUnique.add(Number(x.toFixed(6)));
          }
          if(yUnique.size<400 && Number.isFinite(y)){
            yUnique.add(Number(y.toFixed(6)));
          }
          if(!(y===0 || y===1)){
            approxBinary=false;
          }
          if(y<0 || y>1){
            bounded01=false;
          }
          if(prevPoint){
            const dx=x-prevPoint.x;
            const dy=y-prevPoint.y;
            if(Number.isFinite(dx) && dx!==0 && Number.isFinite(dy)){
              if(dy>0){ monotonicSigns.add('pos'); }
              else if(dy<0){ monotonicSigns.add('neg'); }
            }
          }
          prevPoint=pt;
          xValues.push(x);
          yValues.push(y);
        });
        if(finitePoints.length){
          context.xMin=xMin;
          context.xMax=xMax;
          context.yMin=yMin;
          context.yMax=yMax;
        }
        context.xUniqueCount=xUnique.size;
        context.yUniqueCount=yUnique.size;
        context.approxBinaryY=approxBinary && yUnique.size<=2;
        context.yWithinZeroOne=bounded01;
        context.monotonicSigns=monotonicSigns;
        context.xSortedAscending = xValues.every((value, index) => index === 0 || value >= xValues[index - 1]);
        context.hasReplicateX = hasScatterDuplicateValues(xValues.map(value => Number(value).toFixed(10)));
        context.groupedSeriesCount = Array.isArray(scatterState?.statsContext?.groupedSeries) ? scatterState.statsContext.groupedSeries.length : 0;
        if(yValues.length>3){
          const yMean=yValues.reduce((sum,val)=>sum+val,0)/yValues.length;
          const yVar=yValues.reduce((sum,val)=>sum+Math.pow(val-yMean,2),0)/Math.max(1,yValues.length-1);
          const yStd=Math.sqrt(Math.max(yVar,0));
          context.yStd=yStd;
          if(yStd>0){
            context.yOutlierCount=yValues.reduce((count,val)=>count+(Math.abs((val-yMean)/yStd)>3?1:0),0);
          }else{
            context.yOutlierCount=0;
          }
        }else{
          context.yStd=NaN;
          context.yOutlierCount=0;
        }
        if(xValues.length>3){
          const xMean=xValues.reduce((sum,val)=>sum+val,0)/xValues.length;
          const xVar=xValues.reduce((sum,val)=>sum+Math.pow(val-xMean,2),0)/Math.max(1,xValues.length-1);
          context.xStd=Math.sqrt(Math.max(xVar,0));
        }else{
          context.xStd=NaN;
        }
        return overrides ? { ...context, ...overrides } : context;
      }

      function ensureScatterAdvisorDefaults(context){
        const answers=scatterAdvisorState.answers || {};
        if(!answers.analysisGoal){
          answers.analysisGoal='modelAndAssociation';
        }
        if(!answers.regressionModel){
          if(context.graphType!=='scatter'){
            answers.regressionModel='linear';
          }else{
            answers.regressionModel=context.regressionMode || 'linear';
          }
        }
        if(!answers.fitPreference){
          const currentFit = normalizeScatterFitMethod(context.fitMethod || 'ols');
          const currentFamily = getScatterFitMethodFamily(currentFit);
          if(currentFamily === 'wls'){
            answers.fitPreference='weighted';
          }else if(currentFamily === 'huber'){
            answers.fitPreference='robust';
          }else{
            answers.fitPreference='standard';
          }
        }
        if(!answers.associationPreference){
          const currentAssociation = normalizeScatterAssociationSelection(context.statsMethod || 'auto');
          if(currentAssociation === 'pearson'){
            answers.associationPreference='pearson';
          }else if(currentAssociation === 'spearman'){
            answers.associationPreference='spearman';
          }else{
            answers.associationPreference='automatic';
          }
        }
        if(!answers.xError){
          answers.xError = (context.regressionMode === 'deming' || context.regressionMode === 'orthogonal') ? 'yes' : 'no';
        }
        if(!answers.lineDetail){
          if(context.showDiagnostics){
            answers.lineDetail='diagnostics';
          }else if(context.showIntervals){
            answers.lineDetail='intervals';
          }else if(context.showLine){
            answers.lineDetail='minimal';
          }else{
            answers.lineDetail='hide';
          }
        }
        scatterAdvisorState.answers=answers;
        return answers;
      }

      function buildScatterAdvisorQuestions(context){
        if(context.graphType!=='scatter'){
          return [];
        }
        return [
          {
            id:'analysisGoal',
            prompt:'What is your primary analysis objective?',
            help:'This controls whether the report emphasizes model fitting, association statistics, or both.',
            options:[
              { value:'modelAndAssociation', label:'Model fit + association summary' },
              { value:'modelOnly', label:'Model fit only (parameters/diagnostics)' },
              { value:'associationOnly', label:'Association summary only (no fitted curve)' }
            ]
          },
          {
            id:'regressionModel',
            prompt:'Which regression model best matches your mechanism?',
            help:'Choose the mechanistic model first. Fit method options are constrained by model support.',
            options:[
              { value:'linear', label:'Linear' },
              { value:'linearThroughOrigin', label:'Linear (through origin)' },
              { value:'deming', label:'Deming regression' },
              { value:'orthogonal', label:'Orthogonal regression' },
              { value:'lowess', label:'LOWESS smoothing' },
              { value:'quadratic', label:'Polynomial (quadratic)' },
              { value:'cubic', label:'Polynomial (cubic)' },
              { value:'logistic', label:'Logistic / Dose-response (auto)' },
              { value:'doseResponse3pl', label:'3PL dose-response' },
              { value:'doseResponse4pl', label:'4PL dose-response (IC50)' },
              { value:'doseResponse5pl', label:'5PL dose-response (asymmetric)' },
              { value:'exponential', label:'Exponential' },
              { value:'onePhaseAssociation', label:'One-phase association' },
              { value:'onePhaseDecay', label:'One-phase decay' },
              { value:'gompertz', label:'Gompertz growth' },
              { value:'power', label:'Power' },
              { value:'gaussian', label:'Gaussian' },
              { value:'spline', label:'Spline' },
              { value:'bindingSaturation', label:'Binding - saturation' },
              { value:'bindingCompetitive', label:'Binding - competitive' },
              { value:'enzymeKineticsSubstrate', label:'Enzyme kinetics - substrate' },
              { value:'enzymeKineticsInhibition', label:'Enzyme kinetics - inhibition' }
            ]
          },
          {
            id:'xError',
            prompt:'Does X have meaningful measurement error?',
            help:'Choose “yes” for assay-comparison or calibration workflows where both axes are measured with uncertainty.',
            options:[
              { value:'no', label:'No, treat X as measured without important error' },
              { value:'yes', label:'Yes, both X and Y have meaningful measurement error' }
            ]
          },
          {
            id:'fitPreference',
            prompt:'How should the fit handle variance and outliers?',
            help:'Use weighted or robust fitting only when justified; unsupported choices automatically fall back.',
            options:[
              { value:'standard', label:'Standard least squares (OLS)' },
              { value:'weighted', label:'Weighted least squares (WLS)' },
              { value:'robust', label:'Robust fit (Huber)' }
            ]
          },
          {
            id:'associationPreference',
            prompt:'Which association metric should be reported?',
            help:'Association metrics are optional and do not change fitted regression parameters.',
            options:[
              { value:'automatic', label:'Automatic (recommended)' },
              { value:'pearson', label:'Pearson (linear association)' },
              { value:'spearman', label:'Spearman (rank association)' }
            ]
          },
          {
            id:'lineDetail',
            prompt:'How much model output should be shown on the plot?',
            help:'This controls trend line visibility and optional uncertainty/diagnostics overlays.',
            options:[
              { value:'minimal', label:'Show fitted line only' },
              { value:'intervals', label:'Include confidence/prediction intervals' },
              { value:'diagnostics', label:'Include intervals and diagnostics summary' },
              { value:'hide', label:'Do not draw a trend line' }
            ]
          }
        ];
      }

      function computeScatterAdvisorRecommendation(answers, context){
        const recommendation={
          ready:false,
          message:'',
          summary:'',
          rationale:[],
          warnings:[],
          statsMethod:context.statsMethod || 'auto',
          regression:context.regressionMode || 'linear',
          fitMethod:context.fitMethod || 'ols',
          showLine:context.showLine,
          showLineStats:context.showLineStats,
          showIntervals:context.showIntervals,
          showDiagnostics:context.showDiagnostics
        };
        if(context.graphType!=='scatter'){
          recommendation.message='Switch the graph type to “Scatter Plot” to access correlation and regression guidance.';
          return recommendation;
        }
        if(!answers.analysisGoal || !answers.regressionModel || !answers.fitPreference || !answers.associationPreference || !answers.lineDetail || !answers.xError){
          recommendation.message='Answer the advisor questions to receive a recommendation.';
          return recommendation;
        }
        const modelSelection = String(answers.regressionModel || 'linear').trim();
        const modelInfo = regressionTools && typeof regressionTools.getModelInfo === 'function'
          ? regressionTools.getModelInfo(modelSelection)
          : null;
        const knownByPolicy = !!SCATTER_REGRESSION_METHOD_POLICY[modelSelection];
        recommendation.regression = modelInfo?.id || modelSelection || 'linear';
        if(!modelInfo && !knownByPolicy && recommendation.regression !== 'linear'){
          recommendation.warnings.push(`Selected model "${recommendation.regression}" is not recognized; using linear regression.`);
          recommendation.regression = 'linear';
        }
        const regressionPolicy = resolveScatterRegressionPolicy(recommendation.regression);
        const fitPreferenceMap = {
          standard: 'ols',
          weighted: 'wls_y2',
          robust: 'huber'
        };
        let fitMethodCandidate = fitPreferenceMap[answers.fitPreference] || 'ols';
        const allowedFitMethods = Array.isArray(regressionPolicy?.fitMethods) && regressionPolicy.fitMethods.length
          ? regressionPolicy.fitMethods.map(normalizeScatterFitMethod)
          : ['ols'];
        if(!allowedFitMethods.includes(fitMethodCandidate)){
          const fallbackFitMethod = allowedFitMethods[0] || 'ols';
          recommendation.warnings.push(`Selected fit strategy is not supported for ${getScatterRegressionModeLabel(recommendation.regression)} and was changed to ${getScatterFitMethodLabel(fallbackFitMethod)}.`);
          fitMethodCandidate = fallbackFitMethod;
        }
        recommendation.fitMethod = fitMethodCandidate;
        recommendation.rationale.push(`Regression model set to ${getScatterRegressionModeLabel(recommendation.regression)}.`);
        recommendation.rationale.push(`Fit method set to ${getScatterFitMethodLabel(recommendation.fitMethod)}.`);
        if(regressionPolicy?.fitGuidance){
          recommendation.rationale.push(regressionPolicy.fitGuidance);
        }
        if(String(answers.xError || 'no') === 'yes'){
          if(recommendation.regression === 'linear' || recommendation.regression === 'linearThroughOrigin'){
            recommendation.regression = 'deming';
            recommendation.fitMethod = 'ols';
            recommendation.rationale.push('Deming regression was selected because both X and Y are reported as error-prone.');
          }else if(recommendation.regression !== 'deming' && recommendation.regression !== 'orthogonal'){
            recommendation.warnings.push('You indicated meaningful X error. Consider Deming regression if the scientific question is method comparison rather than mechanistic curve fitting.');
          }
        }
        const associationPreference = String(answers.associationPreference || 'automatic').trim().toLowerCase();
        if(answers.analysisGoal === 'modelOnly'){
          recommendation.statsMethod = 'none';
          recommendation.rationale.push('Association statistics are disabled to focus on parameter estimation and diagnostics.');
        }else if(associationPreference === 'pearson'){
          recommendation.statsMethod = 'pearson';
          recommendation.rationale.push('Pearson association was selected for linear-scale association reporting.');
        }else if(associationPreference === 'spearman'){
          recommendation.statsMethod = 'spearman';
          recommendation.rationale.push('Spearman association was selected for rank-based, outlier-robust reporting.');
        }else{
          recommendation.statsMethod = 'auto';
          recommendation.rationale.push('Association metric is set to automatic so the report follows model-aware defaults.');
        }
        if(answers.analysisGoal === 'associationOnly'){
          recommendation.showLine = false;
          recommendation.showIntervals = false;
          recommendation.showDiagnostics = false;
          recommendation.showLineStats = false;
          recommendation.rationale.push('Trend-line outputs are disabled because association-only analysis was selected.');
        }else{
          switch(answers.lineDetail){
            case 'minimal':
              recommendation.showLine = true;
              recommendation.showIntervals = false;
              recommendation.showDiagnostics = false;
              recommendation.showLineStats = false;
              recommendation.rationale.push('Fitted curve is shown without additional overlays.');
              break;
            case 'intervals':
              recommendation.showLine = true;
              recommendation.showIntervals = recommendation.regression !== 'spline';
              recommendation.showDiagnostics = false;
              recommendation.showLineStats = false;
              recommendation.rationale.push('Interval overlays are enabled to show prediction uncertainty.');
              if(recommendation.regression === 'spline'){
                recommendation.warnings.push('Interval shading is unavailable for spline fits and remains disabled.');
              }
              break;
            case 'diagnostics':
              recommendation.showLine = true;
              recommendation.showIntervals = recommendation.regression !== 'spline';
              recommendation.showDiagnostics = true;
              recommendation.showLineStats = true;
              recommendation.rationale.push('Diagnostics and interval overlays are enabled for assumption checking.');
              if(recommendation.regression === 'spline'){
                recommendation.warnings.push('Interval shading is unavailable for spline fits and remains disabled.');
              }
              break;
            case 'hide':
              recommendation.showLine = false;
              recommendation.showIntervals = false;
              recommendation.showDiagnostics = false;
              recommendation.showLineStats = false;
              recommendation.rationale.push('Trend overlays are hidden.');
              break;
            default:
              break;
          }
        }
        if((recommendation.regression === 'logistic' || recommendation.regression === 'doseResponse4pl') && !context.approxBinaryY && !context.yWithinZeroOne){
          recommendation.warnings.push('Non-binary responses in logistic/dose-response mode can yield extrapolated IC50 estimates outside the tested X range.');
        }
        if(recommendation.regression === 'power' && Number.isFinite(context.xMin) && context.xMin <= 0){
          recommendation.warnings.push('Power regression is unstable with non-positive X values; consider transforming data or selecting a different model.');
        }
        if(context.pointCount > 0 && context.pointCount < 6){
          recommendation.warnings.push('With fewer than six paired observations, nonlinear model diagnostics can be unstable.');
        }
        if(!context.xSortedAscending){
          recommendation.warnings.push('X values are not sorted. Order-sensitive diagnostics and AUC are reported after sorting by X, which should be stated in the methods if relevant.');
        }
        if(context.hasReplicateX){
          recommendation.warnings.push('Replicate X values are present. Lack-of-fit style diagnostics are more informative when replicate structure is preserved.');
        }
        if(context.groupedSeriesCount > 1){
          if(canScatterUseGroupedGlobalFit(recommendation.regression)){
            recommendation.rationale.push('Multiple series are present, so separate fits should be compared against common-curve and shared-parameter global fits when a shared biological mechanism is plausible.');
          }else{
            recommendation.rationale.push('Multiple series are present, so grouped line-comparison statistics should be inspected in addition to per-series fits.');
          }
        }
        const resolvedAssociationLabel = recommendation.statsMethod === 'none'
          ? 'None (model fit only)'
          : (recommendation.statsMethod === 'auto'
            ? `Automatic (${getScatterAssociationMethodLabel(resolveScatterAssociationMethod('auto', recommendation.regression))})`
            : getScatterAssociationMethodLabel(recommendation.statsMethod));
        const regressionLabel = getScatterRegressionModeLabel(recommendation.regression);
        const fitLabel = getScatterFitMethodLabel(recommendation.fitMethod);
        if(answers.analysisGoal === 'associationOnly'){
          recommendation.summary = `${resolvedAssociationLabel} association summary without fitted regression overlays.`;
        }else if(recommendation.showLine){
          recommendation.summary = `${regressionLabel} using ${fitLabel}; association: ${resolvedAssociationLabel}.`;
        }else{
          recommendation.summary = `${regressionLabel} configured with overlays hidden; association: ${resolvedAssociationLabel}.`;
        }
        recommendation.ready=true;
        return recommendation;
      }

      function renderScatterStatsAdvisor(points, providedContext){
        const container=getScatterNodeById('scatterStatsAdvisor');
        if(!container){
          return;
        }
        const shouldCompute = scatterAdvisorState.activated;
        const hasProvided = providedContext && typeof providedContext === 'object';
        const context = hasProvided
          ? providedContext
          : (shouldCompute ? buildScatterAdvisorContext(points||[]) : buildScatterAdvisorContext([]));
        if(!shouldCompute && Array.isArray(points)){
          scatterAdvisorState.pendingPoints = points;
        }
        scatterAdvisorState.context=context;
        const answers=ensureScatterAdvisorDefaults(context);
        const recommendation=computeScatterAdvisorRecommendation(answers, context);
        container.innerHTML='';
        const wrapper=document.createElement('div');
        wrapper.className='stats-advisor';
        wrapper.dataset.open=scatterAdvisorState.open?'1':'0';
        const header=document.createElement('div');
        header.className='stats-advisor__header';
        const title=document.createElement('strong');
        title.textContent='Statistics advisor';
        header.appendChild(title);
        const toggle=document.createElement('button');
        toggle.type='button';
        toggle.className='stats-advisor__toggle';
        toggle.textContent=scatterAdvisorState.open?'Hide advisor':'Guide me';
        toggle.addEventListener('click',()=>{
          scatterAdvisorState.open=!scatterAdvisorState.open;
          if(scatterAdvisorState.open && !scatterAdvisorState.activated){
            scatterAdvisorState.activated=true;
            const pendingPoints = scatterAdvisorState.pendingPoints;
            scatterAdvisorState.pendingPoints = null;
            console.debug('Debug: scatter statsAdvisor activated');
            renderScatterStatsAdvisor(pendingPoints || null, pendingPoints ? null : scatterAdvisorState.context);
            return;
          }
          console.debug('Debug: scatter statsAdvisor toggled',{ open:scatterAdvisorState.open });
          renderScatterStatsAdvisor(null, scatterAdvisorState.context);
        });
        header.appendChild(toggle);
        wrapper.appendChild(header);
        const summary=document.createElement('div');
        summary.className='stats-advisor__summary';
        if(!scatterAdvisorState.activated){
          const message=document.createElement('div');
          message.textContent='Press the "Guide me" button to view advisor recommendations.';
          summary.appendChild(message);
        }else if(recommendation.ready){
          const summaryLine=document.createElement('div');
          summaryLine.className='stats-advisor__summary-line';
          summaryLine.textContent=`Recommendation: ${recommendation.summary}`;
          summary.appendChild(summaryLine);
          if(Array.isArray(recommendation.rationale) && recommendation.rationale.length){
            const list=document.createElement('ul');
            list.className='stats-advisor__rationale';
            recommendation.rationale.forEach(item=>{
              const li=document.createElement('li');
              li.textContent=item;
              list.appendChild(li);
            });
            summary.appendChild(list);
          }
          if(Array.isArray(recommendation.warnings) && recommendation.warnings.length){
            const warnTitle=document.createElement('div');
            warnTitle.className='stats-advisor__warnings-title';
            warnTitle.textContent='Cautions:';
            summary.appendChild(warnTitle);
            const warnList=document.createElement('ul');
            warnList.className='stats-advisor__warnings';
            recommendation.warnings.forEach(item=>{
              const li=document.createElement('li');
              li.textContent=item;
              warnList.appendChild(li);
            });
            summary.appendChild(warnList);
          }
        }else{
          const message=document.createElement('div');
          message.textContent=recommendation.message || 'Answer the advisor questions to receive a recommendation.';
          summary.appendChild(message);
        }
        wrapper.appendChild(summary);
        if(scatterAdvisorState.open){
          if(context.graphType==='scatter'){
            const questionsWrap=document.createElement('div');
            questionsWrap.className='stats-advisor__questions';
            const questions=buildScatterAdvisorQuestions(context);
            questions.forEach(question=>{
              const fieldset=document.createElement('fieldset');
              fieldset.className='stats-advisor__question';
              const legend=document.createElement('legend');
              legend.textContent=question.prompt;
              fieldset.appendChild(legend);
              if(question.help){
                const hint=document.createElement('p');
                hint.className='stats-advisor__hint';
                hint.textContent=question.help;
                fieldset.appendChild(hint);
              }
              (question.options||[]).forEach(option=>{
                const label=document.createElement('label');
                label.className='stats-advisor__option';
                const input=document.createElement('input');
                input.type='radio';
                input.name=`scatter-advisor-${question.id}`;
                input.value=option.value;
                input.checked=answers[question.id]===option.value;
                input.addEventListener('change',()=>{
                  answers[question.id]=option.value;
                  scatterAdvisorState.answers=answers;
                  console.debug('Debug: scatter statsAdvisor answer change',{ question:question.id, value:option.value });
                  renderScatterStatsAdvisor(null, scatterAdvisorState.context);
                });
                const span=document.createElement('span');
                span.textContent=option.label;
                label.appendChild(input);
                label.appendChild(span);
                fieldset.appendChild(label);
              });
              questionsWrap.appendChild(fieldset);
            });
            wrapper.appendChild(questionsWrap);
            const actions=document.createElement('div');
            actions.className='stats-advisor__actions';
            const applyBtn=document.createElement('button');
            applyBtn.type='button';
            applyBtn.textContent='Apply recommendation';
            applyBtn.disabled=!recommendation.ready;
            applyBtn.addEventListener('click',()=>{
              if(!recommendation.ready){
                return;
              }
              if(scatterRegressionMode){
                scatterRegressionMode.value=recommendation.regression;
              }
              syncScatterRegressionOptionVisibility();
              if(scatterFitMethod){
                const preferredFit = normalizeScatterFitMethod(recommendation.fitMethod || 'ols');
                const fitOption = Array.from(scatterFitMethod.options || []).find(option => normalizeScatterFitMethod(option.value) === preferredFit);
                if(fitOption && !fitOption.disabled){
                  scatterFitMethod.value = preferredFit;
                }
              }
              if(scatterStatType){
                scatterStatType.value=normalizeScatterAssociationSelection(recommendation.statsMethod || 'auto');
              }
              if(scatterShowLine){
                scatterShowLine.checked=!!recommendation.showLine || !!recommendation.showIntervals;
              }
              if(scatterShowPlotStats && typeof recommendation.showLineStats === 'boolean'){
                scatterShowPlotStats.checked=recommendation.showLineStats;
              }
              if(scatterShowCI){
                scatterShowCI.checked = !!recommendation.showIntervals;
              }
              if(scatterShowPI){
                scatterShowPI.checked = !!recommendation.showIntervals;
              }
              try{
                updateCIEnabled();
              }catch(err){}
              scatterAdvisorState.lastApplied={ ...recommendation };
              console.debug('Debug: scatter statsAdvisor applied',{
                statsMethod:recommendation.statsMethod,
                regression:recommendation.regression,
                fitMethod:recommendation.fitMethod,
                showLine:recommendation.showLine,
                showIntervals:recommendation.showIntervals,
                showDiagnostics:recommendation.showDiagnostics,
                answers:{ ...answers }
              });
              persistTabState('stats-advisor-apply');
              scheduleScatterViewRefresh('stats-advisor-apply');
              renderScatterStatsAdvisor(null, scatterAdvisorState.context);
              requestScatterStatsContextRefresh('stats-advisor-apply');
            });
            actions.appendChild(applyBtn);
            const resetBtn=document.createElement('button');
            resetBtn.type='button';
            resetBtn.className='stats-advisor__reset';
            resetBtn.textContent='Reset answers';
            resetBtn.addEventListener('click',()=>{
              scatterAdvisorState.answers={};
              console.debug('Debug: scatter statsAdvisor reset');
              renderScatterStatsAdvisor(null, scatterAdvisorState.context);
            });
            actions.appendChild(resetBtn);
            wrapper.appendChild(actions);
          }else{
            const hint=document.createElement('div');
            hint.className='stats-advisor__hint';
            hint.textContent='Switch to the scatter plot type to receive analysis and regression recommendations.';
            wrapper.appendChild(hint);
          }
        }
        container.appendChild(wrapper);
      }
      scatterAlphaVal.textContent=scatterAlpha.value;
      renderScatterStatsAdvisor([], buildScatterAdvisorContext([]));
      if(scatterGraphTypeSelect){
        scatterGraphTypeSelect.addEventListener('change',()=>{
          console.debug('Debug: scatter graph type change event',{value:scatterGraphTypeSelect.value});
          syncScatterGraphTypeUI();
          scatterThresholdSelectionPending = false;
          syncScatterThresholdSelection();
          scheduleDrawScatter();
        });
      }
      if(scatterTableFormatSelect){
        scatterTableFormatSelect.value = normalizeScatterTableFormat(scatterTableFormatSelect.value || scatterTableFormat);
        scatterTableFormat = scatterTableFormatSelect.value;
        scatterTableFormatSelect.addEventListener('change', e => {
          const requested = normalizeScatterTableFormat(e.target?.value || scatterTableFormat);
          applyScatterTableFormatMode(requested);
          persistTabState('scatter-table-format-change');
        });
      }
      if(scatterReplicatesInput){
        scatterReplicatesInput.value = String(clampScatterReplicateCount(scatterReplicatesInput.value || scatterReplicates));
        scatterReplicates = clampScatterReplicateCount(scatterReplicatesInput.value || scatterReplicates);
        if(scatterReplicates > SCATTER_MIN_REPLICATES){
          scatterLastGroupedReplicateCount = Math.min(SCATTER_MAX_REPLICATES, Math.max(2, scatterReplicates));
        }
        scatterReplicatesInput.addEventListener('change', e => {
          const resolved = clampScatterReplicateCount(e.target?.value);
          if(!isGroupedScatterModeActive()){
            scatterReplicatesInput.value = String(scatterReplicates);
            return;
          }
          if(resolved !== scatterReplicates){
            applyScatterReplicateChange(resolved);
            persistTabState('scatter-replicates-change');
          }else{
            scatterReplicatesInput.value = String(scatterReplicates);
            updateScatterReplicateModeControls(SCATTER_TABLE_FORMAT_GROUPED);
          }
        });
      }
      if(scatterGroupedXReplicatesInput){
        scatterGroupedXReplicates = normalizeScatterGroupedXReplicates(scatterGroupedXReplicatesInput.checked);
        scatterGroupedXReplicatesInput.addEventListener('change', e => {
          const nextEnabled = normalizeScatterGroupedXReplicates(e.target?.checked);
          if(!isGroupedScatterModeActive()){
            scatterGroupedXReplicatesInput.checked = !!scatterGroupedXReplicates;
            return;
          }
          if(nextEnabled === scatterGroupedXReplicates){
            updateScatterReplicateModeControls(SCATTER_TABLE_FORMAT_GROUPED);
            return;
          }
          applyScatterReplicateChange(scatterReplicates, {
            sourceReplicates: scatterReplicates,
            sourceFormat: SCATTER_TABLE_FORMAT_GROUPED,
            sourceXReplicatesEnabled: scatterGroupedXReplicates,
            xReplicatesEnabled: nextEnabled
          });
          persistTabState('scatter-x-replicates-toggle');
        });
      }
      if(scatterLog2FCThreshold){
        scatterLog2FCThreshold.addEventListener('input',()=>{
          console.debug('Debug: scatter log2FC threshold input',{value:scatterLog2FCThreshold.value});
          scatterThresholdSelectionPending = false;
          syncScatterThresholdSelection();
          scheduleScatterViewRefresh('scatter-log2fc-input');
          persistTabState('scatter-log2fc-input');
        });
      }
      if(scatterNegLogPThreshold){
        scatterNegLogPThreshold.addEventListener('input',()=>{
          console.debug('Debug: scatter negLogP threshold input',{value:scatterNegLogPThreshold.value});
          scatterThresholdSelectionPending = false;
          syncScatterThresholdSelection();
          scheduleScatterViewRefresh('scatter-neglogp-input');
          persistTabState('scatter-neglogp-input');
        });
      }
      if(scatterShowSignificantLabels){
        scatterShowSignificantLabels.addEventListener('change',()=>{
          scatterState.significantLabelsUserModified = true;
          console.debug('Debug: scatter significant label toggle',{checked:scatterShowSignificantLabels.checked});
          scatterThresholdSelectionPending = false;
          syncScatterThresholdSelection();
          scheduleScatterViewRefresh('scatter-significant-labels-change');
          persistTabState('scatter-significant-labels-change');
        });
      }
      if(scatterColorMode){
        scatterColorMode.addEventListener('change',()=>{
          scatterColorModeDesired = normalizeScatterColorMode(scatterColorMode.value);
          scatterColorMode.value = scatterColorModeDesired;
          syncScatterColorModeUI(scatterColorModeApplied);
          console.debug('Debug: scatter color mode changed',{ value: scatterColorModeDesired });
          persistTabState('scatter-color-mode-change');
          scheduleScatterViewRefresh('color-mode-change');
        });
      }
      if(scatterDensityPalette){
        scatterDensityPalette.addEventListener('change',()=>{
          scatterDensityPalette.value = normalizeScatterDensityPalette(scatterDensityPalette.value);
          console.debug('Debug: scatter density palette changed',{ value: scatterDensityPalette.value });
          scheduleScatterViewRefresh('density-palette-change');
        });
      }
      scatterFill.addEventListener('input',()=>{scatterLog('scatterFill changed', scatterFill.value); scheduleScatterViewRefresh('fill-change');});
      scatterBorder.addEventListener('input',()=>{scatterLog('scatterBorder changed', scatterBorder.value); scheduleScatterViewRefresh('border-color-change');});
      scatterBorderWidth.addEventListener('input',()=>{scatterLog('scatterBorderWidth changed', scatterBorderWidth.value); scheduleScatterViewRefresh('border-width-change');});
      scatterDotSize.addEventListener('input',()=>{
        const raw = Number(scatterDotSize.value);
        if(Number.isFinite(raw)){
          // Enable manual override on user input
          scatterState.dotSizeOverrideEnabled = true;
          scatterState.dotSizeOverrideRaw = raw;
        }else{
          // Non-finite input disables override and falls back to auto sizing
          scatterState.dotSizeOverrideEnabled = false;
          scatterState.dotSizeOverrideRaw = null;
        }
        scatterLog('scatterDotSize changed', scatterState.dotSizeOverrideEnabled ? scatterState.dotSizeOverrideRaw : '(auto)');
        scheduleScatterViewRefresh('dot-size-change');
      });
      if(scatterShowErrorBars){
        scatterShowErrorBars.addEventListener('change', () => {
          syncScatterErrorBarControls();
          persistTabState('scatter-error-bars-toggle');
          scheduleScatterViewRefresh('error-bars-toggle');
        });
      }
      if(scatterShowGroupedReplicates){
        scatterShowGroupedReplicates.addEventListener('change', () => {
          syncScatterGroupedReplicatePointControls();
          persistTabState('scatter-grouped-replicates-toggle');
          scheduleDrawScatter();
        });
      }
      if(scatterErrorBarWidth){
        scatterErrorBarWidth.addEventListener('input', () => {
          syncScatterErrorBarControls();
          scheduleScatterViewRefresh('error-bar-width-change');
        });
      }
      scatterAlpha.addEventListener('input',()=>{scatterAlphaVal.textContent=scatterAlpha.value; scatterLog('scatterAlpha changed',scatterAlpha.value); scheduleScatterViewRefresh('alpha-change');});
      scatterFontSize.addEventListener('input',()=>{
        if(scatterFontSize.dataset){
          scatterFontSize.dataset.fontBasePt = String(scatterFontSize.value);
          console.debug('Debug: scatter font size input manual set',{ value: scatterFontSize.value }); // Debug: manual slider update
        }
        chartStyle.renderFontSizeLabel({ element: scatterFontSizeVal, pt: Number(scatterFontSize.value), input: scatterFontSize, manual: true });
        scheduleScatterViewRefresh('font-size-change');
      });
      [scatterShowGrid,scatterStatType,scatterFitMethod,scatterOriginMode,scatterShowLine,scatterShowPlotStats,scatterShowCI,scatterShowPI]
        .forEach(el=>el&&el.addEventListener('change',()=>{
          console.debug('Debug: scatter config changed', { id: el.id, checked: el.checked, value: el.value });
          if(el===scatterOriginMode){
            const xOk=revalidateActiveScatterLogAxis('x','origin-mode-change');
            const yOk=revalidateActiveScatterLogAxis('y','origin-mode-change');
            if(!xOk||!yOk){
              return;
            }
          }
          if(el===scatterStatType || el===scatterFitMethod){
            requestScatterStatsContextRefresh(`${el.id||'scatter-control'}-change`);
            persistTabState(el===scatterFitMethod ? 'scatter-fit-method-change' : 'scatter-stat-type-change');
          }
          if(el === scatterShowGrid){
            scheduleScatterViewRefresh('grid-toggle');
          }else{
            scheduleScatterViewRefresh(`${el.id || 'control'}-change`);
          }
        }));
      [scatterFitRangeMinX, scatterFitRangeMaxX, scatterConfidenceLevel, scatterInitialValuesJson, scatterParameterConstraintsJson, scatterGlobalFitJson]
        .forEach(el => el && el.addEventListener('change', () => {
          validateScatterFitSpecControls();
          requestScatterStatsContextRefresh(`${el.id || 'scatter-fit-spec'}-change`);
          persistTabState('scatter-fit-spec-change');
          scheduleScatterViewRefresh(`${el.id || 'scatter-fit-spec'}-change`);
        }));
      [scatterInitialValuesJson, scatterParameterConstraintsJson, scatterGlobalFitJson]
        .forEach(el => el && el.addEventListener('input', () => {
          validateScatterFitSpecControls();
        }));
      [scatterFitRangeMinX, scatterFitRangeMaxX, scatterConfidenceLevel]
        .forEach(el => el && el.addEventListener('input', () => {
          validateScatterFitSpecControls();
        }));
      validateScatterFitSpecControls();
      // CI/PI controls depend on the trend line checkbox (scatterShowLine).
      const updateCIEnabled = ()=>{
        const showLineControl = getScatterNodeById('scatterShowLine') || scatterShowLine;
        const showCIControl = getScatterNodeById('scatterShowCI') || scatterShowCI;
        const showPIControl = getScatterNodeById('scatterShowPI') || scatterShowPI;
        const masterOn = !!(showLineControl && showLineControl.checked);
        const regressionDisabled = !!(showLineControl && showLineControl.disabled);
        const disabledState = regressionDisabled || !masterOn;
        if(showCIControl){
          showCIControl.disabled = disabledState;
          const lab = showCIControl.closest && showCIControl.closest('label');
          if(lab){ lab.classList.toggle('config-panel__checkbox--disabled', !!disabledState); }
        }
        if(showPIControl){
          showPIControl.disabled = disabledState;
          const lab = showPIControl.closest && showPIControl.closest('label');
          if(lab){ lab.classList.toggle('config-panel__checkbox--disabled', !!disabledState); }
        }
      };
      updateCIEnabled();
      if(scatterShowLine){
        scatterShowLine.addEventListener('change',()=>{
          updateCIEnabled();
          if(!scatterShowLine.checked){
            try{
              if(additionalLineControls && typeof additionalLineControls.close === 'function'){
                additionalLineControls.close('scatter-trendline-toggle-off');
              }
            }catch(e){}
            try{
              const host = resolveScatterToolbarHost(global.document);
              resetScatterDualHostLayout(host);
            }catch(e){}
          }
          persistTabState('scatter-trendline-change');
          scheduleScatterViewRefresh('trendline-toggle');
        });
      }
      if(scatterShowCI){
        scatterShowCI.addEventListener('change',()=>{
          // Prevent enabling CI unless the trend line is active
          if(!(scatterShowLine && scatterShowLine.checked)){
            if(scatterShowCI.checked){ scatterShowCI.checked = false; }
            return;
          }
          persistTabState('scatter-interval-ci-change');
          scheduleScatterViewRefresh('interval-ci-toggle');
        });
      }
      if(scatterShowPI){
        scatterShowPI.addEventListener('change',()=>{
          // Prevent enabling PI unless the trend line is active
          if(!(scatterShowLine && scatterShowLine.checked)){
            if(scatterShowPI.checked){ scatterShowPI.checked = false; }
            return;
          }
          persistTabState('scatter-interval-pi-change');
          scheduleScatterViewRefresh('interval-pi-toggle');
        });
      }
      const handleScatterLogToggle=(axis,checkbox)=>{
        checkbox?.addEventListener('change',()=>{
          const enabling=!!checkbox.checked;
          if(enabling){
            const validation=validateScatterLogAxis(axis);
            if(!validation.allowed){
              if(validation.canUsePlusOne && validation.hasZeros && !validation.hasNegatives){
                const axisLabel=axis==='x'?'X':'Y';
                const useLogPlusOne = global.confirm(`Your data contains zero values on the ${axisLabel} axis. Would you like to add +1 to all values before log transform?\n\nThis will plot log(x+1) instead of log(x).`);
                if(useLogPlusOne){
                  if(axis==='x'){
                    scatterState.logPlusOneX = true;
                  }else{
                    scatterState.logPlusOneY = true;
                  }
                  clearScatterLogWarning();
                  console.debug('Debug: scatter log+1 enabled by user confirmation',{ axis });
                  scheduleScatterViewRefresh(`log-toggle-${axis}-plus-one`);
                  return;
                }else{
                  checkbox.checked = false;
                  if(axis==='x'){
                    scatterState.logPlusOneX = false;
                  }else{
                    scatterState.logPlusOneY = false;
                  }
                  console.debug('Debug: scatter log scale cancelled by user',{ axis });
                  return;
                }
              }
              checkbox.checked=false;
              const warningMessage=validation.message||`Cannot enable log scale on the ${axis==='x'?'X':'Y'} axis while non-positive values are present.`;
              showScatterLogWarning(warningMessage);
              console.warn('scatter log axis blocked',{ axis, reason: validation.reason, value: validation.value });
              return;
            }
            if(axis==='x'){
              scatterState.logPlusOneX = false;
            }else{
              scatterState.logPlusOneY = false;
            }
            clearScatterLogWarning();
          }else{
            if(axis==='x'){
              scatterState.logPlusOneX = false;
            }else{
              scatterState.logPlusOneY = false;
            }
            clearScatterLogWarning();
          }
          console.debug('Debug: scatter log toggle change',{ id: checkbox.id, checked: checkbox.checked });
          scheduleScatterViewRefresh(`log-toggle-${axis}`);
        });
      };
      handleScatterLogToggle('x',scatterLogX);
      handleScatterLogToggle('y',scatterLogY);
      if(scatterRegressionMode){
        scatterRegressionMode.addEventListener('change',()=>{
          console.debug('Debug: scatter regression mode change',{ value: scatterRegressionMode.value });
          const beforeFitMethod = scatterFitMethod?.value || null;
          syncScatterRegressionOptionVisibility();
          const afterFitMethod = scatterFitMethod?.value || null;
          if(beforeFitMethod !== afterFitMethod){
            persistTabState('scatter-fit-method-auto-adjust');
          }
          requestScatterStatsContextRefresh('regression-mode-change');
          persistTabState('scatter-regression-mode-change');
          scheduleScatterViewRefresh('regression-mode-change');
        });
      }
      scatterShowFrame.addEventListener('change',()=>{console.debug('Debug: scatter showFrame change',{checked:scatterShowFrame.checked}); scheduleScatterViewRefresh('frame-toggle');});
      if(scatterShowLegend){
        scatterShowLegend.addEventListener('change',()=>{
          if(scatterLegendChangeInternal){
            return;
          }
          console.debug('Debug: scatter showLegend change',{checked:scatterShowLegend.checked});
          scheduleScatterViewRefresh('legend-toggle');
        });
      }
      const scatterAxisInputs=[
        { el: scatterXMin, axis: 'x', context: 'axis-min-input', logLabel: 'scatterXMin changed' },
        { el: scatterXMax, axis: 'x', context: 'axis-max-input', logLabel: 'scatterXMax changed' },
        { el: scatterYMin, axis: 'y', context: 'axis-min-input', logLabel: 'scatterYMin changed' },
        { el: scatterYMax, axis: 'y', context: 'axis-max-input', logLabel: 'scatterYMax changed' },
        { el: scatterOriginX, axis: 'x', context: 'origin-input', logLabel: 'scatterOriginX changed' },
        { el: scatterOriginY, axis: 'y', context: 'origin-input', logLabel: 'scatterOriginY changed' }
      ];
      scatterAxisInputs.forEach(({el,axis,context,logLabel})=>{
        if(!el){
          return;
        }
        el.addEventListener('input',()=>{
          scatterLog(logLabel, el.value);
          const logActive = axis === 'x' ? scatterLogX?.checked : scatterLogY?.checked;
          if(logActive && isScatterLogAxisInputInProgress(el)){
            if(scatterDebugEnabled()){
              console.debug('Debug: scatter log axis validation deferred',{ axis, context, value: el.value });
            }
            scheduleScatterViewRefresh(`${axis}-${context}`);
            return;
          }
          if(!revalidateActiveScatterLogAxis(axis,context)){
            return;
          }
          if(!scatterLogX?.checked && !scatterLogY?.checked){
            clearScatterLogWarning();
          }
          scheduleScatterViewRefresh(`${axis}-${context}`);
        });
        el.addEventListener('change',()=>{
          if(!revalidateActiveScatterLogAxis(axis,`${context}-change`)){
            return;
          }
          if(!scatterLogX?.checked && !scatterLogY?.checked){
            clearScatterLogWarning();
          }
          scheduleScatterViewRefresh(`${axis}-${context}-change`);
        });
      });
      syncScatterGraphTypeUI();

      function areScatterLabelSetsEqual(nextSet, prevSet){
        if(!prevSet || !nextSet || prevSet.size !== nextSet.size){
          return false;
        }
        for(const label of nextSet){
          if(!prevSet.has(label)){
            return false;
          }
        }
        return true;
      }

      function ensureScatterLabelColors(labels, meta){
        if(scatterCurrentGraphType!=='scatter'){
          return;
        }
        const labelSet = meta?.labelSet || new Set(labels);
        const perfApi = Shared.Performance;
        const perfSpan = perfApi?.start('scatter.labels.colors', {
          component: 'scatter',
          labels: Array.isArray(labels) ? labels.length : 0
        });
        const debugEnabled = typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled();
        const isSameSet = scatterLabelCache.colorsValid && areScatterLabelSetsEqual(labelSet, scatterLabelCache.colorsSet);
        if(isSameSet){
          if(perfApi && perfSpan){
            perfApi.end(perfSpan, {
              component: 'scatter',
              labels: Array.isArray(labels) ? labels.length : 0,
              created: 0,
              pruned: 0,
              total: labelSet.size,
              skipped: true
            });
          }
          scatterLabelCache.colorsSet = labelSet;
          if(debugEnabled){
            scatterDebug('Debug: ensureScatterLabelColors skipped (unchanged)', { count: labelSet.size });
          }
          return;
        }
        let createdCount = 0;
        let prunedCount = 0;
        const sampleLimit = 5;
        const createdSamples = debugEnabled ? [] : null;
        const prunedSamples = debugEnabled ? [] : null;
        labels.forEach((lab,i)=>{
          if(!scatterLabelColors[lab]){
            scatterLabelColors[lab]=DEFAULT_SCATTER_COLORS[i%DEFAULT_SCATTER_COLORS.length];
            createdCount += 1;
            if(createdSamples && createdSamples.length < sampleLimit){
              createdSamples.push({ label: lab, color: scatterLabelColors[lab] });
            }
          }
        });
        Object.keys(scatterLabelColors).forEach(existing=>{
          if(!labelSet.has(existing)){
            delete scatterLabelColors[existing];
            prunedCount += 1;
            if(prunedSamples && prunedSamples.length < sampleLimit){
              prunedSamples.push(existing);
            }
          }
        });
        const totalCount = Object.keys(scatterLabelColors).length;
        scatterLabelCache.colorsSet = labelSet;
        scatterLabelCache.colorsValid = true;
        if(debugEnabled){
          if(createdSamples && createdSamples.length){
            createdSamples.forEach(entry => scatterDebug('Debug: scatter default label color applied', entry));
          }
          if(prunedSamples && prunedSamples.length){
            prunedSamples.forEach(label => scatterDebug('Debug: scatter label color pruned', { label }));
          }
        }
        if(perfApi && perfSpan){
          perfApi.end(perfSpan, {
            component: 'scatter',
            labels: Array.isArray(labels) ? labels.length : 0,
            created: createdCount,
            pruned: prunedCount,
            total: totalCount
          });
        }
        scatterDebug('Debug: ensureScatterLabelColors sync complete',{count: totalCount, created: createdCount, pruned: prunedCount});
      }

      function sanitizeScatterLabelShape(value, index){
        if(SCATTER_SHAPE_VALUES.has(value)){
          return value;
        }
        const safeIndex = Number.isInteger(index) ? index : 0;
        return SCATTER_SHAPE_DEFAULTS[safeIndex % SCATTER_SHAPE_DEFAULTS.length];
      }

      function compactScatterLabelMapForPayload(mapValue, defaults, mapName){
        if(!mapValue || typeof mapValue !== 'object' || Array.isArray(mapValue)){
          return {};
        }
        const keys = Object.keys(mapValue);
        if(!keys.length){
          return {};
        }
        if(keys.length < 1000 || !Array.isArray(defaults) || !defaults.length){
          return { ...mapValue };
        }
        const compact = {};
        let pruned = 0;
        for(let i = 0; i < keys.length; i += 1){
          const key = keys[i];
          const value = mapValue[key];
          const defaultValue = defaults[i % defaults.length];
          if(value === defaultValue){
            pruned += 1;
            continue;
          }
          compact[key] = value;
        }
        scatterDebug('Debug: scatter payload label map compacted', {
          map: mapName || 'labels',
          total: keys.length,
          pruned,
          kept: keys.length - pruned
        });
        return compact;
      }

      function ensureScatterLabelShapes(labels, meta){
        if(scatterCurrentGraphType!=='scatter'){
          scatterLabelShapes = {};
          scatterLabelCache.shapesSet = null;
          scatterLabelCache.shapesValid = false;
          return;
        }
        const labelSet = meta?.labelSet || new Set(labels);
        const isSameSet = scatterLabelCache.shapesValid && areScatterLabelSetsEqual(labelSet, scatterLabelCache.shapesSet);
        if(isSameSet){
          scatterLabelCache.shapesSet = labelSet;
          scatterDebug('Debug: ensureScatterLabelShapes skipped (unchanged)', { count: labelSet.size });
          return;
        }
        labels.forEach((lab, idx)=>{
          if(!lab){ return; }
          const sanitized = sanitizeScatterLabelShape(scatterLabelShapes[lab], idx);
          scatterLabelShapes[lab] = sanitized;
        });
        Object.keys(scatterLabelShapes).forEach(existing=>{
          if(!labelSet.has(existing)){
            delete scatterLabelShapes[existing];
          }
        });
        const totalCount = Object.keys(scatterLabelShapes).length;
        scatterLabelCache.shapesSet = labelSet;
        scatterLabelCache.shapesValid = true;
        scatterDebug('Debug: ensureScatterLabelShapes sync complete',{count: totalCount});
      }

      function computeScatterLabelDistribution(points){
        const summary = {
          totalPoints: Array.isArray(points) ? points.length : 0,
          labeledPointCount: 0,
          labelCount: 0,
          pureUnique: false,
          averageFrequency: 0,
          shouldUseUniform: false
        };
        if(!Array.isArray(points) || points.length === 0){
          return summary;
        }
        const counts = new Map();
        for(let i = 0; i < points.length; i += 1){
          const rawLabel = points[i]?.label;
          const label = rawLabel ? String(rawLabel) : '';
          if(!label){
            continue;
          }
          summary.labeledPointCount += 1;
          counts.set(label, (counts.get(label) || 0) + 1);
        }
        summary.labelCount = counts.size;
        if(summary.labelCount === 0 || summary.labeledPointCount === 0){
          return summary;
        }
        summary.pureUnique = Array.from(counts.values()).every(count => count === 1);
        const total = summary.totalPoints > 0 ? summary.totalPoints : summary.labeledPointCount;
        summary.averageFrequency = (summary.labeledPointCount / summary.labelCount) / total;
        summary.shouldUseUniform = summary.pureUnique || summary.averageFrequency < 0.05;
        scatterDebug('Debug: scatter label distribution', {
          labelCount: summary.labelCount,
          labeledPointCount: summary.labeledPointCount,
          totalPoints: summary.totalPoints,
          pureUnique: summary.pureUnique,
          averageFrequency: summary.averageFrequency,
          shouldUseUniform: summary.shouldUseUniform
        });
        return summary;
      }

  function createScatterMarkerElement(shape, options){
        const doc = global.document;
        if(!doc){ return null; }
        const normalized = SCATTER_SHAPE_VALUES.has(shape) ? shape : 'circle';
        const radius = Math.max(0, Number(options?.radius) || 0);
        const cx = Number(options?.cx) || 0;
        const cy = Number(options?.cy) || 0;
        const fill = options?.fill ?? '#000000';
        const stroke = options?.stroke ?? null;
        const strokeWidthRaw = Number(options?.strokeWidth);
        const strokeWidth = Number.isFinite(strokeWidthRaw) && strokeWidthRaw > 0 ? strokeWidthRaw : 0;
        const fillOpacityRaw = Number(options?.fillOpacity);
        const fillOpacity = Number.isFinite(fillOpacityRaw) ? Math.min(Math.max(fillOpacityRaw, 0), 1) : 1;
        const strokeOpacityRaw = Number(options?.strokeOpacity);
        const strokeOpacity = Number.isFinite(strokeOpacityRaw) ? Math.min(Math.max(strokeOpacityRaw, 0), 1) : fillOpacity;
        const applyCommonAttributes = (node) => {
          if(!node){ return null; }
          node.setAttribute('fill', fill);
          if(fillOpacity !== 1){
            node.setAttribute('fill-opacity', String(fillOpacity));
          }
          if(stroke && strokeWidth > 0){
            node.setAttribute('stroke', stroke);
            node.setAttribute('stroke-width', String(strokeWidth));
            if(strokeOpacity !== 1){
              node.setAttribute('stroke-opacity', String(strokeOpacity));
            }
          }else if(stroke){
            node.setAttribute('stroke', stroke);
            node.setAttribute('stroke-width', '0');
            if(strokeOpacity !== 1){
              node.setAttribute('stroke-opacity', String(strokeOpacity));
            }
          }
          return node;
        };
        if(normalized === 'square'){
          const size = Math.max(radius * 2, 2);
          const half = size / 2;
          const rect = doc.createElementNS(NS, 'rect');
          rect.setAttribute('x', String(cx - half));
          rect.setAttribute('y', String(cy - half));
          rect.setAttribute('width', String(size));
          rect.setAttribute('height', String(size));
          return applyCommonAttributes(rect);
        }
        if(normalized === 'triangle'){
          const size = Math.max(radius * 2, 2);
          const half = size / 2;
          const path = doc.createElementNS(NS, 'path');
          const d = `M ${cx} ${cy - half} L ${cx + half} ${cy + half} L ${cx - half} ${cy + half} Z`;
          path.setAttribute('d', d);
          return applyCommonAttributes(path);
        }
        if(normalized === 'diamond'){
          const size = Math.max(radius * 2, 2);
          const half = size / 2;
          const path = doc.createElementNS(NS, 'path');
          const d = `M ${cx} ${cy - half} L ${cx + half} ${cy} L ${cx} ${cy + half} L ${cx - half} ${cy} Z`;
          path.setAttribute('d', d);
          return applyCommonAttributes(path);
        }
        if(normalized === 'cross'){
          const size = Math.max(radius * 2, 2);
          const half = size / 2;
          const bar = Math.max(size / 3, 2);
          const hb = bar / 2;
          const top = cy - half;
          const bottom = cy + half;
          const left = cx - half;
          const right = cx + half;
          const path = doc.createElementNS(NS, 'path');
          const d = [
            `M ${left} ${top + hb}`,
            `L ${left + hb} ${top}`,
            `L ${cx} ${cy - hb}`,
            `L ${right - hb} ${top}`,
            `L ${right} ${top + hb}`,
            `L ${cx + hb} ${cy}`,
            `L ${right} ${bottom - hb}`,
            `L ${right - hb} ${bottom}`,
            `L ${cx} ${cy + hb}`,
            `L ${left + hb} ${bottom}`,
            `L ${left} ${bottom - hb}`,
            `L ${cx - hb} ${cy}`,
            'Z'
          ].join(' ');
          path.setAttribute('d', d);
          return applyCommonAttributes(path);
        }
        if(normalized === 'plus'){
          const size = Math.max(radius * 2, 2);
          const half = size / 2;
          const bar = Math.max(size / 3, 2);
          const halfBar = bar / 2;
          const path = doc.createElementNS(NS, 'path');
          const d = `M ${cx - halfBar} ${cy - half} H ${cx + halfBar} V ${cy - halfBar} H ${cx + half} V ${cy + halfBar} H ${cx + halfBar} V ${cy + half} H ${cx - halfBar} V ${cy + halfBar} H ${cx - half} V ${cy - halfBar} H ${cx - halfBar} Z`;
          path.setAttribute('d', d);
          return applyCommonAttributes(path);
        }
        if(normalized === 'star'){
          const outer = Math.max(radius, 1);
          const inner = Math.max(outer * 0.45, 1);
          const points = [];
          for(let i = 0; i < 5; i += 1){
            const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
            points.push({ x: cx + Math.cos(a) * outer, y: cy + Math.sin(a) * outer });
            const b = a + Math.PI / 5;
            points.push({ x: cx + Math.cos(b) * inner, y: cy + Math.sin(b) * inner });
          }
          const path = doc.createElementNS(NS, 'path');
          const d = points.map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ') + ' Z';
          path.setAttribute('d', d);
          return applyCommonAttributes(path);
        }
        const circle = doc.createElementNS(NS, 'circle');
        circle.setAttribute('cx', String(cx));
        circle.setAttribute('cy', String(cy));
        circle.setAttribute('r', String(radius));
        return applyCommonAttributes(circle);
      }

      function buildScatterCirclePathSegment(cx, cy, radius){
        const r = Math.max(0, Number(radius) || 0);
        if(!(r > 0)){
          return '';
        }
        const safeCx = Number(cx) || 0;
        const safeCy = Number(cy) || 0;
        const diameter = r * 2;
        return `M ${safeCx - r} ${safeCy} a ${r} ${r} 0 1 0 ${diameter} 0 a ${r} ${r} 0 1 0 ${-diameter} 0`;
      }

      let scatterPointCanvasSupported = null;

      function canUseScatterPointCanvas(){
        if(scatterPointCanvasSupported != null){
          return scatterPointCanvasSupported;
        }
        try{
          const doc = global.document;
          const canvas = doc && typeof doc.createElement === 'function'
            ? doc.createElement('canvas')
            : null;
          scatterPointCanvasSupported = !!(canvas && typeof canvas.getContext === 'function' && canvas.getContext('2d'));
        }catch(err){
          scatterPointCanvasSupported = false;
        }
        return scatterPointCanvasSupported;
      }

      function appendScatterPointCanvasShapePath(ctx, shape, x, y, radius){
        const safeRadius = Math.max(0.2, Number(radius) || 0.2);
        const normalized = SCATTER_SHAPE_VALUES.has(shape) ? shape : 'circle';
        if(normalized === 'square'){
          ctx.rect(x - safeRadius, y - safeRadius, safeRadius * 2, safeRadius * 2);
          return;
        }
        if(normalized === 'triangle'){
          ctx.moveTo(x, y - safeRadius);
          ctx.lineTo(x + safeRadius, y + safeRadius);
          ctx.lineTo(x - safeRadius, y + safeRadius);
          ctx.closePath();
          return;
        }
        if(normalized === 'diamond'){
          ctx.moveTo(x, y - safeRadius);
          ctx.lineTo(x + safeRadius, y);
          ctx.lineTo(x, y + safeRadius);
          ctx.lineTo(x - safeRadius, y);
          ctx.closePath();
          return;
        }
        if(normalized === 'cross'){
          const size = Math.max(safeRadius * 2, 2);
          const half = size / 2;
          const bar = Math.max(size / 3, 2);
          const hb = bar / 2;
          const top = y - half;
          const bottom = y + half;
          const left = x - half;
          const right = x + half;
          ctx.moveTo(left, top + hb);
          ctx.lineTo(left + hb, top);
          ctx.lineTo(x, y - hb);
          ctx.lineTo(right - hb, top);
          ctx.lineTo(right, top + hb);
          ctx.lineTo(x + hb, y);
          ctx.lineTo(right, bottom - hb);
          ctx.lineTo(right - hb, bottom);
          ctx.lineTo(x, y + hb);
          ctx.lineTo(left + hb, bottom);
          ctx.lineTo(left, bottom - hb);
          ctx.lineTo(x - hb, y);
          ctx.closePath();
          return;
        }
        if(normalized === 'plus'){
          const size = Math.max(safeRadius * 2, 2);
          const half = size / 2;
          const bar = Math.max(size / 3, 2);
          const hb = bar / 2;
          ctx.moveTo(x - hb, y - half);
          ctx.lineTo(x + hb, y - half);
          ctx.lineTo(x + hb, y - hb);
          ctx.lineTo(x + half, y - hb);
          ctx.lineTo(x + half, y + hb);
          ctx.lineTo(x + hb, y + hb);
          ctx.lineTo(x + hb, y + half);
          ctx.lineTo(x - hb, y + half);
          ctx.lineTo(x - hb, y + hb);
          ctx.lineTo(x - half, y + hb);
          ctx.lineTo(x - half, y - hb);
          ctx.lineTo(x - hb, y - hb);
          ctx.closePath();
          return;
        }
        if(normalized === 'star'){
          const innerRadius = Math.max(safeRadius * 0.45, 1);
          for(let k = 0; k < 5; k += 1){
            const a = (Math.PI * 2 * k) / 5 - Math.PI / 2;
            const outerX = x + Math.cos(a) * safeRadius;
            const outerY = y + Math.sin(a) * safeRadius;
            const b = a + Math.PI / 5;
            const innerX = x + Math.cos(b) * innerRadius;
            const innerY = y + Math.sin(b) * innerRadius;
            if(k === 0){
              ctx.moveTo(outerX, outerY);
            }else{
              ctx.lineTo(outerX, outerY);
            }
            ctx.lineTo(innerX, innerY);
          }
          ctx.closePath();
          return;
        }
        ctx.moveTo(x + safeRadius, y);
        ctx.arc(x, y, safeRadius, 0, Math.PI * 2);
      }

      function expandScatterPointCanvasBounds(bounds, padding){
        if(!bounds){
          return null;
        }
        const safePadding = Math.max(0, Number(padding) || 0);
        const minX = Number(bounds.minX) - safePadding;
        const minY = Number(bounds.minY) - safePadding;
        const maxX = Number(bounds.maxX) + safePadding;
        const maxY = Number(bounds.maxY) + safePadding;
        if(!Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)){
          return null;
        }
        return {
          minX,
          minY,
          maxX,
          maxY,
          width: Math.max(1, Math.ceil(maxX - minX)),
          height: Math.max(1, Math.ceil(maxY - minY))
        };
      }

      function createScatterPointCanvasSurface(doc, bounds, rendererType){
        if(!doc || !bounds){
          return null;
        }
        const minX = Number(bounds.minX);
        const minY = Number(bounds.minY);
        const width = Math.max(1, Math.ceil(Number(bounds.width) || 0));
        const height = Math.max(1, Math.ceil(Number(bounds.height) || 0));
        if(!Number.isFinite(minX) || !Number.isFinite(minY) || width <= 0 || height <= 0){
          scatterDebug('Debug: scatter canvas surface skipped due to invalid bounds', { bounds, rendererType });
          return null;
        }
        const foreignObject = doc.createElementNS(NS, 'foreignObject');
        foreignObject.setAttribute('x', String(minX));
        foreignObject.setAttribute('y', String(minY));
        foreignObject.setAttribute('width', String(width));
        foreignObject.setAttribute('height', String(height));
        foreignObject.setAttribute('data-point-renderer', rendererType || 'canvas-preview');
        const canvas = doc.createElement('canvas');
        canvas.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
        canvas.style.display = 'block';
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
        canvas.style.background = 'transparent';
        canvas.style.pointerEvents = 'none';
        const dpr = Math.max(1, (global.window?.devicePixelRatio || 1) * SCATTER_POINT_CANVAS_RESOLUTION_SCALE);
        canvas.setAttribute('data-resolution-scale', String(SCATTER_POINT_CANVAS_RESOLUTION_SCALE));
        canvas.width = Math.max(1, Math.ceil(width * dpr));
        canvas.height = Math.max(1, Math.ceil(height * dpr));
        const ctx = canvas.getContext('2d');
        if(!ctx){
          scatterDebug('Debug: scatter canvas surface skipped because 2D context is unavailable', { rendererType, width, height });
          return null;
        }
        return { foreignObject, canvas, ctx, dpr, width, height, minX, minY };
      }

      function updateScatterPointCanvasBounds(bounds, x, y, radius, strokeWidth){
        const pad = Math.max(0, Number(radius) || 0) + Math.max(0, Number(strokeWidth) || 0) * 0.5;
        if(!Number.isFinite(x) || !Number.isFinite(y)){
          return bounds;
        }
        const next = bounds || { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
        next.minX = Math.min(next.minX, x - pad);
        next.minY = Math.min(next.minY, y - pad);
        next.maxX = Math.max(next.maxX, x + pad);
        next.maxY = Math.max(next.maxY, y + pad);
        return next;
      }

      function waitScatterCanvasFrame(){
        return new Promise(resolve => {
          const raf = global.requestAnimationFrame;
          if(typeof raf === 'function'){
            raf(() => resolve());
            return;
          }
          (global.setTimeout || setTimeout)(resolve, 0);
        });
      }

      function paintScatterPointCanvasBucketChunk(ctx, bucket, points, start, end, bounds){
        ctx.beginPath();
        for(let i = start; i < end; i += 1){
          const point = points[i];
          appendScatterPointCanvasShapePath(
            ctx,
            bucket.shape,
            point.x - bounds.minX,
            point.y - bounds.minY,
            point.r
          );
        }
        if(bucket.fill && bucket.fill !== 'none'){
          ctx.fillStyle = bucket.fill;
          ctx.globalAlpha = Math.max(0, Math.min(1, Number(bucket.fillOpacity)));
          ctx.fill();
        }
        if(bucket.stroke && bucket.strokeWidth > 0){
          ctx.strokeStyle = bucket.stroke;
          ctx.lineWidth = bucket.strokeWidth;
          ctx.globalAlpha = Math.max(0, Math.min(1, Number(bucket.strokeOpacity)));
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }

      async function renderScatterPointCanvasBuckets(group, buckets, bounds, options = {}){
        const doc = options.doc || global.document;
        if(!doc || !group || !buckets || !buckets.size || !canUseScatterPointCanvas()){
          return false;
        }
        const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : null;
        const expandedBounds = expandScatterPointCanvasBounds(bounds, 2);
        if(!expandedBounds){
          return false;
        }
        const surface = createScatterPointCanvasSurface(doc, expandedBounds, 'canvas-preview');
        if(!surface){
          return false;
        }
        const { foreignObject, canvas, ctx, dpr } = surface;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const bucketList = Array.from(buckets.values());
        let pointsSinceYield = 0;
        for(let bucketIndex = 0; bucketIndex < bucketList.length; bucketIndex += 1){
          if(shouldCancel?.()){
            return false;
          }
          const bucket = bucketList[bucketIndex];
          if(!bucket || !Array.isArray(bucket.points) || !bucket.points.length){
            continue;
          }
          const points = bucket.points;
          for(let start = 0; start < points.length; start += SCATTER_POINT_CANVAS_FRAME_POINT_BUDGET){
            if(shouldCancel?.()){
              return false;
            }
            const end = Math.min(points.length, start + SCATTER_POINT_CANVAS_FRAME_POINT_BUDGET);
            paintScatterPointCanvasBucketChunk(ctx, bucket, points, start, end, expandedBounds);
            pointsSinceYield += end - start;
            if(pointsSinceYield >= SCATTER_POINT_CANVAS_FRAME_POINT_BUDGET && (end < points.length || bucketIndex < bucketList.length - 1)){
              pointsSinceYield = 0;
              await waitScatterCanvasFrame();
            }
          }
        }
        if(shouldCancel?.()){
          return false;
        }
        foreignObject.appendChild(canvas);
        group.appendChild(foreignObject);
        group.setAttribute('data-render-mode', 'canvas');
        group.setAttribute('data-point-renderer', 'canvas-preview');
        return true;
      }

      function appendScatterPointCanvasBucketsAsPaths(group, buckets){
        const doc = global.document;
        if(!doc || !group || !buckets || !buckets.size){
          return false;
        }
        let appended = false;
        buckets.forEach(bucket => {
          if(!bucket || !Array.isArray(bucket.points) || !bucket.points.length){
            return;
          }
          const segments = [];
          bucket.points.forEach(point => {
            if(bucket.shape === 'circle'){
              const segment = buildScatterCirclePathSegment(point.x, point.y, point.r);
              if(segment){ segments.push(segment); }
              return;
            }
            const node = createScatterMarkerElement(bucket.shape, {
              cx: point.x,
              cy: point.y,
              radius: point.r,
              fill: bucket.fill,
              stroke: bucket.stroke,
              strokeWidth: bucket.strokeWidth,
              fillOpacity: bucket.fillOpacity,
              strokeOpacity: bucket.strokeOpacity
            });
            if(node){
              group.appendChild(node);
              appended = true;
            }
          });
          if(segments.length){
            const path = doc.createElementNS(NS, 'path');
            path.setAttribute('d', segments.join(' '));
            path.setAttribute('fill', bucket.fill || '#000000');
            if(bucket.fillOpacity !== 1){
              path.setAttribute('fill-opacity', String(bucket.fillOpacity));
            }
            if(bucket.stroke && bucket.strokeWidth > 0){
              path.setAttribute('stroke', bucket.stroke);
              path.setAttribute('stroke-width', String(bucket.strokeWidth));
              if(bucket.strokeOpacity !== 1){
                path.setAttribute('stroke-opacity', String(bucket.strokeOpacity));
              }
            }else{
              path.setAttribute('stroke', 'none');
            }
            group.appendChild(path);
            appended = true;
          }
        });
        if(appended){
          group.setAttribute('data-render-mode', 'batched-fallback');
        }
        return appended;
      }

      function createBubbleRadiusScaler(points, baseRadius){
        const safeBase = Math.max(1, Number(baseRadius) || 1);
        let minValue = Infinity;
        let maxValue = -Infinity;
        let count = 0;
        if(Array.isArray(points)){
          for(let i = 0; i < points.length; i += 1){
            const point = points[i];
            if(!point){ continue; }
            const raw = point.bubbleValue;
            const magnitude = Math.abs(Number(raw));
            if(!Number.isFinite(magnitude)){ continue; }
            if(magnitude < minValue){ minValue = magnitude; }
            if(magnitude > maxValue){ maxValue = magnitude; }
            count += 1;
          }
        }
        const minRadius = Math.max(1, safeBase * 0.6);
        const maxRadius = Math.max(minRadius + 1, safeBase * 2.8);
        if(count === 0){
          const fallback = Math.max(minRadius, Math.min(maxRadius, safeBase));
          return () => fallback;
        }
        if(maxValue <= minValue){
          const radius = Math.max(minRadius, Math.min(maxRadius, safeBase));
          return () => radius;
        }
        return point => {
          const value = Math.abs(Number(point?.bubbleValue));
          if(!Number.isFinite(value)){
            return minRadius;
          }
          const ratio = (value - minValue) / (maxValue - minValue);
          const clamped = Math.min(Math.max(ratio, 0), 1);
          return minRadius + (maxRadius - minRadius) * clamped;
        };
      }

    
      const scatterPlotDiv=getScatterNodeById('scatterPlot');
      if(scatterPlotDiv && !scatterPlotDiv.__scatterAxesLengthCloseHandler){
        const onPlotPointerDown = () => {
          closeScatterAxesLengthMenu('plot-pointer');
        };
        scatterPlotDiv.addEventListener('pointerdown', onPlotPointerDown);
        scatterPlotDiv.__scatterAxesLengthCloseHandler = onPlotPointerDown;
      }
      if(scatterPlotDiv && !scatterPlotDiv.__scatterOverlayToolbarClickHandler){
        const onPlotClick = evt => {
          const clickTarget = evt?.target || null;
          if(!clickTarget){
            return;
          }
          if(clickTarget.closest && clickTarget.closest('text')){
            return;
          }
          if(scatterCurrentGraphType !== 'scatter'){
            return;
          }
          if(resolveScatterPointTarget(clickTarget, scatterPlotDiv)){
            return;
          }
          if(clickTarget.closest && clickTarget.closest('[data-additional-line-control="1"]')){
            return;
          }
          if(clickTarget.closest && clickTarget.closest('[data-grid-control="1"]')){
            return;
          }
          if(clickTarget.closest && clickTarget.closest('.scatter-point-context-menu')){
            return;
          }
          const overlayConfig = showScatterOverlayFormatControls({ target: clickTarget });
          if(overlayConfig){
            try{ evt.stopPropagation(); }catch(e){}
          }else{
            scatterDebug('Debug: scatter plot click bubbled (no overlay panel opened)', {
              reason: 'plot-click-no-overlay'
            });
          }
        };
        scatterPlotDiv.addEventListener('click', onPlotClick);
        scatterPlotDiv.__scatterOverlayToolbarClickHandler = onPlotClick;
      }
      const scatterContainer=scatterPlotDiv.closest('.svgbox')||scatterPlotDiv.parentElement;
      if(!scatterContainer){
        console.debug('Debug: scatter resizer container missing', { hasContainer: !!scatterContainer });
      }

      let scatterTitleText='Scatter plot';
      let scatterXLabelText='X';
      let scatterYLabelText='Y';
      let scatterZLabelText='Z';
      let scatterLabelPositions = { title: null, xLabel: null, yLabel: null, stats: null, legend: null };
      async function drawScatter(drawOptions = {}){
        const debugEnabled = typeof Shared.isDebugEnabled === 'function' ? Shared.isDebugEnabled() : false;
        const debug = debugEnabled ? console.debug.bind(console) : () => {};
        const info = debugEnabled ? console.debug.bind(console) : () => {};
        const time = debugEnabled ? console.time.bind(console) : () => {};
        const timeEnd = debugEnabled ? console.timeEnd.bind(console) : () => {};
        const rowSkipCounts = debugEnabled ? Object.create(null) : null;
        const recordRowSkip = debugEnabled
          ? (reason => {
              rowSkipCounts[reason] = (rowSkipCounts[reason] || 0) + 1;
            })
          : () => {};
        const collectProgressInterval = 5000;
        let nextCollectProgressRow = debugEnabled ? collectProgressInterval : Number.POSITIVE_INFINITY;
        const pointProgressInterval = 5000;
        let nextPointProgress = debugEnabled ? pointProgressInterval : Number.POSITIVE_INFINITY;
        const viewOnly = !!drawOptions?.viewOnly;
        const token=++scatterDrawToken; // debug token for cancellation
        const perfApi = Shared.Performance;
        const drawReasons = scatterState.activeDrawReasons ? Array.from(scatterState.activeDrawReasons) : [];
        scatterState.activeDrawReasons = null;
        const drawPerf = perfApi && typeof perfApi.start === 'function'
          ? perfApi.start('scatter.draw', { component: 'scatter', reasons: drawReasons })
          : null;
        const endDrawPerf = meta => {
          if(perfApi && drawPerf){
            perfApi.end(drawPerf, meta);
          }
        };
        info('drawScatter called',{token, viewOnly, reason: drawOptions?.reason || null});
        try{
        let statsContextPayload=null;
        scatterState.rotationPending = false;
        scatterState.rotationPendingLogged = false;
        scatterLayout?.suppressNextSchedule?.({ reason: 'scatter-draw', count: 2, delayMs: 120 });
        hideScatterTooltip('draw-start');
        const significanceColors = getScatterSignificanceColors();
        const fill=scatterFill.value||significanceColors.neutral;
        const alpha=Number(scatterAlpha.value)||0;
        const borderWidthRaw=Number(scatterBorderWidth.value);
        const borderColor=scatterBorder.value;
        const containerRect=scatterSvgBox?.getBoundingClientRect?.();
        const fontInfo=chartStyle.resolveScaledFontSize({
          rawSize: scatterFontSize.value,
          width: containerRect?.width,
          height: containerRect?.height,
          svgBox: scatterSvgBox,
          input: scatterFontSize
        });
        const fs=fontInfo.scaledPx;
        const styleScaleInfo=fontInfo.scaleInfo;
        const axisStrokeWidthBase = getScatterAxisStrokeWidth();
        const axisStrokeWidth=chartStyle.scaleStrokeWidth(axisStrokeWidthBase, styleScaleInfo, { context: 'scatter-axis', min: 0, exact: true });
        const axisStroke = getScatterAxisColor();
        const scatterThemeDark = String(scatterColorSchemeId || '').toLowerCase() === 'dark';
        const scatterThemeTextColor = normalizeScatterThemeColor(
          scatterTextColor,
          scatterThemeDark ? '#f2f2f2' : (chartStyle.TEXT_COLOR || '#000000')
        );
        const dotSizeInputRaw=Number(scatterDotSize.value)||3;
        // Initial dotSizePx uses user input; will be recalculated with adaptive sizing after points are collected
        let dotSizeRaw=dotSizeInputRaw;
        let dotSizePx=chartStyle.scaleRadius(dotSizeRaw, styleScaleInfo, { context: 'scatter-point', min: 0 });
        const borderWidthPx=chartStyle.scaleStrokeWidth(borderWidthRaw, styleScaleInfo, { context: 'scatter-border', min: 0 });
        const baseAnnotationFontPx = Math.max(fs * 0.65, 7);
        let annotationFontPx = baseAnnotationFontPx;
        let annotationCrowdingScale = 1;
        const annotationStrokeWidthBase = chartStyle.scaleStrokeWidth(0.85, styleScaleInfo, { context: 'scatter-annotation', min: 0.45 });
        let annotationStrokeWidth = annotationStrokeWidthBase;
        debug('Debug: scatter style scaling applied',{
          dotSizeRaw,
          dotSizePx,
          borderWidthRaw,
          borderWidthPx,
          axisStrokeWidth,
          axisStrokeWidthBase,
          axisStroke,
          styleScale: styleScaleInfo?.styleScale
        }); // Debug: scatter style scaling summary
        chartStyle.renderFontSizeLabel({ element: scatterFontSizeVal, fontInfo, input: scatterFontSize });
        debug('Debug: scatter font scaling applied',{
          input: scatterFontSize.value,
          fontSizePt: fontInfo.pt,
          baseFontPx: fontInfo.px,
          scaledFontPx: fs,
          scale: fontInfo.scaleInfo?.scale,
          containerWidth: containerRect?.width,
          containerHeight: containerRect?.height
        }); // Debug: scatter font scaling summary
        const axisMetrics=chartStyle.createAxisMetrics(fontInfo.px, styleScaleInfo);
        debug('Debug: scatter axis metrics',axisMetrics);
        const showGrid=scatterShowGrid.checked;
        const gridStyleBase = getScatterGridStyle(axisStrokeWidthBase);
        const gridStrokeStyle = Object.assign({}, gridStyleBase, {
          thickness: chartStyle.scaleStrokeWidth(gridStyleBase.thickness, styleScaleInfo, { context: 'scatter-grid', min: 0 })
        });
        const gridDash = (gridControls && typeof gridControls.patternToDasharray === 'function')
          ? gridControls.patternToDasharray(gridStrokeStyle.pattern, gridStrokeStyle.thickness)
          : null;
        const gridOpacity = (gridControls && typeof gridControls.transparencyToOpacity === 'function')
          ? gridControls.transparencyToOpacity(gridStrokeStyle.transparency)
          : 1;
        const gridStrokeAttrs = (gridControls && typeof gridControls.getStrokeAttributes === 'function')
          ? gridControls.getStrokeAttributes(gridStrokeStyle, { fallbackColor: DEFAULT_GRID_COLOR, fallbackThickness: axisStrokeWidth })
          : { stroke: DEFAULT_GRID_COLOR, 'stroke-width': axisStrokeWidth };
        info('scatter showGrid', showGrid);
        const showFrame=scatterShowFrame.checked;
        debug('Debug: scatter showFrame state',{showFrame});
        let showLegend = scatterShowLegend ? scatterShowLegend.checked : true;
        debug('Debug: scatter legend toggle state',{ showLegend });
        const showLineControl = getScatterNodeById('scatterShowLine') || scatterShowLine;
        const showPlotStatsControl = getScatterNodeById('scatterShowPlotStats') || scatterShowPlotStats;
        const showCIControl = getScatterNodeById('scatterShowCI') || scatterShowCI;
        const showPIControl = getScatterNodeById('scatterShowPI') || scatterShowPI;
        const graphTypeControl = getScatterNodeById('scatterGraphType') || scatterGraphTypeSelect;
        let showLine = !!showLineControl?.checked;
        let showLineStats = !!showPlotStatsControl?.checked;
        const showIntervals = !!(showLine && ((showCIControl && showCIControl.checked) || (showPIControl && showPIControl.checked)));
        const showDiagnostics = isScatterDiagnosticsEnabled();
        const graphType=graphTypeControl?.value || 'scatter';
        scatterCurrentGraphType=graphType;
        const allowLogAxes=graphType==='scatter';
        if(!allowLogAxes){
          if(scatterLogX?.checked){
            scatterLogX.checked=false;
          }
          if(scatterLogY?.checked){
            scatterLogY.checked=false;
          }
          if(showLine){
            showLine=false;
          }
          if(showLineStats){
            showLineStats=false;
          }
        }
        const logX=allowLogAxes && scatterLogX ? scatterLogX.checked : false;
        const logY=allowLogAxes && scatterLogY ? scatterLogY.checked : false;
        if(showLineControl){
          showLineControl.disabled=!allowLogAxes;
          if(!allowLogAxes && showLineControl.checked){
            showLineControl.checked=false;
          }
        }
        if(showPlotStatsControl){
          showPlotStatsControl.disabled=!allowLogAxes;
          if(!allowLogAxes && showPlotStatsControl.checked){
            showPlotStatsControl.checked=false;
          }
        }
        debug('Debug: scatter graph type resolved',{graphType,allowLogAxes,logX,logY});
        if(!allowLogAxes){
          debug('Debug: scatter forcing trend line off',{graphType});
        }
        debug('Debug: scatter regression toggles', { showLine, showLineStats, showIntervals, showDiagnostics });
        info('drawScatter dot size', dotSizeRaw);
        const log2fcThresholdValue=parseFloat(scatterLog2FCThreshold?.value);
        const negLogPThresholdValue=parseFloat(scatterNegLogPThreshold?.value);
        const log2fcThreshold=Number.isFinite(log2fcThresholdValue)?log2fcThresholdValue:0;
        const negLogPThreshold=Number.isFinite(negLogPThresholdValue)?negLogPThresholdValue:0;
        debug('Debug: scatter threshold values',{graphType,log2fcThreshold,negLogPThreshold});
        const method=scatterStatType.value;
        const xMinManual=parseFloat(scatterXMin.value);
        const xMaxManual=parseFloat(scatterXMax.value);
        const yMinManual=parseFloat(scatterYMin.value);
        const yMaxManual=parseFloat(scatterYMax.value);
        info('scatter manual range',{xMinManual,xMaxManual,yMinManual,yMaxManual});
        const originMode=scatterOriginMode.value;
        const originXInput=parseFloat(scatterOriginX.value);
        const originYInput=parseFloat(scatterOriginY.value);
        info('scatter origin inputs',{originMode,originXInput,originYInput});
        if(scatterThresholdSelectionPending){
          scatterThresholdSelectionPending = false;
          syncScatterThresholdSelection();
        }
        const selectedRowSet = getScatterSelectedRowSet(scatterHot);
        const tableFormatMode = getScatterReplicateMode();
        const cachedCollect = scatterState.cachedCollect;
        let analysis = null;
        let rowCount = 0;
        let colCount = 0;
        let groupedScatterActive = false;
        let includedXCols = [];
        let includedYCols = [];
        let showGroupedReplicatePoints = false;
        let hasZColumn = false;
        let canReuseCollectCache = false;
        const resolvePhysicalRow = (visualRow)=>{
          if(!analysis){
            return visualRow;
          }
          if(typeof analysis.toPhysicalRow === 'function'){
            const mapped = analysis.toPhysicalRow(visualRow);
            if(Number.isInteger(mapped) && mapped >= 0){
              return mapped;
            }
          }
          return visualRow;
        };
        const extractColumn = (colIndex)=>{
          if(!analysis){
            return [];
          }
          if(!Number.isInteger(colIndex) || colIndex < 0 || colIndex >= colCount){
            return [];
          }
          const values = [];
          for(let r = 0; r < rowCount; r++){
            values.push(analysis.data?.[r]?.[colIndex]);
          }
          return values;
        };
        let layout = null;
        const groupedReplicatePointsRequested = graphType === 'scatter'
          && !!scatterShowGroupedReplicates?.checked;
        if(viewOnly
          && !scatterState.dataDirty
          && cachedCollect
          && cachedCollect.graphType === graphType
          && cachedCollect.tableFormat === tableFormatMode
          && (
            !cachedCollect.groupedScatterActive
            || cachedCollect.showGroupedReplicatePoints === (
              groupedReplicatePointsRequested
              && !scatterGroupedXReplicates
            )
          )){
          groupedScatterActive = !!cachedCollect.groupedScatterActive;
          showGroupedReplicatePoints = !!cachedCollect.showGroupedReplicatePoints;
          hasZColumn = !!cachedCollect.hasZColumn;
          canReuseCollectCache = true;
        }else{
          analysis = scatterHot?.getAnalysisData?.() || Shared.hot.getAnalysisData(scatterHot);
          rowCount = analysis.rowCount || 0;
          colCount = analysis.colCount || 0;
          layout = resolveScatterColumnLayout(analysis.data, colCount);
          groupedScatterActive = graphType === 'scatter' && !!layout.grouped;
          const xAnalysisCols = groupedScatterActive
            ? ((Array.isArray(layout.xCols) && layout.xCols.length) ? layout.xCols.slice() : [layout.xCol])
            : [layout.xCol];
          const yAnalysisCols = groupedScatterActive
            ? layout.groups.reduce((acc, group) => {
                for(let col = group.startCol; col <= group.endCol; col += 1){
                  if(col >= 0 && col < colCount){
                    acc.push(col);
                  }
                }
                return acc;
              }, [])
            : [layout.yCol];
          includedXCols = xAnalysisCols.filter(col => !analysis.isColumnExcluded?.(col));
          includedYCols = yAnalysisCols.filter(col => !analysis.isColumnExcluded?.(col));
          const xExcluded = !includedXCols.length;
          const yExcluded = !includedYCols.length;
          if(xExcluded || yExcluded){
            console.warn('Scatter draw cancelled - axis column excluded',{
              xCols: xAnalysisCols,
              yCols: yAnalysisCols,
              excludeX: !!xExcluded,
              excludeY: !!yExcluded
            });
            scatterState.cachedCollect = null;
            scatterState.cachedGeometry = null;
            chartStyle.clearSvg(scatterSvg);
            const placeholder = groupedScatterActive
              ? 'Statistics unavailable until X and at least one grouped Y column are included.'
              : 'Statistics unavailable until both axes are included.';
            primeScatterStatsContext(null,{ placeholder });
            return;
          }
          showGroupedReplicatePoints = groupedScatterActive
            && !scatterGroupedXReplicates
            && !!scatterShowGroupedReplicates?.checked;
          hasZColumn = !groupedScatterActive && Number.isInteger(layout.extraCol) && layout.extraCol >= 0 && colCount > layout.extraCol;
          canReuseCollectCache = viewOnly
            && !scatterState.dataDirty
            && !!cachedCollect
            && cachedCollect.graphType === graphType
            && cachedCollect.tableFormat === tableFormatMode
            && cachedCollect.groupedScatterActive === groupedScatterActive
            && cachedCollect.showGroupedReplicatePoints === showGroupedReplicatePoints
            && cachedCollect.hasZColumn === hasZColumn;
        }
        const selectedRowSignature = buildScatterRowSetSignature(selectedRowSet);
        // Use row selection checkboxes exclusively for point labeling
        const useSelectionFallback = selectedRowSet && selectedRowSet.size > 0;
        let thresholdLabelEnabled = scatterShowSignificantLabels ? !!scatterShowSignificantLabels.checked : true;
        const maxLen = canReuseCollectCache && Array.isArray(cachedCollect?.points)
          ? cachedCollect.points.length
          : rowCount;
        const collectLargeDatasetPolicy = resolveScatterLargeDatasetPolicy({
          graphType,
          rowCount: maxLen,
          viewMode: scatterState.viewMode,
          requestedViewMode: scatterState.requestedViewMode,
          significantLabelsEnabled: thresholdLabelEnabled,
          significantLabelsUserModified: scatterState.significantLabelsUserModified
        });
        const shouldCollectLabelSet = collectLargeDatasetPolicy.collectLabelSet;
        let points=[];
        let labelSet=shouldCollectLabelSet ? new Set() : null;
        let labelsUsed = [];
        let annotationRequests = [];
        let annotationLeaderPadding = 0;
        let annotationTextPadding = 0;
        let annotationAxisPadding = 0;
        let extraLabelRaw = '';
        let legendLayout=null;
        let legendRenderer=EMPTY_LEGEND_RENDERER;
        let legendGapPx=0;
        let legendWidth=0;
        let xMinRaw=Infinity,xMaxRaw=-Infinity,yMinRaw=Infinity,yMaxRaw=-Infinity;
        let skippedRows=0;
        let significantCount=0;
        let maMissingPCount=0;
        let scatter3dCandidates = [];
        let scatter3dEligible = graphType === 'scatter' && hasZColumn;
        let scatter3dMissingZ = 0;
        let scatter3dInvalidZ = 0;
        let zMinRaw=Infinity, zMaxRaw=-Infinity;
        let bubbleEligible = graphType === 'scatter' && hasZColumn;
        let bubbleValidCount = 0;
        let bubbleInvalidCount = 0;
        let bubbleMissingCount = 0;
        let bubbleMinRaw = Infinity;
        let bubbleMaxRaw = -Infinity;
        let manualLabelSignature = selectedRowSignature;
        const shouldAutoDisableSignificantLabels = collectLargeDatasetPolicy.autoDisableSignificantLabels;
        if(shouldAutoDisableSignificantLabels){
          scatterShowSignificantLabels.checked = false;
          thresholdLabelEnabled = false;
          scatterThresholdSelectionPending = false;
          scatterDebug('Debug: scatter significant labels defaulted off for large dataset', {
            graphType,
            rowCount: maxLen,
            limit: SCATTER_SIGNIFICANT_LABELS_AUTO_OFF_POINT_LIMIT
          });
        }
        if(collectLargeDatasetPolicy.largeRows){
          scatterDebug('Debug: scatter large dataset policy resolved', {
            graphType,
            rowCount: collectLargeDatasetPolicy.rowCount,
            viewMode: collectLargeDatasetPolicy.viewMode,
            requestedViewMode: collectLargeDatasetPolicy.requestedViewMode,
            collectLabelSet: collectLargeDatasetPolicy.collectLabelSet,
            autoDensity: collectLargeDatasetPolicy.autoDensity
          });
        }
        const collectPerf = !canReuseCollectCache && perfApi && typeof perfApi.start === 'function'
          ? perfApi.start('scatter.data.collect', { component: 'scatter', rows: maxLen })
          : null;
        if(canReuseCollectCache){
          points = Array.isArray(cachedCollect.points) ? cachedCollect.points : [];
          labelsUsed = Array.isArray(cachedCollect.labelsUsed) ? cachedCollect.labelsUsed.slice() : [];
          if(!shouldCollectLabelSet && labelsUsed.length){
            labelsUsed = [];
          }
          labelSet = shouldCollectLabelSet ? new Set(labelsUsed) : null;
          xMinRaw = Number(cachedCollect.xMinRaw);
          xMaxRaw = Number(cachedCollect.xMaxRaw);
          yMinRaw = Number(cachedCollect.yMinRaw);
          yMaxRaw = Number(cachedCollect.yMaxRaw);
          significantCount = Number(cachedCollect.significantCount) || 0;
          maMissingPCount = Number(cachedCollect.maMissingPCount) || 0;
          scatter3dCandidates = Array.isArray(cachedCollect.scatter3dCandidates) ? cachedCollect.scatter3dCandidates : [];
          scatter3dEligible = !!cachedCollect.scatter3dEligible;
          scatter3dMissingZ = Number(cachedCollect.scatter3dMissingZ) || 0;
          scatter3dInvalidZ = Number(cachedCollect.scatter3dInvalidZ) || 0;
          zMinRaw = Number(cachedCollect.zMinRaw);
          zMaxRaw = Number(cachedCollect.zMaxRaw);
          bubbleEligible = !!cachedCollect.bubbleEligible;
          bubbleValidCount = Number(cachedCollect.bubbleValidCount) || 0;
          bubbleInvalidCount = Number(cachedCollect.bubbleInvalidCount) || 0;
          bubbleMissingCount = Number(cachedCollect.bubbleMissingCount) || 0;
          bubbleMinRaw = Number(cachedCollect.bubbleMinRaw);
          bubbleMaxRaw = Number(cachedCollect.bubbleMaxRaw);
          manualLabelSignature = typeof cachedCollect.manualLabelSignature === 'string'
            ? cachedCollect.manualLabelSignature
            : selectedRowSignature;
          extraLabelRaw = cachedCollect.extraLabelRaw || '';
          if(scatterState.axisLabelModes?.x !== 'manual' && cachedCollect.xLabelText != null){
            scatterState.xLabelText = cachedCollect.xLabelText;
          }
          if(scatterState.axisLabelModes?.y !== 'manual' && cachedCollect.yLabelText != null){
            scatterState.yLabelText = cachedCollect.yLabelText;
          }
          if(scatterState.axisLabelModes?.z !== 'manual' && cachedCollect.zLabelText != null){
            scatterState.zLabelText = cachedCollect.zLabelText;
          }
          scatterXLabelText = scatterState.xLabelText;
          scatterYLabelText = scatterState.yLabelText;
          scatterZLabelText = scatterState.zLabelText;
          info('scatter data collect skipped (view cache)', {
            token,
            points: points.length,
            labels: labelsUsed.length,
            reason: drawOptions?.reason || null
          });
        }else{
          const labelCol = extractColumn(layout.labelCol);
          const xCol = extractColumn(layout.xCol);
          const yCol = extractColumn(layout.yCol);
          const extraCol = extractColumn(layout.extraCol);
          const groupedXColumns = groupedScatterActive ? includedXCols.slice() : [];
          const groupedYColumns = groupedScatterActive
            ? layout.groups.map(group => ({
                index: group.index,
                label: group.label,
                columns: includedYCols.filter(col => col >= group.startCol && col <= group.endCol)
              })).filter(group => group.columns.length)
            : [];
          info('scatter column lengths',{
            label:labelCol.length,
            x:xCol.length,
            y:yCol.length,
            extra:extraCol.length,
            layout
          });
          const rawXLabelHeader = xCol[0];
          const xLabelRaw = groupedScatterActive && layout.xReplicateCount > 1
            ? inferScatterGroupBaseName(rawXLabelHeader, rawXLabelHeader || 'X')
            : rawXLabelHeader;
          const yLabelRaw = groupedScatterActive
            ? (yCol[0] != null ? yCol[0] : '')
            : yCol[0];
          extraLabelRaw = extraCol[0];
          if(graphType==='volcano'){
            const autoXLabel = (xLabelRaw&&String(xLabelRaw).trim())||'log2 Fold Change';
            const basePLabel=(yLabelRaw&&String(yLabelRaw).trim())||'p-value';
            const autoYLabel = `-log10(${basePLabel})`;
            if(scatterState.axisLabelModes?.x !== 'manual'){
              scatterState.xLabelText = autoXLabel;
            }
            if(scatterState.axisLabelModes?.y !== 'manual'){
              scatterState.yLabelText = autoYLabel;
            }
          }else if(graphType==='ma'){
            const autoXLabel = (xLabelRaw&&String(xLabelRaw).trim())||'Mean Expression';
            const autoYLabel = (yLabelRaw&&String(yLabelRaw).trim())||'log2 Fold Change';
            if(scatterState.axisLabelModes?.x !== 'manual'){
              scatterState.xLabelText = autoXLabel;
            }
            if(scatterState.axisLabelModes?.y !== 'manual'){
              scatterState.yLabelText = autoYLabel;
            }
          }else{
            const autoXLabel = (xLabelRaw&&String(xLabelRaw).trim())||'X';
            const normalizedYLabel = yLabelRaw && String(yLabelRaw).trim();
            const yLooksLikeReplicate = /^rep(?:licate)?\s*\d+$/i.test(normalizedYLabel || '');
            const yMatchesGroupedLabel = groupedScatterActive
              && Array.isArray(groupedYColumns)
              && groupedYColumns.some(group => {
                const label = group?.label == null ? '' : String(group.label).trim();
                return !!label && normalizedYLabel && label.toLowerCase() === normalizedYLabel.toLowerCase();
              });
            const autoYLabel = (!groupedScatterActive || (!yLooksLikeReplicate && !yMatchesGroupedLabel))
              ? (normalizedYLabel || 'Y')
              : 'Y';
            const zHeader = extraLabelRaw && String(extraLabelRaw).trim();
            const autoZLabel = zHeader || 'Z';
            if(scatterState.axisLabelModes?.x !== 'manual'){
              scatterState.xLabelText = autoXLabel;
            }
            if(scatterState.axisLabelModes?.y !== 'manual'){
              scatterState.yLabelText = autoYLabel;
            }
            if(scatterState.axisLabelModes?.z !== 'manual'){
              scatterState.zLabelText = autoZLabel;
            }
          }
          scatterXLabelText = scatterState.xLabelText;
          scatterYLabelText = scatterState.yLabelText;
          scatterZLabelText = scatterState.zLabelText;
          time(`scatterCollectPoints_${token}`);
          for(let r=1;r<maxLen;r++){
          const labelValue = labelCol[r];
          const lab=labelValue ? String(labelValue).trim() : '';
          const physicalRow = resolvePhysicalRow(r);
          // Use row selection checkboxes exclusively for point labeling
          const isManualLabel = useSelectionFallback && selectedRowSet?.has(physicalRow);
          const rawX=xCol[r];
          const rawY=yCol[r];
          if(graphType==='scatter'){
            if(groupedScatterActive){
              const xRepValues = [];
              for(let xIdx = 0; xIdx < groupedXColumns.length; xIdx += 1){
                const xColIndex = groupedXColumns[xIdx];
                const rawXValue = analysis.data?.[r]?.[xColIndex];
                if(rawXValue === null || typeof rawXValue === 'undefined' || rawXValue === ''){
                  continue;
                }
                const numericX = parseFloat(rawXValue);
                if(Number.isFinite(numericX)){
                  xRepValues.push(numericX);
                }
              }
              if(!xRepValues.length){
                skippedRows++;
                recordRowSkip('scatter-grouped:missingXReplicates');
                continue;
              }
              const xReplicateCount = xRepValues.length;
              const xv = xRepValues.reduce((sum, value) => sum + value, 0) / xReplicateCount;
              let xStdev = 0;
              if(xReplicateCount > 1){
                const xVariance = xRepValues.reduce((sum, value) => {
                  const diff = value - xv;
                  return sum + diff * diff;
                }, 0) / (xReplicateCount - 1);
                xStdev = Math.sqrt(Math.max(0, xVariance));
              }
              const hasXSpread = xReplicateCount > 1 && Number.isFinite(xStdev) && xStdev > 0;
              const xLower = hasXSpread ? (xv - xStdev) : null;
              const xUpper = hasXSpread ? (xv + xStdev) : null;
              const xMinCandidate = hasXSpread && Number.isFinite(xLower) ? xLower : xv;
              const xMaxCandidate = hasXSpread && Number.isFinite(xUpper) ? xUpper : xv;
              let hasGroupedPoint = false;
              for(let g = 0; g < groupedYColumns.length; g += 1){
                const group = groupedYColumns[g];
                const repValues = [];
                for(let c = 0; c < group.columns.length; c += 1){
                  const colIndex = group.columns[c];
                  const rawRep = analysis.data?.[r]?.[colIndex];
                  if(rawRep === null || typeof rawRep === 'undefined' || rawRep === ''){
                    continue;
                  }
                  const numeric = parseFloat(rawRep);
                  if(Number.isFinite(numeric)){
                    repValues.push(numeric);
                  }
                }
                if(!repValues.length){
                  continue;
                }
                hasGroupedPoint = true;
                const replicateCount = repValues.length;
                const mean = repValues.reduce((sum, value) => sum + value, 0) / replicateCount;
                let stdev = 0;
                if(replicateCount > 1){
                  const variance = repValues.reduce((sum, value) => {
                    const diff = value - mean;
                    return sum + diff * diff;
                  }, 0) / (replicateCount - 1);
                  stdev = Math.sqrt(Math.max(0, variance));
                }
                const hasSpread = replicateCount > 1 && Number.isFinite(stdev) && stdev > 0;
                const lower = hasSpread ? (mean - stdev) : null;
                const upper = hasSpread ? (mean + stdev) : null;
                const repMin = repValues.reduce((min, value) => value < min ? value : min, Number.POSITIVE_INFINITY);
                const repMax = repValues.reduce((max, value) => value > max ? value : max, Number.NEGATIVE_INFINITY);
                const yMinCandidate = showGroupedReplicatePoints
                  ? (Number.isFinite(repMin) ? repMin : mean)
                  : (hasSpread && Number.isFinite(lower) ? lower : mean);
                const yMaxCandidate = showGroupedReplicatePoints
                  ? (Number.isFinite(repMax) ? repMax : mean)
                  : (hasSpread && Number.isFinite(upper) ? upper : mean);
                const groupLabel = (group.label && String(group.label).trim()) || `Series ${group.index + 1}`;
                const pointName = lab || groupLabel;
                points.push({
                  x: xv,
                  y: mean,
                  label: groupLabel,
                  series: groupLabel,
                  pointName,
                  rowIndex: physicalRow,
                  isManualLabel,
                  replicates: repValues.slice(),
                  replicateCount,
                  stdev: hasSpread ? stdev : 0,
                  lower,
                  upper,
                  xReplicates: xRepValues.slice(),
                  xReplicateCount,
                  xStdev: hasXSpread ? xStdev : 0,
                  xLower,
                  xUpper,
                  isGroupedReplicatePoint: false
                });
                if(showGroupedReplicatePoints){
                  for(let repIdx = 0; repIdx < replicateCount; repIdx += 1){
                    const replicateValue = repValues[repIdx];
                    points.push({
                      x: xv,
                      y: replicateValue,
                      label: groupLabel,
                      series: groupLabel,
                      pointName: lab || `${groupLabel} replicate ${repIdx + 1}`,
                      rowIndex: physicalRow,
                      isManualLabel: false,
                      replicateIndex: repIdx + 1,
                      isGroupedReplicatePoint: true
                    });
                  }
                }
                if(labelSet){
                  labelSet.add(groupLabel);
                }
                if(xMinCandidate<xMinRaw) xMinRaw=xMinCandidate;
                if(xMaxCandidate>xMaxRaw) xMaxRaw=xMaxCandidate;
                if(yMinCandidate<yMinRaw) yMinRaw=yMinCandidate;
                if(yMaxCandidate>yMaxRaw) yMaxRaw=yMaxCandidate;
              }
              if(!hasGroupedPoint){
                skippedRows++;
                recordRowSkip('scatter-grouped:noReplicates');
              }
            }else{
              if(rawX === null || typeof rawX === 'undefined' || rawX === ''){
                skippedRows++;
                recordRowSkip('scatter:missingX');
                continue;
              }
              const xv=parseFloat(rawX);
              if(Number.isNaN(xv) || !Number.isFinite(xv)){
                skippedRows++;
                recordRowSkip('scatter:nonNumericX');
                continue;
              }
              if(rawY === null || typeof rawY === 'undefined' || rawY === ''){
                skippedRows++;
                recordRowSkip('scatter:missingY');
                continue;
              }
              const yv=parseFloat(rawY);
              const rawZ = hasZColumn ? extraCol[r] : undefined;
              const hasZValue = hasZColumn && rawZ !== null && typeof rawZ !== 'undefined' && rawZ !== '';
              const zv = hasZValue ? Number(rawZ) : NaN;
              if(!Number.isNaN(yv) && Number.isFinite(yv)){
                const pointRecord = {x:xv,y:yv,label:lab,pointName:lab,rowIndex:physicalRow,isManualLabel};
                if(hasZValue && Number.isFinite(zv)){
                  pointRecord.z = zv;
                  pointRecord.bubbleValue = zv;
                  scatter3dCandidates.push({ x: xv, y: yv, z: zv, label: lab, pointName: lab, rowIndex: physicalRow, isManualLabel, index: scatter3dCandidates.length });
                  if(zv<zMinRaw) zMinRaw=zv;
                  if(zv>zMaxRaw) zMaxRaw=zv;
                  if(zv<bubbleMinRaw) bubbleMinRaw = zv;
                  if(zv>bubbleMaxRaw) bubbleMaxRaw = zv;
                  bubbleValidCount += 1;
                }else if(hasZValue){
                  scatter3dEligible = false;
                  scatter3dInvalidZ += 1;
                  recordRowSkip('scatter3d:nonNumericZ');
                  bubbleEligible = false;
                  bubbleInvalidCount += 1;
                }else{
                  scatter3dEligible = false;
                  scatter3dMissingZ += 1;
                  if(hasZColumn){
                    bubbleEligible = false;
                    bubbleMissingCount += 1;
                  }
                }
                if(!hasZValue && hasZColumn){
                  pointRecord.bubbleValue = NaN;
                }
                points.push(pointRecord);
                if(labelSet && lab) labelSet.add(lab);
                if(xv<xMinRaw) xMinRaw=xv;
                if(xv>xMaxRaw) xMaxRaw=xv;
                if(yv<yMinRaw) yMinRaw=yv;
                if(yv>yMaxRaw) yMaxRaw=yv;
              }else{
                skippedRows++;
                recordRowSkip('scatter:nonNumericY');
              }
            }
          }else if(graphType==='volcano'){
            if(rawX === null || rawY === null || typeof rawX === 'undefined' || typeof rawY === 'undefined'){
              skippedRows++;
              recordRowSkip('volcano:missingValue');
              continue;
            }
            const log2fc=parseFloat(rawX);
            const pRaw=parseFloat(rawY);
            if(Number.isFinite(log2fc) && Number.isFinite(pRaw) && pRaw>0){
              let negLogP=-Math.log10(pRaw);
              if(!Number.isFinite(negLogP)){
                negLogP=-Math.log10(Number.MIN_VALUE);
              }
              const isSignificant=Math.abs(log2fc)>=log2fcThreshold && negLogP>=negLogPThreshold;
              const isThresholdLabel = thresholdLabelEnabled && isSignificant;
              points.push({x:log2fc,y:negLogP,negLogP,label:'',pointName:lab,rowIndex:physicalRow,isManualLabel,isSignificant,isThresholdLabel});
              if(isSignificant){
                significantCount++;
              }
              if(labelSet && lab) labelSet.add(lab);
              if(log2fc<xMinRaw) xMinRaw=log2fc;
              if(log2fc>xMaxRaw) xMaxRaw=log2fc;
              if(negLogP<yMinRaw) yMinRaw=negLogP;
              if(negLogP>yMaxRaw) yMaxRaw=negLogP;
            }else{
              skippedRows++;
              recordRowSkip('volcano:invalid');
            }
          }else{
            if(rawX === null || rawY === null || typeof rawX === 'undefined' || typeof rawY === 'undefined'){
              skippedRows++;
              recordRowSkip('ma:missingValue');
              continue;
            }
            const meanExpr=parseFloat(rawX);
            const log2fcVal=parseFloat(rawY);
            const rawExtra = extraCol[r];
            const pRaw = rawExtra === null || typeof rawExtra === 'undefined' ? NaN : parseFloat(rawExtra);
            const hasPositiveP=Number.isFinite(pRaw) && pRaw>0;
            if(Number.isFinite(meanExpr) && Number.isFinite(log2fcVal)){
              let negLogP=hasPositiveP?-Math.log10(pRaw):NaN;
              if(hasPositiveP && !Number.isFinite(negLogP)){
                negLogP=-Math.log10(Number.MIN_VALUE);
              }
              const isSignificant=hasPositiveP && Math.abs(log2fcVal)>=log2fcThreshold && Number.isFinite(negLogP) && negLogP>=negLogPThreshold;
              const isThresholdLabel = thresholdLabelEnabled && isSignificant;
              // Match volcano plot behavior - use empty label and let AG Grid selection handle labeling
              const labelValueFinal = '';
              points.push({x:meanExpr,y:log2fcVal,negLogP,label:labelValueFinal,pointName:lab,rowIndex:physicalRow,isManualLabel,isSignificant,isThresholdLabel});
              if(isSignificant) significantCount++;
              if(!hasPositiveP){
                maMissingPCount++;
                recordRowSkip('ma:missingPositiveP');
              }
              if(labelSet && lab) labelSet.add(lab);
              if(meanExpr<xMinRaw) xMinRaw=meanExpr;
              if(meanExpr>xMaxRaw) xMaxRaw=meanExpr;
              if(log2fcVal<yMinRaw) yMinRaw=log2fcVal;
              if(log2fcVal>yMaxRaw) yMaxRaw=log2fcVal;
            }else{
              skippedRows++;
              recordRowSkip('ma:nonNumeric');
            }
          }
          if(r >= nextCollectProgressRow){
            info('scatter collect progress',{row:r,token});
            nextCollectProgressRow += collectProgressInterval;
          }
        }
        timeEnd(`scatterCollectPoints_${token}`);
        if(collectPerf && perfApi){
          perfApi.end(collectPerf, { component: 'scatter', points: points.length, skippedRows });
        }
        if(debugEnabled && rowSkipCounts && Object.keys(rowSkipCounts).length){
          debug('Debug: scatter row skip summary',{graphType,skippedRows,reasons:rowSkipCounts});
        }else if(skippedRows>0){
          debug('Debug: scatter skipped rows summary',{graphType,skippedRows});
        }
        if(debugEnabled && maMissingPCount>0){
          debug('Debug: MA missing p-values summary',{count:maMissingPCount});
        }
        if(scatterCurrentGraphType==='scatter'){
          debug('Debug: scatter 3d candidate summary',{
            hasZColumn,
            eligible: scatter3dEligible,
            candidateCount: scatter3dCandidates.length,
            missingZ: scatter3dMissingZ,
            invalidZ: scatter3dInvalidZ
          });
          debug('Debug: scatter bubble candidate summary',{
            hasZColumn,
            eligible: bubbleEligible,
            validCount: bubbleValidCount,
            invalidCount: bubbleInvalidCount,
            missingCount: bubbleMissingCount,
            min: bubbleMinRaw,
            max: bubbleMaxRaw
          });
        }
        }
        if(!canReuseCollectCache){
          labelsUsed = labelSet ? Array.from(labelSet) : [];
          scatterState.cachedCollect = {
            graphType,
            tableFormat: tableFormatMode,
            groupedScatterActive,
            showGroupedReplicatePoints,
            hasZColumn,
            xLabelText: scatterState.xLabelText || '',
            yLabelText: scatterState.yLabelText || '',
            zLabelText: scatterState.zLabelText || '',
            points,
            labelsUsed: labelsUsed.slice(),
            xMinRaw,
            xMaxRaw,
            yMinRaw,
            yMaxRaw,
            significantCount,
            maMissingPCount,
            manualLabelSignature: selectedRowSignature,
            extraLabelRaw,
            scatter3dCandidates,
            scatter3dEligible,
            scatter3dMissingZ,
            scatter3dInvalidZ,
            zMinRaw,
            zMaxRaw,
            bubbleEligible,
            bubbleValidCount,
            bubbleInvalidCount,
            bubbleMissingCount,
            bubbleMinRaw,
            bubbleMaxRaw
          };
        }else if(!Array.isArray(labelsUsed) || !labelsUsed.length){
          labelsUsed = labelSet ? Array.from(labelSet) : [];
        }
        if(scatterState.cachedCollect){
          scatterState.cachedCollect.manualLabelSignature = manualLabelSignature;
        }
        if(scatterState.cachedCollect && !canReuseCollectCache){
          scatterState.dataDirty = false;
          scatterDebug('Debug: scatter data marked clean after collect cache update', {
            graphType,
            points: points.length,
            labels: labelsUsed.length
          });
        }
        debug('Debug: scatter label summary',{graphType:scatterCurrentGraphType,labelCount:labelsUsed.length,tracked:shouldCollectLabelSet}); // Debug: label usage summary
        if(scatterCurrentGraphType!=='scatter'){
          renderScatterStatsAdvisor([], buildScatterAdvisorContext([]));
        }
        let labelShapeLookup=new Map();
        info('scatter points collected',points.length,{xMinRaw,xMaxRaw,yMinRaw,yMaxRaw,graphType});
        const significanceLegendNeeded=scatterCurrentGraphType!=='scatter';
        const shouldRenderSignificantLabels = false;
        if(token!==scatterDrawToken){info('scatter draw cancelled after collect',{token});return;}
        const plotEl=getScatterNodeById('scatterPlot');
        plotEl.style.display='block';
        const clearScatterPlot=()=>{
          if(!plotEl){
            return;
          }
          while(plotEl.firstChild){
            plotEl.removeChild(plotEl.firstChild);
          }
        };
        const renderScatterNotice=(message)=>{
          if(typeof Shared.renderPlotNotice === 'function'){
            Shared.renderPlotNotice(plotEl, message, { resetAspect: true, show: true });
            return;
          }
          plotEl.style.aspectRatio='';
          plotEl.style.padding='';
          clearScatterPlot();
          const notice=document.createElement('i');
          notice.textContent=message;
          plotEl.appendChild(notice);
        };
        if(!points.length){
          const emptyPlotNotice = Shared.getEmptyPlotNoticeMessage
            ? Shared.getEmptyPlotNoticeMessage()
            : 'Add data to the input table to generate a plot.';
          renderScatterNotice(emptyPlotNotice);
          debug('Debug: scatter plot aborted due to empty dataset',{graphType});
          primeScatterStatsContext(null,{ placeholder:'Add data to enable statistics.' });
          return;
        }
        if(logX&&points.some(p=>p.x<=0)){
          if(!scatterState.logPlusOneX){
            renderScatterNotice('Log scale requires positive X values.');
            primeScatterStatsContext(null,{ placeholder:'Statistics unavailable until the axis range is valid.' });
            return;
          }
        }
        if(logY&&points.some(p=>p.y<=0)){
          if(!scatterState.logPlusOneY){
            renderScatterNotice('Log scale requires positive Y values.');
            primeScatterStatsContext(null,{ placeholder:'Statistics unavailable until the axis range is valid.' });
            return;
          }
        }
        let pointsMutable = false;
        const ensureMutablePoints = () => {
          if(pointsMutable){
            return;
          }
          points = cloneScatterPoints(points);
          pointsMutable = true;
        };
        // Apply log+1 transform if enabled
        if(logX && scatterState.logPlusOneX){
          ensureMutablePoints();
          for(let i = 0; i < points.length; i += 1){
            const p = points[i];
            if(Number.isFinite(p?.x)){
              p.x = p.x + 1;
            }
            if(Number.isFinite(p?.xLower)){
              p.xLower = p.xLower + 1;
            }
            if(Number.isFinite(p?.xUpper)){
              p.xUpper = p.xUpper + 1;
            }
            if(Array.isArray(p?.xReplicates) && p.xReplicates.length){
              p.xReplicates = p.xReplicates.map(value => Number.isFinite(value) ? value + 1 : value);
            }
          }
          if(Number.isFinite(xMinRaw)) xMinRaw = xMinRaw + 1;
          if(Number.isFinite(xMaxRaw)) xMaxRaw = xMaxRaw + 1;
          debug('Debug: scatter log+1 transform applied to X');
        }
        if(logY && scatterState.logPlusOneY){
          ensureMutablePoints();
          for(let i = 0; i < points.length; i += 1){
            const p = points[i];
            if(Number.isFinite(p?.y)){
              p.y = p.y + 1;
            }
            if(Number.isFinite(p?.lower)){
              p.lower = p.lower + 1;
            }
            if(Number.isFinite(p?.upper)){
              p.upper = p.upper + 1;
            }
            if(Array.isArray(p?.replicates) && p.replicates.length){
              p.replicates = p.replicates.map(value => Number.isFinite(value) ? value + 1 : value);
            }
          }
          if(Number.isFinite(yMinRaw)) yMinRaw = yMinRaw + 1;
          if(Number.isFinite(yMaxRaw)) yMaxRaw = yMaxRaw + 1;
          debug('Debug: scatter log+1 transform applied to Y');
        }
        if(graphType === 'scatter'){
          const manualSelectionChanged = manualLabelSignature !== selectedRowSignature;
          if(manualSelectionChanged){
            const selectedRows = selectedRowSet && selectedRowSet.size ? selectedRowSet : null;
            for(let i = 0; i < points.length; i += 1){
              const point = points[i];
              if(!point){
                continue;
              }
              if(point.isGroupedReplicatePoint){
                point.isManualLabel = false;
                continue;
              }
              const rowIndex = Number.isInteger(point.rowIndex) ? point.rowIndex : null;
              point.isManualLabel = !!(selectedRows && rowIndex !== null && selectedRows.has(rowIndex));
            }
            manualLabelSignature = selectedRowSignature;
            if(scatterState.cachedCollect && !pointsMutable){
              scatterState.cachedCollect.manualLabelSignature = manualLabelSignature;
            }
          }else{
            debug('Debug: scatter manual label refresh skipped (selection unchanged)', {
              pointCount: points.length,
              selectionSignature: selectedRowSignature
            });
          }
        }else{
          const significanceRefreshSignature = [
            graphType,
            points.length,
            selectedRowSignature,
            Number.isFinite(log2fcThreshold) ? log2fcThreshold : 'nan',
            Number.isFinite(negLogPThreshold) ? negLogPThreshold : 'nan',
            thresholdLabelEnabled ? 1 : 0,
            'direct-threshold-labels'
          ].join('|');
          const cachedSignificanceSignature = typeof scatterState.cachedCollect?.significanceRefreshSignature === 'string'
            ? scatterState.cachedCollect.significanceRefreshSignature
            : scatterState.significanceRefreshSignature;
          const canSkipSignificanceRefresh = viewOnly
            && !pointsMutable
            && canReuseCollectCache
            && cachedSignificanceSignature === significanceRefreshSignature;
          if(canSkipSignificanceRefresh){
            debug('Debug: scatter threshold label refresh skipped (signature unchanged)', {
              graphType,
              pointCount: points.length,
              selectionSignature: selectedRowSignature
            });
          }else{
            let refreshedSignificantCount = 0;
            let refreshedMissingPCount = 0;
            const selectedRows = selectedRowSet && selectedRowSet.size ? selectedRowSet : null;
            for(let i = 0; i < points.length; i += 1){
              const point = points[i];
              if(!point){
                continue;
              }
              const rowIndex = Number.isInteger(point.rowIndex) ? point.rowIndex : null;
              point.isManualLabel = !!(selectedRows && rowIndex !== null && selectedRows.has(rowIndex));
              const negLogPValue = Number.isFinite(Number(point.negLogP))
                ? Number(point.negLogP)
                : (graphType === 'volcano' ? Number(point.y) : NaN);
              const foldChangeValue = graphType === 'volcano' ? Number(point.x) : Number(point.y);
              const isSignificant = Number.isFinite(negLogPValue)
                && Number.isFinite(foldChangeValue)
                && Math.abs(foldChangeValue) >= log2fcThreshold
                && negLogPValue >= negLogPThreshold;
              point.isSignificant = isSignificant;
              point.isThresholdLabel = thresholdLabelEnabled && isSignificant;
              if(isSignificant){
                refreshedSignificantCount += 1;
              }
              if(graphType === 'ma' && !Number.isFinite(negLogPValue)){
                refreshedMissingPCount += 1;
              }
            }
            significantCount = refreshedSignificantCount;
            if(graphType === 'ma'){
              maMissingPCount = refreshedMissingPCount;
            }
            scatterState.significanceRefreshSignature = significanceRefreshSignature;
            if(scatterState.cachedCollect){
              scatterState.cachedCollect.significanceRefreshSignature = significanceRefreshSignature;
              scatterState.cachedCollect.significantCount = significantCount;
              scatterState.cachedCollect.maMissingPCount = maMissingPCount;
            }
          }
        }

        const pointsPrepPerf = perfApi?.start('scatter.points.prepare', {
          component: 'scatter',
          token,
          points: points.length,
          viewOnly
        });
        let xMin=xMinRaw, xMax=xMaxRaw, yMin=yMinRaw, yMax=yMaxRaw;
        if(isFinite(xMinManual)) xMin=xMinManual;
        if(isFinite(xMaxManual)) xMax=xMaxManual;
        if(isFinite(yMinManual)) yMin=yMinManual;
        if(isFinite(yMaxManual)) yMax=yMaxManual;
        const useZeroOrigin = originMode === 'zero';
        if(originMode==='custom'){
          if(isFinite(originXInput)){
            if(logX && originXInput<=0){
              info('scatter custom origin ignored for X in log scale', originXInput);
            }else{
              if(originXInput<xMin) xMin=originXInput;
              if(originXInput>xMax) xMax=originXInput;
            }
          }
          if(isFinite(originYInput)){
            if(logY && originYInput<=0){
              info('scatter custom origin ignored for Y in log scale', originYInput);
            }else{
              if(originYInput<yMin) yMin=originYInput;
              if(originYInput>yMax) yMax=originYInput;
            }
          }
          info('scatter range adjusted for custom origin',{xMin,xMax,yMin,yMax});
        }else if(useZeroOrigin){
          if(!logX){
            if(!isFinite(xMinManual)) xMin = Math.min(xMin, 0);
            if(!isFinite(xMaxManual)) xMax = Math.max(xMax, 0);
          }
          if(!logY){
            if(!isFinite(yMinManual)) yMin = Math.min(yMin, 0);
            if(!isFinite(yMaxManual)) yMax = Math.max(yMax, 0);
          }
          info('scatter range adjusted for zero origin',{xMin,xMax,yMin,yMax,logX,logY});
        }
        let pointsInRange = points;
        let removedForRange = 0;
        let cachedVisualStats = null;
        let cachedVisualStatsSignature = null;
        let cachedVisualStatsControlSignature = null;
        if(graphType === 'scatter' && showIntervals){
          const statsSourcePoints = groupedScatterActive
            ? points.filter(point => !point?.isGroupedReplicatePoint)
            : points;
          const statsPoints = statsSourcePoints.map(p => ({
            label: p.label,
            series: p.series || p.label || '',
            pointName: p.pointName || p.label || '',
            x: p.x,
            y: p.y
          }));
          const groupedStatsSeries = groupedScatterActive
            ? Array.from(statsPoints.reduce((acc, point) => {
                const rawLabel = point?.series != null && String(point.series).trim() !== ''
                  ? String(point.series).trim()
                  : (point?.label != null && String(point.label).trim() !== ''
                    ? String(point.label).trim()
                    : '');
                if(!rawLabel){
                  return acc;
                }
                if(!acc.has(rawLabel)){
                  acc.set(rawLabel, []);
                }
                acc.get(rawLabel).push(point);
                return acc;
              }, new Map()).entries())
              .map(([label, groupPoints]) => ({ label, points: groupPoints.slice() }))
            : [];
          const statsPayloadBase = {
            graphType: 'scatter',
            tabId: resolveScatterTabId(scatterHot),
            points: statsPoints,
            pointSummary: summarizeScatterPoints(statsPoints),
            domain: { minX: xMin, maxX: xMax },
            groupedSeries: groupedStatsSeries,
            thresholds: null,
            significance: null,
            precomputedStats: null,
            precomputedSignature: null,
            signatureSeed: groupedStatsSeries.length ? buildScatterGroupedSignatureSeed(groupedStatsSeries) : null
          };
          const cachedStatsResult = resolveScatterCachedVisualStatsForContext(statsPayloadBase);
          cachedVisualStats = cachedStatsResult.stats;
          cachedVisualStatsSignature = cachedStatsResult.signature;
          cachedVisualStatsControlSignature = cachedStatsResult.controlSignature;
          const intervalBounds = collectScatterIntervalYBounds(cachedVisualStats, {
            includeConfidence: !!(scatterShowCI && scatterShowCI.checked),
            includePrediction: !!(scatterShowPI && scatterShowPI.checked),
            minX: xMin,
            maxX: xMax,
            logX,
            logY
          });
          if(intervalBounds){
            const previousYMin = yMin;
            const previousYMax = yMax;
            if(!isFinite(yMinManual)){
              yMin = Math.min(yMin, intervalBounds.minY);
            }
            if(!isFinite(yMaxManual)){
              yMax = Math.max(yMax, intervalBounds.maxY);
            }
            debug('Debug: scatter auto range expanded for interval bands', {
              previousYMin,
              previousYMax,
              nextYMin: yMin,
              nextYMax: yMax,
              intervalMinY: intervalBounds.minY,
              intervalMaxY: intervalBounds.maxY,
              modelCount: intervalBounds.modelCount,
              sampleCount: intervalBounds.sampleCount,
              signature: cachedVisualStatsSignature
            });
          }else{
            debug('Debug: scatter interval bounds unavailable for auto range', {
              hasCachedVisualStats: !!cachedVisualStats,
              signature: cachedVisualStatsSignature
            });
          }
        }
        const fullRangeCoverage = points.length
          && xMin <= xMinRaw
          && xMax >= xMaxRaw
          && yMin <= yMinRaw
          && yMax >= yMaxRaw;
        if(points.length && !fullRangeCoverage){
          let anyOut = false;
          const filtered = [];
          for(let i = 0; i < points.length; i += 1){
            const p = points[i];
            if(p.x>=xMin && p.x<=xMax && p.y>=yMin && p.y<=yMax){
              filtered.push(p);
            }else{
              removedForRange += 1;
              anyOut = true;
            }
          }
          pointsInRange = anyOut ? filtered : points;
        }
        if(removedForRange>0){
          debug('Debug: scatter filtered points outside axis',{removed:removedForRange,xMin,xMax,yMin,yMax});
        }
        if(!pointsInRange.length){
          if(scatterCurrentGraphType==='scatter'){
            renderScatterStatsAdvisor([], buildScatterAdvisorContext([]));
          }
          renderScatterNotice('No points fall within the specified axis range.');
          debug('Debug: scatter plot aborted due to range filter',{range:{xMin,xMax,yMin,yMax}});
          primeScatterStatsContext(null,{ placeholder:'Adjust the axis range to enable statistics.' });
          return;
        }
        const axisVarianceInfo = scatterState.axesVarianceScaled
          ? resolveScatterAxisVariance(pointsInRange)
          : null;
        scatterColorModeDesired = scatterColorMode ? normalizeScatterColorMode(scatterColorMode.value) : SCATTER_DENSITY_MODE_DEFAULT;
        const renderLargeDatasetPolicy = resolveScatterLargeDatasetPolicy({
          graphType: scatterCurrentGraphType,
          rowCount: maxLen,
          pointCount: pointsInRange.length,
          viewMode: scatterState.viewMode,
          requestedViewMode: scatterState.requestedViewMode
        });
        const colorModeSetting = resolveScatterColorMode({
          mode: scatterColorModeDesired,
          pointCount: pointsInRange.length,
          graphType: scatterCurrentGraphType,
          viewMode: scatterState.viewMode,
          largeDatasetPolicy: renderLargeDatasetPolicy
        });
        scatterColorModeApplied = colorModeSetting.applied;
        const densityPaletteKey = normalizeScatterDensityPalette(scatterDensityPalette?.value);
        const densityColorFor = scatterColorModeApplied === 'density'
          ? createScatterDensityColorMapper(densityPaletteKey)
          : null;
        const densityColoringActive = scatterCurrentGraphType==='scatter' && scatterColorModeApplied === 'density';
        syncScatterColorModeUI(scatterColorModeApplied);
        debug('Debug: scatter color mode resolved',{
          desired: scatterColorModeDesired,
          applied: scatterColorModeApplied,
          allowDensity: colorModeSetting.allowDensity,
          largeDataset: renderLargeDatasetPolicy.largePoints,
          autoDensityAllowed: renderLargeDatasetPolicy.autoDensity,
          palette: densityPaletteKey,
          pointCount: pointsInRange.length,
          viewMode: scatterState.viewMode
        });
        // Apply adaptive point sizing based on the number of data points unless user override is enabled
        if(scatterState.dotSizeOverrideEnabled && Number.isFinite(scatterState.dotSizeOverrideRaw)){
          dotSizeRaw = scatterState.dotSizeOverrideRaw;
          dotSizePx = chartStyle.scaleRadius(dotSizeRaw, styleScaleInfo, { context: 'scatter-point', min: 0 });
          debug('Debug: scatter dot size override applied',{
            pointCount: pointsInRange.length,
            overrideSize: dotSizeRaw,
            scaledSize: dotSizePx
          });
        }else{
          dotSizeRaw = computeAdaptivePointSize(pointsInRange.length);
          dotSizePx = chartStyle.scaleRadius(dotSizeRaw, styleScaleInfo, { context: 'scatter-point', min: 0 });
          debug('Debug: scatter adaptive point size applied',{
            pointCount: pointsInRange.length,
            adaptiveSize: dotSizeRaw,
            scaledSize: dotSizePx
          });
          // Sync the Dot size control to display the applied adaptive size when auto mode is active
          if(scatterDotSize && String(scatterDotSize.value) !== String(dotSizeRaw)){
            try{ scatterDotSize.value = String(dotSizeRaw); }catch(err){ /* ignore UI sync errors */ }
          }
        }
        const shouldAutoHideLegend = scatterCurrentGraphType === 'scatter' && !densityColoringActive && pointsInRange.length > 10;
        if(shouldAutoHideLegend && showLegend){
          scatterLegendChangeInternal = true;
          try{
            if(scatterShowLegend){
              scatterShowLegend.checked = false;
            }
            showLegend = false;
            debug('Debug: scatter legend auto-hidden for large dataset',{ pointCount: pointsInRange.length });
          }finally{
            scatterLegendChangeInternal = false;
          }
        }
        const advisorPerf = perfApi?.start('scatter.stats.advisor', {
          component: 'scatter',
          token,
          points: pointsInRange.length
        });
        if(scatterCurrentGraphType==='scatter'){
          renderScatterStatsAdvisor(pointsInRange);
        }else{
          significantCount=pointsInRange.reduce((acc,p)=>acc+(p.isSignificant?1:0),0);
        }
        if(perfApi && advisorPerf){
          perfApi.end(advisorPerf, {
            component: 'scatter',
            token,
            points: pointsInRange.length
          });
        }
        const largeScatterPointMode = scatterCurrentGraphType === 'scatter'
          && renderLargeDatasetPolicy.useLargePointMode;
        const labelDistribution = scatterCurrentGraphType==='scatter'
          ? (largeScatterPointMode
            ? {
                shouldUseUniform: true,
                pureUnique: false,
                averageFrequency: 0,
                labelCount: labelsUsed.length,
                labeledPointCount: pointsInRange.length,
                totalPoints: pointsInRange.length
              }
            : computeScatterLabelDistribution(pointsInRange))
          : { shouldUseUniform: false, pureUnique: false, averageFrequency: 0, labelCount: 0, labeledPointCount: 0, totalPoints: pointsInRange.length };
        const useUniformLabelStyle = densityColoringActive
          || (scatterCurrentGraphType==='scatter' && labelDistribution.shouldUseUniform);
        if(useUniformLabelStyle){
          scatterDebug('Debug: scatter uniform label styling enabled', {
            largeDataset: largeScatterPointMode,
            pureUnique: labelDistribution.pureUnique,
            averageFrequency: labelDistribution.averageFrequency,
            labelCount: labelDistribution.labelCount,
            labeledPointCount: labelDistribution.labeledPointCount,
            totalPoints: labelDistribution.totalPoints
          });
        }
        scatter.__lastLargeDatasetRenderSummary = {
          graphType: scatterCurrentGraphType,
          viewMode: scatterState.viewMode,
          pointCount: pointsInRange.length,
          labelCount: labelsUsed.length,
          colorModeDesired: scatterColorModeDesired,
          colorModeApplied: scatterColorModeApplied,
          collectLabelSet: shouldCollectLabelSet,
          useLargePointMode: renderLargeDatasetPolicy.useLargePointMode,
          renderMode: null
        };
        if(scatterCurrentGraphType==='scatter' && !useUniformLabelStyle){
          const labelsUsedSet = labelSet || new Set(labelsUsed);
          ensureScatterLabelColors(labelsUsed, { labelSet: labelsUsedSet });
          ensureScatterLabelShapes(labelsUsed, { labelSet: labelsUsedSet });
        }
        labelShapeLookup = new Map();
        if(scatterCurrentGraphType === 'scatter' && !useUniformLabelStyle){
          labelsUsed.forEach((lab, idx)=>{
            if(!lab){ return; }
            const sanitized = sanitizeScatterLabelShape(scatterLabelShapes[lab], idx);
            scatterLabelShapes[lab] = sanitized;
            labelShapeLookup.set(lab, sanitized);
          });
        }
        const visibleLabels = shouldCollectLabelSet
          ? (removedForRange === 0 ? labelsUsed : Array.from(new Set(pointsInRange.map(p=>p.label).filter(Boolean))))
          : [];
        legendLayout = null;
        if(showLegend){
          const legendEntries=[];
          if(scatterCurrentGraphType==='scatter'){
            if(densityColoringActive){
              const low = densityColorFor ? densityColorFor(0.1) : fill;
              const mid = densityColorFor ? densityColorFor(0.55) : fill;
              const high = densityColorFor ? densityColorFor(1) : fill;
              legendEntries.push({ label:'High density', fill: high, editable:false, key:'__scatter_density_high__', shape:'circle' });
              legendEntries.push({ label:'Medium', fill: mid, editable:false, key:'__scatter_density_mid__', shape:'circle' });
              legendEntries.push({ label:'Low density', fill: low, editable:false, key:'__scatter_density_low__', shape:'circle' });
            }else if(useUniformLabelStyle){
              legendEntries.push({
                label:'All points',
                fill,
                key:'__scatter_uniform__',
                editable:false,
                shape:'circle',
                labelIndex:0
              });
            }else{
              visibleLabels.forEach((labelName, labelIndex)=>{
                const shapeValue = sanitizeScatterLabelShape(scatterLabelShapes[labelName], labelIndex);
                scatterLabelShapes[labelName] = shapeValue;
                legendEntries.push({
                  label:labelName,
                  fill:scatterLabelColors[labelName]||fill,
                  key:labelName,
                  editable:true,
                  shape: shapeValue,
                  labelIndex
                });
              });
            }
          }else if(significanceLegendNeeded){
            if(scatterCurrentGraphType === 'volcano'){
              legendEntries.push({label:'Significant (positive)',fill:significanceColors.positive});
              legendEntries.push({label:'Significant (negative)',fill:significanceColors.negative});
              legendEntries.push({label:'Not significant',fill});
            }else{
              legendEntries.push({label:'Significant',fill:significanceColors.positive});
              legendEntries.push({label:'Not significant',fill});
            }
          }
          legendLayout = chartStyle.computeLegendLayout({
            entries:legendEntries,
            fontSize:fs,
            strokeWidth:borderWidthPx,
            textColor: scatterThemeTextColor,
            onSwatchClick:({ entry, event, swatch, index })=>{
              const labelKey=entry?.key;
              if(!labelKey || entry?.editable===false || scatterColorModeApplied === 'density'){
                return;
              }
              if(event){ event.stopPropagation(); }
              const currentColor=scatterLabelColors[labelKey]||entry.fill;
              const labelIndex = Number.isInteger(entry?.labelIndex) ? entry.labelIndex : (Number.isInteger(index) ? index : visibleLabels.indexOf(labelKey));
              const currentShape = sanitizeScatterLabelShape(scatterLabelShapes[labelKey], labelIndex);
              scatterLabelShapes[labelKey] = currentShape;
              const applyLegendColor=value=>{
                const nextValue=value!=null?String(value):'';
                const previousValue=scatterLabelColors[labelKey] || '';
                if(nextValue){
                  if(previousValue===nextValue){
                    return true;
                  }
                  scatterLabelColors[labelKey]=nextValue;
                }else if(previousValue){
                  delete scatterLabelColors[labelKey];
                }else{
                  return true;
                }
                scheduleScatterViewRefresh('legend-color-change');
                return true;
              };
              const applyLegendShape=value=>{
                const sanitizedValue=sanitizeScatterLabelShape(value, labelIndex);
                if(sanitizeScatterLabelShape(scatterLabelShapes[labelKey], labelIndex)===sanitizedValue){
                  return true;
                }
                scatterLabelShapes[labelKey]=sanitizedValue;
                scheduleScatterViewRefresh('legend-shape-change');
                return true;
              };
              let previousColor=currentColor;
              let previousShape=currentShape;
              Shared.openColorPicker({
                anchor:swatch,
                color:currentColor,
                shapePicker: scatterCurrentGraphType==='scatter' && scatterState.viewMode !== 'bubble' ? {
                  value: currentShape,
                  options: SCATTER_SHAPE_OPTIONS,
                  onChange(nextShape){
                    const sanitized = sanitizeScatterLabelShape(nextShape, labelIndex);
                    if(sanitized===previousShape){
                      return;
                    }
                    applyLegendShape(sanitized);
                    recordScatterChange(`scatter:legend-shape:${labelKey}`,previousShape,sanitized,applyLegendShape);
                    previousShape=sanitized;
                    debug('Debug: scatter legend shape change',{ label: labelKey, shape: sanitized, index: labelIndex });
                  }
                } : null,
                onInput(value){
                  applyLegendColor(value);
                  debug('Debug: scatter legend color input',{label:labelKey,color:value});
                },
                onChange(value){
                  const nextValue=value!=null?String(value):'';
                  if(nextValue===previousColor){
                    return;
                  }
                  applyLegendColor(nextValue);
                  recordScatterChange(`scatter:legend-color:${labelKey}`,previousColor,nextValue,applyLegendColor);
                  previousColor=nextValue;
                }
              });
            }
          });
          legendRenderer=legendLayout.renderer || EMPTY_LEGEND_RENDERER;
          legendGapPx=legendLayout.legendGapPx || 0;
          legendWidth=legendLayout.legendWidthForMargin || 0;
        }else{
          legendLayout = null;
          legendRenderer=EMPTY_LEGEND_RENDERER;
          legendGapPx=0;
          legendWidth=0;
          debug('Debug: scatter legend hidden via toggle',{graphType:scatterCurrentGraphType});
        }
        const legendVisible = showLegend && legendRenderer.entries.length > 0;
        debug('Debug: scatter legend metrics',{legendWidth,legendGapPx,entryCount:legendRenderer.entries.length,graphType:scatterCurrentGraphType,showLegend,legendVisible});
        points = pointsInRange;
        if(xMin===xMax) xMax=xMin+1;
        if(yMin===yMax) yMax=yMin+1;
        info('scatter final raw range',{xMin,xMax,yMin,yMax});
        const axisMidpoint = Number.isFinite(xMin) && Number.isFinite(xMax)
          ? (xMin + xMax) / 2
          : 0;
        const desiredAnnotationCap = shouldRenderSignificantLabels ? points.length : undefined;
        let annotationRequestInfo = buildScatterAnnotationRequests(points, {
          enabled: shouldRenderSignificantLabels,
          axisMid: axisMidpoint,
          fontSize: annotationFontPx,
          maxAnnotations: desiredAnnotationCap
        });
        annotationRequests = annotationRequestInfo.requests;
        if(annotationRequests.length){
          annotationCrowdingScale = resolveScatterAnnotationCrowdingScale(annotationRequests.length, {
            comfortable: SCATTER_ANNOTATION_COMFORTABLE_COUNT,
            minScale: SCATTER_ANNOTATION_MIN_SCALE
          });
          const scaledFontPx = Math.max(5.5, baseAnnotationFontPx * annotationCrowdingScale);
          if(Math.abs(scaledFontPx - annotationFontPx) > 0.25){
            annotationFontPx = scaledFontPx;
            annotationRequestInfo = buildScatterAnnotationRequests(points, {
              enabled: shouldRenderSignificantLabels,
              axisMid: axisMidpoint,
              fontSize: annotationFontPx,
              maxAnnotations: desiredAnnotationCap
            });
            annotationRequests = annotationRequestInfo.requests;
          }else{
            annotationFontPx = scaledFontPx;
          }
          const annotationLeaderPaddingBase = chartStyle.scaleStrokeWidth(Math.max(dotSizePx * 3, fs * 1.1), styleScaleInfo, { context: 'scatter-annotation-padding', min: 10 });
          const annotationAxisPaddingBase = Math.max(fs * 0.8, axisStrokeWidth * 3, 10);
          const annotationTextPaddingBase = Math.max(4, annotationLeaderPaddingBase * 0.4);
          const connectorScale = Math.max(0.45, annotationCrowdingScale);
          annotationLeaderPadding = Math.max(6, annotationLeaderPaddingBase * connectorScale);
          annotationTextPadding = Math.max(2, annotationTextPaddingBase * connectorScale);
          annotationAxisPadding = Math.max(6, annotationAxisPaddingBase * connectorScale);
          annotationStrokeWidth = Math.max(0.35, annotationStrokeWidthBase * connectorScale);
        }else{
          annotationLeaderPadding = 0;
          annotationTextPadding = 0;
          annotationAxisPadding = 0;
        }
        let points3dInRange = [];
        if(scatterCurrentGraphType==='scatter' && scatter3dCandidates.length){
          const full3dRangeCoverage = xMin <= xMinRaw
            && xMax >= xMaxRaw
            && yMin <= yMinRaw
            && yMax >= yMaxRaw;
          points3dInRange = full3dRangeCoverage
            ? scatter3dCandidates
            : scatter3dCandidates.filter(pt => pt.x>=xMin && pt.x<=xMax && pt.y>=yMin && pt.y<=yMax);
        }
        let supports3d = scatterCurrentGraphType==='scatter' && scatter3dEligible && scatter3dCandidates.length>=3 && points3dInRange.length>=3;
        let supportsBubble = false;
        if(scatterCurrentGraphType==='scatter' && bubbleEligible){
          const fullBubbleRangeCoverage = xMin <= xMinRaw
            && xMax >= xMaxRaw
            && yMin <= yMinRaw
            && yMax >= yMaxRaw;
          let bubbleValidInRange = fullBubbleRangeCoverage ? bubbleValidCount : 0;
          let bubbleMissingInRange = fullBubbleRangeCoverage ? bubbleMissingCount : 0;
          if(!fullBubbleRangeCoverage){
            for(let i = 0; i < pointsInRange.length; i += 1){
              const candidate = pointsInRange[i];
              if(Number.isFinite(candidate?.bubbleValue)){
                bubbleValidInRange += 1;
              }else{
                bubbleMissingInRange += 1;
              }
            }
          }
          supportsBubble = bubbleValidInRange > 0 && bubbleMissingInRange === 0;
        }
        scatterState.supports3d = supports3d;
        scatterState.supportsBubble = supportsBubble;
        updateScatterViewModeOptionVisibility();
        const desiredViewMode = scatterState.requestedViewMode || scatterState.viewMode || '2d';
        const allowAdvanced = scatterCurrentGraphType === 'scatter';
        const effectiveViewMode = applyScatterViewMode(desiredViewMode, {
          allow3d: allowAdvanced,
          allowBubble: allowAdvanced,
          skipSchedule: true,
          forceUpdate: true
        });
        if(effectiveViewMode === '3d' && !supports3d){
          renderScatterNotice('3D scatter view requires numeric X, Y, and Z values (with at least three complete rows). Add a Z column to continue.');
          debug('Debug: scatter 3d view pending dataset',{ supports3d, candidateCount: scatter3dCandidates.length, pointsInRange: points3dInRange.length });
          return;
        }
        if(effectiveViewMode === 'bubble' && !supportsBubble){
          renderScatterNotice('Bubble view requires numeric X, Y, and bubble columns with non-missing values for every visible row.');
          debug('Debug: scatter bubble view pending dataset',{ supportsBubble, bubbleEligible, bubbleCandidates: pointsInRange.length });
          return;
        }
        if(perfApi && pointsPrepPerf){
          perfApi.end(pointsPrepPerf, {
            component: 'scatter',
            token,
            points: points.length,
            viewOnly
          });
        }
        const existingScatterSvg = plotEl.querySelector('#scatterSvg');
        const reuse3dSvg = supports3d && effectiveViewMode === '3d' && existingScatterSvg && existingScatterSvg.dataset.viewMode === '3d';
        if(effectiveViewMode === '3d' && !reuse3dSvg){
          clearScatterPlot();
        }
        if(supports3d && effectiveViewMode === '3d'){
          scatterState.rotationPending = false;
          scatterState.rotationPendingLogged = false;
          if(typeof plot3d.normalizeRotation === 'function'){
            plot3d.normalizeRotation(scatterState.rotation);
          }
          const targetAspect = Number.isFinite(SCATTER_3D_DEFAULTS.aspectRatio) && SCATTER_3D_DEFAULTS.aspectRatio > 0 ? SCATTER_3D_DEFAULTS.aspectRatio : (4/3);
          const fallbackWidth = 420;
          const fallbackHeight = Math.round(fallbackWidth / targetAspect);
          const bounds = typeof plotEl.getBoundingClientRect === 'function' ? plotEl.getBoundingClientRect() : { width: 0, height: 0 };
          const availableWidth = Math.floor(bounds.width || plotEl.clientWidth || 0);
          const availableHeight = Math.floor(bounds.height || plotEl.clientHeight || 0);
          let W3 = availableWidth > 0 ? availableWidth : fallbackWidth;
          let H3 = Math.round(W3 / targetAspect);
          if(availableHeight > 0 && H3 > availableHeight){
            H3 = Math.max(1, availableHeight);
            W3 = Math.max(1, Math.round(H3 * targetAspect));
            if(availableWidth > 0 && W3 > availableWidth){
              W3 = Math.max(1, availableWidth);
              H3 = Math.max(1, Math.round(W3 / targetAspect));
            }
          }
          if(W3 <= 0 || H3 <= 0){
            W3 = fallbackWidth;
            H3 = fallbackHeight;
          }
          plotEl.style.position='relative';
          plotEl.style.aspectRatio = `${W3} / ${H3}`;
          plotEl.style.padding = plotEl.style.padding || '12px';
          plotEl.style.backgroundColor = '';
          plotEl.style.boxSizing = 'border-box';
          const svg3 = reuse3dSvg ? existingScatterSvg : document.createElementNS(NS,'svg');
          if(!svg3){
            return;
          }
          if(!reuse3dSvg){
            svg3.setAttribute('id','scatterSvg');
            plotEl.appendChild(svg3);
          }
          svg3.setAttribute('width',String(W3));
          svg3.setAttribute('height',String(H3));
          svg3.setAttribute('viewBox',`0 0 ${W3} ${H3}`);
          svg3.setAttribute('font-family',chartStyle.FONT_FAMILY);
          svg3.dataset.viewMode = '3d';
          chartStyle.applySvgDefaults(svg3);
          while(svg3.firstChild){
            svg3.removeChild(svg3.firstChild);
          }
          svg3.style.backgroundColor = scatterThemeDark
            ? normalizeScatterThemeColor(scatterBackgroundColor, '#000000')
            : '';
          svg3.style.pointerEvents = 'all';
          svg3.setAttribute('data-color-scheme', scatterColorSchemeId || 'scientific');
          appendScatter3dBackground(svg3, W3, H3);
          svg3.addEventListener('mouseleave', handleScatterPlotMouseLeave);
          plot3d.attachRotationControls(svg3, {
            state: scatterState.rotation,
            onChange: () => scheduleScatterRotationRedraw(),
            shouldIgnorePointer: (event) => {
              if(typeof plot3d.isInteractivePointerTarget === 'function'){
                return plot3d.isInteractivePointerTarget(event?.target);
              }
              return plot3d.isLegendPointerTarget(event?.target);
            },
            debugLabel: 'scatter-3d'
          });
          if(fontControls && typeof fontControls.enableForSvg === 'function'){
            fontControls.enableForSvg(svg3,{ scopeId: 'scatter' });
          }
          const legendAxisGap = Math.max(fs * 0.9, 18);
          const appliedLegendAxisGap = legendVisible ? legendAxisGap : 0;
          const legendGapFor3d = legendLayout?.legendGapPx ?? legendGapPx;
          const baseLegendMargin = Math.max(fs * 2.25, 28);
          const legendMargin = legendVisible ? legendWidth + appliedLegendAxisGap + baseLegendMargin : baseLegendMargin;
          const margin3 = {
            top: Math.max(fs * 3.2, 36),
            right: legendMargin,
            bottom: Math.max(fs * 3.2, 40),
            left: Math.max(fs * 3.2, 40)
          };
          const legendShiftX = typeof plot3d.resolveLegendShiftX === 'function'
            ? plot3d.resolveLegendShiftX({ legendVisible, margin: margin3, fontSize: fs, legendWidth })
            : 0;
          const plotW3 = Math.max(20, W3 - margin3.left - margin3.right);
          const plotH3 = Math.max(20, H3 - margin3.top - margin3.bottom);
          const dataBounds = { xMin: Infinity, xMax: -Infinity, yMin: Infinity, yMax: -Infinity, zMin: Infinity, zMax: -Infinity };
          points3dInRange.forEach(pt => {
            if(pt.x<dataBounds.xMin) dataBounds.xMin=pt.x;
            if(pt.x>dataBounds.xMax) dataBounds.xMax=pt.x;
            if(pt.y<dataBounds.yMin) dataBounds.yMin=pt.y;
            if(pt.y>dataBounds.yMax) dataBounds.yMax=pt.y;
            if(pt.z<dataBounds.zMin) dataBounds.zMin=pt.z;
            if(pt.z>dataBounds.zMax) dataBounds.zMax=pt.z;
          });
          if(!Number.isFinite(dataBounds.xMin)){ dataBounds.xMin = xMin; }
          if(!Number.isFinite(dataBounds.xMax)){ dataBounds.xMax = xMax; }
          if(!Number.isFinite(dataBounds.yMin)){ dataBounds.yMin = yMin; }
          if(!Number.isFinite(dataBounds.yMax)){ dataBounds.yMax = yMax; }
          if(!Number.isFinite(dataBounds.zMin) || !Number.isFinite(dataBounds.zMax)){
            dataBounds.zMin = Math.min(-1, zMinRaw);
            dataBounds.zMax = Math.max(1, zMaxRaw);
          }
          if(dataBounds.zMin === dataBounds.zMax){
            const pad = Math.abs(dataBounds.zMin) || 1;
            dataBounds.zMin -= pad;
            dataBounds.zMax += pad;
          }
          const baseTickEstimate3d = chartStyle.estimateTickCount ? chartStyle.estimateTickCount(Math.max(plotW3, plotH3), { fallback: 6 }) : 6;
          const tickTarget3d = clampScatterTickTarget(baseTickEstimate3d || 6);
          const xScale3d = buildScatterScale({
            dataMin: dataBounds.xMin,
            dataMax: dataBounds.xMax,
            manualMin: Number.isFinite(xMinManual) ? xMinManual : NaN,
            manualMax: Number.isFinite(xMaxManual) ? xMaxManual : NaN,
            targetTickCount: tickTarget3d
          });
          const yScale3d = buildScatterScale({
            dataMin: dataBounds.yMin,
            dataMax: dataBounds.yMax,
            manualMin: Number.isFinite(yMinManual) ? yMinManual : NaN,
            manualMax: Number.isFinite(yMaxManual) ? yMaxManual : NaN,
            targetTickCount: tickTarget3d
          });
          const zScale3d = buildScatterScale({
            dataMin: dataBounds.zMin,
            dataMax: dataBounds.zMax,
            targetTickCount: tickTarget3d
          });
          let axisRanges3d = {
            x: { min: Number.isFinite(xScale3d.min) ? xScale3d.min : dataBounds.xMin, max: Number.isFinite(xScale3d.max) ? xScale3d.max : dataBounds.xMax },
            y: { min: Number.isFinite(yScale3d.min) ? yScale3d.min : dataBounds.yMin, max: Number.isFinite(yScale3d.max) ? yScale3d.max : dataBounds.yMax },
            z: { min: Number.isFinite(zScale3d.min) ? zScale3d.min : dataBounds.zMin, max: Number.isFinite(zScale3d.max) ? zScale3d.max : dataBounds.zMax }
          };
          const axisTicksOriginal3d = {
            x: Array.isArray(xScale3d.ticks) ? xScale3d.ticks : [],
            y: Array.isArray(yScale3d.ticks) ? yScale3d.ticks : [],
            z: Array.isArray(zScale3d.ticks) ? zScale3d.ticks : []
          };
          let axisTicks3d = axisTicksOriginal3d;
          let renderAxisRanges3d = axisRanges3d;
          let renderPoints3d = points3dInRange;
          let axisTickFormatters3d = null;
          const equalScale3d = !!scatterState.equalScaleAxes;
          const equalLength3d = !!scatterState.equalAxes;
          if(equalScale3d){
            const axisCenters3d = {
              x: (axisRanges3d.x.min + axisRanges3d.x.max) / 2,
              y: (axisRanges3d.y.min + axisRanges3d.y.max) / 2,
              z: (axisRanges3d.z.min + axisRanges3d.z.max) / 2
            };
            const axisSpans3d = {
              x: axisRanges3d.x.max - axisRanges3d.x.min,
              y: axisRanges3d.y.max - axisRanges3d.y.min,
              z: axisRanges3d.z.max - axisRanges3d.z.min
            };
            const maxSpan = Math.max(axisSpans3d.x, axisSpans3d.y, axisSpans3d.z, 1);
            if(Number.isFinite(maxSpan) && maxSpan > 0){
              const halfSpan = maxSpan / 2;
              axisRanges3d = {
                x: { min: axisCenters3d.x - halfSpan, max: axisCenters3d.x + halfSpan },
                y: { min: axisCenters3d.y - halfSpan, max: axisCenters3d.y + halfSpan },
                z: { min: axisCenters3d.z - halfSpan, max: axisCenters3d.z + halfSpan }
              };
              renderAxisRanges3d = axisRanges3d;
              const xTicksScale3d = buildScatterScale({
                dataMin: axisRanges3d.x.min,
                dataMax: axisRanges3d.x.max,
                manualMin: axisRanges3d.x.min,
                manualMax: axisRanges3d.x.max,
                targetTickCount: tickTarget3d
              });
              const yTicksScale3d = buildScatterScale({
                dataMin: axisRanges3d.y.min,
                dataMax: axisRanges3d.y.max,
                manualMin: axisRanges3d.y.min,
                manualMax: axisRanges3d.y.max,
                targetTickCount: tickTarget3d
              });
              const zTicksScale3d = buildScatterScale({
                dataMin: axisRanges3d.z.min,
                dataMax: axisRanges3d.z.max,
                manualMin: axisRanges3d.z.min,
                manualMax: axisRanges3d.z.max,
                targetTickCount: tickTarget3d
              });
              axisTicks3d = {
                x: Array.isArray(xTicksScale3d.ticks) ? xTicksScale3d.ticks : [],
                y: Array.isArray(yTicksScale3d.ticks) ? yTicksScale3d.ticks : [],
                z: Array.isArray(zTicksScale3d.ticks) ? zTicksScale3d.ticks : []
              };
              scatterDebug('Debug: scatter 3d equal scale applied', {
                maxSpan,
                axisRanges: axisRanges3d
              });
            }else{
              scatterDebug('Debug: scatter 3d equal scale skipped', { maxSpan, axisSpans: axisSpans3d });
            }
          }else if(equalLength3d){
            const axisCenters3d = {
              x: (axisRanges3d.x.min + axisRanges3d.x.max) / 2,
              y: (axisRanges3d.y.min + axisRanges3d.y.max) / 2,
              z: (axisRanges3d.z.min + axisRanges3d.z.max) / 2
            };
            const axisSpans3d = {
              x: axisRanges3d.x.max - axisRanges3d.x.min,
              y: axisRanges3d.y.max - axisRanges3d.y.min,
              z: axisRanges3d.z.max - axisRanges3d.z.min
            };
            const maxSpan = Math.max(axisSpans3d.x, axisSpans3d.y, axisSpans3d.z, 1);
            const scaleFactors = {
              x: axisSpans3d.x > 0 ? (maxSpan / axisSpans3d.x) : 1,
              y: axisSpans3d.y > 0 ? (maxSpan / axisSpans3d.y) : 1,
              z: axisSpans3d.z > 0 ? (maxSpan / axisSpans3d.z) : 1
            };
            const scaleValue = (axisKey, value) => axisCenters3d[axisKey] + (value - axisCenters3d[axisKey]) * scaleFactors[axisKey];
            const unscaleValue = (axisKey, value) => axisCenters3d[axisKey] + (value - axisCenters3d[axisKey]) / (scaleFactors[axisKey] || 1);
            renderAxisRanges3d = {
              x: { min: scaleValue('x', axisRanges3d.x.min), max: scaleValue('x', axisRanges3d.x.max) },
              y: { min: scaleValue('y', axisRanges3d.y.min), max: scaleValue('y', axisRanges3d.y.max) },
              z: { min: scaleValue('z', axisRanges3d.z.min), max: scaleValue('z', axisRanges3d.z.max) }
            };
            axisTicks3d = {
              x: axisTicksOriginal3d.x.map(value => scaleValue('x', value)),
              y: axisTicksOriginal3d.y.map(value => scaleValue('y', value)),
              z: axisTicksOriginal3d.z.map(value => scaleValue('z', value))
            };
            const formatTick = (axisKey, scaledValue) => {
              const originalValue = unscaleValue(axisKey, scaledValue);
              if(typeof chartStyle.formatAxisValue === 'function'){
                return chartStyle.formatAxisValue(originalValue, { maxDecimals: 2 });
              }
              if(typeof chartStyle.formatScientific === 'function'){
                return chartStyle.formatScientific(originalValue, { maxDecimals: 2 });
              }
              if(!Number.isFinite(originalValue)){
                return '';
              }
              return String(originalValue);
            };
            axisTickFormatters3d = {
              x: value => formatTick('x', value),
              y: value => formatTick('y', value),
              z: value => formatTick('z', value)
            };
            renderPoints3d = points3dInRange.map(pt => ({
              ...pt,
              x: scaleValue('x', pt.x),
              y: scaleValue('y', pt.y),
              z: scaleValue('z', pt.z)
            }));
            scatterDebug('Debug: scatter 3d equal length applied', {
              maxSpan,
              axisRanges: axisRanges3d,
              renderAxisRanges: renderAxisRanges3d,
              scaleFactors
            });
          }
          const allCorners = [
            { x: renderAxisRanges3d.x.min, y: renderAxisRanges3d.y.min, z: renderAxisRanges3d.z.min },
            { x: renderAxisRanges3d.x.max, y: renderAxisRanges3d.y.min, z: renderAxisRanges3d.z.min },
            { x: renderAxisRanges3d.x.min, y: renderAxisRanges3d.y.max, z: renderAxisRanges3d.z.min },
            { x: renderAxisRanges3d.x.max, y: renderAxisRanges3d.y.max, z: renderAxisRanges3d.z.min },
            { x: renderAxisRanges3d.x.min, y: renderAxisRanges3d.y.min, z: renderAxisRanges3d.z.max },
            { x: renderAxisRanges3d.x.max, y: renderAxisRanges3d.y.min, z: renderAxisRanges3d.z.max },
            { x: renderAxisRanges3d.x.min, y: renderAxisRanges3d.y.max, z: renderAxisRanges3d.z.max },
            { x: renderAxisRanges3d.x.max, y: renderAxisRanges3d.y.max, z: renderAxisRanges3d.z.max }
          ];
          const rotatePoint = (pt) => plot3d.rotatePoint(pt, scatterState.rotation);
          const rotatedCorners = allCorners.map(corner => rotatePoint(corner));
          const rotatedPoints = renderPoints3d.map(pt => rotatePoint(pt));
          const projector = plot3d.createProjector({
            rotatedPoints,
            rotatedCorners,
            width: W3,
            height: H3,
            margin: margin3,
            shiftX: legendShiftX
          });
          const labelBounds3d = computeScatterLabelBounds3d(rotatedCorners, projector.project);
          if(labelBounds3d){
            scatterDebug('Debug: scatter 3d label bounds resolved', {
              minX: labelBounds3d.minX,
              maxX: labelBounds3d.maxX,
              minY: labelBounds3d.minY,
              maxY: labelBounds3d.maxY
            });
          }
          const labelHull3d = Shared.labelLayout && typeof Shared.labelLayout.computeConvexHull2d === 'function'
            ? Shared.labelLayout.computeConvexHull2d(rotatedCorners.map(corner => projector.project(corner)))
            : null;
          if(labelHull3d && labelHull3d.length >= 3){
            scatterDebug('Debug: scatter 3d label hull resolved', { points: labelHull3d.length });
          }
          const projectedPoints = renderPoints3d.map((pt, idx) => {
            const rotated = rotatedPoints[idx];
            const projected = projector.project(rotated);
            const original = points3dInRange[idx];
            return { original, rotated, projected };
          });
          const sortedPoints = projectedPoints.map((entry, idx) => {
            const pt = entry.original;
            const projected = entry.projected;
            return {
              index: idx,
              projected,
              label: pt.label,
              color: useUniformLabelStyle ? fill : (scatterLabelColors[pt.label] || fill),
              shape: useUniformLabelStyle ? 'circle' : (labelShapeLookup.get(pt.label) || 'circle'),
              data: pt
            };
          }).sort((a, b) => (a.projected.depth || 0) - (b.projected.depth || 0));
          const add3 = (tag, attrs, text) => {
            const el = document.createElementNS(NS, tag);
            Object.keys(attrs || {}).forEach(key => el.setAttribute(key, String(attrs[key])));
            if(text){ el.textContent = text; }
            svg3.appendChild(el);
            return el;
          };
          const frontFrameLayer = document.createElementNS(NS, 'g');
          frontFrameLayer.setAttribute('data-layer', 'frame-front');
          svg3.appendChild(frontFrameLayer);
          plot3d.renderAxesAndGrid({
            svg: svg3,
            project: projector.project,
            rotatePoint,
            axisRanges: renderAxisRanges3d,
            axisTicks: axisTicks3d,
            axisLabels: {
              x: scatterState.xLabelText || 'X',
              y: scatterState.yLabelText || 'Y',
              z: scatterState.zLabelText || 'Z'
            },
            fontSize: fs,
            axisStrokeWidth,
            axisColor: axisStroke,
            frameColor: axisStroke,
            tickTextColor: scatterThemeTextColor,
            axisLabelColor: scatterThemeTextColor,
            showPanes: showFrame,
            paneFill: scatterThemeDark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.03)',
            paneOpacityRange: scatterThemeDark ? { min: 0.10, max: 0.22 } : { min: 0.01, max: 0.05 },
            gridColor: gridStrokeStyle.color,
            gridDash: gridDash || undefined,
            gridOpacity,
            gridStrokeWidth: gridStrokeStyle.thickness,
            gridOutlineColors: { primary: gridStrokeStyle.color, secondary: gridStrokeStyle.color },
            chartStyle,
            showGrid,
            showFrame,
            axisTickFormatters: axisTickFormatters3d || undefined,
            frontFrameTarget: frontFrameLayer,
            debugLabel: 'scatter-3d',
            onAxisLabel: (node, axisKey) => {
              if(!node){ return; }
              const role = axisKey === 'z' ? 'zTitle' : (axisKey === 'y' ? 'yTitle' : 'xTitle');
              const defaultLabel = axisKey === 'y' ? 'Y' : (axisKey === 'z' ? 'Z' : 'X');
              const applyAxisLabel = (value) => {
                const trimmed = value != null ? String(value).trim() : '';
                const resolved = trimmed || defaultLabel;
                const current = axisKey === 'x'
                  ? scatterState.xLabelText
                  : (axisKey === 'y' ? scatterState.yLabelText : scatterState.zLabelText);
                const didChange = current !== resolved;
                if(axisKey === 'x'){
                  if(didChange){
                    scatterState.xLabelText = resolved;
                    scatterXLabelText = resolved;
                    scatterState.axisLabelModes = normalizeScatterAxisLabelModes({
                      ...scatterState.axisLabelModes,
                      x: 'manual'
                    }, scatterState.axisLabelModes);
                  }
                }else if(axisKey === 'y'){
                  if(didChange){
                    scatterState.yLabelText = resolved;
                    scatterYLabelText = resolved;
                    scatterState.axisLabelModes = normalizeScatterAxisLabelModes({
                      ...scatterState.axisLabelModes,
                      y: 'manual'
                    }, scatterState.axisLabelModes);
                  }
                }else{
                  if(didChange){
                    scatterState.zLabelText = resolved;
                    scatterZLabelText = resolved;
                    scatterState.axisLabelModes = normalizeScatterAxisLabelModes({
                      ...scatterState.axisLabelModes,
                      z: 'manual'
                    }, scatterState.axisLabelModes);
                  }
                }
                syncScatterAxisHeader(axisKey, resolved, { source: 'scatter-axis-inline' });
                if(node.textContent !== resolved){ node.textContent = resolved; }
                if(didChange){
                  scheduleScatterViewRefresh(`axis-label-${axisKey}-change`);
                }
                return resolved;
              };
              markFontEditable(node, role, role);
              makeEditableLocal(node, text => {
                const previous = axisKey === 'x'
                  ? (scatterState.xLabelText ?? '')
                  : (axisKey === 'y' ? (scatterState.yLabelText ?? '') : (scatterState.zLabelText ?? ''));
                const nextValue = applyAxisLabel(text);
                if(previous === nextValue){
                  return;
                }
                recordScatterChange(`scatter:${axisKey}-label`, previous, nextValue, applyAxisLabel);
              });
            }
          });
          const axisLabelBounds=[];
          let contentRightBound=margin3.left+plotW3;
          if(typeof svg3.querySelectorAll === 'function'){
            const axisLabelNodes=svg3.querySelectorAll('[data-axis-label]');
            axisLabelNodes.forEach(node=>{
              if(!node || typeof node.getBBox !== 'function'){ return; }
              try{
                const bbox=node.getBBox();
                const valid=Number.isFinite(bbox?.x) && Number.isFinite(bbox?.y) && Number.isFinite(bbox?.width) && Number.isFinite(bbox?.height);
                if(!valid){ return; }
                axisLabelBounds.push({ x:bbox.x, y:bbox.y, width:bbox.width, height:bbox.height });
                const rightEdge=bbox.x + bbox.width;
                if(Number.isFinite(rightEdge)){
                  contentRightBound=Math.max(contentRightBound,rightEdge);
                }
              }catch(err){
                scatterDebug('Debug: scatter axis label bbox error',{ message: err?.message || String(err) });
              }
            });
          }
          const pointLayer = document.createElementNS(NS,'g');
          svg3.appendChild(pointLayer);
          const manualLabelEntries3d = [];
          const pointBounds3d = [];
          let maxPointRight=contentRightBound;
          sortedPoints.forEach(entry => {
            const styleOverride = getScatterLabelStyle(entry.data?.label || null);
            const markerAlpha = styleOverride && styleOverride.alpha != null ? clampScatterAlpha(styleOverride.alpha) : alpha;
            const markerBorderWidth = styleOverride && styleOverride.borderWidth != null ? clampScatterBorderWidth(styleOverride.borderWidth) : borderWidthPx;
            const markerSize = styleOverride && styleOverride.size != null ? clampScatterSize(styleOverride.size) : dotSizePx;
            const markerBorderColor = styleOverride && styleOverride.borderColor ? styleOverride.borderColor : borderColor;
            const marker = createScatterMarkerElement(entry.shape, {
              cx: entry.projected.x,
              cy: entry.projected.y,
              radius: markerSize != null ? markerSize : dotSizePx,
              fill: entry.color,
              stroke: markerBorderWidth>0 ? markerBorderColor : null,
              strokeWidth: markerBorderWidth>0 ? markerBorderWidth : 0,
              fillOpacity: 1 - (markerAlpha != null ? markerAlpha : alpha),
              strokeOpacity: 1 - (markerAlpha != null ? markerAlpha : alpha)
            });
            if(!marker){ return; }
            pointLayer.appendChild(marker);
            const manualLabelText = (entry.data?.pointName || entry.data?.label || '').trim();
            const markerRadius = markerSize != null ? markerSize : dotSizePx;
            pointBounds3d.push({ cx: entry.projected?.x, cy: entry.projected?.y, r: markerRadius });
            if((entry.data?.isManualLabel || entry.data?.isThresholdLabel) && manualLabelText){
              manualLabelEntries3d.push({
                text: manualLabelText,
                cx: entry.projected?.x,
                cy: entry.projected?.y,
                radius: markerRadius
              });
            }
            attachScatterPointTooltip(marker, {
              label: entry.data.label || '',
              pointName: entry.data.pointName || '',
              rowIndex: Number.isInteger(entry.data.rowIndex) ? entry.data.rowIndex : undefined,
              isManualLabel: !!entry.data.isManualLabel,
              x: entry.data.x,
              y: entry.data.y,
              z: entry.data.z,
              graphType: 'scatter',
              series: entry.data.series || entry.data.label || '',
              replicates: Array.isArray(entry.data.replicates) ? entry.data.replicates : undefined,
              stdev: Number.isFinite(entry.data.stdev) ? entry.data.stdev : undefined,
              xReplicates: Array.isArray(entry.data.xReplicates) ? entry.data.xReplicates : undefined,
              xStdev: Number.isFinite(entry.data.xStdev) ? entry.data.xStdev : undefined
            });
            const approxRight = entry.projected?.x + markerRadius + (markerBorderWidth>0 ? markerBorderWidth : 0);
            if(Number.isFinite(approxRight)){
              maxPointRight = Math.max(maxPointRight, approxRight);
            }
          });
          if(manualLabelEntries3d.length){
            const labelLayer = document.createElementNS(NS,'g');
            labelLayer.setAttribute('data-layer','point-labels');
            labelLayer.setAttribute('pointer-events','none');
            const baseManualLabelSize = fs * 0.6;
            const labelWidth = labelBounds3d ? Math.max(1, labelBounds3d.maxX - labelBounds3d.minX) : plotW3;
            const labelHeight = labelBounds3d ? Math.max(1, labelBounds3d.maxY - labelBounds3d.minY) : plotH3;
            const labelLayout = Shared.labelLayout;
            const tickFontSizeCap = labelLayout?.readFontSizeFromNodes
              ? (labelLayout.readFontSizeFromNodes(svg3.querySelectorAll('[data-axis-tick-label]'))
                || Math.max(9, Math.round(fs * 0.85)))
              : Math.max(9, Math.round(fs * 0.85));
            const labelFontSizeRaw = computeScatterManualLabelFontSize(baseManualLabelSize, manualLabelEntries3d.length, labelWidth, labelHeight);
            const labelFontSize = Math.min(labelFontSizeRaw, tickFontSizeCap);
            const labelScale = Math.min(1, labelFontSize / Math.max(1, baseManualLabelSize));
            const leaderStrokeWidth = chartStyle.scaleStrokeWidth(0.75 * labelScale, styleScaleInfo, { context: 'scatter-point-label-3d', min: 0.25 });
            const labelColor = scatterThemeTextColor;
            const plotLeft = labelBounds3d ? labelBounds3d.minX : margin3.left;
            const plotRight = labelBounds3d ? labelBounds3d.maxX : margin3.left + plotW3;
            const plotTop = labelBounds3d ? labelBounds3d.minY : margin3.top;
            const plotBottom = labelBounds3d ? labelBounds3d.maxY : margin3.top + plotH3;
            const font = typeof chartStyle?.makeFont === 'function'
              ? chartStyle.makeFont(labelFontSize)
              : null;
            const manualLabelLayout = computeScatterManualLabelLayout(manualLabelEntries3d, {
              plotLeft,
              plotRight,
              plotTop,
              plotBottom,
              plotHull: labelHull3d,
              enforceHull: true,
              hullPenalty: 18,
              labelFontSize,
              leaderGap: Math.max(2, Math.round(labelFontSize * 0.2)),
              leaderScale: labelScale,
              pointBounds: pointBounds3d,
              measureText: chartStyle?.measureText,
              font,
              angleSteps: 16,
              maxLeaderScale: 3
            });
            manualLabelLayout.forEach(result => {
              const entry = result.entry;
              const placement = result.placement;
              const cx = Number(entry?.cx) || 0;
              const cy = Number(entry?.cy) || 0;
              const textValue = entry?.text ? String(entry.text) : '';
              if(!textValue || !placement){
                return;
              }
              const textX = placement.textX;
              const textY = placement.textY;
              const anchor = placement.anchor;
              const lineX2 = placement.lineX2;
              const leader = document.createElementNS(NS,'line');
              leader.setAttribute('x1', String(cx));
              leader.setAttribute('y1', String(cy));
              leader.setAttribute('x2', String(lineX2));
              leader.setAttribute('y2', String(textY));
              leader.setAttribute('stroke', labelColor);
              leader.setAttribute('stroke-width', String(leaderStrokeWidth));
              leader.setAttribute('stroke-linecap', 'round');
              labelLayer.appendChild(leader);
              const textNode = document.createElementNS(NS,'text');
              textNode.setAttribute('x', String(textX));
              textNode.setAttribute('y', String(textY));
              textNode.setAttribute('font-size', String(labelFontSize));
              textNode.setAttribute('fill', labelColor);
              textNode.setAttribute('text-anchor', anchor);
              textNode.setAttribute('dominant-baseline', 'middle');
              textNode.textContent = textValue;
              labelLayer.appendChild(textNode);
            });
            svg3.appendChild(labelLayer);
            debug('Debug: scatter 3d manual labels rendered', { count: manualLabelEntries3d.length });
          }
          svg3.appendChild(frontFrameLayer);
          contentRightBound=Math.max(contentRightBound,maxPointRight);
          if(legendVisible){
            const legendContentWidth=Math.max(legendRenderer.width || 0,0);
            const legendContentHeight=Math.max(legendRenderer.height || 0,0);
            const horizontalBase=margin3.left+plotW3+legendGapFor3d+appliedLegendAxisGap;
            const horizontalPadding=Math.max(fs*0.6,12)+appliedLegendAxisGap;
            const storedLegendPos=scatterLabelPositions?.legend;
            let legendX3=Math.max(horizontalBase,contentRightBound+horizontalPadding);
            const safeRightPad=Math.max(fs*0.6,12);
            const widthForClamp=Math.max(legendContentWidth,legendWidth);
            const maxLegendX=W3-safeRightPad-widthForClamp;
            if(widthForClamp>0 && legendX3>maxLegendX){
              const previousX=legendX3;
              legendX3=Math.max(horizontalBase,maxLegendX);
              scatterDebug('Debug: scatter legend horizontal clamped',{ previousX, legendX3, maxLegendX });
            }
            const baseLegendY=margin3.top;
            const legendHeight=legendContentHeight;
            const legendBottomLimit=Math.max(baseLegendY,H3-margin3.bottom-legendHeight);
            const verticalPadding=Math.max(fs*0.45,8);
            const candidates=[baseLegendY];
            axisLabelBounds.forEach(bounds=>{
              const below=bounds.y + bounds.height + verticalPadding;
              const above=bounds.y - legendHeight - verticalPadding;
              if(below<=legendBottomLimit){ candidates.push(below); }
              if(above>=baseLegendY){ candidates.push(above); }
            });
            if(legendBottomLimit!==baseLegendY){
              candidates.push(legendBottomLimit);
            }
            const candidatePositions=[];
            candidates.forEach(candidate=>{
              const clamped=Math.min(Math.max(candidate,baseLegendY),legendBottomLimit);
              if(!candidatePositions.some(existing=>Math.abs(existing-clamped)<0.5)){
                candidatePositions.push(clamped);
              }
            });
            candidatePositions.sort((a,b)=>Math.abs(a-baseLegendY)-Math.abs(b-baseLegendY));
            const intersectsAxis=(rect)=>{
              for(let idx=0;idx<axisLabelBounds.length;idx+=1){
                const bounds=axisLabelBounds[idx];
                const horizontalOverlap=rect.x < bounds.x + bounds.width + horizontalPadding
                  && rect.x + rect.width > bounds.x - horizontalPadding;
                const verticalOverlap=rect.y < bounds.y + bounds.height + verticalPadding
                  && rect.y + rect.height > bounds.y - verticalPadding;
                if(horizontalOverlap && verticalOverlap){
                  return true;
                }
              }
              return false;
            };
            let legendStartY=baseLegendY;
            if(storedLegendPos) {
              if (storedLegendPos.relX !== undefined && storedLegendPos.relY !== undefined) {
                // Use relative positioning for 3D legend
                legendX3 = horizontalBase + storedLegendPos.relX * legendGapFor3d;
                legendStartY = baseLegendY + storedLegendPos.relY * plotH3;
              } else if (Number.isFinite(storedLegendPos.x) && Number.isFinite(storedLegendPos.y)) {
                // Use absolute positioning (backward compatibility)
                legendX3 = storedLegendPos.x;
                legendStartY = storedLegendPos.y;
              }
            }
            if(!storedLegendPos || (storedLegendPos.relX === undefined && storedLegendPos.relY === undefined && (isNaN(storedLegendPos?.x) || isNaN(storedLegendPos?.y)))){
              for(let idx=0;idx<candidatePositions.length;idx+=1){
                const candidateY=candidatePositions[idx];
                const legendRect={ x:legendX3, y:candidateY, width:legendContentWidth || widthForClamp, height:legendHeight };
                if(!intersectsAxis(legendRect)){
                  legendStartY=candidateY;
                  break;
                }
              }
            }
            scatterDebug('Debug: scatter legend placement resolved',{ legendX: legendX3, legendY: legendStartY, legendHeight, axisLabels: axisLabelBounds.length });
            const legendGroup=legendRenderer.draw(svg3,{ x:legendX3, y:legendStartY });
            if(legendGroup){
              plot3d.applyLegendPointerGuards(legendGroup, { label: 'scatter-legend-3d' });
            }
            if(legendGroup && typeof Shared.enableLegendDrag === 'function'){
              Shared.enableLegendDrag(legendGroup, svg3, {
                onDragEnd: pos => {
                  // Store both absolute and relative positions for 3D legend
                  const relX = (pos.x - horizontalBase) / legendGapFor3d;
                  const relY = (pos.y - baseLegendY) / plotH3;
                  scatterLabelPositions.legend = { 
                    x: pos.x, 
                    y: pos.y,
                    relX: relX, 
                    relY: relY 
                  };
                  if(Shared.isDebugEnabled?.()){
                    console.debug('Debug: scatter 3d legend position saved', { absolute: pos, relative: { relX, relY } });
                  }
                }
              });
            }
            if(legendGroup && typeof legendGroup.querySelectorAll === 'function'){
              const interactiveNodes=legendGroup.querySelectorAll('[data-legend-key]');
              interactiveNodes.forEach(node=>{
                plot3d.applyLegendPointerGuards(node,{ label: node.dataset.legendKey || null });
              });
              // Mark legend text nodes editable so graph-scope font styles apply
              const textNodes = legendGroup.querySelectorAll('text');
              Array.from(textNodes).forEach((node, idx) => {
                try{ markFontEditable(node, 'legend', `legend-${idx}`); }catch(e){}
              });
            }
          }
          const defaultTitleX = margin3.left + plotW3 / 2;
          const defaultTitleY = Math.max(margin3.top * 0.4, fs * 1.6);
          const titlePos = scatterLabelPositions?.title;
          
          // Convert relative positions to absolute if needed for 3D
          let absoluteTitleX = defaultTitleX;
          let absoluteTitleY = defaultTitleY;
          if (titlePos) {
            if (titlePos.relX !== undefined && titlePos.relY !== undefined) {
              // Use relative positioning
              absoluteTitleX = margin3.left + titlePos.relX * plotW3;
              absoluteTitleY = margin3.top + titlePos.relY * plotH3;
            } else if (titlePos.x !== undefined && titlePos.y !== undefined) {
              // Use absolute positioning (backward compatibility)
              absoluteTitleX = titlePos.x;
              absoluteTitleY = titlePos.y;
            }
          }
          
          const title3d = add3('text',{
            x: absoluteTitleX,
            y: absoluteTitleY,
            'text-anchor':'middle',
            'font-size': fs,
            fill: scatterThemeTextColor
          }, scatterTitleText);
          markFontEditable(title3d,'graphTitle','graphTitle');
          plot3d.applyLegendPointerGuards(title3d, { label: 'scatter-title-3d' });
          const applyScatterTitle3d=value=>{
            const nextValue=value!=null?String(value):'';
            scatterTitleText=nextValue;
            if(title3d.textContent!==nextValue){
              title3d.textContent=nextValue;
            }
            scheduleScatterViewRefresh('title-change');
          };
          makeEditableLocal(title3d,txt=>{
            const previous=scatterTitleText!=null?String(scatterTitleText):'';
            const nextValue=txt!=null?String(txt):'';
            if(previous===nextValue){
              return;
            }
            applyScatterTitle3d(nextValue);
            recordScatterChange('scatter:title',previous,nextValue,applyScatterTitle3d);
          });
          if(typeof Shared.enableLabelDrag === 'function'){
            Shared.enableLabelDrag(title3d, svg3, {
              onDragEnd: pos => {
                // Store both absolute and relative positions for 3D
                const relX = (pos.x - margin3.left) / plotW3;
                const relY = (pos.y - margin3.top) / plotH3;
                scatterLabelPositions.title = { 
                  x: pos.x, 
                  y: pos.y,
                  relX: relX, 
                  relY: relY 
                };
                if(Shared.isDebugEnabled?.()){
                  console.debug('Debug: scatter 3d title position saved', { absolute: pos, relative: { relX, relY } });
                }
              }
            });
          }
          registerScatterGridControlTarget(svg3, { fallbackThickness: axisStrokeWidthBase });
          ensureGraphViewport(svg3,{ padding: Math.max(fs, 18), debugLabel: 'scatter-3d-graph' });
          return;
        }
        const previousPlotChildren = Array.from(plotEl.childNodes || []);
        plotEl.style.aspectRatio='';
        plotEl.style.padding='';
        const W=Math.max(50,Math.floor(plotEl.clientWidth||50));
        const H=Math.max(40,Math.floor(plotEl.clientHeight||40));
        plotEl.style.position='relative';
        const svg=document.createElementNS(NS,'svg');
        svg.setAttribute('id','scatterSvg');
        svg.setAttribute('width',String(W));
        svg.setAttribute('height',String(H));
        svg.setAttribute('viewBox',`0 0 ${W} ${H}`);
        svg.setAttribute('font-family',chartStyle.FONT_FAMILY);
        svg.dataset.viewMode='2d';
        svg.style.visibility='hidden';
        svg.style.pointerEvents='none';
        chartStyle.applySvgDefaults(svg);
        svg.addEventListener('mouseleave', handleScatterPlotMouseLeave);
        plotEl.appendChild(svg);
        const commitScatterSvg = () => {
          svg.style.visibility='';
          svg.style.pointerEvents='auto';
          if(Array.isArray(previousPlotChildren) && previousPlotChildren.length){
            for(let i = 0; i < previousPlotChildren.length; i += 1){
              const node = previousPlotChildren[i];
              if(!node || node === svg){
                continue;
              }
              if(node.parentNode === plotEl){
                try{
                  plotEl.removeChild(node);
                }catch(err){}
              }
            }
          }
        };
        if(fontControls && typeof fontControls.enableForSvg === 'function'){
          fontControls.enableForSvg(svg,{ scopeId: 'scatter' });
          debug('Debug: scatter fontControls enableForSvg invoked',{ width: W, height: H }); // Debug: font panel binding
        } else {
          debug('Debug: scatter fontControls enableForSvg missing',{ hasFontControls: !!fontControls }); // Debug: font panel missing
        }
        const svgLayoutPerf = perfApi?.start('scatter.svg.layout', {
          component: 'scatter',
          token,
          points: points.length
        });
        let xMinT=logX?Math.log10(xMin):xMin;
        let xMaxT=logX?Math.log10(xMax):xMax;
        let yMinT=logY?Math.log10(yMin):yMin;
        let yMaxT=logY?Math.log10(yMax):yMax;
        let manualXMinValue=Number.isFinite(xMinManual) && (!logX || xMinManual > 0)
          ? (logX ? Math.log10(xMinManual) : xMinManual)
          : null;
        let manualXMaxValue=Number.isFinite(xMaxManual) && (!logX || xMaxManual > 0)
          ? (logX ? Math.log10(xMaxManual) : xMaxManual)
          : null;
        let manualYMinValue=Number.isFinite(yMinManual) && (!logY || yMinManual > 0)
          ? (logY ? Math.log10(yMinManual) : yMinManual)
          : null;
        let manualYMaxValue=Number.isFinite(yMaxManual) && (!logY || yMaxManual > 0)
          ? (logY ? Math.log10(yMaxManual) : yMaxManual)
          : null;
        const shouldEqualScale = !!scatterState.equalScaleAxes;
        if(shouldEqualScale){
          const spanX = Number.isFinite(xMaxT) && Number.isFinite(xMinT) ? (xMaxT - xMinT) : NaN;
          const spanY = Number.isFinite(yMaxT) && Number.isFinite(yMinT) ? (yMaxT - yMinT) : NaN;
          if(Number.isFinite(spanX) && Number.isFinite(spanY) && spanX > 0 && spanY > 0){
            const maxSpan = Math.max(spanX, spanY);
            const centerX = (xMaxT + xMinT) / 2;
            const centerY = (yMaxT + yMinT) / 2;
            xMinT = centerX - maxSpan / 2;
            xMaxT = centerX + maxSpan / 2;
            yMinT = centerY - maxSpan / 2;
            yMaxT = centerY + maxSpan / 2;
            manualXMinValue = null;
            manualXMaxValue = null;
            manualYMinValue = null;
            manualYMaxValue = null;
            debug('Debug: scatter equal scale ranges applied',{ spanX, spanY, maxSpan, xMinT, xMaxT, yMinT, yMaxT });
          }else{
            debug('Debug: scatter equal scale ranges skipped',{ spanX, spanY });
          }
        }
        const tickBaseSpacing=Math.max(48,Math.round(fs*3.2));
        const xTickEstimateOptions={axis:'x',fallback:6,baseSpacing:tickBaseSpacing,min:4};
        const yTickEstimateOptions={axis:'y',fallback:6,baseSpacing:tickBaseSpacing,min:4};
        let xTickTarget=clampScatterTickTarget(chartStyle.estimateTickCount(W,xTickEstimateOptions));
        let yTickTarget=clampScatterTickTarget(chartStyle.estimateTickCount(H,yTickEstimateOptions));
        debug('Debug: scatter initial tick targets',{xTickTarget,yTickTarget,width:W,height:H});
        const scatterNotationX = getScatterAxisNotation('x');
        const scatterNotationY = getScatterAxisNotation('y');
        const formatTickX = v => chartStyle.formatAxisValue(v,{ notation: scatterNotationX, maxDecimals: 2 });
        const formatTickY = v => chartStyle.formatAxisValue(v,{ notation: scatterNotationY, maxDecimals: 2 });
        const scatterFontStyles = exportFontStyles('scatter');
        const xTickMeasureProfile = (chartStyle && typeof chartStyle.resolveScopedLabelMeasureFont === 'function')
          ? chartStyle.resolveScopedLabelMeasureFont({ styles: scatterFontStyles, role: 'xTick', fallbackPx: fs })
          : { fontSpec: chartStyle.makeFont(fs), fontSizePx: fs };
        const yTickMeasureProfile = (chartStyle && typeof chartStyle.resolveScopedLabelMeasureFont === 'function')
          ? chartStyle.resolveScopedLabelMeasureFont({ styles: scatterFontStyles, role: 'yTick', fallbackPx: fs })
          : { fontSpec: chartStyle.makeFont(fs), fontSizePx: fs };
        const xTickMeasureFont = xTickMeasureProfile.fontSpec;
        const yTickMeasureFont = yTickMeasureProfile.fontSpec;
        const xTickFontSize = Number.isFinite(Number(xTickMeasureProfile.fontSizePx)) ? Number(xTickMeasureProfile.fontSizePx) : fs;
        const yTickFontSize = Number.isFinite(Number(yTickMeasureProfile.fontSizePx)) ? Number(yTickMeasureProfile.fontSizePx) : fs;
        const yTitleSeparation = (axisMetrics.axisTitleGap || Math.max(4, Math.round(fs * 0.75))) + Math.max(2, yTickFontSize * 0.5);
        const tickFont=yTickMeasureFont;
        const axisLabelFont=chartStyle.makeFont(fs);
        const yTitleWidthBase=chartStyle.measureText(scatterYLabelText,axisLabelFont);
        const tickLen=axisMetrics.tickLength;
        const tickGap=axisMetrics.tickLabelGap;
        let margin=chartStyle.computeBaseMargins({fontSize:fs,legendWidth,maxYLabelWidth:0,yTitleWidth:yTitleWidthBase,axisMetrics,xTickFontSize,yTickFontSize});
        margin.left=Math.max(margin.left,yTickFontSize*0.5);
        let plotW=Math.max(20,W-margin.left-margin.right);
        let plotH=Math.max(20,H-margin.top-margin.bottom);
        let bottomLayout=chartStyle.computeBottomLayout({labels:[],fontSize:fs,labelMeasureFont:xTickMeasureFont,labelFontSizePx:xTickFontSize,plotWidth:plotW,baseBottom:margin.bottom,axisMetrics});
        margin.bottom=bottomLayout.bottom;
        plotW=Math.max(20,W-margin.left-margin.right);
        plotH=Math.max(20,H-margin.top-margin.bottom);
        const storedManualIntervalX = getScatterAxisTickInterval('x');
        const storedManualIntervalY = getScatterAxisTickInterval('y');
        const manualIntervalX = !logX ? storedManualIntervalX : null;
        const manualIntervalY = !logY ? storedManualIntervalY : null;
        if(logX && storedManualIntervalX){
          debug('Debug: scatter manual interval suppressed',{ axis: 'x', reason: 'log-scale', stored: storedManualIntervalX });
        }
        if(logY && storedManualIntervalY){
          debug('Debug: scatter manual interval suppressed',{ axis: 'y', reason: 'log-scale', stored: storedManualIntervalY });
        }
        const applyLogTickOverride = (axisKey, scale, manualMin, manualMax, fallbackMin, fallbackMax, enabled) => {
          if(!enabled || !scale || !chartStyle.axisTicks?.applyLogTicks){
            return;
          }
          const applied = chartStyle.axisTicks.applyLogTicks(scale, {
            manualMin: Number.isFinite(manualMin) ? manualMin : null,
            manualMax: Number.isFinite(manualMax) ? manualMax : null,
            fallbackMin,
            fallbackMax
          });
          if(applied){
            debug('Debug: scatter log tick override',{ axis: axisKey, tickCount: scale.ticks.length });
          }
        };
        let xScale=buildScatterScale({
          dataMin:xMinT,
          dataMax:xMaxT,
          manualMin:manualXMinValue,
          manualMax:manualXMaxValue,
          targetTickCount:xTickTarget,
          fixedStep:Number.isFinite(manualIntervalX)&&manualIntervalX>0?manualIntervalX:null
        });
        let yScale=buildScatterScale({
          dataMin:yMinT,
          dataMax:yMaxT,
          manualMin:manualYMinValue,
          manualMax:manualYMaxValue,
          targetTickCount:yTickTarget,
          fixedStep:Number.isFinite(manualIntervalY)&&manualIntervalY>0?manualIntervalY:null
        });
        applyLogTickOverride('x', xScale, manualXMinValue, manualXMaxValue, xMinT, xMaxT, logX);
        applyLogTickOverride('y', yScale, manualYMinValue, manualYMaxValue, yMinT, yMaxT, logY);
        let xTickLabels=xScale.ticks.map(t=>formatTickX(logX?Math.pow(10,t):t));
        let yTickLabels=yScale.ticks.map(t=>formatTickY(logY?Math.pow(10,t):t));
        let maxYLabelWidth=0;
        let maxXLabelWidth=0;
        for(let pass=0;pass<2;pass++){
          xScale=buildScatterScale({
            dataMin:xMinT,
            dataMax:xMaxT,
            manualMin:manualXMinValue,
            manualMax:manualXMaxValue,
            targetTickCount:xTickTarget,
            fixedStep:Number.isFinite(manualIntervalX)&&manualIntervalX>0?manualIntervalX:null
          });
          yScale=buildScatterScale({
            dataMin:yMinT,
            dataMax:yMaxT,
            manualMin:manualYMinValue,
            manualMax:manualYMaxValue,
            targetTickCount:yTickTarget,
            fixedStep:Number.isFinite(manualIntervalY)&&manualIntervalY>0?manualIntervalY:null
          });
          applyLogTickOverride('x', xScale, manualXMinValue, manualXMaxValue, xMinT, xMaxT, logX);
          applyLogTickOverride('y', yScale, manualYMinValue, manualYMaxValue, yMinT, yMaxT, logY);
          xTickLabels=xScale.ticks.map(t=>formatTickX(logX?Math.pow(10,t):t));
          yTickLabels=yScale.ticks.map(t=>formatTickY(logY?Math.pow(10,t):t));
          const yLabelWidths=yTickLabels.map(lbl=>chartStyle.measureText(lbl,tickFont));
          maxYLabelWidth=Math.max(...yLabelWidths,0);
          const xLabelWidths=xTickLabels.map(lbl=>chartStyle.measureText(lbl,xTickMeasureFont));
          maxXLabelWidth=Math.max(...xLabelWidths,0);
          margin=chartStyle.computeBaseMargins({fontSize:fs,legendWidth,maxYLabelWidth,yTitleWidth:yTitleWidthBase,axisMetrics,xTickFontSize,yTickFontSize});
          margin.left=Math.max(margin.left,maxYLabelWidth+tickLen+tickGap+yTitleSeparation);
          plotW=Math.max(20,W-margin.left-margin.right);
          plotH=Math.max(20,H-margin.top-margin.bottom);
          bottomLayout=chartStyle.computeBottomLayout({labels:xTickLabels,fontSize:fs,labelMeasureFont:xTickMeasureFont,labelFontSizePx:xTickFontSize,plotWidth:plotW,baseBottom:margin.bottom,axisMetrics});
          margin.bottom=bottomLayout.bottom;
          plotW=Math.max(20,W-margin.left-margin.right);
          plotH=Math.max(20,H-margin.top-margin.bottom);
          const refinedX=clampScatterTickTarget(chartStyle.estimateTickCount(plotW,{...xTickEstimateOptions,fallback:xTickTarget}));
          const refinedY=clampScatterTickTarget(chartStyle.estimateTickCount(plotH,{...yTickEstimateOptions,fallback:yTickTarget}));
          debug('Debug: scatter tick target evaluation',{pass,plotW,plotH,xTickTarget,refinedX,yTickTarget,refinedY,maxXLabelWidth,maxYLabelWidth});
          if(refinedX===xTickTarget && refinedY===yTickTarget){
            break;
          }
          xTickTarget=refinedX;
          yTickTarget=refinedY;
        }
        debug('Debug: scatter layout',{margin,plotW,plotH,rotate:bottomLayout.shouldRotate,xTickTarget,yTickTarget,maxXLabelWidth,maxYLabelWidth});
        const enforcePlotAspect = (marginInput, totalWidth, totalHeight, aspectValue) => {
          const aspect = Number.isFinite(aspectValue) && aspectValue > 0 ? aspectValue : null;
          const baseMargin = { ...marginInput };
          const innerW = Math.max(20, totalWidth - baseMargin.left - baseMargin.right);
          const innerH = Math.max(20, totalHeight - baseMargin.top - baseMargin.bottom);
          if(!aspect){
            return { margin: baseMargin, plotW: innerW, plotH: innerH };
          }
          const squareSize = Math.min(innerW, innerH);
          let targetW = squareSize;
          let targetH = squareSize;
          if(aspect >= 1){
            targetW = squareSize;
            targetH = squareSize / aspect;
          }else{
            targetH = squareSize;
            targetW = squareSize * aspect;
          }
          if(!Number.isFinite(targetW) || targetW <= 0 || !Number.isFinite(targetH) || targetH <= 0){
            return { margin: baseMargin, plotW: innerW, plotH: innerH };
          }
          const adjusted = { ...baseMargin };
          if(innerW > targetW){
            adjusted.right += innerW - targetW;
          }
          if(innerH > targetH){
            adjusted.bottom += innerH - targetH;
          }
          return {
            margin: adjusted,
            plotW: Math.max(20, targetW),
            plotH: Math.max(20, targetH)
          };
        };
        const aspectData=scatterSvgBox?.dataset;
        const shouldLockAspect=aspectData?.resizerAspectLocked==='true';
        const shouldEqualAxes = !!scatterState.equalAxes;
        debug('Debug: scatter aspect ratio decision',{
          shouldEqualAxes,
          shouldEqualScale,
          varianceAxesEnabled: !!scatterState.axesVarianceScaled,
          lockRatioEnabled: shouldLockAspect,
          storedRatio: aspectData?.resizerAspectRatio
        }); // Debug: scatter aspect toggle decision
        let varianceAspectApplied = false;
        if(scatterState.axesVarianceScaled){
          const weightX = axisVarianceInfo?.weights?.x;
          const weightY = axisVarianceInfo?.weights?.y;
          if(Number.isFinite(weightX) && weightX > 0 && Number.isFinite(weightY) && weightY > 0){
            const desiredAspect = weightX / weightY;
            const baseInnerW = Math.max(20, W - margin.left - margin.right);
            const baseInnerH = Math.max(20, H - margin.top - margin.bottom);
            const baseSquareSize = Math.min(baseInnerW, baseInnerH);
            const enforced = enforcePlotAspect(margin, W, H, desiredAspect);
            margin = enforced.margin;
            plotW = enforced.plotW;
            plotH = enforced.plotH;
            varianceAspectApplied = true;
            debug('Debug: scatter layout (variance-enforced)',{
              desiredAspect,
              appliedAspect: plotH > 0 ? plotW / plotH : null,
              squareSize: baseSquareSize,
              margin,
              plotW,
              plotH,
              weights: axisVarianceInfo.weights
            });
          } else {
            debug('Debug: scatter variance aspect skipped',{ reason: 'insufficient-weights', weights: axisVarianceInfo?.weights });
          }
        }
        if(!varianceAspectApplied){
          if(shouldEqualAxes || shouldEqualScale){
            const square=chartStyle.ensureSquarePlot(W,H,margin);
            margin=square.margin;
            plotW=square.plotW;
            plotH=square.plotH;
            debug('Debug: scatter layout (equal-length)',{margin,plotW,plotH,rotate:bottomLayout.shouldRotate}); // Debug: scatter square enforcement branch
          }else{
            debug('Debug: scatter layout (unlocked)',{margin,plotW,plotH,rotate:bottomLayout.shouldRotate}); // Debug: scatter free resize branch
          }
        }
        const brokenXEnabled = getBrokenAxisEnabled('x');
        const brokenXSegments = brokenXEnabled ? getBrokenAxisSegments('x') : [];
        const brokenXScale = brokenXEnabled && brokenXSegments.length > 0
          ? computeBrokenAxisScale({
              dataMin: xScale.min,
              dataMax: xScale.max,
              segments: brokenXSegments,
              plotLength: plotW,
              orientation: 'horizontal'
            })
          : null;
        const brokenYEnabled = getBrokenAxisEnabled('y');
        const brokenYSegments = brokenYEnabled ? getBrokenAxisSegments('y') : [];
        const brokenYScale = brokenYEnabled && brokenYSegments.length > 0
          ? computeBrokenAxisScale({
              dataMin: yScale.min,
              dataMax: yScale.max,
              segments: brokenYSegments,
              plotLength: plotH,
              orientation: 'vertical'
            })
          : null;
        debug('Debug: scatter broken axis',{
          xEnabled: brokenXEnabled,
          xSegments: brokenXSegments,
          xBroken: brokenXScale?.isBroken,
          yEnabled: brokenYEnabled,
          ySegments: brokenYSegments,
          yBroken: brokenYScale?.isBroken
        });
        const isXValueVisible = value => {
          if(!brokenXScale || !brokenXScale.isBroken){ return true; }
          return brokenXScale.segments.some(seg => value >= seg.start && value <= seg.end);
        };
        const isYValueVisible = value => {
          if(!brokenYScale || !brokenYScale.isBroken){ return true; }
          return brokenYScale.segments.some(seg => value >= seg.start && value <= seg.end);
        };
        const x2px=v=>{
          const safeV = Math.min(Math.max(v, xScale.min), xScale.max);
          if(brokenXScale && brokenXScale.isBroken){
            return brokenXScale.valueToPixel(safeV, margin.left, plotW);
          }
          return margin.left+plotW*(safeV-xScale.min)/(xScale.max-xScale.min);
        };
        const y2px=v=>{
          const safeV = Math.min(Math.max(v, yScale.min), yScale.max);
          if(brokenYScale && brokenYScale.isBroken){
            return brokenYScale.valueToPixel(safeV, margin.top, plotH);
          }
          return margin.top+plotH*(1-(safeV-yScale.min)/(yScale.max-yScale.min));
        };
        function add(tag,attrs){const el=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))el.setAttribute(k,String(v));svg.appendChild(el);return el;}
        if(showGrid){
          xScale.ticks.forEach(t=>{
            if(!isXValueVisible(t)){ return; }
            const x=x2px(t);
            const gridLine = add('line',Object.assign({x1:x,y1:margin.top,x2:x,y2:margin.top+plotH},gridStrokeAttrs));
            gridLine.setAttribute('data-grid-control','1');
          });
          yScale.ticks.forEach(t=>{
            if(!isYValueVisible(t)){ return; }
            const y=y2px(t);
            const gridLine = add('line',Object.assign({x1:margin.left,y1:y,x2:margin.left+plotW,y2:y},gridStrokeAttrs));
            gridLine.setAttribute('data-grid-control','1');
          });
          debug('Debug: scatter grid stroke scaled',{vertical:xScale.ticks.length,horizontal:yScale.ticks.length,gridStrokeStyle});
        }
        if(scatterCurrentGraphType === 'volcano'){
          const thresholdStroke = '#9b9b9b';
          const thresholdWidth = chartStyle.scaleStrokeWidth(0.85, styleScaleInfo, { context: 'scatter-threshold', min: 0.35 });
          const dashSize = Math.max(2, Math.round(thresholdWidth * 3));
          const dashArray = `${dashSize},${dashSize}`;
          const absLog2fc = Number.isFinite(log2fcThreshold) ? Math.abs(log2fcThreshold) : NaN;
          if(Number.isFinite(absLog2fc) && absLog2fc > 0){
            const thresholdXT = logX ? Math.log10(absLog2fc) : absLog2fc;
            if(Number.isFinite(thresholdXT) && thresholdXT >= xScale.min && thresholdXT <= xScale.max && isXValueVisible(thresholdXT)){
              const xPos = x2px(thresholdXT);
              add('line',{
                x1: xPos,
                y1: margin.top,
                x2: xPos,
                y2: margin.top + plotH,
                stroke: thresholdStroke,
                'stroke-width': thresholdWidth,
                'stroke-dasharray': dashArray
              });
            }
            if(!logX){
              const negXT = -absLog2fc;
              if(negXT >= xScale.min && negXT <= xScale.max && isXValueVisible(negXT)){
                const xNegPos = x2px(negXT);
                add('line',{
                  x1: xNegPos,
                  y1: margin.top,
                  x2: xNegPos,
                  y2: margin.top + plotH,
                  stroke: thresholdStroke,
                  'stroke-width': thresholdWidth,
                  'stroke-dasharray': dashArray
                });
              }
            }
          }
          if(Number.isFinite(negLogPThreshold) && negLogPThreshold > 0){
            const thresholdYT = logY ? Math.log10(negLogPThreshold) : negLogPThreshold;
            if(Number.isFinite(thresholdYT) && thresholdYT >= yScale.min && thresholdYT <= yScale.max && isYValueVisible(thresholdYT)){
              const yPos = y2px(thresholdYT);
              add('line',{
                x1: margin.left,
                y1: yPos,
                x2: margin.left + plotW,
                y2: yPos,
                stroke: thresholdStroke,
                'stroke-width': thresholdWidth,
                'stroke-dasharray': dashArray
              });
            }
          }
        }
        let originXT,originYT;
        if(originMode==='custom'){
          originXT=logX?Math.log10(isFinite(originXInput)?originXInput:0):(isFinite(originXInput)?originXInput:0);
          originYT=logY?Math.log10(isFinite(originYInput)?originYInput:0):(isFinite(originYInput)?originYInput:0);
        }else if(originMode==='zero'){
          originXT=logX?xScale.min:0;
          originYT=logY?yScale.min:0;
        }else{
          originXT=xScale.min;
          originYT=yScale.min;
        }
        const clampedXT=Math.min(Math.max(originXT,xScale.min),xScale.max);
        const clampedYT=Math.min(Math.max(originYT,yScale.min),yScale.max);
        info('scatter origin final',{originXT,originYT,clampedXT,clampedYT});
        const xAxisY=y2px(clampedYT);
        const yAxisX=x2px(clampedXT);
        info('scatter axes',{tickLen,xAxisY,yAxisX});
        const xTickPositions=xScale.ticks.map(t=>x2px(t));
        const yTickPositions=yScale.ticks.map(t=>y2px(t));
        const axisXMinPos=x2px(Number.isFinite(xScale.min)?xScale.min:xMinT);
        const axisXMaxPos=x2px(Number.isFinite(xScale.max)?xScale.max:xMaxT);
        const axisYMinPos=y2px(Number.isFinite(yScale.min)?yScale.min:yMinT);
        const axisYMaxPos=y2px(Number.isFinite(yScale.max)?yScale.max:yMaxT);
        let axisXStart=xTickPositions.length?Math.min(...xTickPositions,axisXMinPos):axisXMinPos;
        let axisXEnd=xTickPositions.length?Math.max(...xTickPositions,axisXMaxPos):axisXMaxPos;
        let axisYStart=yTickPositions.length?Math.min(...yTickPositions,axisYMinPos):axisYMinPos;
        let axisYEnd=yTickPositions.length?Math.max(...yTickPositions,axisYMaxPos):axisYMaxPos;
        if(axisXStart===axisXEnd){axisXStart=axisXMinPos;axisXEnd=axisXMaxPos;}
        if(axisYStart===axisYEnd){axisYStart=axisYMinPos;axisYEnd=axisYMaxPos;}
        debug('Debug: scatter axis span',{axisXStart,axisXEnd,axisYStart,axisYEnd});
        const axisCrossTickTolerance = Math.max(1.5, axisStrokeWidth * 1.5);
        const axisCrossLabelTolerance = Math.max(1.5, axisStrokeWidth * 1.5, tickLen * 0.2);
        const yAxisCrossesXTickZone = axisYEnd > (xAxisY + axisCrossTickTolerance);
        const xAxisCrossesYTickZone = axisXStart < (yAxisX - axisCrossTickTolerance);
        const yAxisCrossesXLabelZone = axisYEnd > (xAxisY + axisCrossLabelTolerance);
        const xAxisCrossesYLabelZone = axisXStart < (yAxisX - axisCrossLabelTolerance);
        const shouldHideXAxisTickMark = pixel => yAxisCrossesXTickZone && Number.isFinite(pixel) && Math.abs(pixel - yAxisX) <= axisCrossTickTolerance;
        const shouldHideYAxisTickMark = pixel => xAxisCrossesYTickZone && Number.isFinite(pixel) && Math.abs(pixel - xAxisY) <= axisCrossTickTolerance;
        const shouldHideXAxisTickLabel = pixel => yAxisCrossesXLabelZone && Number.isFinite(pixel) && Math.abs(pixel - yAxisX) <= axisCrossLabelTolerance;
        const shouldHideYAxisTickLabel = pixel => xAxisCrossesYLabelZone && Number.isFinite(pixel) && Math.abs(pixel - xAxisY) <= axisCrossLabelTolerance;
        const minorTickStyle = chartStyle.resolveMinorTickStyle({ tickLength: tickLen, strokeWidth: axisStrokeWidth });
        const minorSubdivisionsX = getScatterAxisMinorTickSubdivisions('x');
        const minorSubdivisionsY = getScatterAxisMinorTickSubdivisions('y');
        const minorTicksX = getScatterAxisMinorTicksEnabled('x')
          ? chartStyle.computeMinorTickPositions({
              majorTicks: xScale.ticks,
              min: Number.isFinite(xScale.min) ? xScale.min : xMinT,
              max: Number.isFinite(xScale.max) ? xScale.max : xMaxT,
              scale: logX ? 'log' : 'linear',
              domainMin: logX ? xMin : null,
              domainMax: logX ? xMax : null,
              logBase: 10,
              subdivisions: minorSubdivisionsX
            })
          : [];
        const minorTicksY = getScatterAxisMinorTicksEnabled('y')
          ? chartStyle.computeMinorTickPositions({
              majorTicks: yScale.ticks,
              min: Number.isFinite(yScale.min) ? yScale.min : yMinT,
              max: Number.isFinite(yScale.max) ? yScale.max : yMaxT,
              scale: logY ? 'log' : 'linear',
              domainMin: logY ? yMin : null,
              domainMax: logY ? yMax : null,
              logBase: 10,
              subdivisions: minorSubdivisionsY
            })
          : [];
        const getAdditionalLineStyle = entry => {
          if(axisExtras && typeof axisExtras.getLineStyle === 'function'){
            return axisExtras.getLineStyle(entry, {
              defaultStroke: axisStroke,
              defaultStrokeWidth: Math.max(0.75, axisStrokeWidth * 0.85),
              defaultPattern: 'dotted',
              defaultTransparency: 0
            });
          }
          return {
            stroke: axisStroke,
            strokeWidth: Math.max(0.75, axisStrokeWidth * 0.85),
            linePattern: 'dotted',
            lineTransparency: 0,
            opacity: 1,
            strokeDasharray: '0 6',
            strokeLinecap: 'round'
          };
        };
        const replaceMajorTickLabel = (majorLabelEntries, pixel, label) => {
          if(!Array.isArray(majorLabelEntries) || !majorLabelEntries.length){
            return false;
          }
          let best = null;
          let bestDist = Infinity;
          majorLabelEntries.forEach(candidate => {
            const candidatePixel = Number(candidate?.pixel);
            if(!Number.isFinite(candidatePixel)){ return; }
            const dist = Math.abs(candidatePixel - pixel);
            if(dist < bestDist){
              bestDist = dist;
              best = candidate;
            }
          });
          if(!best || !best.node || bestDist > 1.5){
            return false;
          }
          best.node.textContent = label;
          return true;
        };
        const registerAdditionalLineControlElement = (axis, index, lineElement) => {
          if(!lineElement || !additionalLineControls || typeof additionalLineControls.registerAdditionalLineElement !== 'function'){
            return;
          }
          additionalLineControls.registerAdditionalLineElement(lineElement, {
            scopeId: 'scatter',
            axis,
            index,
            getValue: () => getScatterAxisAdditionalTicks(axis)?.[index]?.value,
            getColor: () => getScatterAxisAdditionalTicks(axis)?.[index]?.lineColor ?? null,
            getThickness: () => getScatterAxisAdditionalTicks(axis)?.[index]?.lineWidth ?? null,
            getPattern: () => getScatterAxisAdditionalTicks(axis)?.[index]?.linePattern ?? 'dotted',
            getTransparency: () => getScatterAxisAdditionalTicks(axis)?.[index]?.lineTransparency ?? 0,
            onColorChange: value => {
              const entry = getScatterAxisAdditionalTicks(axis)?.[index] || null;
              if(!entry){ return; }
              updateScatterAxisAdditionalTick(axis, index, { ...entry, lineColor: value });
            },
            onThicknessChange: value => {
              const entry = getScatterAxisAdditionalTicks(axis)?.[index] || null;
              if(!entry){ return; }
              updateScatterAxisAdditionalTick(axis, index, { ...entry, lineWidth: value });
            },
            onPatternChange: value => {
              const entry = getScatterAxisAdditionalTicks(axis)?.[index] || null;
              if(!entry){ return; }
              updateScatterAxisAdditionalTick(axis, index, { ...entry, linePattern: value });
            },
            onTransparencyChange: value => {
              const entry = getScatterAxisAdditionalTicks(axis)?.[index] || null;
              if(!entry){ return; }
              updateScatterAxisAdditionalTick(axis, index, { ...entry, lineTransparency: value });
            }
          });
        };
        const axisControlConfig = axis => ({
          axis,
          scopeId: 'scatter',
          additionalTickDefaults: DEFAULT_AXIS_ADDITIONAL_TICK,
          getAxisBounds: () => axis === 'x'
            ? { min: xScale.min, max: xScale.max }
            : { min: yScale.min, max: yScale.max },
          getTickInterval: () => getScatterAxisTickInterval(axis),
          getThickness: () => getScatterAxisStrokeWidth(),
          getColor: () => getScatterAxisColor(),
          isTickIntervalEnabled: () => axis === 'x' ? !logX : !logY,
          getTickIntervalDisabledMessage: () => axis === 'x'
            ? 'Tick interval is disabled while the X axis uses a logarithmic scale.'
            : 'Tick interval is disabled while the Y axis uses a logarithmic scale.',
          tickPlaceholder: 'Auto',
          onTickIntervalChange: value => updateScatterAxisTickInterval(axis, value),
          getMinorTicksEnabled: () => getScatterAxisMinorTicksEnabled(axis),
          onMinorTicksChange: value => updateScatterAxisMinorTicks(axis, value),
          isMinorTicksSupported: () => true,
          getMinorTickSubdivisions: () => getScatterAxisMinorTickSubdivisions(axis),
          onMinorTickSubdivisionsChange: value => updateScatterAxisMinorTickSubdivisions(axis, value),
          onThicknessChange: value => updateScatterAxisStrokeWidth(value),
          onColorChange: value => updateScatterAxisColor(value),
          getNotationMode: () => getScatterAxisNotation(axis),
          onNotationChange: value => updateScatterAxisNotation(axis, value),
          isNotationSupported: () => true,
          isAdditionalTicksSupported: () => true,
          getAdditionalTicks: () => getScatterAxisAdditionalTicks(axis),
          onAdditionalTickChange: (axisName, index, entry) => updateScatterAxisAdditionalTick(axisName, index, entry),
          onAdditionalTickAdd: axisName => addScatterAxisAdditionalTick(axisName),
          onAdditionalTickRemove: (axisName, index) => removeScatterAxisAdditionalTick(axisName, index),
          isBrokenAxisSupported: () => true,
          getBrokenAxisEnabled: () => getBrokenAxisEnabled(axis),
          onBrokenAxisEnabledChange: value => updateBrokenAxisEnabled(axis, value),
          getBrokenAxisSegments: () => getBrokenAxisSegments(axis),
          onBrokenAxisSegmentChange: (axisName, index, segment) => {
            const segments = getBrokenAxisSegments(axis);
            if(index >= 0 && index < segments.length){
              segments[index] = segment;
              updateBrokenAxisSegments(axis, segments);
            }
          },
          onBrokenAxisAddSegment: () => {
            const segments = getBrokenAxisSegments(axis);
            segments.push({ ...BROKEN_AXIS_DEFAULT_SEGMENT });
            updateBrokenAxisSegments(axis, segments);
          },
          onBrokenAxisRemoveSegment: (axisName, index) => {
            const segments = getBrokenAxisSegments(axis);
            if(index >= 0 && index < segments.length){
              segments.splice(index, 1);
              updateBrokenAxisSegments(axis, segments);
            }
          }
        });
        if(brokenXScale && brokenXScale.isBroken){
          let combinedLeft = Infinity;
          let combinedRight = -Infinity;
          let xBreakCapCount = 0;
          brokenXScale.segments.forEach((seg, segIndex) => {
            const segLeft = x2px(seg.start);
            const segRight = x2px(seg.end);
            add('line',{
              x1: segLeft,
              y1: xAxisY,
              x2: segRight,
              y2: xAxisY,
              stroke: axisStroke,
              'stroke-linecap': 'square',
              'stroke-width': axisStrokeWidth
            });
            if(segIndex > 0){
              const breakCapHalfLen = Math.max(0.5, tickLen * 0.9);
              add('line',{
                x1: segLeft,
                y1: xAxisY - breakCapHalfLen,
                x2: segLeft,
                y2: xAxisY + breakCapHalfLen,
                stroke: axisStroke,
                'stroke-width': axisStrokeWidth
              });
              xBreakCapCount += 1;
            }
            if(segIndex < brokenXScale.segments.length - 1){
              const breakCapHalfLen = Math.max(0.5, tickLen * 0.9);
              add('line',{
                x1: segRight,
                y1: xAxisY - breakCapHalfLen,
                x2: segRight,
                y2: xAxisY + breakCapHalfLen,
                stroke: axisStroke,
                'stroke-width': axisStrokeWidth
              });
              xBreakCapCount += 1;
            }
            combinedLeft = Math.min(combinedLeft, segLeft);
            combinedRight = Math.max(combinedRight, segRight);
          });
          debug('Debug: scatter broken X axis caps rendered',{ count: xBreakCapCount, segmentCount: brokenXScale.segments.length });
          if(isFinite(combinedLeft) && isFinite(combinedRight)){
            const hitLine = add('line',{
              x1: combinedLeft,
              y1: xAxisY,
              x2: combinedRight,
              y2: xAxisY,
              stroke: 'transparent',
              'stroke-width': 20,
              'pointer-events': 'stroke'
            });
            if(axisControls && typeof axisControls.registerAxisElement === 'function'){
              axisControls.registerAxisElement(hitLine, axisControlConfig('x'));
            }
          }
        }else{
          const xAxisLine = add('line',{x1:axisXStart,y1:xAxisY,x2:axisXEnd,y2:xAxisY,stroke:axisStroke,'stroke-linecap':'square','stroke-width':axisStrokeWidth});
          if(axisControls && typeof axisControls.registerAxisElement === 'function'){
            axisControls.registerAxisElement(xAxisLine, axisControlConfig('x'));
          }
        }
        if(brokenYScale && brokenYScale.isBroken){
          let combinedTop = Infinity;
          let combinedBottom = -Infinity;
          let yBreakCapCount = 0;
          brokenYScale.segments.forEach((seg, segIndex) => {
            const segTop = y2px(seg.end);
            const segBottom = y2px(seg.start);
            add('line',{
              x1: yAxisX,
              y1: segTop,
              x2: yAxisX,
              y2: segBottom,
              stroke: axisStroke,
              'stroke-linecap': 'square',
              'stroke-width': axisStrokeWidth
            });
            if(segIndex > 0){
              const breakCapHalfLen = Math.max(0.5, tickLen * 0.9);
              add('line',{
                x1: yAxisX - breakCapHalfLen,
                y1: segBottom,
                x2: yAxisX + breakCapHalfLen,
                y2: segBottom,
                stroke: axisStroke,
                'stroke-width': axisStrokeWidth
              });
              yBreakCapCount += 1;
            }
            if(segIndex < brokenYScale.segments.length - 1){
              const breakCapHalfLen = Math.max(0.5, tickLen * 0.9);
              add('line',{
                x1: yAxisX - breakCapHalfLen,
                y1: segTop,
                x2: yAxisX + breakCapHalfLen,
                y2: segTop,
                stroke: axisStroke,
                'stroke-width': axisStrokeWidth
              });
              yBreakCapCount += 1;
            }
            combinedTop = Math.min(combinedTop, segTop);
            combinedBottom = Math.max(combinedBottom, segBottom);
          });
          debug('Debug: scatter broken Y axis caps rendered',{ count: yBreakCapCount, segmentCount: brokenYScale.segments.length });
          if(isFinite(combinedTop) && isFinite(combinedBottom)){
            const hitLine = add('line',{
              x1: yAxisX,
              y1: combinedTop,
              x2: yAxisX,
              y2: combinedBottom,
              stroke: 'transparent',
              'stroke-width': 20,
              'pointer-events': 'stroke'
            });
            if(axisControls && typeof axisControls.registerAxisElement === 'function'){
              axisControls.registerAxisElement(hitLine, axisControlConfig('y'));
            }
          }
        }else{
          const yAxisLine = add('line',{x1:yAxisX,y1:axisYStart,x2:yAxisX,y2:axisYEnd,stroke:axisStroke,'stroke-linecap':'square','stroke-width':axisStrokeWidth});
          if(axisControls && typeof axisControls.registerAxisElement === 'function'){
            axisControls.registerAxisElement(yAxisLine, axisControlConfig('y'));
          }
        }
        debug('Debug: scatter axes stroke scaled',{ axisStrokeWidth, axisStrokeWidthBase, axisStroke });
        if(showFrame){
          debug('Debug: scatter frame request',{stroke:axisStroke, showFrame, axisStrokeWidth}); // Debug: frame styling inputs
          chartStyle.drawPlotFrame({ svg, margin, plotW, plotH, stroke: axisStroke, strokeWidth: axisStrokeWidth, sides: ['top','right'] });
        }
        // Frame closes scatter plot using axis styling continuity
        const xTickNodes=[];
        const xMajorTickLabels=[];
        let xTickFontCount=0;
        if(minorTicksX.length){
          minorTicksX.forEach(value => {
            if(!isXValueVisible(value)){ return; }
            const x = x2px(value);
            if(shouldHideXAxisTickMark(x)){ return; }
            add('line',{
              x1: x,
              y1: xAxisY,
              x2: x,
              y2: xAxisY + minorTickStyle.length,
              stroke: axisStroke,
              'stroke-width': minorTickStyle.strokeWidth,
              'stroke-linecap': 'round',
              opacity: minorTickStyle.opacity
            });
          });
        }
        xScale.ticks.forEach((t,i)=>{
          if(!isXValueVisible(t)){
            return;
          }
          const x = x2px(t);
          if(shouldHideXAxisTickMark(x)){
            debug('Debug: scatter x-axis tick mark hidden at axis crossing',{ value: t, pixel: x, crossingPixel: yAxisX });
            return;
          }
          add('line',{x1:x,y1:xAxisY,x2:x,y2:xAxisY+tickLen,stroke:axisStroke,'stroke-width':axisStrokeWidth});
          if(shouldHideXAxisTickLabel(x)){
            debug('Debug: scatter x-axis tick label hidden at axis crossing',{ value: t, pixel: x, crossingPixel: yAxisX });
            return;
          }
          const extra = Shared.computeAxisLabelYOffset ? Shared.computeAxisLabelYOffset(fs, tickLen, tickGap) : 0;
          const txt = add('text',{x, y: xAxisY + tickLen + tickGap + extra, 'font-size': fs, 'text-anchor':'middle', fill: chartStyle.TEXT_COLOR});
          txt.textContent = formatTickX(logX ? Math.pow(10, t) : t);
          Shared.applyTextBaseline && Shared.applyTextBaseline(txt,'hanging',fs);
          markFontEditable(txt,'xTick');
          xTickFontCount += 1;
          xTickNodes.push(txt);
          xMajorTickLabels.push({ pixel: x, node: txt });
        });
        const additionalXTicks = getScatterAxisAdditionalTicks('x');
        if(additionalXTicks.length){
          const renderExtras = axisExtras && typeof axisExtras.renderLinearExtras === 'function'
            ? axisExtras.renderLinearExtras
            : null;
          if(renderExtras){
            renderExtras({
              entries: additionalXTicks,
              logScale: logX,
              axisMin: xScale.min,
              axisMax: xScale.max,
              majorTicks: xScale.ticks,
              showGrid,
              isValueVisible: value => isXValueVisible(value),
              toPixel: value => x2px(value),
              onSkip: ({ reason, index, entry }) => {
                debug('Debug: scatter additional axis tick skipped', {
                  axis: 'x',
                  index,
                  reason,
                  value: entry?.value,
                  min: xScale.min,
                  max: xScale.max,
                  logScale: logX
                });
              },
              onLine: ({ index, entry, pixel }) => {
                const style = getAdditionalLineStyle(entry);
                const lineEl = add('line',{
                  x1: pixel,
                  y1: margin.top,
                  x2: pixel,
                  y2: margin.top + plotH,
                  stroke: style.stroke,
                  'stroke-width': style.strokeWidth,
                  opacity: Number.isFinite(style.opacity) ? style.opacity : 1
                });
                if(style.strokeDasharray){
                  lineEl.setAttribute('stroke-dasharray', style.strokeDasharray);
                }
                if(style.strokeLinecap){
                  lineEl.setAttribute('stroke-linecap', style.strokeLinecap);
                }
                registerAdditionalLineControlElement('x', index, lineEl);
              },
              onTick: ({ pixel }) => {
                if(shouldHideXAxisTickMark(pixel)){
                  debug('Debug: scatter additional x-axis tick mark hidden at axis crossing',{ pixel });
                  return;
                }
                add('line',{
                  x1: pixel,
                  y1: xAxisY,
                  x2: pixel,
                  y2: xAxisY + tickLen,
                  stroke: axisStroke,
                  'stroke-width': axisStrokeWidth
                });
              },
              onLabel: ({ pixel, label, nearMajor }) => {
                if(shouldHideXAxisTickLabel(pixel)){
                  debug('Debug: scatter additional x-axis label hidden at axis crossing',{ pixel, label });
                  return;
                }
                if(nearMajor && replaceMajorTickLabel(xMajorTickLabels, pixel, label)){
                  return;
                }
                const extra = Shared.computeAxisLabelYOffset ? Shared.computeAxisLabelYOffset(fs, tickLen, tickGap) : 0;
                const txt = add('text',{
                  x: pixel,
                  y: xAxisY + tickLen + tickGap + extra + Math.max(2, fs * 0.85),
                  'font-size': fs,
                  'text-anchor': 'middle',
                  fill: chartStyle.TEXT_COLOR
                });
                txt.textContent = label;
                Shared.applyTextBaseline && Shared.applyTextBaseline(txt,'hanging',fs);
                markFontEditable(txt,'xTick');
                xTickFontCount += 1;
                xTickNodes.push(txt);
              }
            });
          }
        }
        chartStyle.applyLabelOrientation(xTickNodes,{angle:-45,anchor:'end',dy:'0.35em',force:bottomLayout.shouldRotate});
        const yTickNodes=[];
        const yMajorTickLabels=[];
        let yTickFontCount=0;
        if(minorTicksY.length){
          minorTicksY.forEach(value => {
            if(!isYValueVisible(value)){ return; }
            const y = y2px(value);
            if(shouldHideYAxisTickMark(y)){ return; }
            add('line',{
              x1: yAxisX - minorTickStyle.length,
              y1: y,
              x2: yAxisX,
              y2: y,
              stroke: axisStroke,
              'stroke-width': minorTickStyle.strokeWidth,
              'stroke-linecap': 'round',
              opacity: minorTickStyle.opacity
            });
          });
        }
        yScale.ticks.forEach((t,i)=>{
          if(!isYValueVisible(t)){
            return;
          }
          const y=y2px(t);
          if(shouldHideYAxisTickMark(y)){
            debug('Debug: scatter y-axis tick mark hidden at axis crossing',{ value: t, pixel: y, crossingPixel: xAxisY });
            return;
          }
          add('line',{x1:yAxisX - tickLen,y1:y,x2:yAxisX,y2:y,stroke:axisStroke,'stroke-width':axisStrokeWidth});
          if(shouldHideYAxisTickLabel(y)){
            debug('Debug: scatter y-axis tick label hidden at axis crossing',{ value: t, pixel: y, crossingPixel: xAxisY });
            return;
          }
          const txt=add('text',{x:yAxisX-(tickLen+tickGap),y,'font-size':fs,'text-anchor':'end','dominant-baseline':'middle',fill:chartStyle.TEXT_COLOR});
          txt.textContent=formatTickY(logY?Math.pow(10,t):t);
          markFontEditable(txt,'yTick');
          yTickFontCount+=1;
          yTickNodes.push(txt);
          yMajorTickLabels.push({ pixel: y, node: txt });
        });
        const additionalYTicks = getScatterAxisAdditionalTicks('y');
        if(additionalYTicks.length){
          const renderExtras = axisExtras && typeof axisExtras.renderLinearExtras === 'function'
            ? axisExtras.renderLinearExtras
            : null;
          if(renderExtras){
            renderExtras({
              entries: additionalYTicks,
              logScale: logY,
              axisMin: yScale.min,
              axisMax: yScale.max,
              majorTicks: yScale.ticks,
              showGrid,
              isValueVisible: value => isYValueVisible(value),
              toPixel: value => y2px(value),
              onSkip: ({ reason, index, entry }) => {
                debug('Debug: scatter additional axis tick skipped', {
                  axis: 'y',
                  index,
                  reason,
                  value: entry?.value,
                  min: yScale.min,
                  max: yScale.max,
                  logScale: logY
                });
              },
              onLine: ({ index, entry, pixel }) => {
                const style = getAdditionalLineStyle(entry);
                const lineEl = add('line',{
                  x1: margin.left,
                  y1: pixel,
                  x2: margin.left + plotW,
                  y2: pixel,
                  stroke: style.stroke,
                  'stroke-width': style.strokeWidth,
                  opacity: Number.isFinite(style.opacity) ? style.opacity : 1
                });
                if(style.strokeDasharray){
                  lineEl.setAttribute('stroke-dasharray', style.strokeDasharray);
                }
                if(style.strokeLinecap){
                  lineEl.setAttribute('stroke-linecap', style.strokeLinecap);
                }
                registerAdditionalLineControlElement('y', index, lineEl);
              },
              onTick: ({ pixel }) => {
                if(shouldHideYAxisTickMark(pixel)){
                  debug('Debug: scatter additional y-axis tick mark hidden at axis crossing',{ pixel });
                  return;
                }
                add('line',{
                  x1: yAxisX - tickLen,
                  y1: pixel,
                  x2: yAxisX,
                  y2: pixel,
                  stroke: axisStroke,
                  'stroke-width': axisStrokeWidth
                });
              },
              onLabel: ({ pixel, label, nearMajor }) => {
                if(shouldHideYAxisTickLabel(pixel)){
                  debug('Debug: scatter additional y-axis label hidden at axis crossing',{ pixel, label });
                  return;
                }
                if(nearMajor && replaceMajorTickLabel(yMajorTickLabels, pixel, label)){
                  return;
                }
                const txt = add('text',{
                  x: yAxisX - (tickLen + tickGap),
                  y: pixel,
                  'font-size': fs,
                  'text-anchor': 'end',
                  'dominant-baseline': 'middle',
                  fill: chartStyle.TEXT_COLOR
                });
                txt.textContent = label;
                markFontEditable(txt,'yTick');
                yTickFontCount += 1;
                yTickNodes.push(txt);
              }
            });
          }
        }
        debug('Debug: scatter font tick binding',{ xTickFontCount, yTickFontCount }); // Debug: tick font binding counts
        debug('Debug: scatter ticks stroke scaled',{xTickCount:xScale.ticks.length,yTickCount:yScale.ticks.length,axisStrokeWidth});
        if(perfApi && svgLayoutPerf){
          perfApi.end(svgLayoutPerf, {
            component: 'scatter',
            token,
            points: points.length
          });
        }
        time(`scatterSvgDraw_${token}`);
        const renderPerf = perfApi?.start('scatter.svg.draw', {
          component: 'scatter',
          token,
          points: points.length
        });
        let geometryPrep = null;
        let densityInfo = null;
        const densityEnabled = scatterColorModeApplied === 'density';
        const geometryCache = scatterState.cachedGeometry;
        const canReuseGeometryCache = !!(viewOnly
          && !scatterState.dataDirty
          && geometryCache
          && geometryCache.points === points
          && geometryCache.logX === !!logX
          && geometryCache.logY === !!logY
          && geometryCache.xMin === xScale.min
          && geometryCache.xMax === xScale.max
          && geometryCache.yMin === yScale.min
          && geometryCache.yMax === yScale.max
          && geometryCache.marginLeft === margin.left
          && geometryCache.marginTop === margin.top
          && geometryCache.plotW === plotW
          && geometryCache.plotH === plotH);
        let pointXv = canReuseGeometryCache ? geometryCache.xv : null;
        let pointYv = canReuseGeometryCache ? geometryCache.yv : null;
        let pointCx = canReuseGeometryCache ? geometryCache.cx : null;
        let pointCy = canReuseGeometryCache ? geometryCache.cy : null;
        if(canReuseGeometryCache && densityEnabled){
          densityInfo = geometryCache.density || null;
        }
        if(canReuseGeometryCache){
          debug('Debug: scatter geometry cache reused', {
            token,
            points: points.length,
            density: !!densityInfo
          });
        }
        const geometryCount = points.length;
        const hasCompleteGeometry = pointXv
          && pointYv
          && pointCx
          && pointCy
          && pointXv.length === geometryCount
          && pointYv.length === geometryCount
          && pointCx.length === geometryCount
          && pointCy.length === geometryCount;
        if(!hasCompleteGeometry){
          const useRenderWorker = shouldUseScatterRenderWorker(points.length, {
            brokenX: brokenXScale?.isBroken,
            brokenY: brokenYScale?.isBroken
          });
          if(useRenderWorker){
            try{
              geometryPrep = await runScatterRenderWorker({
                points: points.map(p => ({ x: p.x, y: p.y })),
                logX,
                logY,
                xScale: { min: xScale.min, max: xScale.max },
                yScale: { min: yScale.min, max: yScale.max },
                margin: { left: margin.left, top: margin.top },
                plotW,
                plotH,
                densityEnabled: densityEnabled,
                debug: debugEnabled
              });
              if(token !== scatterDrawToken){
                if(perfApi && renderPerf){
                  perfApi.end(renderPerf, {
                    component: 'scatter',
                    token,
                    points: points.length,
                    outcome: 'stale'
                  });
                }
                debug('Debug: scatter render worker result ignored',{ reason:'stale-token', token, current: scatterDrawToken });
                return;
              }
              pointXv = geometryPrep?.geometry?.xv || null;
              pointYv = geometryPrep?.geometry?.yv || null;
              pointCx = geometryPrep?.geometry?.cx || null;
              pointCy = geometryPrep?.geometry?.cy || null;
              if(geometryPrep && geometryPrep.density && densityEnabled){
                densityInfo = geometryPrep.density;
                debug('Debug: scatter density computed (worker)',{ max: densityInfo.max, count: densityInfo.values?.length || 0 });
              }
              debug('Debug: scatter render prep resolved',{ usedWorker: true, pointCount: points.length });
            }catch(err){
              geometryPrep = null;
              pointXv = null;
              pointYv = null;
              pointCx = null;
              pointCy = null;
              debug('Debug: scatter render worker failed',{ message: err?.message || String(err) });
            }
          }
          const workerGeometryComplete = pointXv
            && pointYv
            && pointCx
            && pointCy
            && pointXv.length === geometryCount
            && pointYv.length === geometryCount
            && pointCx.length === geometryCount
            && pointCy.length === geometryCount;
          if(!workerGeometryComplete){
            pointXv = new Float64Array(geometryCount);
            pointYv = new Float64Array(geometryCount);
            pointCx = new Float64Array(geometryCount);
            pointCy = new Float64Array(geometryCount);
            for(let i = 0; i < geometryCount; i += 1){
              const p = points[i];
              const xv = logX ? Math.log10(p.x) : p.x;
              const yv = logY ? Math.log10(p.y) : p.y;
              pointXv[i] = xv;
              pointYv[i] = yv;
              pointCx[i] = x2px(xv);
              pointCy[i] = y2px(yv);
            }
          }
        }
        if(densityEnabled && !densityInfo){
          const densityPerf = perfApi?.start('scatter.density.compute', {
            component: 'scatter',
            token,
            points: geometryCount
          });
          densityInfo = computeScatterDensityValuesFromGeometry(pointCx, pointCy, {
            width: plotW,
            height: plotH,
            offsetX: margin.left,
            offsetY: margin.top
          });
          if(perfApi && densityPerf){
            perfApi.end(densityPerf, {
              component: 'scatter',
              token,
              points: geometryCount,
              max: densityInfo?.max || 0
            });
          }
          debug('Debug: scatter density computed',{ max: densityInfo.max, count: geometryCount });
        }
        scatterState.cachedGeometry = {
          points,
          logX: !!logX,
          logY: !!logY,
          xMin: xScale.min,
          xMax: xScale.max,
          yMin: yScale.min,
          yMax: yScale.max,
          marginLeft: margin.left,
          marginTop: margin.top,
          plotW,
          plotH,
          xv: pointXv,
          yv: pointYv,
          cx: pointCx,
          cy: pointCy,
          density: densityEnabled ? densityInfo : null
        };
        const resolveNonScatterColor = point => {
          if(!point || !point.isSignificant){
            return fill;
          }
          if(scatterCurrentGraphType === 'volcano' && Number.isFinite(point.x) && point.x < 0){
            return significanceColors.negative;
          }
          return significanceColors.positive;
        };
        const frag=document.createDocumentFragment();
        const errorBarFrag=document.createDocumentFragment();
        const manualLabelEntries = [];
        const shouldCollectManualLabels = useSelectionFallback || (thresholdLabelEnabled && (graphType === 'volcano' || graphType === 'ma'));
        let pointBounds = shouldCollectManualLabels ? [] : null;
        let pointIndex=0;
        const isBubbleView = scatterCurrentGraphType==='scatter' && scatterState.viewMode === 'bubble';
        const resolveBubbleRadius = isBubbleView ? createBubbleRadiusScaler(points, dotSizePx) : null;
        const errorBarWidthRaw = Number(scatterErrorBarWidth?.value);
        const errorBarWidthPx = chartStyle.scaleStrokeWidth(
          Number.isFinite(errorBarWidthRaw) ? Math.max(0, errorBarWidthRaw) : 1,
          styleScaleInfo,
          { context: 'scatter-error-bar', min: 0 }
        );
        const showGroupedErrorBars = groupedScatterActive
          && scatterCurrentGraphType === 'scatter'
          && !!scatterShowErrorBars?.checked
          && errorBarWidthPx > 0;
        const largePointMode = renderLargeDatasetPolicy.useLargePointMode;
        const useCanvasPointRender = largePointMode && !isBubbleView && !showGroupedErrorBars && canUseScatterPointCanvas();
        const useBatchedCircleRender = largePointMode && !useCanvasPointRender && !isBubbleView && !showGroupedErrorBars;
        const densityColorSteps = (largePointMode && scatterColorModeApplied === 'density')
          ? SCATTER_DENSITY_LARGE_COLOR_STEPS
          : 0;
        const enablePointInteractivity = !largePointMode;
        const canvasPointBuckets = useCanvasPointRender ? new Map() : null;
        let canvasPointBounds = null;
        const batchedCircleBuckets = useBatchedCircleRender ? new Map() : null;
        if(largePointMode){
          debug('Debug: scatter large point render mode', {
            pointCount: points.length,
            useCanvasPointRender,
            useBatchedCircleRender,
            densityColorSteps,
            showGroupedErrorBars,
            isBubbleView
          });
        }
        for(const p of points){
          const xv = pointXv ? pointXv[pointIndex] : (logX ? Math.log10(p.x) : p.x);
          const yv = pointYv ? pointYv[pointIndex] : (logY ? Math.log10(p.y) : p.y);
          const cxVal = pointCx ? pointCx[pointIndex] : x2px(xv);
          const cyVal = pointCy ? pointCy[pointIndex] : y2px(yv);
          const densityRatioRaw = densityInfo && densityInfo.max>0
            ? (densityInfo.values[pointIndex] || 0) / densityInfo.max
            : 0;
          const densityRatio = densityColorSteps > 0
            ? (Math.round(Math.min(1, Math.max(0, densityRatioRaw)) * densityColorSteps) / densityColorSteps)
            : densityRatioRaw;
          const color=scatterCurrentGraphType==='scatter'
            ? (scatterColorModeApplied === 'density'
              ? (densityColorFor ? densityColorFor(densityRatio) : fill)
              : (useUniformLabelStyle ? fill : (scatterLabelColors[p.label]||fill)))
            : resolveNonScatterColor(p);
          const markerShape = isBubbleView ? 'circle' : (scatterCurrentGraphType==='scatter'
            ? (useUniformLabelStyle ? 'circle' : (labelShapeLookup.get(p.label) || 'circle'))
            : 'circle');
          const styleOverride = getScatterLabelStyle(p.label || null);
          const markerAlpha = styleOverride && styleOverride.alpha != null ? clampScatterAlpha(styleOverride.alpha) : alpha;
          const markerBorderWidth = styleOverride && styleOverride.borderWidth != null ? clampScatterBorderWidth(styleOverride.borderWidth) : borderWidthPx;
          const radiusOverride = styleOverride && styleOverride.size != null ? clampScatterSize(styleOverride.size) : null;
          const markerRadius = isBubbleView && resolveBubbleRadius
            ? resolveBubbleRadius(p)
            : (radiusOverride != null ? radiusOverride : dotSizePx);
          const markerBorderColor = styleOverride && styleOverride.borderColor ? styleOverride.borderColor : borderColor;
          const markerOpacity = 1 - (markerAlpha != null ? markerAlpha : alpha);
          const canBatchCirclePoint = !!batchedCircleBuckets
            && markerShape === 'circle'
            && Number.isFinite(markerRadius)
            && markerRadius > 0;
          const canCanvasPoint = !!canvasPointBuckets
            && Number.isFinite(markerRadius)
            && markerRadius > 0;
          if(showGroupedErrorBars && !p?.isGroupedReplicatePoint){
            const yReplicateCount = Number.isInteger(p?.replicateCount)
              ? p.replicateCount
              : (Array.isArray(p?.replicates) ? p.replicates.length : 0);
            const xReplicateCount = Number.isInteger(p?.xReplicateCount)
              ? p.xReplicateCount
              : (Array.isArray(p?.xReplicates) ? p.xReplicates.length : 0);
            const canShowVerticalError = yReplicateCount > 1
              && Number.isFinite(p?.lower)
              && Number.isFinite(p?.upper)
              && p.upper >= p.lower;
            const canShowHorizontalError = xReplicateCount > 1
              && Number.isFinite(p?.xLower)
              && Number.isFinite(p?.xUpper)
              && p.xUpper >= p.xLower;
            if(!canShowVerticalError && !canShowHorizontalError && yReplicateCount <= 1 && xReplicateCount <= 1){
              debug('Debug: scatter error bar suppressed for single value',{
                rowIndex: p?.rowIndex,
                x: p?.x,
                series: p?.series || p?.label || ''
              });
            }
            const capHalf = Math.max(4, markerRadius * 1.2);
            const opacity = 1 - (markerAlpha != null ? markerAlpha : alpha);
            if(canShowVerticalError){
              const lowerVal = logY ? (p.lower > 0 ? Math.log10(p.lower) : null) : p.lower;
              const upperVal = logY ? (p.upper > 0 ? Math.log10(p.upper) : null) : p.upper;
              if(lowerVal != null && upperVal != null && Number.isFinite(lowerVal) && Number.isFinite(upperVal)){
                const lowerPx = y2px(lowerVal);
                const upperPx = y2px(upperVal);
                const vertical = document.createElementNS(NS,'line');
                vertical.setAttribute('x1', String(cxVal));
                vertical.setAttribute('y1', String(upperPx));
                vertical.setAttribute('x2', String(cxVal));
                vertical.setAttribute('y2', String(lowerPx));
                vertical.setAttribute('stroke', color);
                vertical.setAttribute('stroke-width', String(errorBarWidthPx));
                vertical.setAttribute('stroke-linecap', 'square');
                vertical.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(vertical);
                const topCap = document.createElementNS(NS,'line');
                topCap.setAttribute('x1', String(cxVal - capHalf));
                topCap.setAttribute('y1', String(upperPx));
                topCap.setAttribute('x2', String(cxVal + capHalf));
                topCap.setAttribute('y2', String(upperPx));
                topCap.setAttribute('stroke', color);
                topCap.setAttribute('stroke-width', String(errorBarWidthPx));
                topCap.setAttribute('stroke-linecap', 'square');
                topCap.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(topCap);
                const bottomCap = document.createElementNS(NS,'line');
                bottomCap.setAttribute('x1', String(cxVal - capHalf));
                bottomCap.setAttribute('y1', String(lowerPx));
                bottomCap.setAttribute('x2', String(cxVal + capHalf));
                bottomCap.setAttribute('y2', String(lowerPx));
                bottomCap.setAttribute('stroke', color);
                bottomCap.setAttribute('stroke-width', String(errorBarWidthPx));
                bottomCap.setAttribute('stroke-linecap', 'square');
                bottomCap.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(bottomCap);
              }
            }
            if(canShowHorizontalError){
              const leftVal = logX ? (p.xLower > 0 ? Math.log10(p.xLower) : null) : p.xLower;
              const rightVal = logX ? (p.xUpper > 0 ? Math.log10(p.xUpper) : null) : p.xUpper;
              if(leftVal != null && rightVal != null && Number.isFinite(leftVal) && Number.isFinite(rightVal)){
                const leftPx = x2px(leftVal);
                const rightPx = x2px(rightVal);
                const horizontal = document.createElementNS(NS,'line');
                horizontal.setAttribute('x1', String(leftPx));
                horizontal.setAttribute('y1', String(cyVal));
                horizontal.setAttribute('x2', String(rightPx));
                horizontal.setAttribute('y2', String(cyVal));
                horizontal.setAttribute('stroke', color);
                horizontal.setAttribute('stroke-width', String(errorBarWidthPx));
                horizontal.setAttribute('stroke-linecap', 'square');
                horizontal.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(horizontal);
                const leftCap = document.createElementNS(NS,'line');
                leftCap.setAttribute('x1', String(leftPx));
                leftCap.setAttribute('y1', String(cyVal - capHalf));
                leftCap.setAttribute('x2', String(leftPx));
                leftCap.setAttribute('y2', String(cyVal + capHalf));
                leftCap.setAttribute('stroke', color);
                leftCap.setAttribute('stroke-width', String(errorBarWidthPx));
                leftCap.setAttribute('stroke-linecap', 'square');
                leftCap.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(leftCap);
                const rightCap = document.createElementNS(NS,'line');
                rightCap.setAttribute('x1', String(rightPx));
                rightCap.setAttribute('y1', String(cyVal - capHalf));
                rightCap.setAttribute('x2', String(rightPx));
                rightCap.setAttribute('y2', String(cyVal + capHalf));
                rightCap.setAttribute('stroke', color);
                rightCap.setAttribute('stroke-width', String(errorBarWidthPx));
                rightCap.setAttribute('stroke-linecap', 'square');
                rightCap.setAttribute('stroke-opacity', String(opacity));
                errorBarFrag.appendChild(rightCap);
              }
            }
          }
          if(pointBounds){
            pointBounds.push({ cx: cxVal, cy: cyVal, r: markerRadius });
          }
          const manualLabelText = (p.pointName || p.label || '').trim();
          if((p.isManualLabel || p.isThresholdLabel) && manualLabelText){
            manualLabelEntries.push({
              text: manualLabelText,
              cx: cxVal,
              cy: cyVal,
              radius: markerRadius,
              labelColor: null
            });
          }
          if(canCanvasPoint){
            const strokeValue = markerBorderWidth>0 ? markerBorderColor : '';
            const strokeWidthValue = markerBorderWidth>0 ? markerBorderWidth : 0;
            const bucketKey = [
              markerShape,
              color,
              markerOpacity,
              strokeValue,
              strokeWidthValue,
              markerOpacity
            ].join('|');
            let bucket = canvasPointBuckets.get(bucketKey);
            if(!bucket){
              bucket = {
                shape: markerShape,
                fill: color,
                fillOpacity: markerOpacity,
                stroke: strokeValue,
                strokeWidth: strokeWidthValue,
                strokeOpacity: markerOpacity,
                points: []
              };
              canvasPointBuckets.set(bucketKey, bucket);
            }
            bucket.points.push({ x: cxVal, y: cyVal, r: markerRadius });
            canvasPointBounds = updateScatterPointCanvasBounds(canvasPointBounds, cxVal, cyVal, markerRadius, strokeWidthValue);
          }else if(canBatchCirclePoint){
            const strokeValue = markerBorderWidth>0 ? markerBorderColor : '';
            const strokeWidthValue = markerBorderWidth>0 ? markerBorderWidth : 0;
            const bucketKey = [
              color,
              markerOpacity,
              strokeValue,
              strokeWidthValue,
              markerOpacity
            ].join('|');
            let bucket = batchedCircleBuckets.get(bucketKey);
            if(!bucket){
              bucket = {
                fill: color,
                fillOpacity: markerOpacity,
                stroke: strokeValue,
                strokeWidth: strokeWidthValue,
                strokeOpacity: markerOpacity,
                segments: []
              };
              batchedCircleBuckets.set(bucketKey, bucket);
            }
            const segment = buildScatterCirclePathSegment(cxVal, cyVal, markerRadius);
            if(segment){
              bucket.segments.push(segment);
            }
          }else{
            const marker = createScatterMarkerElement(markerShape, {
              cx: cxVal,
              cy: cyVal,
              radius: markerRadius,
              fill: color,
              stroke: markerBorderWidth>0 ? markerBorderColor : null,
              strokeWidth: markerBorderWidth>0 ? markerBorderWidth : 0,
              fillOpacity: markerOpacity,
              strokeOpacity: markerOpacity
            });
            if(marker){
              if(enablePointInteractivity){
                attachScatterPointTooltip(marker, {
                  label: p.label || '',
                  pointName: p.pointName || '',
                  rowIndex: Number.isInteger(p.rowIndex) ? p.rowIndex : undefined,
                  isManualLabel: !!p.isManualLabel,
                  x: p.x,
                  y: p.y,
                  logXValue: logX ? xv : undefined,
                  logYValue: logY ? yv : undefined,
                  graphType: scatterCurrentGraphType,
                  isSignificant: typeof p.isSignificant === 'boolean' ? p.isSignificant : undefined,
                  size: isBubbleView ? p.bubbleValue : undefined,
                  series: p.series || p.label || '',
                  replicates: Array.isArray(p.replicates) ? p.replicates : undefined,
                  stdev: Number.isFinite(p.stdev) ? p.stdev : undefined,
                  xReplicates: Array.isArray(p.xReplicates) ? p.xReplicates : undefined,
                  xStdev: Number.isFinite(p.xStdev) ? p.xStdev : undefined,
                  groupedReplicateIndex: Number.isInteger(p.replicateIndex) ? p.replicateIndex : undefined,
                  isGroupedReplicatePoint: !!p.isGroupedReplicatePoint
                });
              }
              frag.appendChild(marker);
            }
          }
          pointIndex++;
          if(pointIndex >= nextPointProgress){info('scatter svg draw progress',{pointIndex,token});nextPointProgress += pointProgressInterval;}
        }
        if(batchedCircleBuckets && batchedCircleBuckets.size){
          const doc = global.document;
          batchedCircleBuckets.forEach(bucket => {
            if(!bucket || !Array.isArray(bucket.segments) || !bucket.segments.length || !doc){
              return;
            }
            const path = doc.createElementNS(NS, 'path');
            path.setAttribute('d', bucket.segments.join(' '));
            path.setAttribute('fill', bucket.fill || '#000000');
            if(bucket.fillOpacity !== 1){
              path.setAttribute('fill-opacity', String(bucket.fillOpacity));
            }
            if(bucket.stroke && bucket.strokeWidth > 0){
              path.setAttribute('stroke', bucket.stroke);
              path.setAttribute('stroke-width', String(bucket.strokeWidth));
              if(bucket.strokeOpacity !== 1){
                path.setAttribute('stroke-opacity', String(bucket.strokeOpacity));
              }
            }else{
              path.setAttribute('stroke', 'none');
            }
            frag.appendChild(path);
          });
        }
        if(perfApi && renderPerf){
          perfApi.end(renderPerf, {
            component: 'scatter',
            token,
            points: points.length,
            density: scatterColorModeApplied === 'density'
          });
        }
        if(showGroupedErrorBars && errorBarFrag.childNodes.length){
          const errorLayer=add('g',{'data-export-layer':'scatter-error-bars','data-layer':'error-bars'});
          errorLayer.appendChild(errorBarFrag);
        }
        const pointLayer=add('g',{'data-export-layer':'scatter-points','data-layer':'points'});
        pointLayer.setAttribute('data-render-mode', useCanvasPointRender ? 'canvas-pending' : (useBatchedCircleRender ? 'batched-circles' : 'markers'));
        if(!enablePointInteractivity){
          pointLayer.setAttribute('pointer-events', 'none');
          hideScatterTooltip('point-interaction-disabled-large-dataset');
        }
        const pointAttachPerf = perfApi?.start('scatter.svg.attach', {
          component: 'scatter',
          token,
          points: points.length
        });
        let canvasPointLayerRendered = false;
        if(useCanvasPointRender){
          canvasPointLayerRendered = await renderScatterPointCanvasBuckets(pointLayer, canvasPointBuckets, canvasPointBounds, {
            doc: global.document,
            shouldCancel: () => token !== scatterDrawToken
          });
          if(token !== scatterDrawToken){
            if(perfApi && pointAttachPerf){
              perfApi.end(pointAttachPerf, { component: 'scatter', token, points: points.length, canvas: false, outcome: 'stale' });
            }
            debug('Debug: scatter canvas point render ignored', { reason: 'stale-token', token, current: scatterDrawToken });
            return;
          }
          if(!canvasPointLayerRendered){
            appendScatterPointCanvasBucketsAsPaths(pointLayer, canvasPointBuckets);
            debug('Debug: scatter canvas point render fallback used', { pointCount: points.length });
          }else{
            debug('Debug: scatter canvas point render complete', {
              pointCount: points.length,
              bucketCount: canvasPointBuckets?.size || 0,
              bounds: canvasPointBounds
            });
          }
        }
        if(frag.childNodes.length){
          pointLayer.appendChild(frag);
        }
        if(perfApi && pointAttachPerf){
          perfApi.end(pointAttachPerf, { component: 'scatter', token, points: points.length, canvas: canvasPointLayerRendered });
        }
        if(scatter.__lastLargeDatasetRenderSummary){
          scatter.__lastLargeDatasetRenderSummary.renderMode = pointLayer.getAttribute('data-render-mode') || null;
        }
        if(scatterState.useDelegatedPointEvents && enablePointInteractivity){
          ensureScatterPointDelegation(pointLayer);
        }
        const annotationPerf = annotationRequests.length
          ? perfApi?.start('scatter.annotations.layout', {
              component: 'scatter',
              token,
              requests: annotationRequests.length
            })
          : null;
        if(annotationRequests.length){
          const pointGeometry = new Array(points.length);
          for(let i = 0; i < points.length; i += 1){
            pointGeometry[i] = {
              xv: pointXv ? pointXv[i] : (logX ? Math.log10(points[i]?.x) : points[i]?.x),
              yv: pointYv ? pointYv[i] : (logY ? Math.log10(points[i]?.y) : points[i]?.y),
              cx: pointCx ? pointCx[i] : x2px(logX ? Math.log10(points[i]?.x) : points[i]?.x),
              cy: pointCy ? pointCy[i] : y2px(logY ? Math.log10(points[i]?.y) : points[i]?.y)
            };
          }
          const annotationLayout = layoutScatterAnnotations({
            requests: annotationRequests,
            pointGeometry,
            margin,
            plotW,
            plotH,
            fontSize: annotationFontPx,
            leaderPadding: annotationLeaderPadding,
            leaderGap: Math.max(annotationLeaderPadding * 1.25, annotationLeaderPadding + 4),
            textPadding: annotationTextPadding,
            axisPadding: annotationAxisPadding,
            graphType: scatterCurrentGraphType,
            verticalPadding: Math.max(
              annotationAxisPadding * 0.6 * Math.max(0.6, annotationCrowdingScale),
              fs * 0.6 * Math.max(0.6, annotationCrowdingScale),
              6
            )
          });
          if(annotationLayout.length){
            const annotationLayer=document.createElementNS(NS,'g');
            annotationLayout.forEach((entry, idx)=>{
              const textNode=document.createElementNS(NS,'text');
              textNode.setAttribute('x',entry.textX);
              textNode.setAttribute('y',entry.anchorY);
              textNode.setAttribute('font-size',annotationFontPx);
              textNode.setAttribute('fill',chartStyle.TEXT_COLOR || '#333333');
              textNode.setAttribute('text-anchor',entry.textAnchor);
              textNode.setAttribute('dominant-baseline','middle');
              textNode.textContent=entry.label;
              markFontEditable(textNode,'annotation',`annotation-${idx}`);
              annotationLayer.appendChild(textNode);
              const connector=document.createElementNS(NS,'path');
              const path=`M ${entry.attachX} ${entry.anchorY} L ${entry.pointX} ${entry.pointY}`;
              connector.setAttribute('d',path);
              connector.setAttribute('fill','none');
              connector.setAttribute('stroke',chartStyle.TEXT_COLOR || '#333333');
              connector.setAttribute('stroke-width',annotationStrokeWidth);
              connector.setAttribute('stroke-linecap','round');
              annotationLayer.appendChild(connector);
            });
            svg.appendChild(annotationLayer);
            debug('Debug: scatter annotations rendered',{count:annotationLayout.length,graphType:scatterCurrentGraphType});
          }
        }
        if(perfApi && annotationPerf){
          perfApi.end(annotationPerf, { component: 'scatter', token, requests: annotationRequests.length });
        }
        if(manualLabelEntries.length){
          const labelLayer = document.createElementNS(NS,'g');
          labelLayer.setAttribute('data-layer','point-labels');
          labelLayer.setAttribute('pointer-events','none');
          const baseManualLabelSize = fs * 0.6;
          const labelLayout = Shared.labelLayout;
          const xTickFontSize = labelLayout?.readFontSizeFromNodes ? labelLayout.readFontSizeFromNodes(xTickNodes) : null;
          const yTickFontSize = labelLayout?.readFontSizeFromNodes ? labelLayout.readFontSizeFromNodes(yTickNodes) : null;
          const tickFontSizeCap = (Number.isFinite(xTickFontSize) && Number.isFinite(yTickFontSize))
            ? Math.min(xTickFontSize, yTickFontSize)
            : (Number.isFinite(xTickFontSize)
              ? xTickFontSize
              : (Number.isFinite(yTickFontSize) ? yTickFontSize : fs));
          const labelFontSizeRaw = computeScatterManualLabelFontSize(baseManualLabelSize, manualLabelEntries.length, plotW, plotH);
          const labelFontSize = Math.min(labelFontSizeRaw, tickFontSizeCap);
          const labelScale = Math.min(1, labelFontSize / Math.max(1, baseManualLabelSize));
          const leaderStrokeWidth = chartStyle.scaleStrokeWidth(0.75 * labelScale, styleScaleInfo, { context: 'scatter-point-label', min: 0.25 });
          const labelColor = chartStyle.TEXT_COLOR || '#333333';
          const plotLeft = margin.left;
          const plotRight = margin.left + plotW;
          const plotTop = margin.top;
          const plotBottom = margin.top + plotH;
          const font = typeof chartStyle?.makeFont === 'function'
            ? chartStyle.makeFont(labelFontSize)
            : null;
          const boundsForLayout = Array.isArray(pointBounds) ? pointBounds : [];
          const manualLabelLayout = computeScatterManualLabelLayout(manualLabelEntries, {
            plotLeft,
            plotRight,
            plotTop,
            plotBottom,
            labelFontSize,
            leaderGap: Math.max(2, Math.round(labelFontSize * 0.2)),
            leaderScale: labelScale,
            pointBounds: boundsForLayout,
            measureText: chartStyle?.measureText,
            font,
            angleSteps: 16,
            maxLeaderScale: 3
          });
          manualLabelLayout.forEach(result => {
            const entry = result.entry;
            const placement = result.placement;
            const cx = Number(entry?.cx) || 0;
            const cy = Number(entry?.cy) || 0;
            const textValue = entry?.text ? String(entry.text) : '';
            const entryColor = entry?.labelColor || labelColor;
            if(!textValue || !placement){
              return;
            }
            const textX = placement.textX;
            const textY = placement.textY;
            const anchor = placement.anchor;
            const lineX2 = placement.lineX2;
            const leader = document.createElementNS(NS,'line');
            leader.setAttribute('x1', String(cx));
            leader.setAttribute('y1', String(cy));
            leader.setAttribute('x2', String(lineX2));
            leader.setAttribute('y2', String(textY));
            leader.setAttribute('stroke', entryColor);
            leader.setAttribute('stroke-width', String(leaderStrokeWidth));
            leader.setAttribute('stroke-linecap', 'round');
            labelLayer.appendChild(leader);
            const textNode = document.createElementNS(NS,'text');
            textNode.setAttribute('x', String(textX));
            textNode.setAttribute('y', String(textY));
            textNode.setAttribute('font-size', String(labelFontSize));
            textNode.setAttribute('fill', entryColor);
            textNode.setAttribute('text-anchor', anchor);
            textNode.setAttribute('dominant-baseline', 'middle');
            textNode.textContent = textValue;
            labelLayer.appendChild(textNode);
          });
          svg.appendChild(labelLayer);
          debug('Debug: scatter manual labels rendered', { count: manualLabelEntries.length });
        }
        timeEnd(`scatterSvgDraw_${token}`);
        if(legendVisible){
          const legendPerf = perfApi?.start('scatter.legend.render', {
            component: 'scatter',
            token,
            entries: legendRenderer.entries?.length || 0
          });
          const plotRight=margin.left+plotW;
          const defaultLegendX=plotRight+legendGapPx;
          const defaultLegendY=margin.top;
          const legendPos=scatterLabelPositions?.legend;
          
          // Convert relative positions to absolute if needed for legend
          let absoluteLegendX = defaultLegendX;
          let absoluteLegendY = defaultLegendY;
          if (legendPos) {
            if (legendPos.relX !== undefined && legendPos.relY !== undefined) {
              // Use relative positioning
              absoluteLegendX = plotRight + legendPos.relX * legendGapPx;
              absoluteLegendY = margin.top + legendPos.relY * plotH;
            } else if (legendPos.x !== undefined && legendPos.y !== undefined) {
              // Use absolute positioning (backward compatibility)
              absoluteLegendX = legendPos.x;
              absoluteLegendY = legendPos.y;
            }
          }
          
          const legendGroup=legendRenderer.draw(svg,{
            x: absoluteLegendX,
            y: absoluteLegendY
          });
          if(legendGroup && typeof Shared.enableLegendDrag === 'function'){
            Shared.enableLegendDrag(legendGroup, svg, {
              onDragEnd: pos => {
                // Store both absolute and relative positions for legend
                const relX = (pos.x - plotRight) / legendGapPx;
                const relY = (pos.y - margin.top) / plotH;
                scatterLabelPositions.legend = { 
                  x: pos.x, 
                  y: pos.y,
                  relX: relX, 
                  relY: relY 
                };
                if(Shared.isDebugEnabled?.()){
                  console.debug('Debug: scatter legend position saved', { absolute: pos, relative: { relX, relY } });
                }
              }
            });
          }
          // Mark legend text nodes editable so graph-scope font styles apply
          if(legendGroup && typeof legendGroup.querySelectorAll === 'function'){
            const textNodes = legendGroup.querySelectorAll('text');
            Array.from(textNodes).forEach((node, idx) => {
              try{ markFontEditable(node, 'legend', `legend-${idx}`); }catch(e){}
            });
          }
          debug('Debug: scatter legend rendered shared helper',{
            legendX: legendPos?.x ?? defaultLegendX,
            legendY: legendPos?.y ?? defaultLegendY,
            legendGapPx,
            entryCount:legendRenderer.entries.length
          });
          if(perfApi && legendPerf){
            perfApi.end(legendPerf, { component: 'scatter', token, entries: legendRenderer.entries?.length || 0 });
          }
        }
        const xAxisBase=margin.top+plotH;
        const defaultXLabelX = margin.left+plotW/2;
        // Prevent overlap between x-axis title and rotated tick labels by adding
        // a rotation-aware separation to the default Y when ticks rotate.
        let rotationExtra = 0;
        if(bottomLayout && bottomLayout.shouldRotate){
          const maxLabelWidthLocal = bottomLayout.maxLabelWidth || 0;
          rotationExtra = Math.min(220, Math.max(fs * 1.8, Math.ceil(Math.SQRT1_2 * maxLabelWidthLocal) + fs));
        }
        const rotationSeparation = rotationExtra ? Math.round(rotationExtra * 0.55) : 0;
        const defaultXLabelY = xAxisBase + bottomLayout.titleOffset + rotationSeparation;
        const xLabelPos = scatterLabelPositions?.xLabel;
        
        // Convert relative positions to absolute if needed
        let absoluteXLabelX = defaultXLabelX;
        let absoluteXLabelY = defaultXLabelY;
        if (xLabelPos) {
          if (xLabelPos.relX !== undefined && xLabelPos.relY !== undefined) {
            // Use relative positioning
            absoluteXLabelX = margin.left + xLabelPos.relX * plotW;
            absoluteXLabelY = xAxisBase + xLabelPos.relY * (plotH + margin.top);
          } else if (xLabelPos.x !== undefined && xLabelPos.y !== undefined) {
            // Use absolute positioning (backward compatibility)
            absoluteXLabelX = xLabelPos.x;
            absoluteXLabelY = xLabelPos.y;
          }
        }
        
        const xText=add('text',{x: absoluteXLabelX, y: absoluteXLabelY,'text-anchor':'middle','font-size':fs,fill:chartStyle.TEXT_COLOR});
        xText.textContent=scatterState.xLabelText;
        markFontEditable(xText,'xTitle','xTitle');
        const applyScatterXLabel=value=>{
          const nextValue=value!=null?String(value):'';
          scatterState.xLabelText=nextValue;
          scatterXLabelText=nextValue;
          scatterState.axisLabelModes = normalizeScatterAxisLabelModes({
            ...scatterState.axisLabelModes,
            x: 'manual'
          }, scatterState.axisLabelModes);
          if(xText.textContent!==nextValue){
            xText.textContent=nextValue;
          }
          scheduleScatterViewRefresh('x-label-change');
        };
        makeEditableLocal(xText,txt=>{
          const previous=scatterXLabelText!=null?String(scatterXLabelText):'';
          const nextValue=txt!=null?String(txt):'';
          if(previous===nextValue){
            return;
          }
          
          // Create a combined apply function that updates both visual and table header
          const applyBoth = (value) => {
            scatterLog('applyBoth called with value:', value);
            
            // Update visual title
            applyScatterXLabel(value);
            
            // Also update the table header to maintain consistency
            const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
            scatterLog('Undo sync - HOT instance:', hot);
            
            if(hot && typeof hot.setDataAtCell === 'function'){
              try {
                const data = hot.getData() || [];
                scatterLog('Undo sync - Current table data:', data);
                
                if(Array.isArray(data) && data.length > 0) {
                  const headerRow = Array.isArray(data[0]) ? data[0] : [];
                  scatterLog('Undo sync - Current header row:', headerRow);
                  
                  const layout = resolveScatterColumnLayout(data);
                  scatterLog('Undo sync - Column layout:', layout);
                  
                  if(layout && Number.isInteger(layout.xCol) && layout.xCol >= 0 && layout.xCol < headerRow.length){
                    scatterLog('Undo sync - Updating x-axis header to:', value);
                    
                    // Try multiple approaches to ensure the update works
                    let updateSuccessful = false;
                    
                    // Approach 1: setDataAtCell
                    try {
                      const result = hot.setDataAtCell([0, layout.xCol, value], 'scatter-x-axis-undo-sync');
                      scatterLog('Undo sync - setDataAtCell result:', result);
                      
                      // Verify the update
                      const verifyData = hot.getData() || [];
                      const verifyHeader = Array.isArray(verifyData[0]) ? verifyData[0] : [];
                      if(verifyHeader[layout.xCol] === value) {
                        updateSuccessful = true;
                        scatterLog('Undo sync - Successfully updated with setDataAtCell');
                      }
                    } catch(err) {
                      scatterLog('Undo sync - setDataAtCell failed:', err.message);
                    }
                    
                    // Approach 2: Direct data manipulation if setDataAtCell failed
                    if(!updateSuccessful) {
                      try {
                        const currentData = hot.getData() || [];
                        const newData = JSON.parse(JSON.stringify(currentData));
                        
                        if(Array.isArray(newData[0]) && layout.xCol >= 0 && layout.xCol < newData[0].length) {
                          newData[0][layout.xCol] = value;
                          
                          // Try different update methods
                          if(typeof hot.setData === 'function') {
                            hot.setData(newData);
                            scatterLog('Undo sync - Used setData method');
                          } else if(typeof hot.updateSettings === 'function') {
                            hot.updateSettings({ data: newData });
                            scatterLog('Undo sync - Used updateSettings method');
                          } else if(typeof hot.gridApi?.setRowData === 'function') {
                            hot.gridApi.setRowData(newData);
                            scatterLog('Undo sync - Used gridApi.setRowData method');
                          }
                          
                          // Verify the update
                          const verifyData = hot.getData() || [];
                          const verifyHeader = Array.isArray(verifyData[0]) ? verifyData[0] : [];
                          if(verifyHeader[layout.xCol] === value) {
                            updateSuccessful = true;
                            scatterLog('Undo sync - Successfully updated with direct manipulation');
                          }
                        }
                      } catch(err) {
                        console.error('Undo sync - Direct manipulation failed:', err);
                      }
                    }
                    
                    if(!updateSuccessful) {
                      console.error('Undo sync - Failed to update x-axis header in table');
                    }
                  }
                }
              } catch(err) {
                console.error('Failed to sync x-axis header during undo:', err);
              }
            } else {
              console.error('Undo sync - HOT instance or setDataAtCell not available');
            }
            
            // Force a redraw to ensure consistency
            if(typeof scheduleDrawScatter === 'function'){
              scheduleScatterViewRefresh('x-axis-undo-sync');
            }
            
            scatterLog('Undo sync - Completed x-axis update');
            return true;
          };
          
          applyBoth(nextValue);
          recordScatterChange('scatter:x-label',previous,nextValue,applyBoth);
          
          // IMMEDIATE DEBUG: Check if this function is being called
          scatterLog('X-AXIS EDIT HANDLER CALLED!', { previous, nextValue });
          
          // Update the table header to make the change permanent
          const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
          scatterLog('HOT instance:', hot, 'scatterRefs.hot:', scatterRefs.hot);
          
          if(hot && typeof hot.setDataAtCell === 'function'){
            try {
              scatterLog('Attempting to update table header...');
              const data = hot.getData() || [];
              scatterLog('Table data:', data);
              
              if(!Array.isArray(data) || data.length === 0) {
                console.warn('No table data available for x-axis header update');
                return;
              }
              
              const headerRow = Array.isArray(data[0]) ? data[0] : [];
              scatterLog('Header row:', headerRow);
              
              if(!Array.isArray(headerRow) || headerRow.length === 0) {
                console.warn('No header row available for x-axis header update');
                return;
              }
              
              const layout = resolveScatterColumnLayout(data);
              scatterLog('Column layout:', layout);
              
              if(!layout || !Number.isInteger(layout.xCol)) {
                console.warn('Invalid column layout for x-axis:', layout);
                return;
              }
              
              if(layout.xCol < 0 || layout.xCol >= headerRow.length) {
                console.warn('X-axis column index out of bounds:', { index: layout.xCol, headerLength: headerRow.length });
                return;
              }
              
              scatterLog('Updating x-axis header:', { 
                row: 0, 
                col: layout.xCol, 
                oldValue: headerRow[layout.xCol], 
                newValue: nextValue 
              });
              
              // Try multiple approaches to update the cell
              let updateSuccessful = false;
              
              // Approach 1: Try the original setDataAtCell
              try {
                const result = hot.setDataAtCell([0, layout.xCol, nextValue], 'scatter-x-axis-edit');
                scatterLog('setDataAtCell result:', result);
                
                // Check if the update worked
                const updatedData1 = hot.getData() || [];
                const updatedHeader1 = Array.isArray(updatedData1[0]) ? updatedData1[0] : [];
                if(updatedHeader1[layout.xCol] === nextValue) {
                  updateSuccessful = true;
                  scatterLog('Update successful with setDataAtCell');
                }
              } catch(err) {
                scatterLog('setDataAtCell failed, trying alternative approach:', err.message);
              }
              
              // Approach 2: If setDataAtCell didn't work, try updating the data directly
              if(!updateSuccessful) {
                try {
                  const currentData = hot.getData() || [];
                  const newData = JSON.parse(JSON.stringify(currentData)); // Deep clone
                  
                  if(Array.isArray(newData[0]) && layout.xCol >= 0 && layout.xCol < newData[0].length) {
                    newData[0][layout.xCol] = nextValue;
                    
                    // Try different AG Grid update methods
                    if(typeof hot.setData === 'function') {
                      hot.setData(newData);
                      scatterLog('Used setData method');
                    } else if(typeof hot.updateSettings === 'function') {
                      hot.updateSettings({ data: newData });
                      scatterLog('Used updateSettings method');
                    } else if(typeof hot.gridApi?.setRowData === 'function') {
                      hot.gridApi.setRowData(newData);
                      scatterLog('Used gridApi.setRowData method');
                    } else {
                      console.warn('No suitable update method found');
                    }
                    
                    // Verify the update
                    const updatedData2 = hot.getData() || [];
                    const updatedHeader2 = Array.isArray(updatedData2[0]) ? updatedData2[0] : [];
                    if(updatedHeader2[layout.xCol] === nextValue) {
                      updateSuccessful = true;
                      scatterLog('Update successful with direct data manipulation');
                    }
                  }
                } catch(err) {
                  console.error('Direct data manipulation failed:', err);
                }
              }
              
              // Final verification
              const finalData = hot.getData() || [];
              const finalHeader = Array.isArray(finalData[0]) ? finalData[0] : [];
              scatterLog('Final header row:', finalHeader);
              scatterLog('Header at xCol after all attempts:', finalHeader[layout.xCol]);
              
              if(finalHeader[layout.xCol] === nextValue) {
                scatterLog('SUCCESS: X-axis header updated to:', nextValue);
              } else {
                console.error('FAILED: X-axis header still shows:', finalHeader[layout.xCol]);
              }
              
              // Force a redraw to ensure the changes are reflected
              if(typeof scheduleDrawScatter === 'function'){
                setTimeout(() => scheduleScatterViewRefresh('x-axis-header-update'), 100);
              }
              
            } catch(err) {
              console.error('Failed to update table header for x-axis:', err);
            }
          } else {
            console.error('HOT instance or setDataAtCell function not available!');
          }
        });
        // Enable drag for x-axis label
        if(typeof Shared.enableLabelDrag === 'function'){
          Shared.enableLabelDrag(xText, svg, {
            onDragEnd: pos => {
              // Store both absolute and relative positions
              const relX = (pos.x - margin.left) / plotW;
              const relY = (pos.y - xAxisBase) / (plotH + margin.top);
              scatterLabelPositions.xLabel = { 
                x: pos.x, 
                y: pos.y,
                relX: relX, 
                relY: relY 
              };
              console.debug('Debug: scatter x-label position saved', { absolute: pos, relative: { relX, relY } });
            }
          });
        }
        const yLabelOffsetSpan = (maxYLabelWidth + tickLen + tickGap + yTitleSeparation);
        const defaultYX = margin.left - yLabelOffsetSpan;
        const defaultYY = margin.top+plotH/2;
        const yLabelPos = scatterLabelPositions?.yLabel;
        
        // Convert relative positions to absolute if needed
        let absoluteYTextX = defaultYX;
        let absoluteYTextY = defaultYY;
        if (yLabelPos) {
          if (yLabelPos.relX !== undefined && yLabelPos.relY !== undefined) {
            // Use relative positioning
            absoluteYTextX = margin.left + yLabelPos.relX * yLabelOffsetSpan;
            absoluteYTextY = margin.top + yLabelPos.relY * plotH;
          } else if (yLabelPos.x !== undefined && yLabelPos.y !== undefined) {
            // Migrate legacy absolute-only positions to relative so font/layout changes stay responsive.
            const legacyX = Number(yLabelPos.x);
            const legacyY = Number(yLabelPos.y);
            if(Number.isFinite(legacyX) && Number.isFinite(legacyY)){
              const relX = (legacyX - margin.left) / Math.max(yLabelOffsetSpan, 1);
              const relY = (legacyY - margin.top) / Math.max(plotH, 1);
              absoluteYTextX = margin.left + relX * yLabelOffsetSpan;
              absoluteYTextY = margin.top + relY * plotH;
              scatterLabelPositions.yLabel = {
                x: absoluteYTextX,
                y: absoluteYTextY,
                relX,
                relY
              };
              debug('Debug: scatter y-label legacy absolute position migrated', {
                legacy: { x: legacyX, y: legacyY },
                relative: { relX, relY }
              });
            }else{
              absoluteYTextX = defaultYX;
              absoluteYTextY = defaultYY;
            }
          }
        }
        
        info('scatter y-axis position',absoluteYTextX);
        const yText=add('text',{x:absoluteYTextX,y:absoluteYTextY,transform:`rotate(-90 ${absoluteYTextX} ${absoluteYTextY})`,'text-anchor':'middle','font-size':fs,fill:chartStyle.TEXT_COLOR});
        yText.textContent=scatterState.yLabelText;
        markFontEditable(yText,'yTitle','yTitle');
        const applyScatterYLabel=value=>{
          const nextValue=value!=null?String(value):'';
          scatterState.yLabelText=nextValue;
          scatterYLabelText=nextValue;
          scatterState.axisLabelModes = normalizeScatterAxisLabelModes({
            ...scatterState.axisLabelModes,
            y: 'manual'
          }, scatterState.axisLabelModes);
          if(yText.textContent!==nextValue){
            yText.textContent=nextValue;
          }
          scheduleScatterViewRefresh('y-label-change');
        };
        makeEditableLocal(yText,txt=>{
          const previous=scatterYLabelText!=null?String(scatterYLabelText):'';
          const nextValue=txt!=null?String(txt):'';
          if(previous===nextValue){
            return;
          }
          
          // Create a combined apply function that updates both visual and table header
          const applyBoth = (value) => {
            scatterLog('applyBoth called with value:', value);
            
            // Update visual title
            applyScatterYLabel(value);
            
            // Also update the table header to maintain consistency
            const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
            scatterLog('Undo sync - HOT instance:', hot);
            
            if(hot && typeof hot.setDataAtCell === 'function'){
              try {
                const data = hot.getData() || [];
                scatterLog('Undo sync - Current table data:', data);
                
                if(Array.isArray(data) && data.length > 0) {
                  const headerRow = Array.isArray(data[0]) ? data[0] : [];
                  scatterLog('Undo sync - Current header row:', headerRow);
                  
                  const layout = resolveScatterColumnLayout(data);
                  scatterLog('Undo sync - Column layout:', layout);
                  
                  if(layout && Number.isInteger(layout.yCol) && layout.yCol >= 0 && layout.yCol < headerRow.length){
                    scatterLog('Undo sync - Updating y-axis header to:', value);
                    
                    // Try multiple approaches to ensure the update works
                    let updateSuccessful = false;
                    
                    // Approach 1: setDataAtCell
                    try {
                      const result = hot.setDataAtCell([0, layout.yCol, value], 'scatter-y-axis-undo-sync');
                      scatterLog('Undo sync - setDataAtCell result:', result);
                      
                      // Verify the update
                      const verifyData = hot.getData() || [];
                      const verifyHeader = Array.isArray(verifyData[0]) ? verifyData[0] : [];
                      if(verifyHeader[layout.yCol] === value) {
                        updateSuccessful = true;
                        scatterLog('Undo sync - Successfully updated with setDataAtCell');
                      }
                    } catch(err) {
                      scatterLog('Undo sync - setDataAtCell failed:', err.message);
                    }
                    
                    // Approach 2: Direct data manipulation if setDataAtCell failed
                    if(!updateSuccessful) {
                      try {
                        const currentData = hot.getData() || [];
                        const newData = JSON.parse(JSON.stringify(currentData));
                        
                        if(Array.isArray(newData[0]) && layout.yCol >= 0 && layout.yCol < newData[0].length) {
                          newData[0][layout.yCol] = value;
                          
                          // Try different update methods
                          if(typeof hot.setData === 'function') {
                            hot.setData(newData);
                            scatterLog('Undo sync - Used setData method');
                          } else if(typeof hot.updateSettings === 'function') {
                            hot.updateSettings({ data: newData });
                            scatterLog('Undo sync - Used updateSettings method');
                          } else if(typeof hot.gridApi?.setRowData === 'function') {
                            hot.gridApi.setRowData(newData);
                            scatterLog('Undo sync - Used gridApi.setRowData method');
                          }
                          
                          // Verify the update
                          const verifyData = hot.getData() || [];
                          const verifyHeader = Array.isArray(verifyData[0]) ? verifyData[0] : [];
                          if(verifyHeader[layout.yCol] === value) {
                            updateSuccessful = true;
                            scatterLog('Undo sync - Successfully updated with direct manipulation');
                          }
                        }
                      } catch(err) {
                        console.error('Undo sync - Direct manipulation failed:', err);
                      }
                    }
                    
                    if(!updateSuccessful) {
                      console.error('Undo sync - Failed to update y-axis header in table');
                    }
                  }
                }
              } catch(err) {
                console.error('Failed to sync y-axis header during undo:', err);
              }
            } else {
              console.error('Undo sync - HOT instance or setDataAtCell not available');
            }
            
            // Force a redraw to ensure consistency
            if(typeof scheduleDrawScatter === 'function'){
              scheduleScatterViewRefresh('y-axis-undo-sync');
            }
            
            scatterLog('Undo sync - Completed y-axis update');
            return true;
          };
          
          applyBoth(nextValue);
          recordScatterChange('scatter:y-label',previous,nextValue,applyBoth);
          
          // IMMEDIATE DEBUG: Check if this function is being called
          scatterLog('Y-AXIS EDIT HANDLER CALLED!', { previous, nextValue });
          
          // Update the table header to make the change permanent
          const hot = scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
          scatterLog('HOT instance:', hot, 'scatterRefs.hot:', scatterRefs.hot);
          
          if(hot && typeof hot.setDataAtCell === 'function'){
            try {
              scatterLog('Attempting to update table header...');
              const data = hot.getData() || [];
              scatterLog('Table data:', data);
              
              if(!Array.isArray(data) || data.length === 0) {
                console.warn('No table data available for y-axis header update');
                return;
              }
              
              const headerRow = Array.isArray(data[0]) ? data[0] : [];
              scatterLog('Header row:', headerRow);
              
              if(!Array.isArray(headerRow) || headerRow.length === 0) {
                console.warn('No header row available for y-axis header update');
                return;
              }
              
              const layout = resolveScatterColumnLayout(data);
              scatterLog('Column layout:', layout);
              
              if(!layout || !Number.isInteger(layout.yCol)) {
                console.warn('Invalid column layout for y-axis:', layout);
                return;
              }
              
              if(layout.yCol < 0 || layout.yCol >= headerRow.length) {
                console.warn('Y-axis column index out of bounds:', { index: layout.yCol, headerLength: headerRow.length });
                return;
              }
              
              scatterLog('Updating y-axis header:', { 
                row: 0, 
                col: layout.yCol, 
                oldValue: headerRow[layout.yCol], 
                newValue: nextValue 
              });
              
              // Try multiple approaches to update the cell
              let updateSuccessful = false;
              
              // Approach 1: Try the original setDataAtCell
              try {
                const result = hot.setDataAtCell([0, layout.yCol, nextValue], 'scatter-y-axis-edit');
                scatterLog('setDataAtCell result:', result);
                
                // Check if the update worked
                const updatedData1 = hot.getData() || [];
                const updatedHeader1 = Array.isArray(updatedData1[0]) ? updatedData1[0] : [];
                if(updatedHeader1[layout.yCol] === nextValue) {
                  updateSuccessful = true;
                  scatterLog('Update successful with setDataAtCell');
                }
              } catch(err) {
                scatterLog('setDataAtCell failed, trying alternative approach:', err.message);
              }
              
              // Approach 2: If setDataAtCell didn't work, try updating the data directly
              if(!updateSuccessful) {
                try {
                  const currentData = hot.getData() || [];
                  const newData = JSON.parse(JSON.stringify(currentData)); // Deep clone
                  
                  if(Array.isArray(newData[0]) && layout.yCol >= 0 && layout.yCol < newData[0].length) {
                    newData[0][layout.yCol] = nextValue;
                    
                    // Try different AG Grid update methods
                    if(typeof hot.setData === 'function') {
                      hot.setData(newData);
                      scatterLog('Used setData method');
                    } else if(typeof hot.updateSettings === 'function') {
                      hot.updateSettings({ data: newData });
                      scatterLog('Used updateSettings method');
                    } else if(typeof hot.gridApi?.setRowData === 'function') {
                      hot.gridApi.setRowData(newData);
                      scatterLog('Used gridApi.setRowData method');
                    } else {
                      console.warn('No suitable update method found');
                    }
                    
                    // Verify the update
                    const updatedData2 = hot.getData() || [];
                    const updatedHeader2 = Array.isArray(updatedData2[0]) ? updatedData2[0] : [];
                    if(updatedHeader2[layout.yCol] === nextValue) {
                      updateSuccessful = true;
                      scatterLog('Update successful with direct data manipulation');
                    }
                  }
                } catch(err) {
                  console.error('Direct data manipulation failed:', err);
                }
              }
              
              // Final verification
              const finalData = hot.getData() || [];
              const finalHeader = Array.isArray(finalData[0]) ? finalData[0] : [];
              scatterLog('Final header row:', finalHeader);
              scatterLog('Header at yCol after all attempts:', finalHeader[layout.yCol]);
              
              if(finalHeader[layout.yCol] === nextValue) {
                scatterLog('SUCCESS: Y-axis header updated to:', nextValue);
              } else {
                console.error('FAILED: Y-axis header still shows:', finalHeader[layout.yCol]);
              }
              
              // Force a redraw to ensure the changes are reflected
              if(typeof scheduleDrawScatter === 'function'){
                setTimeout(() => scheduleScatterViewRefresh('y-axis-header-update'), 100);
              }
              
            } catch(err) {
              console.error('Failed to update table header for y-axis:', err);
            }
          } else {
            console.error('HOT instance or setDataAtCell function not available!');
          }
        });
        // Enable drag for y-axis label
        if(typeof Shared.enableLabelDrag === 'function'){
          Shared.enableLabelDrag(yText, svg, {
            onDragEnd: pos => {
              // Store both absolute and relative positions
              const relX = (pos.x - margin.left) / yLabelOffsetSpan;
              const relY = (pos.y - margin.top) / plotH;
              scatterLabelPositions.yLabel = { 
                x: pos.x, 
                y: pos.y,
                relX: relX, 
                relY: relY 
              };
              console.debug('Debug: scatter y-label position saved', { absolute: pos, relative: { relX, relY } });
            }
          });
        }
        const defaultTitleX = margin.left+plotW/2;
        const defaultTitleY = margin.top/2;
        const titlePos = scatterLabelPositions?.title;
        
        // Convert relative positions to absolute if needed
        let absoluteTitleX = defaultTitleX;
        let absoluteTitleY = defaultTitleY;
        if (titlePos) {
          if (titlePos.relX !== undefined && titlePos.relY !== undefined) {
            // Use relative positioning
            absoluteTitleX = margin.left + titlePos.relX * plotW;
            absoluteTitleY = margin.top + titlePos.relY * plotH;
          } else if (titlePos.x !== undefined && titlePos.y !== undefined) {
            // Use absolute positioning (backward compatibility)
            absoluteTitleX = titlePos.x;
            absoluteTitleY = titlePos.y;
          }
        }
        
        const titleText=add('text',{x: absoluteTitleX, y: absoluteTitleY,'text-anchor':'middle','font-size':fs,fill:chartStyle.TEXT_COLOR});
        titleText.textContent=scatterTitleText;
        markFontEditable(titleText,'graphTitle','graphTitle');
        const applyScatterTitle=value=>{
          const nextValue=value!=null?String(value):'';
          scatterTitleText=nextValue;
          if(titleText.textContent!==nextValue){
            titleText.textContent=nextValue;
          }
          scheduleScatterViewRefresh('title-change');
        };
        makeEditableLocal(titleText,txt=>{
          const previous=scatterTitleText!=null?String(scatterTitleText):'';
          const nextValue=txt!=null?String(txt):'';
          if(previous===nextValue){
            return;
          }
          applyScatterTitle(nextValue);
          recordScatterChange('scatter:title',previous,nextValue,applyScatterTitle);
        });
        // Enable drag for title
        if(typeof Shared.enableLabelDrag === 'function'){
          Shared.enableLabelDrag(titleText, svg, {
            onDragEnd: pos => {
              // Store both absolute and relative positions
              const relX = (pos.x - margin.left) / plotW;
              const relY = (pos.y - margin.top) / plotH;
              scatterLabelPositions.title = { 
                x: pos.x, 
                y: pos.y,
                relX: relX, 
                relY: relY 
              };
              console.debug('Debug: scatter title position saved', { absolute: pos, relative: { relX, relY } });
            }
          });
        }
        if(scatterCurrentGraphType==='scatter'){
          const statsSourcePoints = groupedScatterActive
            ? points.filter(point => !point?.isGroupedReplicatePoint)
            : points;
          const statsPoints=statsSourcePoints.map(p=>({
            label:p.label,
            series:p.series || p.label || '',
            pointName:p.pointName || p.label || '',
            x:p.x,
            y:p.y
          }));
          const groupedStatsSeries = groupedScatterActive
            ? Array.from(statsPoints.reduce((acc, point) => {
                const rawLabel = point?.series != null && String(point.series).trim() !== ''
                  ? String(point.series).trim()
                  : (point?.label != null && String(point.label).trim() !== ''
                    ? String(point.label).trim()
                    : '');
                if(!rawLabel){
                  return acc;
                }
                if(!acc.has(rawLabel)){
                  acc.set(rawLabel, []);
                }
                acc.get(rawLabel).push(point);
                return acc;
              }, new Map()).entries())
              .map(([label, groupPoints]) => ({ label, points: groupPoints.slice() }))
            : [];
          const statsPointSummary=summarizeScatterPoints(statsPoints);
          const groupedSignatureSeed = groupedStatsSeries.length
            ? buildScatterGroupedSignatureSeed(groupedStatsSeries)
            : '';
          const statsPayloadBase={
            graphType:'scatter',
            tabId: resolveScatterTabId(scatterHot),
            points:statsPoints,
            pointSummary:statsPointSummary,
            domain:{ minX:xMin, maxX:xMax },
            groupedSeries: groupedStatsSeries,
            thresholds:null,
            significance:null,
            precomputedStats:null,
            precomputedSignature:null,
            signatureSeed: groupedSignatureSeed || null
          };
          const nextStatsSignature=buildScatterStatsSignature(statsPayloadBase);
          const cachedStatsResult = (cachedVisualStatsSignature === nextStatsSignature)
            ? {
                signature: cachedVisualStatsSignature,
                stats: cachedVisualStats,
                controlSignature: cachedVisualStatsControlSignature
              }
            : resolveScatterCachedVisualStatsForContext(statsPayloadBase);
          let visualStats=cachedStatsResult.stats;
          if(visualStats){
            statsPayloadBase.precomputedStats=visualStats;
            statsPayloadBase.precomputedSignature=cachedStatsResult.controlSignature || getScatterStatsControlSignature();
            if(cachedStatsResult.signature === nextStatsSignature){
              scatterDebug('Debug: scatter stats restored from signature cache', {
                signature: nextStatsSignature,
                groupedSeries: Array.isArray(visualStats?.groupedSeriesStats) ? visualStats.groupedSeriesStats.length : 0
              });
            }
          }
          if(visualStats?.regression){
            scatterLastRegressionSummary = typeof regressionTools.createSummary === 'function'
              ? regressionTools.createSummary(visualStats.regression)
              : null;
          }else if(Array.isArray(visualStats?.groupedSeriesStats) && visualStats.groupedSeriesStats.length){
            scatterLastRegressionSummary = {
              grouped: true,
              series: visualStats.groupedSeriesStats.map((entry, idx) => ({
                label: entry?.label || `Series ${idx + 1}`,
                summary: entry?.stats?.regression?.summary || null
              }))
            };
          }else{
            scatterLastRegressionSummary = null;
          }
          const groupedVisualSeriesStats = Array.isArray(visualStats?.groupedSeriesStats)
            ? visualStats.groupedSeriesStats
            : [];
          const regressionVisualEntries = groupedVisualSeriesStats.length
            ? groupedVisualSeriesStats.map((entry, idx) => {
                const label = (entry?.label != null && String(entry.label).trim() !== '')
                  ? String(entry.label).trim()
                  : `Series ${idx + 1}`;
                const fallbackColor = DEFAULT_SCATTER_COLORS[idx % Math.max(1, DEFAULT_SCATTER_COLORS.length)] || '#d00';
                return {
                  label,
                  color: scatterLabelColors[label] || fallbackColor,
                  stats: entry?.stats || null,
                  regressionModel: entry?.stats?.regression || null
                };
              })
            : (visualStats?.regression
              ? [{
                  label: '',
                  color: getScatterOverlayStyle('trend')?.color || '#d00',
                  stats: visualStats,
                  regressionModel: visualStats.regression
                }]
              : []);
          const shouldRenderTrend = showLine && regressionVisualEntries.length > 0;
          const shouldRenderStatsOverlay = showLineStats && visualStats;
          if(shouldRenderTrend){
            const showLineMaster = !!(scatterShowLine && scatterShowLine.checked);
            const drawCI = !!(showLineMaster && scatterShowCI && scatterShowCI.checked);
            const drawPI = !!(showLineMaster && scatterShowPI && scatterShowPI.checked);
            regressionVisualEntries.forEach((entry, entryIndex) => {
              const regressionModel = entry?.regressionModel || null;
              if(!regressionModel){
                debug('Debug: scatter regression trend omitted',{ showLine, label: entry?.label || null, hasModel: false });
                return;
              }
              const trendStyle = getScatterOverlayStyle('trend');
              const trendColor = entry?.color || trendStyle?.color || '#d00';
              const intervalSamplesRaw = Array.isArray(regressionModel.intervals?.samples) ? regressionModel.intervals.samples.slice() : [];
              const intervalSamples = intervalSamplesRaw.sort((a,b)=> (a?.x ?? 0) - (b?.x ?? 0));
              const intervalLayer = ((drawCI || drawPI) && intervalSamples.length >= 2) ? document.createElementNS(NS,'g') : null;
              if(intervalLayer){
                intervalLayer.setAttribute('data-layer','interval-bands');
                if(entry?.label){
                  intervalLayer.setAttribute('data-series', entry.label);
                }
                svg.appendChild(intervalLayer);
                const buildIntervalPath = (lowerKey, upperKey) => {
                  const upperPoints=[];
                  const lowerPoints=[];
                  intervalSamples.forEach(sample => {
                    const xRaw = sample?.x;
                    const upperRaw = sample?.[upperKey];
                    const lowerRaw = sample?.[lowerKey];
                    if(!Number.isFinite(xRaw) || !Number.isFinite(upperRaw) || !Number.isFinite(lowerRaw)){
                      return;
                    }
                    if(logX && xRaw <= 0){
                      return;
                    }
                    if(logY && (upperRaw <= 0 || lowerRaw <= 0)){
                      return;
                    }
                    const xVal = logX ? Math.log10(xRaw) : xRaw;
                    const upperVal = logY ? Math.log10(upperRaw) : upperRaw;
                    const lowerVal = logY ? Math.log10(lowerRaw) : lowerRaw;
                    if(!Number.isFinite(xVal) || !Number.isFinite(upperVal) || !Number.isFinite(lowerVal)){
                      return;
                    }
                    upperPoints.push({ x: x2px(xVal), y: y2px(upperVal) });
                    lowerPoints.push({ x: x2px(xVal), y: y2px(lowerVal) });
                  });
                  if(upperPoints.length < 2 || lowerPoints.length < 2){
                    return null;
                  }
                  const commands=[];
                  upperPoints.forEach((pt, idx)=>{
                    commands.push(`${idx?'L':'M'}${pt.x},${pt.y}`);
                  });
                  lowerPoints.slice().reverse().forEach(pt=>{
                    commands.push(`L${pt.x},${pt.y}`);
                  });
                  commands.push('Z');
                  return commands.join(' ');
                };
                const confidencePath = drawCI ? buildIntervalPath('ciLow','ciHigh') : null;
                const predictionPath = drawPI ? buildIntervalPath('piLow','piHigh') : null;
                const confidenceStyle = getScatterOverlayStyle('confidence');
                const predictionStyle = getScatterOverlayStyle('prediction');
                const confidenceColor = (confidenceStyle?.linkColorToTrend === true)
                  ? trendColor
                  : (confidenceStyle?.color || trendColor || '#d62728');
                const predictionColor = (predictionStyle?.linkColorToTrend === true)
                  ? trendColor
                  : (predictionStyle?.color || trendColor || '#d62728');
                if(confidencePath){
                  const confEl=document.createElementNS(NS,'path');
                  confEl.setAttribute('d',confidencePath);
                  confEl.setAttribute('fill',confidenceColor);
                  confEl.setAttribute('fill-opacity',String(1 - ((confidenceStyle?.transparency ?? 85) / 100)));
                  const confidenceThickness = Number(confidenceStyle?.thickness);
                  if(Number.isFinite(confidenceThickness) && confidenceThickness > 0){
                    confEl.setAttribute('stroke',confidenceColor);
                    confEl.setAttribute('stroke-width',String(confidenceThickness));
                    confEl.setAttribute('stroke-opacity',String(1 - ((confidenceStyle?.transparency ?? 85) / 100)));
                    const confidenceDash = scatterOverlayPatternToDasharray(confidenceStyle?.pattern, confidenceThickness);
                    if(confidenceDash){
                      confEl.setAttribute('stroke-dasharray', confidenceDash);
                    }else{
                      confEl.removeAttribute('stroke-dasharray');
                    }
                  }else{
                    confEl.setAttribute('stroke','none');
                  }
                  confEl.dataset.band='confidence';
                  confEl.dataset.scatterOverlay='confidence';
                  intervalLayer.appendChild(confEl);
                  registerScatterOverlayControlElement(confEl, 'confidence');
                }
                if(predictionPath){
                  const predEl=document.createElementNS(NS,'path');
                  predEl.setAttribute('d',predictionPath);
                  predEl.setAttribute('fill',predictionColor);
                  predEl.setAttribute('fill-opacity',String(1 - ((predictionStyle?.transparency ?? 92) / 100)));
                  const predictionThickness = Number(predictionStyle?.thickness);
                  if(Number.isFinite(predictionThickness) && predictionThickness > 0){
                    predEl.setAttribute('stroke',predictionColor);
                    predEl.setAttribute('stroke-width',String(predictionThickness));
                    predEl.setAttribute('stroke-opacity',String(1 - ((predictionStyle?.transparency ?? 92) / 100)));
                    const predictionDash = scatterOverlayPatternToDasharray(predictionStyle?.pattern, predictionThickness);
                    if(predictionDash){
                      predEl.setAttribute('stroke-dasharray', predictionDash);
                    }else{
                      predEl.removeAttribute('stroke-dasharray');
                    }
                  }else{
                    predEl.setAttribute('stroke','none');
                  }
                  predEl.dataset.band='prediction';
                  predEl.dataset.scatterOverlay='prediction';
                  intervalLayer.appendChild(predEl);
                  registerScatterOverlayControlElement(predEl, 'prediction');
                }
                debug('Debug: scatter interval shading rendered', {
                  sampleCount: intervalSamples.length,
                  hasConfidence: !!confidencePath,
                  hasPrediction: !!predictionPath,
                  label: entry?.label || null
                });
              }
              const sampleCount = regressionModel.mode === 'linear' ? 60 : 160;
              const precomputedSamples = Array.isArray(entry?.stats?.curveSamples)
                ? entry.stats.curveSamples
                : (Array.isArray(regressionModel?.curveSamples) ? regressionModel.curveSamples : null);
              const domainMinX = Number.isFinite(regressionModel?.domain?.minX) ? regressionModel.domain.minX : xMin;
              const domainMaxX = Number.isFinite(regressionModel?.domain?.maxX) ? regressionModel.domain.maxX : xMax;
              const samples = (precomputedSamples && precomputedSamples.length)
                ? precomputedSamples.slice().sort((a,b)=> (a?.x ?? 0) - (b?.x ?? 0))
                : (typeof regressionTools.sampleCurve === 'function'
                  ? regressionTools.sampleCurve(regressionModel,{ minX: domainMinX, maxX: domainMaxX, sampleCount })
                  : []);
              const pathCommands = [];
              samples.forEach((sample) => {
                if(!Number.isFinite(sample.x) || !Number.isFinite(sample.y)) return;
                if(logX && sample.x <= 0) return;
                if(logY && sample.y <= 0) return;
                const xVal = logX ? Math.log10(sample.x) : sample.x;
                const yVal = logY ? Math.log10(sample.y) : sample.y;
                if(!Number.isFinite(xVal) || !Number.isFinite(yVal)) return;
                const command = `${pathCommands.length?'L':'M'}${x2px(xVal)},${y2px(yVal)}`;
                pathCommands.push(command);
              });
              if(pathCommands.length>1){
                const rawTrendThickness = Number(trendStyle?.thickness);
                const trendThickness = Number.isFinite(rawTrendThickness) ? Math.max(0, rawTrendThickness) : 1.5;
                const strokeWidth=chartStyle.scaleStrokeWidth(trendThickness, styleScaleInfo, { context: 'scatter-trend', min: 0 });
                const trendOpacity = 1 - ((trendStyle?.transparency ?? 0) / 100);
                const path=add('path',{
                  d:pathCommands.join(' '),
                  fill:'none',
                  stroke: trendColor,
                  'stroke-width': strokeWidth,
                  'stroke-opacity': String(Math.min(1, Math.max(0, trendOpacity)))
                });
                const trendDash = scatterOverlayPatternToDasharray(trendStyle?.pattern, strokeWidth);
                if(trendDash){
                  path.setAttribute('stroke-dasharray', trendDash);
                }else{
                  path.removeAttribute('stroke-dasharray');
                }
                path.setAttribute('vector-effect','non-scaling-stroke');
                path.dataset.scatterOverlay='trend';
                if(entry?.label){
                  path.setAttribute('data-series', entry.label);
                }
                registerScatterOverlayControlElement(path, 'trend');
                debug('Debug: scatter regression path drawn',{ mode: regressionModel.mode, label: entry?.label || null, entryIndex, commandCount: pathCommands.length, strokeWidth });
              }else{
                debug('Debug: scatter regression path skipped',{ mode: regressionModel.mode, label: entry?.label || null, pathCommands: pathCommands.length });
              }
            });
          }else{
            if(showLine && !visualStats){
              debug('Debug: scatter regression trend omitted',{ showLine, reason:'stats-not-computed' });
            }
          }
          if(shouldRenderStatsOverlay){
            const infoLines=[];
            if(regressionVisualEntries.length){
              regressionVisualEntries.forEach((entry, idx) => {
                const entryStats = entry?.stats || {};
                const regressionModel = entry?.regressionModel || null;
                const prefix = entry?.label ? `${entry.label}: ` : '';
                if(regressionModel?.summary?.equation){
                  infoLines.push(`${prefix}${regressionModel.summary.equation}`);
                }else if(Number.isFinite(entryStats?.m) && Number.isFinite(entryStats?.b)){
                  const eq=`y=${entryStats.m.toFixed(2)}x${entryStats.b>=0?'+':'-'}${Math.abs(entryStats.b).toFixed(2)}`;
                  infoLines.push(`${prefix}${eq}`);
                }
                const associationMethod = inferScatterAssociationMethod(entryStats);
                if(associationMethod === 'none'){
                  infoLines.push(`${prefix}R²=${formatMetricValue(entryStats?.r2,2)}`);
                }else{
                  infoLines.push(`${prefix}r=${formatMetricValue(entryStats?.r,2)} R²=${formatMetricValue(entryStats?.r2,2)} p=${formatP(entryStats?.p)}`);
                }
                if(idx < regressionVisualEntries.length - 1){
                  infoLines.push(' ');
                }
              });
            }else if(visualStats?.regression?.summary?.equation){
              infoLines.push(visualStats.regression.summary.equation);
              const associationMethod = inferScatterAssociationMethod(visualStats);
              if(associationMethod === 'none'){
                infoLines.push(`R²=${formatMetricValue(visualStats.r2,2)}`);
              }else{
                infoLines.push(`r=${formatMetricValue(visualStats.r,2)} R²=${formatMetricValue(visualStats.r2,2)} p=${formatP(visualStats.p)}`);
              }
            }
            const statsFontSize = Math.max(Math.round(fs * 0.65), 7);
            const statsPos = scatterLabelPositions?.stats || null;
            const defaultInfoX=margin.left+plotW-4;
            const primarySlope = Number.isFinite(regressionVisualEntries?.[0]?.stats?.m)
              ? regressionVisualEntries[0].stats.m
              : (Number.isFinite(visualStats?.m) ? visualStats.m : 0);
            const slopeCandidate=Number.isFinite(primarySlope)?primarySlope:0;
            const defaultInfoY=slopeCandidate>=0?margin.top+plotH-(fs*2):margin.top+fs*2;
            const infoX=Number.isFinite(statsPos?.x)?statsPos.x:defaultInfoX;
            const infoY=Number.isFinite(statsPos?.y)?statsPos.y:defaultInfoY;
            const infoText=add('text',{x:infoX,y:infoY,'text-anchor':'start','font-size':statsFontSize,fill:'#000'});
            infoLines.forEach((line,lineIdx)=>{
              const t=document.createElementNS(NS,'tspan');
              t.setAttribute('dy',lineIdx===0?0:statsFontSize);
              t.setAttribute('x', String(infoX));
              t.textContent=line;
              infoText.appendChild(t);
            });
            if(typeof Shared.enableLabelDrag === 'function'){
              Shared.enableLabelDrag(infoText, svg, {
                syncChildX: true,
                onDragEnd: pos => {
                  scatterLabelPositions.stats = { x: pos.x, y: pos.y };
                  console.debug('Debug: scatter stats overlay position saved', pos);
                }
              });
            }
            info('scatter stats (visual)',{ stats: visualStats, regressionSummary: scatterLastRegressionSummary });
          }else if(showLineStats && !visualStats){
            debug('Debug: scatter stats overlay omitted',{ reason:'stats-not-computed' });
          }
          statsContextPayload=statsPayloadBase;
        }else{
          scatterLastRegressionSummary=null;
          const totalPoints=points.length;
          const nonSigCount=totalPoints-significantCount;
          const negLabel=scatterCurrentGraphType==='ma' ? (extraLabelRaw && String(extraLabelRaw).trim() ? `-log10(${String(extraLabelRaw).trim()})` : '-log10(p-value)') : scatterYLabelText;
          statsContextPayload={
            graphType:scatterCurrentGraphType,
            tabId: resolveScatterTabId(scatterHot),
            points:[],
            pointSummary:null,
            domain:null,
            thresholds:{
              log2fc:log2fcThreshold,
              negLogP:negLogPThreshold,
              negLabel
            },
            significance:{
              totalPoints,
              significantCount,
              nonSignificantCount:nonSigCount,
              log2fcThreshold,
              negLogPThreshold,
              missingP:maMissingPCount,
              negLabel
            },
            precomputedStats:null,
            precomputedSignature:null,
            signatureSeed:[
              totalPoints,
              significantCount,
              nonSigCount,
              log2fcThreshold,
              negLogPThreshold,
              maMissingPCount,
              negLabel
            ].join('|')
          };
          debug('Debug: scatter significance summary',{graphType:scatterCurrentGraphType,significantCount,nonSigCount,log2fcThreshold,negLogPThreshold,missingP:maMissingPCount});
        }
        primeScatterStatsContext(statsContextPayload);
        const viewportPerf = perfApi?.start('scatter.viewport.sync', {
          component: 'scatter',
          token
        });
        registerScatterGridControlTarget(svg, { fallbackThickness: axisStrokeWidthBase });
        ensureGraphViewport(svg, { padding: Math.max(fs, 16), debugLabel: 'scatter-graph' });
        if(perfApi && viewportPerf){
          perfApi.end(viewportPerf, { component: 'scatter', token });
        }
        commitScatterSvg();
        const panelSyncPerf = perfApi?.start('scatter.layout.syncPanels', {
          component: 'scatter',
          token,
          reason: drawOptions?.reason || null,
          viewOnly
        });
        scatterLayout?.syncPanels?.({ skipSchedule: true });
        if(perfApi && panelSyncPerf){
          perfApi.end(panelSyncPerf, {
            component: 'scatter',
            token,
            reason: drawOptions?.reason || null,
            viewOnly
          });
        }
        info('scatter render complete with enhanced styles');
        } finally {
          scatterState.lastDrawMeta = {
            graphType: scatterCurrentGraphType,
            viewMode: scatterState.viewMode,
            xLabelText: scatterState.xLabelText,
            yLabelText: scatterState.yLabelText,
            zLabelText: scatterState.zLabelText
          };
          endDrawPerf({ component: 'scatter', token });
        }
      }
      const mergeScatterDrawOptions = (prev, next) => {
        if(!prev){
          return next ? { ...next } : {};
        }
        if(!next){
          return { ...prev };
        }
        const prevView = !!prev.viewOnly;
        const nextView = !!next.viewOnly;
        return {
          ...prev,
          ...next,
          force: !!(prev.force || next.force),
          viewOnly: prevView && nextView,
          reason: next.reason || prev.reason
        };
      };

      const runScatterDrawCycle = async (opts = {}) => {
        const nextOpts = normalizeScatterSessionOptions(opts || {});
        if(!isCurrentScatterSessionMeta(nextOpts.__workspaceSessionMeta)){
          scatterDebug('Debug: scatter draw skipped (stale session)', {
            tabId: nextOpts.__workspaceSessionMeta?.tabId || null,
            sessionGeneration: nextOpts.__workspaceSessionMeta?.sessionGeneration || 0,
            reason: nextOpts.reason || null
          });
          return;
        }
        if(scatterState.drawInProgress){
          scatterState.pendingDrawOpts = mergeScatterDrawOptions(scatterState.pendingDrawOpts, nextOpts);
          scatterDebug('Debug: scatter draw coalesced', { reason: nextOpts.reason || null, force: !!nextOpts.force });
          return;
        }
        if(scatterState.skipNextDraw && !nextOpts.force){
          scatterState.skipNextDraw = false;
          scatterState.skipNextDrawReason = null;
          scatterState.rotationPending = false;
          scatterState.rotationPendingLogged = false;
          resolveScatterOverlay('skipped');
          scatterDebug('Debug: scatter draw skipped (render cache)');
          return;
        }
        scatterState.drawInProgress = true;
        scatterState.activeDrawReasons = scatterState.pendingDrawReasons;
        scatterState.pendingDrawReasons = null;
        let status = 'complete';
        try{
          if(!isCurrentScatterSessionMeta(nextOpts.__workspaceSessionMeta)){
            status = 'stale';
            scatterDebug('Debug: scatter draw skipped before render (stale session)', {
              tabId: nextOpts.__workspaceSessionMeta?.tabId || null,
              sessionGeneration: nextOpts.__workspaceSessionMeta?.sessionGeneration || 0,
              reason: nextOpts.reason || null
            });
            return;
          }
          await drawScatter(nextOpts);
          if(status === 'complete'){
            scatterState.dataDirty = false;
          }
        }catch(err){
          status = 'error';
          throw err;
        }finally{
          scatterState.drawInProgress = false;
          scatterState.lastDrawAt = (global.performance && typeof global.performance.now === 'function')
            ? global.performance.now()
            : Date.now();
          resolveScatterOverlay(status);
          const pending = scatterState.pendingDrawOpts;
          scatterState.pendingDrawOpts = null;
          if(pending){
            scheduleDrawScatterRaw(pending);
          }
        }
      };
      const scheduleScatterBase = Shared.debounceFrame ? Shared.debounceFrame(runScatterDrawCycle) : runScatterDrawCycle;
      const scheduleScatterInstrumented = (opts) => {
        const nextOpts = normalizeScatterSessionOptions(opts || {});
        if(!isCurrentScatterSessionMeta(nextOpts.__workspaceSessionMeta)){
          scatterDebug('Debug: scatter schedule skipped (stale session)', {
            tabId: nextOpts.__workspaceSessionMeta?.tabId || null,
            sessionGeneration: nextOpts.__workspaceSessionMeta?.sessionGeneration || 0,
            reason: nextOpts.reason || null
          });
          return;
        }
        if(scatterState.skipNextDraw && !nextOpts.force){
          scatterState.skipNextDraw = false;
          scatterState.skipNextDrawReason = null;
          scatterState.rotationPending = false;
          scatterState.rotationPendingLogged = false;
          resolveScatterOverlay('skipped');
          scatterDebug('Debug: scatter schedule suppressed (render cache)');
          return;
        }
        if(scatterState.skipNextDraw && nextOpts.force){
          scatterState.skipNextDraw = false;
          scatterState.skipNextDrawReason = null;
        }
        const overlayReason = nextOpts.reason || (nextOpts.force ? 'force-redraw' : 'schedule');
        if(nextOpts.reason){
          if(!scatterState.pendingDrawReasons){
            scatterState.pendingDrawReasons = new Set();
          }
          scatterState.pendingDrawReasons.add(nextOpts.reason);
        }
        if(nextOpts.reason === 'x-axis-header-update' || nextOpts.reason === 'y-axis-header-update'){
          const lastMeta = scatterState.lastDrawMeta;
          if(!nextOpts.force && lastMeta
            && lastMeta.graphType === scatterCurrentGraphType
            && lastMeta.viewMode === scatterState.viewMode
            && lastMeta.xLabelText === scatterState.xLabelText
            && lastMeta.yLabelText === scatterState.yLabelText
            && lastMeta.zLabelText === scatterState.zLabelText){
            scatterDebug('Debug: scatter header-update draw skipped (no label change)', { reason: nextOpts.reason });
            return;
          }
        }
        if(nextOpts.force){
          markScatterOverlayPending(overlayReason);
          forceScatterOverlay(overlayReason, { message: 'Rendering scatter plot...' });
        }else if(!nextOpts.viewOnly){
          queueScatterOverlay(overlayReason);
        }
        const runSchedule = (runOpts) => {
          const guarded = normalizeScatterSessionOptions(runOpts || nextOpts);
          if(!isCurrentScatterSessionMeta(guarded.__workspaceSessionMeta)){
            scatterDebug('Debug: scatter delayed schedule skipped (stale session)', {
              tabId: guarded.__workspaceSessionMeta?.tabId || null,
              sessionGeneration: guarded.__workspaceSessionMeta?.sessionGeneration || 0,
              reason: guarded.reason || null
            });
            return;
          }
          scheduleScatterBase(guarded);
        };
        if(!nextOpts.force && scatterState.lastDrawAt){
          const now = (global.performance && typeof global.performance.now === 'function')
            ? global.performance.now()
            : Date.now();
          const cachedPointCount = Array.isArray(scatterState.cachedCollect?.points)
            ? scatterState.cachedCollect.points.length
            : 0;
          const cooldownMs = nextOpts.viewOnly
            ? (cachedPointCount >= SCATTER_POINT_BATCH_THRESHOLD ? 50 : 0)
            : 80;
          const elapsed = now - scatterState.lastDrawAt;
          if(cooldownMs > 0 && elapsed < cooldownMs){
            scatterState.pendingDrawOpts = mergeScatterDrawOptions(scatterState.pendingDrawOpts, nextOpts);
            if(!scatterState.drawCooldownTimer){
              const wait = Math.max(0, cooldownMs - elapsed);
              scatterState.drawCooldownTimer = (global.setTimeout || setTimeout)(() => {
                scatterState.drawCooldownTimer = null;
                const pending = scatterState.pendingDrawOpts;
                scatterState.pendingDrawOpts = null;
                runSchedule(pending || nextOpts);
              }, wait);
            }
            return;
          }
        }
        const shouldDelayForOverlay = scatterOverlayController?.isActive?.() && !nextOpts.viewOnly;
        if(shouldDelayForOverlay){
          const scheduleAfterPaint = () => {
            scatterDebug('Debug: scatter autoDraw deferred for overlay',{ reason: overlayReason });
            runSchedule(nextOpts);
          };
          if(typeof global.requestAnimationFrame === 'function'){
            global.requestAnimationFrame(scheduleAfterPaint);
          }else{
            (global.setTimeout || setTimeout)(scheduleAfterPaint, 0);
          }
          return;
        }
        runSchedule();
      };
      scheduleDrawScatterRaw = Shared.workspaceTabs?.createTabScopedScheduler
        ? Shared.workspaceTabs.createTabScopedScheduler({
            componentKey: 'scatter',
            debugLabel: 'scatter',
            scheduleRaw: scheduleScatterInstrumented
          })
        : scheduleScatterInstrumented;
      scheduleDrawScatter = scheduleDrawScatterRaw;
      scatterLayout?.setScheduleDraw?.(() => scheduleDrawScatter());
      console.debug('Debug: scatter scheduleDraw configured via Shared.debounceFrame', { guarded: true }); // Debug: scheduler setup
    
    
      function computeScatterStats(points,method,options={}){
        const debugEnabled = typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled();
        if(debugEnabled){
          console.debug('Debug: computeScatterStats',{ method, pointCount: points.length, options });
        }
        const stats = computeScatterStatsCore(points, method, options, {
          normalizeAssociationSelection: normalizeScatterAssociationSelection,
          resolveAssociationMethod: resolveScatterAssociationMethod,
          getAssociationMethodLabel: getScatterAssociationMethodLabel,
          collectPairs: collectScatterStatPairs,
          computeCorrelationStats: computeScatterCorrelationStats,
          getStatsApi: getScatterJStat,
          fitRegressionModel: fitScatterRegressionModel,
          computeDerivedRegressionStats: computeScatterDerivedRegressionStats,
          onPaired: paired => {
            if((typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()) && paired.droppedRows > 0){
              console.debug('Debug: scatter stats dropped invalid rows', {
                totalRows: paired.totalRows,
                droppedRows: paired.droppedRows,
                retainedRows: paired.count
              });
            }
          }
        });
        if(debugEnabled){
          console.debug('Debug: computeScatterStats result',{
            method: stats.method,
            r: stats.r,
            r2: stats.r2,
            p: stats.p,
            slope: stats.m,
            intercept: stats.b,
            mode: options.regressionMode || 'linear'
          });
        }
        return stats;
      }
    
  function getScatterGraphPayload(){
      const noteControl = notesState.control || null;
      const notesText = noteControl && typeof noteControl.getValue === 'function'
        ? noteControl.getValue()
        : (notesState.text || '');
      const notesOpen = noteControl && typeof noteControl.isOpen === 'function'
        ? noteControl.isOpen()
        : !!notesState.open;
      notesState.text = notesText;
      notesState.open = notesOpen;
      const axisSettings = ensureScatterAxisSettings();
      const fontStyles = exportFontStyles('scatter');
      const payloadScatterShowLine = getScatterNodeById('scatterShowLine') || scatterShowLine;
      const payloadScatterShowPlotStats = getScatterNodeById('scatterShowPlotStats') || scatterShowPlotStats;
      const payloadScatterShowCI = getScatterNodeById('scatterShowCI') || scatterShowCI;
      const payloadScatterShowPI = getScatterNodeById('scatterShowPI') || scatterShowPI;
      const payloadScatterGraphType = getScatterNodeById('scatterGraphType') || scatterGraphTypeSelect;
      const payloadScatterTableFormat = getScatterNodeById('scatterTableFormat') || scatterTableFormatSelect;
      const payloadScatterHotWrapper = getScatterNodeById('scatterHotWrapper') || scatterHotWrapper;
      const payloadScatterHotContainer = getScatterNodeById('scatterHot') || scatterHotContainer;
      const activeHot = scatterHot || scatterRefs.hot || scatter.__ensureHotForActiveTab?.();
      const activeManager = activeHot
        ? ensureScatterDataViewsForHot(activeHot, {
            wrapper: payloadScatterHotWrapper,
            container: activeHot.__scatterHostContainer || payloadScatterHotContainer
          })
        : (scatterDataViewsManager || null);
      if(activeHot){
        syncScatterActiveDataViewFromHot(activeHot, 'payload');
      }
      const dataViewsPayload = activeManager?.serialize?.({ includeData: true }) || null;
      const includeDataViews = !!(dataViewsPayload && Array.isArray(dataViewsPayload.views) && dataViewsPayload.views.length > 1);
      const persistedLabelColors = compactScatterLabelMapForPayload(scatterLabelColors, DEFAULT_SCATTER_COLORS, 'labelColors');
      const persistedLabelShapes = compactScatterLabelMapForPayload(scatterLabelShapes, SCATTER_SHAPE_DEFAULTS, 'labelShapes');
      const persistedStats = getScatterPersistedStatsSnapshot();
      const selectedRows = activeHot ? getScatterSelectedRowSet(activeHot) : null;
      return {
        type:'scatter',
        data:activeHot?.getData?.() || [],
        exclusions: activeHot?.exportExclusions?.() || Shared.hot.exportExclusions(activeHot),
        filters: activeHot?.exportFilters?.() || Shared.hot.exportFilters(activeHot),
        dataViews: includeDataViews ? dataViewsPayload : undefined,
        activeDataViewId: includeDataViews ? (dataViewsPayload?.activeViewId || null) : undefined,
        config:{
          title:scatterTitleText,
            xLabel:scatterState.xLabelText,
            yLabel:scatterState.yLabelText,
            zLabel:scatterState.zLabelText,
            axisLabelModes: normalizeScatterAxisLabelModes(scatterState.axisLabelModes, { x: 'auto', y: 'auto', z: 'auto' }),
            dotSize:scatterDotSize.value,
            dotSizeOverrideEnabled: !!scatterState.dotSizeOverrideEnabled,
            dotSizeOverrideRaw: Number.isFinite(scatterState.dotSizeOverrideRaw) ? scatterState.dotSizeOverrideRaw : null,
            fill:scatterFill.value,
            colorMode: scatterColorMode ? normalizeScatterColorMode(scatterColorMode.value) : SCATTER_DENSITY_MODE_DEFAULT,
            densityPalette: scatterDensityPalette ? normalizeScatterDensityPalette(scatterDensityPalette.value) : SCATTER_DENSITY_PALETTE_DEFAULT,
            colorScheme: scatterColorSchemeId,
            textColor: scatterTextColor,
            backgroundColor: scatterBackgroundColor,
            border:scatterBorder.value,
            borderWidth:scatterBorderWidth.value,
            alpha:scatterAlpha.value,
            labelColors: persistedLabelColors,
            labelShapes: persistedLabelShapes,
            labelStyles:{ ...scatterLabelStyles },
            overlayStyles: sanitizeScatterOverlayStylesMap(scatterOverlayStyles),
            selectedRows: selectedRows ? Array.from(selectedRows).sort((a, b) => a - b) : [],
            showGrid:scatterShowGrid.checked,
            gridStyle: getScatterGridStyle(getScatterAxisStrokeWidth()),
            showFrame:scatterShowFrame.checked,
            showLegend:scatterShowLegend ? scatterShowLegend.checked : true,
            equalAxes: scatterState.equalAxes,
            equalScaleAxes: scatterState.equalScaleAxes,
            axesVarianceScaled: scatterState.axesVarianceScaled,
            logX:scatterLogX.checked,
            logY:scatterLogY.checked,
            logPlusOneX:!!scatterState.logPlusOneX,
            logPlusOneY:!!scatterState.logPlusOneY,
            xMin:scatterXMin.value,
            xMax:scatterXMax.value,
            yMin:scatterYMin.value,
            yMax:scatterYMax.value,
            originMode:scatterOriginMode.value,
            originX:scatterOriginX.value,
            originY:scatterOriginY.value,
            showLine: !!payloadScatterShowLine?.checked,
            showPlotStats: payloadScatterShowPlotStats ? payloadScatterShowPlotStats.checked : false,
            showCI: payloadScatterShowCI ? !!payloadScatterShowCI.checked : undefined,
            showPI: payloadScatterShowPI ? !!payloadScatterShowPI.checked : undefined,
            showDiagnostics:isScatterDiagnosticsEnabled(),
            graphType:payloadScatterGraphType?.value || scatterCurrentGraphType || 'scatter',
            tableFormat: normalizeScatterTableFormat(payloadScatterTableFormat?.value || scatterTableFormat),
            replicates: clampScatterReplicateCount(scatterReplicates),
            xReplicates: !!scatterGroupedXReplicates,
            groupLabels: Array.isArray(scatterSeriesGroupLabels) ? scatterSeriesGroupLabels.slice() : [],
            showErrorBars: scatterShowErrorBars ? !!scatterShowErrorBars.checked : false,
            showGroupedReplicatePoints: scatterShowGroupedReplicates ? !!scatterShowGroupedReplicates.checked : false,
            errorBarWidth: scatterErrorBarWidth ? scatterErrorBarWidth.value : undefined,
            log2fcThreshold:scatterLog2FCThreshold?.value || '',
            negLogPThreshold:scatterNegLogPThreshold?.value || '',
            showSignificantLabels: scatterShowSignificantLabels ? !!scatterShowSignificantLabels.checked : undefined,
            regression:{
              mode: scatterRegressionMode ? (scatterRegressionMode.value || 'linear') : 'linear',
              method: scatterFitMethod ? (scatterFitMethod.value || 'ols') : 'ols',
              fitSpec: buildScatterFitSpec(),
              summary: scatterLastRegressionSummary
            },
            axis:{
              strokeWidth: axisSettings.strokeWidth,
              color: axisSettings.color,
              tickIntervalX: axisSettings.x?.tickInterval ?? null,
            tickIntervalY: axisSettings.y?.tickInterval ?? null,
            minorTicksX: axisSettings.x?.minorTicks ?? false,
            minorTicksY: axisSettings.y?.minorTicks ?? false,
            minorTickSubdivisionsX: clampMinorTickSubdivisions(axisSettings.x?.minorTickSubdivisions),
            minorTickSubdivisionsY: clampMinorTickSubdivisions(axisSettings.y?.minorTickSubdivisions),
            notationX: axisSettings.x?.notation ?? 'decimal',
            notationY: axisSettings.y?.notation ?? 'decimal',
            additionalTicks: {
              x: sanitizeScatterAxisAdditionalTicks(axisSettings.x?.additionalTicks),
              y: sanitizeScatterAxisAdditionalTicks(axisSettings.y?.additionalTicks)
            },
            brokenAxis: {
              x: {
                enabled: axisSettings.x?.brokenAxis?.enabled ?? false,
                segments: axisSettings.x?.brokenAxis?.segments ?? []
              },
              y: {
                enabled: axisSettings.y?.brokenAxis?.enabled ?? false,
                segments: axisSettings.y?.brokenAxis?.segments ?? []
              }
            }
          },
            fontStyles: fontStyles || undefined,
            viewMode: scatterState.requestedViewMode || scatterState.viewMode,
            rotation: scatterState.rotation ? {
              x: scatterState.rotation.x,
              y: scatterState.rotation.y,
              z: scatterState.rotation.z,
              quaternion: scatterState.rotation.quaternion ? {
                w: scatterState.rotation.quaternion.w,
                x: scatterState.rotation.quaternion.x,
                y: scatterState.rotation.quaternion.y,
                z: scatterState.rotation.quaternion.z
              } : null
            } : null,
            labelPositions: scatterLabelPositions || null,
            stats: {
              ...(Shared.statsReporting && typeof Shared.statsReporting.capturePanelHtml === 'function'
                ? Shared.statsReporting.capturePanelHtml(scatterStatsResults)
                : { resultsHtml: (scatterStatsResults ? (scatterStatsResults.innerHTML || '') : null), reportHtml: null }),
              lastRunVersion: Number.isFinite(scatterState.statsLastRunVersion) ? scatterState.statsLastRunVersion : 0,
              contextSignature: scatterState.statsContextSignature || null,
              contextVersion: Number.isFinite(scatterState.statsContextVersion) ? scatterState.statsContextVersion : 0,
              statType: scatterStatType ? scatterStatType.value : undefined,
              regressionMode: scatterRegressionMode ? scatterRegressionMode.value : undefined,
              fitMethod: scatterFitMethod ? scatterFitMethod.value : undefined,
              fitSpec: buildScatterFitSpec(),
              showCI: payloadScatterShowCI ? !!payloadScatterShowCI.checked : undefined,
              showPI: payloadScatterShowPI ? !!payloadScatterShowPI.checked : undefined,
              showDiagnostics: isScatterDiagnosticsEnabled(),
              precomputedStats: persistedStats.precomputedStats,
              precomputedSignature: persistedStats.precomputedSignature
            },
            notes: {
              text: notesText,
              open: notesOpen
            }
          }
        };
      }
      let scatterFileHandle=null, scatterFileName='scatter.graph';
      async function saveScatterFile(){
        console.debug('Debug: saveScatterFile invoked', { hasHandle: !!scatterFileHandle });
        if(!fileIO || typeof fileIO.saveGraphFile !== 'function'){
          console.error('saveScatterFile missing fileIO.saveGraphFile');
          return;
        }
        const result = await fileIO.saveGraphFile({
          context: 'scatter',
          fileHandle: scatterFileHandle,
          getPayload: getScatterGraphPayload,
          fileName: scatterFileName,
          downloadFileName: scatterFileName,
          setFileHandle: handle => { scatterFileHandle = handle; },
          setFileName: name => { scatterFileName = name; }
        });
        console.debug('Debug: saveScatterFile result', result);
      }
      async function saveAsScatterFile(){
        console.debug('Debug: saveAsScatterFile invoked', { currentName: scatterFileName });
        if(!fileIO || typeof fileIO.saveGraphFileAs !== 'function'){
          console.error('saveAsScatterFile missing fileIO.saveGraphFileAs');
          return;
        }
        const result = await fileIO.saveGraphFileAs({
          context: 'scatter',
          getPayload: getScatterGraphPayload,
          fileName: scatterFileName,
          downloadFileName: scatterFileName,
          setFileHandle: handle => { scatterFileHandle = handle; },
          setFileName: name => { scatterFileName = name; }
        });
        console.debug('Debug: saveAsScatterFile result', result);
      }
      async function openScatterFile(){
        console.debug('Debug: openScatterFile invoked');
        if(!fileIO || typeof fileIO.openGraphFile !== 'function'){
          console.error('openScatterFile missing fileIO.openGraphFile');
          return;
        }
        const result = await fileIO.openGraphFile({
          context: 'scatter',
          setFileHandle: handle => { scatterFileHandle = handle; },
          setFileName: name => { scatterFileName = name; },
          loadFromFile: file => loadScatterGraphFile(file),
          triggerInput: () => {
            const input = getScatterNodeById('scatterGraphFile');
            if(input){
              input.value='';
              input.click();
            }
          }
        });
        console.debug('Debug: openScatterFile result', result);
      }
      function applyScatterPayload(obj, meta = {}){
        if(!obj || typeof obj !== 'object'){
          console.error('scatter payload missing or invalid', { meta });
          return false;
        }
        if(obj.type && obj.type !== 'scatter'){
          console.error('Invalid scatter payload type', { type: obj.type, meta });
          return false;
        }
        if(meta?.flagOverlay){
          const overlayReason = meta?.overlayReason || (typeof meta?.source === 'string' ? `payload-${meta.source}` : 'payload');
          markScatterOverlayPending(overlayReason);
        }
        const skipDraw = meta?.skipDraw === true;
        const styleOnly = meta?.styleOnly === true || meta?.colorSchemeOnly === true;
        const skipDataLoad = meta?.skipDataLoad === true || styleOnly;
        const scheduleOriginal = typeof scheduleDrawScatter === 'function' ? scheduleDrawScatter : null;
        const shouldSuspendSchedule = !!(scheduleOriginal && (skipDraw || !skipDataLoad));
        if(shouldSuspendSchedule){
          scheduleDrawScatter = () => {};
        }
      try{
      const dataMatrix = Array.isArray(obj.data) ? obj.data : [];
      const serializedViews = (obj.dataViews && typeof obj.dataViews === 'object') ? obj.dataViews : null;
      const requestedActiveViewId = obj.activeDataViewId || serializedViews?.activeViewId || null;
      const manager = ensureScatterDataViewsForHot(scatterHot, {
        wrapper: scatterHotWrapper,
        container: scatterHot?.__scatterHostContainer || scatterHotContainer
      });
      if(manager){
        if(serializedViews){
          manager.deserialize(serializedViews, {
            fallbackData: dataMatrix,
            activeViewId: requestedActiveViewId,
            silent: true,
            activate: false
          });
        }else{
          manager.initialize(dataMatrix, { rawTitle: 'Raw' });
        }
      }
      const activeViewData = manager?.getActiveView?.()?.data;
      const matrixToLoad = Array.isArray(activeViewData) ? activeViewData : dataMatrix;
      const filtersToApply = obj.filters || manager?.getActiveView?.()?.filters || null;
      if(!skipDataLoad && scatterHot && typeof scatterHot.loadData === 'function'){
        scatterState.dataDirty = true;
        scatterState.cachedCollect = null;
        scatterState.cachedGeometry = null;
        scatterHot.loadData(matrixToLoad);
        if(obj.exclusions){
          scatterHot.applyExclusions?.(obj.exclusions);
        }else if(manager?.getActiveView?.()?.exclusions){
          scatterHot.applyExclusions?.(manager.getActiveView().exclusions);
        }
        if(filtersToApply){
          scatterHot.applyFilters?.(filtersToApply, { schedule: false });
        }
        ensureScatterHeaderTitles(scatterHot);
        if(isGroupedScatterModeActive()){
          normalizeScatterGroupedHeaderRow(scatterHot, { source: 'scatter-grouped-header-normalize' });
        }
        syncScatterActiveDataViewFromHot(scatterHot, 'payload-load');
      }
        const c=obj.config||{};
        const defaultStatType = normalizeScatterAssociationSelection(resolveScatterSelectDefaultValue(scatterStatType, 'auto'));
        if(scatterStatType){
          scatterStatType.value = defaultStatType;
        }
        applyScatterThemeConfig(c);
        if(c.notes && typeof c.notes === 'object'){
          notesState.text = c.notes.text == null ? '' : String(c.notes.text);
          notesState.open = !!c.notes.open;
        }else if(typeof c.notes === 'string'){
          notesState.text = c.notes;
          notesState.open = !!notesState.open;
        }else{
          notesState.text = '';
          notesState.open = false;
        }
        if(notesState.control){
          notesState.control.setValue(notesState.text);
          notesState.control.setOpen(notesState.open);
        }
        importFontStyles('scatter', c.fontStyles || null);
        if(c.title !== undefined){
          scatterTitleText = c.title != null ? String(c.title) : '';
        }
        if(c.xLabel !== undefined){
          scatterXLabelText = c.xLabel != null ? String(c.xLabel) : '';
          scatterState.xLabelText = scatterXLabelText;
        }
        if(c.yLabel !== undefined){
          scatterYLabelText = c.yLabel != null ? String(c.yLabel) : '';
          scatterState.yLabelText = scatterYLabelText;
        }
        if(c.zLabel !== undefined){
          scatterZLabelText = c.zLabel != null ? String(c.zLabel) : '';
          scatterState.zLabelText = scatterZLabelText;
        }
        if(c.axisLabelModes && typeof c.axisLabelModes === 'object'){
          scatterState.axisLabelModes = normalizeScatterAxisLabelModes(c.axisLabelModes, scatterState.axisLabelModes);
        }else if(styleOnly){
          const styleAxisModes = {};
          if(c.xLabel !== undefined){ styleAxisModes.x = 'manual'; }
          if(c.yLabel !== undefined){ styleAxisModes.y = 'manual'; }
          if(c.zLabel !== undefined){ styleAxisModes.z = 'manual'; }
          if(Object.keys(styleAxisModes).length){
            scatterState.axisLabelModes = normalizeScatterAxisLabelModes(styleAxisModes, scatterState.axisLabelModes);
          }
        }
        scatterDotSize.value=c.dotSize||scatterDotSize.value;
        scatterState.dotSizeOverrideEnabled = c.dotSizeOverrideEnabled === true;
        const restoredDotSizeOverride = Number(c.dotSizeOverrideRaw);
        scatterState.dotSizeOverrideRaw = scatterState.dotSizeOverrideEnabled && Number.isFinite(restoredDotSizeOverride)
          ? restoredDotSizeOverride
          : null;
        scatterFill.value=c.fill||scatterFill.value;
        if(scatterColorMode){
          scatterColorMode.value = normalizeScatterColorMode(c.colorMode || scatterColorMode.value);
          scatterColorModeDesired = scatterColorMode.value;
        }
        if(scatterDensityPalette){
          scatterDensityPalette.value = normalizeScatterDensityPalette(c.densityPalette || scatterDensityPalette.value);
        }
        scatterBorder.value=c.border||scatterBorder.value;
        scatterBorderWidth.value=c.borderWidth||scatterBorderWidth.value;
        scatterAlpha.value=c.alpha||0;
        scatterAlphaVal.textContent=scatterAlpha.value;
        scatterLabelColors=c.labelColors||{};
        scatterLabelStyles=c.labelStyles||{};
        scatterLabelShapes=c.labelShapes||{};
        scatterOverlayStyles=sanitizeScatterOverlayStylesMap(c.overlayStyles);
        scatterLabelCache.colorsSet = null;
        scatterLabelCache.shapesSet = null;
        scatterLabelCache.colorsValid = false;
        scatterLabelCache.shapesValid = false;
        scatterShowGrid.checked=!!c.showGrid;
        setScatterGridStyle(c.gridStyle, c.axis?.strokeWidth);
        scatterShowFrame.checked=!!c.showFrame;
        if(scatterShowLegend){
          scatterShowLegend.checked = c.showLegend !== false;
        }
        if(typeof c.equalAxes === 'boolean'){
          scatterState.equalAxes = c.equalAxes;
        }
        if(typeof c.equalScaleAxes === 'boolean'){
          scatterState.equalScaleAxes = c.equalScaleAxes;
        }
        if(typeof c.axesVarianceScaled === 'boolean'){
          scatterState.axesVarianceScaled = c.axesVarianceScaled;
        }
        if(scatterState.equalScaleAxes){
          scatterState.equalAxes = false;
          scatterState.axesVarianceScaled = false;
          console.debug('Debug: scatter axes length payload exclusivity enforced',{ kept: 'equal-scale' });
        }else if(scatterState.axesVarianceScaled && scatterState.equalAxes){
          scatterState.equalAxes = false;
          console.debug('Debug: scatter axes length payload exclusivity enforced',{ kept: 'variance' });
        }
        scatterLogX.checked=!!c.logX;
        scatterLogY.checked=!!c.logY;
        scatterState.logPlusOneX=!!c.logPlusOneX;
        scatterState.logPlusOneY=!!c.logPlusOneY;
        scatterXMin.value=c.xMin||'';
        scatterXMax.value=c.xMax||'';
        scatterYMin.value=c.yMin||'';
        scatterYMax.value=c.yMax||'';
        scatterOriginMode.value=c.originMode||scatterOriginMode.value;
        scatterOriginX.value=c.originX||'';
        scatterOriginY.value=c.originY||'';
        // If the payload requests CI/PI, ensure the trend line is enabled first
        if((c.showCI || c.showPI) && scatterShowLine){
          scatterShowLine.checked = true;
        } else {
          scatterShowLine.checked = !!c.showLine;
        }
        if(scatterShowPlotStats){
          scatterShowPlotStats.checked = typeof c.showPlotStats === 'boolean' ? c.showPlotStats : !!scatterShowLine.checked;
        }
        if(typeof c.showCI === 'boolean' && scatterShowCI){ scatterShowCI.checked = !!c.showCI; }
        if(typeof c.showPI === 'boolean' && scatterShowPI){ scatterShowPI.checked = !!c.showPI; }
        // Ensure CI/PI controls reflect enabled/disabled state after payload applied
        try{ updateCIEnabled(); }catch(e){ /* ignore if unavailable */ }
        if(scatterGraphTypeSelect && c.graphType){
          scatterGraphTypeSelect.value=c.graphType;
        }
        const storedGraphType = String(c.graphType || scatterGraphTypeSelect?.value || 'scatter').toLowerCase();
        scatterCurrentGraphType = storedGraphType;
        const storedTableFormat = normalizeScatterTableFormat(c.tableFormat || scatterTableFormat);
        const storedReplicateCount = clampScatterReplicateCount(c.replicates ?? scatterReplicates);
        const storedXReplicates = typeof c.xReplicates === 'boolean'
          ? normalizeScatterGroupedXReplicates(c.xReplicates)
          : !!scatterGroupedXReplicates;
        const storedGroupLabels = Array.isArray(c.groupLabels)
          ? c.groupLabels.map((label, idx) => sanitizeScatterGroupLabel(label, idx))
          : [];
        if(storedGroupLabels.length){
          scatterSeriesGroupLabels = storedGroupLabels.slice();
        }
        scatterGroupedXReplicates = storedXReplicates;
        if(scatterGroupedXReplicatesInput){
          scatterGroupedXReplicatesInput.checked = storedXReplicates;
        }
        scatterReplicates = storedReplicateCount;
        if(scatterReplicates > SCATTER_MIN_REPLICATES){
          scatterLastGroupedReplicateCount = Math.min(
            SCATTER_MAX_REPLICATES,
            Math.max(2, scatterReplicates)
          );
        }
        if(scatterReplicatesInput){
          scatterReplicatesInput.value = String(scatterReplicates);
        }
        const desiredTableFormat = storedGraphType === 'scatter'
          ? storedTableFormat
          : SCATTER_TABLE_FORMAT_SINGLE;
        scatterTableFormat = desiredTableFormat;
        if(scatterTableFormatSelect){
          scatterTableFormatSelect.value = desiredTableFormat;
        }
        if(scatterShowErrorBars){
          scatterShowErrorBars.checked = typeof c.showErrorBars === 'boolean' ? c.showErrorBars : false;
        }
        if(scatterShowGroupedReplicates){
          scatterShowGroupedReplicates.checked = typeof c.showGroupedReplicatePoints === 'boolean' ? c.showGroupedReplicatePoints : true;
        }
        if(scatterShowGroupedReplicates?.checked && scatterShowErrorBars){
          scatterShowErrorBars.checked = false;
        }
        if(scatterErrorBarWidth && c.errorBarWidth !== undefined && c.errorBarWidth !== null){
          scatterErrorBarWidth.value = String(c.errorBarWidth);
        }
        if(scatterLog2FCThreshold && c.log2fcThreshold!==undefined){
          scatterLog2FCThreshold.value=c.log2fcThreshold;
        }
        if(scatterNegLogPThreshold && c.negLogPThreshold!==undefined){
          scatterNegLogPThreshold.value=c.negLogPThreshold;
        }
        if(scatterShowSignificantLabels && typeof c.showSignificantLabels === 'boolean'){
          scatterShowSignificantLabels.checked = c.showSignificantLabels;
        }
        if(scatterRegressionMode && c.regression?.mode){
          scatterRegressionMode.value=c.regression.mode;
        }
        if(scatterFitMethod && c.regression?.method){
          scatterFitMethod.value=c.regression.method;
        }
        if(c.regression?.fitSpec){
          applyScatterFitSpecControls(c.regression.fitSpec);
        }
        scatterLastRegressionSummary = c.regression?.summary || null;
        if(c.rotation){
          scatterState.rotation = plot3d.createRotationState(c.rotation);
          if(typeof plot3d.normalizeRotation === 'function'){
            plot3d.normalizeRotation(scatterState.rotation);
          }
        } else {
          scatterState.rotation = plot3d.createRotationState({ x: SCATTER_3D_DEFAULTS.rotationX, y: SCATTER_3D_DEFAULTS.rotationY });
          if(typeof plot3d.normalizeRotation === 'function'){
            plot3d.normalizeRotation(scatterState.rotation);
          }
        }
        scatterState.supports3d = false;
        if(typeof c.viewMode === 'string'){
          const normalizedMode = String(c.viewMode).toLowerCase();
          let storedMode = '2d';
          if(normalizedMode === '3d'){
            storedMode = '3d';
          }else if(normalizedMode === 'bubble'){
            storedMode = 'bubble';
          }
          scatterState.supportsBubble = false;
          applyScatterViewMode(storedMode, {
            allow3d: true,
            allowBubble: true,
            skipSchedule: true,
            forceUpdate: true,
            persistRequest: true
          });
        }
        if(c.axis){
          applyScatterAxisSettings({
            strokeWidth: c.axis.strokeWidth,
            color: c.axis.color,
            tickIntervalX: c.axis.tickIntervalX ?? c.axis.xTickInterval ?? c.axis?.x?.tickInterval ?? null,
            tickIntervalY: c.axis.tickIntervalY ?? c.axis.yTickInterval ?? c.axis?.y?.tickInterval ?? null,
            minorTicksX: c.axis.minorTicksX ?? c.axis?.x?.minorTicks ?? false,
            minorTicksY: c.axis.minorTicksY ?? c.axis?.y?.minorTicks ?? false,
            minorTickSubdivisionsX: c.axis.minorTickSubdivisionsX ?? c.axis.minorSubdivisionsX ?? c.axis?.x?.minorTickSubdivisions ?? c.axis?.x?.minorSubdivisions ?? DEFAULT_MINOR_TICK_SUBDIVISIONS,
            minorTickSubdivisionsY: c.axis.minorTickSubdivisionsY ?? c.axis.minorSubdivisionsY ?? c.axis?.y?.minorTickSubdivisions ?? c.axis?.y?.minorSubdivisions ?? DEFAULT_MINOR_TICK_SUBDIVISIONS,
            notationX: c.axis.notationX ?? c.axis.axisNotationX ?? c.axis?.x?.notation ?? 'decimal',
            notationY: c.axis.notationY ?? c.axis.axisNotationY ?? c.axis?.y?.notation ?? 'decimal',
            additionalTicks: c.axis.additionalTicks,
            additionalTicksX: c.axis.additionalTicksX ?? c.axis?.x?.additionalTicks,
            additionalTicksY: c.axis.additionalTicksY ?? c.axis?.y?.additionalTicks,
            brokenAxis: c.axis.brokenAxis || {}
          });
          console.debug('Debug: scatter axis settings restored',{ axis: ensureScatterAxisSettings() });
        }
        // Restore label positions if saved
        if(c.labelPositions){
          scatterLabelPositions = {
            title: c.labelPositions.title || null,
            xLabel: c.labelPositions.xLabel || null,
            yLabel: c.labelPositions.yLabel || null,
            stats: c.labelPositions.stats || null,
            legend: c.labelPositions.legend || null
          };
        }
        // Restore previously computed statistics results (if present in payload)
        try{
          let restoredComputedStats = false;
          if(c.stats && typeof c.stats === 'object'){
            const savedHtml = c.stats.resultsHtml;
            const savedVersion = Number.isFinite(Number(c.stats.lastRunVersion)) ? Number(c.stats.lastRunVersion) : 0;
            const savedSig = typeof c.stats.contextSignature === 'string' ? c.stats.contextSignature : null;
            const savedCtxVer = Number.isFinite(Number(c.stats.contextVersion)) ? Number(c.stats.contextVersion) : 0;
            const savedStatType = typeof c.stats.statType === 'string' ? c.stats.statType : null;
            const savedRegressionMode = typeof c.stats.regressionMode === 'string' ? c.stats.regressionMode : null;
            const savedFitMethod = typeof c.stats.fitMethod === 'string' ? c.stats.fitMethod : null;
            const savedFitSpec = c.stats.fitSpec && typeof c.stats.fitSpec === 'object' ? c.stats.fitSpec : null;
            const savedShowCI = c.stats.showCI === true;
            const savedShowPI = c.stats.showPI === true;
            const savedPrecomputedStats = c.stats.precomputedStats && typeof c.stats.precomputedStats === 'object'
              ? cloneScatterStatsForPayload(c.stats.precomputedStats)
              : null;
            const savedPrecomputedSignature = typeof c.stats.precomputedSignature === 'string'
              ? c.stats.precomputedSignature
              : null;
            if(scatterStatsResults){
              if(Shared.statsReporting && typeof Shared.statsReporting.restorePanelHtml === 'function'){
                Shared.statsReporting.restorePanelHtml(scatterStatsResults, c.stats, {
                  ensureReportHost: () => ensureScatterStatsReportHost()
                });
              }else if(savedHtml != null){
                try{ scatterStatsResults.innerHTML = savedHtml; }catch(e){ scatterStatsResults.textContent = String(savedHtml || ''); }
              }
            }
            // restore control values if present
            if(savedStatType && scatterStatType){ scatterStatType.value = normalizeScatterAssociationSelection(savedStatType); }
            if(savedRegressionMode && scatterRegressionMode){ scatterRegressionMode.value = savedRegressionMode; }
            if(savedFitMethod && scatterFitMethod){ scatterFitMethod.value = savedFitMethod; }
            if(savedFitSpec){ applyScatterFitSpecControls(savedFitSpec); }
            if(typeof c.stats.showCI === 'boolean' && scatterShowCI){ scatterShowCI.checked = savedShowCI; }
            if(typeof c.stats.showPI === 'boolean' && scatterShowPI){ scatterShowPI.checked = savedShowPI; }
            if((savedShowCI || savedShowPI) && scatterShowLine){ scatterShowLine.checked = true; }

            scatterState.statsLastRunVersion = savedVersion;
            scatterState.statsContextSignature = savedSig;
            scatterState.statsContextVersion = savedCtxVer || scatterState.statsContextVersion;
            scatterState.statsContext = null;
            scatterState.statsComputationPending = false;
            const hasResults = scatterStatsPanelHasRenderedResults();
            if(hasResults && savedVersion > 0){
              scatterState.statsRestorePending = {
                contextSignature: savedSig,
                precomputedStats: savedPrecomputedStats,
                precomputedSignature: savedPrecomputedSignature,
                autoCompute: !savedPrecomputedStats
              };
              setScatterStatsStatus('Statistics up to date.');
              updateScatterStatsButtonState({ disabled:false, label:'Recalculate statistics' });
              syncScatterRegressionOptionVisibility();
              restoredComputedStats = true;
            }else{
              scatterState.statsRestorePending = null;
            }
          }
          if(!restoredComputedStats){
            resetScatterStatsRuntimeState({ placeholder: scatterStatsPlaceholder });
          }
        }catch(err){
          console.debug('Debug: scatter restore stats failed', { err: err?.message || String(err) });
          resetScatterStatsRuntimeState({ placeholder: scatterStatsPlaceholder });
        }
        syncScatterGraphTypeUI();
        syncScatterErrorBarControls(scatterTableFormat);
        const postApplyGraphTypeControl = getScatterNodeById('scatterGraphType') || global.document?.getElementById?.('scatterGraphType') || null;
        const postApplyShowLineControl = getScatterNodeById('scatterShowLine') || global.document?.getElementById?.('scatterShowLine') || null;
        const postApplyGraphType = String(c.graphType || postApplyGraphTypeControl?.value || 'scatter').toLowerCase();
        if(postApplyShowLineControl){
          const shouldShowLine = postApplyGraphType === 'scatter' && !!c.showLine;
          postApplyShowLineControl.disabled = postApplyGraphType !== 'scatter';
          postApplyShowLineControl.checked = shouldShowLine;
        }
        if(scatterHot){
          const selectedRows = Array.isArray(c.selectedRows)
            ? c.selectedRows.map(value => Number(value)).filter(value => Number.isInteger(value) && value >= 0)
            : [];
          restoreScatterSelectedRowsFromPayload(scatterHot, selectedRows, resolveScatterTabId(scatterHot));
        }
        const publicationStyleApply = typeof meta?.reason === 'string'
          && meta.reason.indexOf('publication-style-scatter') === 0;
        if(!skipDraw && scheduleOriginal){
          const scheduleMeta = normalizeScatterSessionOptions({
            tabId: meta?.tabId || null,
            sessionGeneration: meta?.sessionGeneration || 0,
            __workspaceSessionMeta: meta?.__workspaceSessionMeta || null
          });
          if(styleOnly){
            scheduleOriginal({
              ...scheduleMeta,
              viewOnly: true,
              reason: meta?.reason || 'scatter-style-payload'
            });
          }else{
            scheduleOriginal({
              ...scheduleMeta,
              reason: meta?.reason || (meta?.source ? `payload-${meta.source}` : 'payload')
            });
          }
        }
        if(publicationStyleApply){
          scheduleScatterPublicationStyleStabilization('publication-style-scatter-stabilize');
        }
        // No deferred reapply needed: stats context has been refreshed and versions set.
        scatterDebug('Debug: scatter payload applied', { source: meta.source || 'unknown', rows: dataMatrix.length });
        return true;
      }finally{
        if(shouldSuspendSchedule && scheduleOriginal){
          scheduleDrawScatter = scheduleOriginal;
        }
      }
    }

    function initNotes(){
      const stack = queryScatterRoot('#scatterGraphPanel .scatter-plot-stack')
        || queryScatterRoot('#scatterGraphPanel .diagram-area');
      if(!stack){
        if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
          console.debug('Debug: scatter notes mount skipped (missing stack)');
        }
        return;
      }
      const helper = Shared.notes;
      if(!helper || typeof helper.mountFoldable !== 'function'){
        console.warn('scatter notes helper unavailable', { hasSharedNotes: !!helper });
        return;
      }
      if(notesState.control?.root && notesState.control.root.isConnected){
        notesState.control.setValue(notesState.text || '');
        notesState.control.setOpen(!!notesState.open);
        return;
      }
      notesState.control = helper.mountFoldable({
        container: stack,
        id: 'scatter-notes',
        title: 'Notes',
        placeholder: 'Write notes about the data being analyzed...',
        richText: true,
        scopeId: 'scatter',
        fontKey: 'notes',
        value: notesState.text || '',
        open: !!notesState.open,
        onChange: value => {
          notesState.text = value == null ? '' : String(value);
        },
        onToggle: open => {
          notesState.open = !!open;
        }
      });
    }

      function loadScatterGraphFile(file){
        const reader=new FileReader();
        reader.onload=e=>{
          try{
            const obj=JSON.parse(e.target.result);
            if(!applyScatterPayload(obj, { source: 'file', flagOverlay: true, overlayReason: 'graph-file' })){
              console.warn('scatter payload rejected from file', { hasType: !!obj?.type });
            }
          }catch(err){console.error('loadScatterGraph error',err);}
        };
        reader.readAsText(file);
      }
    
      if(Shared.exporter && typeof Shared.exporter.mountSvgControls === 'function'){
        Shared.exporter.mountSvgControls({
          container: '#scatterExportControls',
          svgSelector: '#scatterSvg',
          fileName: 'scatter',
          contextLabel: 'scatter-export',
          hybridOptions: {
            label: 'SVG (points as PNG)',
            fileNameSuffix: '-light',
            layers: [
              {
                selector: '[data-export-layer="scatter-points"]',
                label: 'scatter-points',
                padding: 2,
                scale: 4
              }
            ]
          }
        });
        console.debug('Debug: scatter export controls mounted', { hasExporter: true }); // Debug: scatter export mount
      }else{
        console.debug('Debug: scatter export controls unavailable', { hasExporter: !!Shared.exporter }); // Debug: scatter export fallback
      }
      getScatterNodeById('openScatterGraph')?.addEventListener('click',openScatterFile);
      getScatterNodeById('saveScatterGraph')?.addEventListener('click',saveScatterFile);
      getScatterNodeById('saveAsScatter').addEventListener('click',saveAsScatterFile);
      getScatterNodeById('scatterGraphFile').addEventListener('change',e=>{
        const f=e.target.files[0];
        if(f){
          scatterFileName=f.name;
          scatterFileHandle=null;
          loadScatterGraphFile(f);
        }
      });
      
    scatter.save = saveScatterFile;
    scatter.saveAs = saveAsScatterFile;
    scatter.open = openScatterFile;
    scatter.loadFromFile = loadScatterGraphFile;
    scatter.loadFromPayload = function loadScatterFromPayload(payload, options = {}){
      if(!applyScatterPayload(payload, { source: 'payload', ...options })){
        console.warn('scatter payload application failed', { source: 'payload' });
      }
    };

    scatter.applyColorSchemePayload = function applyScatterColorSchemePayload(payload, options = {}){
      return applyScatterPayload(payload, {
        source: 'color-scheme',
        colorSchemeOnly: true,
        ...options
      });
    };
    scatter.getPayload = getScatterGraphPayload;
    scatter.captureEmptyPayloadTemplate = function captureScatterEmptyPayloadTemplate(){
    const snapshot = scatter.createEmptyPayload();
    console.debug('Debug: scatter empty payload template captured', { hasTemplate: !!snapshot });
    return snapshot;
  };
  scatter.restoreEmptyPayloadTemplate = function restoreScatterEmptyPayloadTemplate(template, options = {}){
    if(!template || typeof template !== 'object'){
      console.debug('Debug: scatter empty payload template restore skipped', { reason: 'invalid-template', options });
      return false;
    }
    emptyPayloadTemplate = cloneSimple(template);
    console.debug('Debug: scatter empty payload template restored', { hasTemplate: !!emptyPayloadTemplate, reason: options.reason || 'unspecified' });
    return !!emptyPayloadTemplate;
  };
  scatter.createEmptyPayload = function createEmptyScatterPayload(){
      scatter.ensure();
      const payload = { type: 'scatter', config: {} };
      payload.type = 'scatter';
      const createEmpty = Shared.createEmptyData;
      const emptyData = typeof createEmpty === 'function'
        ? createEmpty(DEFAULT_ROWS, DEFAULT_COLS)
        : Array.from({ length: DEFAULT_ROWS }, () => Array(DEFAULT_COLS).fill(''));
      if(Array.isArray(emptyData?.[0])){
        emptyData[0][0] = '';
        emptyData[0][1] = 'X title';
        emptyData[0][2] = 'Y title';
        emptyData[0][3] = 'Z title';

      }
      payload.data = emptyData;
      payload.exclusions = [];
      payload.filters = null;
      payload.series = Array.isArray(payload.series) ? [] : [];
      const defaultRegressionMode = 'linear';
      const defaultFitMethod = normalizeScatterFitMethod('ols');
      const defaultStatType = normalizeScatterAssociationSelection('auto');
      payload.config = payload.config && typeof payload.config === 'object' ? payload.config : {};
      if(typeof payload.config.colorScheme !== 'string' || !payload.config.colorScheme.trim()){
        payload.config.colorScheme = Shared.colorSchemes?.getDefaultSchemeId?.('scatter') || 'scientific';
      }
      payload.config.regression = payload.config.regression && typeof payload.config.regression === 'object'
        ? payload.config.regression
        : {};
      payload.config.regression.mode = defaultRegressionMode;
      payload.config.regression.method = defaultFitMethod;
      payload.config.regression.fitSpec = {};
      payload.config.regression.summary = null;
      payload.config.stats = payload.config.stats && typeof payload.config.stats === 'object'
        ? payload.config.stats
        : {};
      payload.config.stats.resultsHtml = null;
      payload.config.stats.reportHtml = null;
      payload.config.stats.lastRunVersion = 0;
      payload.config.stats.contextSignature = null;
      payload.config.stats.contextVersion = 0;
      payload.config.stats.statType = defaultStatType;
      payload.config.stats.regressionMode = defaultRegressionMode;
      payload.config.stats.fitMethod = defaultFitMethod;
      payload.config.stats.fitSpec = {};
      payload.config.stats.showCI = false;
      payload.config.stats.showPI = false;
      payload.config.stats.showDiagnostics = true;
      payload.config.selectedRows = [];
      payload.config.dotSizeOverrideEnabled = false;
      payload.config.dotSizeOverrideRaw = null;
      payload.config.showErrorBars = false;
      payload.config.showGroupedReplicatePoints = true;
      if(Object.prototype.hasOwnProperty.call(payload, 'stats')){
        delete payload.stats;
      }
      if(payload.meta && typeof payload.meta === 'object' && Object.prototype.hasOwnProperty.call(payload.meta, 'graphSizing')){
        delete payload.meta.graphSizing;
        if(!Object.keys(payload.meta).length){
          delete payload.meta;
        }
      }
      return payload;
    };

    scatter.serialize = serializeSvg;
    initNotes();
    ensureScatterFontEventListener();
    ensureEmptyPayloadTemplate();
    scatter.__boundTabId = Shared.hot?.resolveActiveTabId?.()
      || global.Main?.tabs?.getActiveTab?.()?.id
      || null;
    scatter.ready = true;
    console.debug('Debug: Components.scatter.setup complete');
  }

  function ensureReady(){
    if(ensureScatterDomBindings()){
      return;
    }
    if(!scatter.ready) setup();
  }

  function ensureScatterDomBindings(tabLike){
    if(typeof Shared.workspaceTabs?.ensureActiveDomBindings !== 'function'){
      return false;
    }
    const rebound = Shared.workspaceTabs.ensureActiveDomBindings({
      componentKey: 'scatter',
      tabLike: tabLike || null,
      sentinelSelector: '#scatterShowLine',
      getCurrentRoot: () => scatterRoot || null,
      getCurrentSentinel: () => scatter.__domSentinel || null,
      rebind: (info) => {
        scatterRoot = info?.root || resolveScatterRoot(tabLike || info?.tabId || null);
        console.debug('Debug: Components.scatter.setup refreshing stale DOM bindings');
        scatter.ready = false;
        setup({
          root: scatterRoot,
          tabId: info?.tabId || null,
          reason: 'workspace-dom-rebind'
        });
      }
    });
    return !!rebound?.rebound;
  }

  function syncScatterActivationControlsFromPayload(tabLike){
    const tab = (tabLike && typeof tabLike === 'object')
      ? tabLike
      : (global.Main?.session?.getActiveTab?.() || null);
    const payloadConfig = tab?.payload?.config;
    if(!payloadConfig || typeof payloadConfig !== 'object'){
      return;
    }
    const graphTypeControl = getScatterNodeById('scatterGraphType', tab);
    const showLineControl = getScatterNodeById('scatterShowLine', tab);
    const targetGraphType = String(payloadConfig.graphType || graphTypeControl?.value || 'scatter').toLowerCase();
    if(graphTypeControl && graphTypeControl.value !== targetGraphType){
      graphTypeControl.value = targetGraphType;
      graphTypeControl.dispatchEvent(new Event('change', { bubbles: true }));
    }
    const docGraphTypeControl = global.document?.getElementById?.('scatterGraphType') || null;
    if(docGraphTypeControl && docGraphTypeControl !== graphTypeControl && docGraphTypeControl.value !== targetGraphType){
      docGraphTypeControl.value = targetGraphType;
    }
    if(showLineControl){
      const shouldShowLine = targetGraphType === 'scatter' && !!payloadConfig.showLine;
      if(showLineControl.checked !== shouldShowLine){
        showLineControl.checked = shouldShowLine;
        showLineControl.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
    const docShowLineControl = global.document?.getElementById?.('scatterShowLine') || null;
    if(docShowLineControl && docShowLineControl !== showLineControl){
      const shouldShowLine = targetGraphType === 'scatter' && !!payloadConfig.showLine;
      docShowLineControl.checked = shouldShowLine;
      docShowLineControl.disabled = targetGraphType !== 'scatter';
    }
  }

  scatter.init = setup;
  scatter.ensure = ensureReady;
  scatter.computeAdaptivePointSize = computeAdaptivePointSize;
  scatter.captureRuntimeState = function captureRuntimeState(meta = {}){
    const snapshot = captureScatterRuntimeSnapshot(meta.reason || 'capture-runtime-state');
    const sessionRecord = getScatterSessionRecord(meta.tabId || Shared.hot?.resolveActiveTabId?.(), { create: true });
    if(sessionRecord){
      sessionRecord.runtime = snapshot;
    }
    return snapshot;
  };
  scatter.applyRuntimeState = function applyRuntimeState(snapshot, meta = {}){
    return applyScatterRuntimeSnapshot(snapshot, meta.reason || 'apply-runtime-state');
  };
  scatter.deactivateTab = function deactivateTab(_tab, meta = {}){
    scatterDrawToken += 1;
    clearScatterScheduledDraw(meta.reason || 'deactivate-tab');
    scatterState.drawInProgress = false;
    scatterState.statsComputationPending = false;
    scatterState.rotationPending = false;
    scatterState.rotationPendingLogged = false;
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: scatter tab deactivated', {
        reason: meta.reason || 'deactivate-tab',
        drawToken: scatterDrawToken,
        sessionGeneration: meta.sessionGeneration || 0
      });
    }
  };
  scatter.activateTab = function activateTab(tab, meta = {}){
    const targetTabId = (typeof tab === 'string' ? tab : tab?.id)
      || Shared.hot?.resolveActiveTabId?.()
      || null;
    if(targetTabId && scatter.__boundTabId && scatter.__boundTabId !== targetTabId){
      scatterRoot = resolveScatterRoot(tab || null);
      scatter.ready = false;
      setup({
        root: scatterRoot,
        tabId: targetTabId,
        reason: 'activate-tab-rebind'
      });
    }
    scatterRoot = resolveScatterRoot(tab || null);
    if(ensureScatterDomBindings(tab)){
      syncScatterActivationControlsFromPayload(tab);
      applyScatterRuntimeSnapshot(getScatterSessionRecord(tab || Shared.hot?.resolveActiveTabId?.(), { create: true })?.runtime || null, meta.reason || 'activate-tab');
      return;
    }
    syncScatterActivationControlsFromPayload(tab);
    applyScatterRuntimeSnapshot(getScatterSessionRecord(tab || Shared.hot?.resolveActiveTabId?.(), { create: true })?.runtime || null, meta.reason || 'activate-tab');
    if(!scatter.ready){
      scatter.init({
        root: scatterRoot,
        tabId: targetTabId,
        reason: meta.reason || 'activate-tab'
      });
      return;
    }
    scatterLayoutWasHidden = true;
    if(typeof scatter.__ensureHotForActiveTab === 'function'){
      scatter.__ensureHotForActiveTab();
    }
  };

  function detachChildren(node){
    if(!node){ return null; }
    const doc = node.ownerDocument || global.document;
    const fragment = doc?.createDocumentFragment ? doc.createDocumentFragment() : null;
    if(!fragment){ return null; }
    let count = 0;
    while(node.firstChild){
      fragment.appendChild(node.firstChild);
      count += 1;
    }
    return { fragment, count };
  }

  function restoreChildren(node, payload){
    if(!node || !payload || !payload.fragment){ return false; }
    while(node.firstChild){
      node.removeChild(node.firstChild);
    }
    node.appendChild(payload.fragment);
    return true;
  }

  function resolveScatterPreviewSourceSvg(tab){
    const cachedFragment = tab?.renderCache?.cache?.plot?.fragment || null;
    if(cachedFragment && typeof cachedFragment.querySelector === 'function'){
      const cachedSvg = cachedFragment.querySelector('#scatterSvg') || cachedFragment.querySelector('svg');
      if(cachedSvg){
        return cachedSvg;
      }
    }
    const plot = getScatterNodeById('scatterPlot');
    return plot?.querySelector?.('#scatterSvg') || plot?.querySelector?.('svg') || null;
  }

  scatter.getThumbnailSvg = function getThumbnailSvg(tab){
    return resolveScatterPreviewSourceSvg(tab);
  };

  scatter.captureRenderCache = function captureRenderCache(){
    const plot = getScatterNodeById('scatterPlot');
    const stats = getScatterNodeById('scatterStatsResults');
    const plotCache = detachChildren(plot);
    const statsCache = detachChildren(stats);
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      scatterDebug('Debug: scatter render cache captured', {
        plotNodes: plotCache?.count || 0,
        statsNodes: statsCache?.count || 0
      });
    }
    return { plot: plotCache, stats: statsCache };
  };

  scatter.restoreRenderCache = function restoreRenderCache(cache, meta){
    if(!cache){ return false; }
    const plot = getScatterNodeById('scatterPlot');
    const stats = getScatterNodeById('scatterStatsResults');
    const restoredPlot = restoreChildren(plot, cache.plot);
    const restoredStats = restoreChildren(stats, cache.stats);
    const restored = restoredPlot || restoredStats;
    if(restored){
      scatterState.rotationPending = false;
      scatterState.rotationPendingLogged = false;
      const svg = plot ? plot.querySelector('#scatterSvg') : null;
      if(svg && svg.dataset && svg.dataset.viewMode === '3d'){
        delete svg.dataset.rotationControlsAttached;
        plot3d.attachRotationControls(svg, {
          state: scatterState.rotation,
          onChange: () => scheduleScatterRotationRedraw(),
          shouldIgnorePointer: (event) => {
            if(typeof plot3d.isInteractivePointerTarget === 'function'){
              return plot3d.isInteractivePointerTarget(event?.target);
            }
            return plot3d.isLegendPointerTarget(event?.target);
          },
          debugLabel: 'scatter-3d-restore'
        });
        if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
          scatterDebug('Debug: scatter 3d rotation handlers rebound');
        }
      }
    }
    if(restored){
      scatterState.skipNextDraw = true;
      scatterState.skipNextDrawReason = meta?.reason || meta?.type || 'render-cache';
    }
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      scatterDebug('Debug: scatter render cache restored', {
        restored,
        plot: restoredPlot,
        stats: restoredStats
      });
    }
    return restored;
  };
  scatter.draw = function draw(options = {}){
    ensureReady();
    const drawOptions = normalizeScatterSessionOptions(options || {});
    if(scatterLayout && typeof scatterLayout.syncPanels === 'function'){
      const graphPanel = scatterLayout.elements?.graphPanel || null;
      const isVisible = !!(graphPanel && graphPanel.offsetParent !== null);
      scatterLayout.syncPanels({ skipSchedule: true });
      if(isVisible && scatterLayoutWasHidden && !scatterLayoutDeferredSync){
        scatterLayoutWasHidden = false;
        scatterLayoutDeferredSync = true;
        const scheduleSync = () => {
          scatterLayoutDeferredSync = false;
          scatterLayout?.syncPanels?.({ skipSchedule: true });
        };
        if(typeof global.requestAnimationFrame === 'function'){
          global.requestAnimationFrame(scheduleSync);
        }else{
          (global.setTimeout || setTimeout)(scheduleSync, 0);
        }
      }else if(!isVisible){
        scatterLayoutWasHidden = true;
      }
    }
    scheduleDrawScatter && scheduleDrawScatter(drawOptions);
  };

  function benchmarkScatterLoad(config){
    const points = Math.max(1, Math.floor(Number(config?.points) || 1000));
    const dims = Math.max(2, Math.floor(Number(config?.dimensions) || 2));
    const generator = typeof config?.generator === 'function'
      ? config.generator
      : ((index, dimension) => ((index * 37 + dimension * 19) % 1000) / 10);
    const perf = global.performance;
    const coords = new Array(points);
    for(let idx = 0; idx < points; idx++){
      const entry = new Array(dims);
      for(let dim = 0; dim < dims; dim++){
        entry[dim] = Number(generator(idx, dim)) || 0;
      }
      coords[idx] = entry;
    }
    const start = perf?.now ? perf.now() : Date.now();
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for(let idx = 0; idx < points; idx++){
      const entry = coords[idx];
      const x = entry[0];
      const y = entry[1] ?? 0;
      if(x < minX) minX = x;
      if(x > maxX) maxX = x;
      if(y < minY) minY = y;
      if(y > maxY) maxY = y;
    }
    const end = perf?.now ? perf.now() : Date.now();
    return {
      points,
      dimensions: dims,
      durationMs: Number((end - start).toFixed(3)),
      extent: {
        x: [minX, maxX],
        y: [minY, maxY]
      }
    };
  }

  scatter.__testHooks = Object.assign({}, scatter.__testHooks, {
    benchmarkLoad: opts => benchmarkScatterLoad(opts),
    resolveLargeDatasetPolicy: opts => resolveScatterLargeDatasetPolicy(opts || {}),
    resolveColorMode: opts => resolveScatterColorMode(opts || {}),
    getLargeDatasetRenderSummary: () => Object.assign({}, scatter.__lastLargeDatasetRenderSummary || {}, {
      renderMode: getScatterNodeById('scatterPlot')?.querySelector?.('svg [data-layer="points"]')?.getAttribute?.('data-render-mode')
        || scatter.__lastLargeDatasetRenderSummary?.renderMode
        || null
    }),
    buildAnnotationRequests: (points, options) => buildScatterAnnotationRequests(points, options),
    layoutAnnotations: params => layoutScatterAnnotations(params),
    resolveAnnotationCrowdingScale: (count, options) => resolveScatterAnnotationCrowdingScale(count, options),
    setRowSelected: (hotInstance, rowIndex, selected, options) => setScatterRowSelected(hotInstance, rowIndex, selected, options),
    toggleRowSelected: (hotInstance, rowIndex, options) => toggleScatterRowSelected(hotInstance, rowIndex, options),
    computeScatterCorrelationStats: (method, x, y) => {
      const rawMethod = String(method || 'pearson').trim().toLowerCase();
      const resolvedMethod = rawMethod === 'spearman'
        ? 'spearman'
        : (rawMethod === 'none' ? 'none' : 'pearson');
      const xs = Array.isArray(x) ? x : [];
      const ys = Array.isArray(y) ? y : [];
      const n = Math.min(xs.length, ys.length);
      const cleanX = [];
      const cleanY = [];
      for(let i = 0; i < n; i += 1){
        const xv = Number(xs[i]);
        const yv = Number(ys[i]);
        if(Number.isFinite(xv) && Number.isFinite(yv)){
          cleanX.push(xv);
          cleanY.push(yv);
        }
      }
      const count = cleanX.length;
      const jStatLib = global.jStat || global.window?.jStat || null;
      if(resolvedMethod === 'none'){
        return {
          methodCode: 'none',
          methodLabel: 'None (model fit only)',
          r: NaN,
          p: NaN,
          pMethod: 'not computed',
          ci: null,
          ciApproximate: false
        };
      }
      if(count < 3){
        return {
          methodCode: resolvedMethod,
          methodLabel: resolvedMethod === 'spearman' ? 'Spearman' : 'Pearson',
          r: NaN,
          p: NaN,
          pMethod: 'not enough data',
          ci: null,
          ciApproximate: resolvedMethod === 'spearman'
        };
      }
      const corr = (a, b) => {
        if(jStatLib && typeof jStatLib.corrcoeff === 'function'){
          return Number(jStatLib.corrcoeff(a, b));
        }
        const m = a.length;
        const meanA = a.reduce((sum, value) => sum + value, 0) / Math.max(1, m);
        const meanB = b.reduce((sum, value) => sum + value, 0) / Math.max(1, m);
        let num = 0;
        let denA = 0;
        let denB = 0;
        for(let i = 0; i < m; i += 1){
          const da = a[i] - meanA;
          const db = b[i] - meanB;
          num += da * db;
          denA += da * da;
          denB += db * db;
        }
        const denom = Math.sqrt(Math.max(0, denA * denB));
        return denom > 0 ? (num / denom) : NaN;
      };
      const pFromR = r => {
        if(!Number.isFinite(r)){
          return NaN;
        }
        const cdf = jStatLib && jStatLib.studentt && typeof jStatLib.studentt.cdf === 'function'
          ? jStatLib.studentt.cdf.bind(jStatLib.studentt)
          : null;
        if(!cdf){
          return NaN;
        }
        const bounded = Math.max(-0.999999999999, Math.min(0.999999999999, r));
        const t = bounded * Math.sqrt((count - 2) / Math.max(1e-12, 1 - (bounded * bounded)));
        return 2 * (1 - cdf(Math.abs(t), count - 2));
      };
      const toRanks = values => {
        const order = values.map((value, index) => ({ value, index })).sort((a, b) => a.value - b.value);
        const ranks = Array(values.length).fill(0);
        let i = 0;
        while(i < order.length){
          let j = i + 1;
          while(j < order.length && order[j].value === order[i].value){
            j += 1;
          }
          const avgRank = ((i + 1) + j) / 2;
          for(let k = i; k < j; k += 1){
            ranks[order[k].index] = avgRank;
          }
          i = j;
        }
        return ranks;
      };
      if(resolvedMethod === 'spearman'){
        const spearman = (jStatLib && typeof jStatLib.spearmancoeff === 'function')
          ? Number(jStatLib.spearmancoeff(cleanX, cleanY))
          : corr(toRanks(cleanX), toRanks(cleanY));
        return {
          methodCode: 'spearman',
          methodLabel: 'Spearman',
          r: spearman,
          p: pFromR(spearman),
          pMethod: 't approximation',
          ci: null,
          ciApproximate: true
        };
      }
      const pearson = corr(cleanX, cleanY);
      return {
        methodCode: 'pearson',
        methodLabel: 'Pearson',
        r: pearson,
        p: pFromR(pearson),
        pMethod: 'Student t approximation',
        ci: null,
        ciApproximate: false
      };
    },
    computeScatterStats: (points, method, options = {}) => computeScatterStatsCore(points, method, options, {
      resolveAssociationFromSelection: true,
      computeCorrelationStats: (resolvedMethod, x, y) => scatter.__testHooks.computeScatterCorrelationStats(resolvedMethod, x, y),
      fitRegressionModel: scatterFitRegressionModelForTests,
      fitDemingRegression: scatterFitDemingRegressionForTests,
      fitLowessRegression: typeof scatterFitLowessRegressionForTests === 'function'
        ? scatterFitLowessRegressionForTests
        : fitScatterLowessRegressionCore,
      computeDerivedRegressionStats: typeof computeScatterDerivedRegressionStats === 'function'
        ? computeScatterDerivedRegressionStats
        : null
    }),
    fitScatterLowessRegression: (points, options = {}) => fitScatterLowessRegressionCore(
      Array.isArray(points) ? points : [],
      options || {}
    ),
    constants: Object.assign({}, scatter.__testHooks?.constants, {
      MAX_SIGNIFICANT_ANNOTATIONS
    })
  });

})(window);

