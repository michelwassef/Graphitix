const fs = require('fs');
const path = require('path');

const KNOWN_NON_FATAL_LOG_PATTERNS = [
  /AG Grid: invalid gridOptions property 'columnBuffer'/i,
  /AG Grid: to see all the valid gridOptions properties/i,
  /AG Grid: The return of `getRowHeight` cannot be zero/i,
  /exporter clipboard write error .*Write permission denied/i,
  /The Components object is deprecated\./i
];

const CDN_OVERRIDE_ENTRIES = [
  {
    match: /\/(?:npm\/)?ag-grid-community@32\.3\.3\/styles\/ag-grid\.css$/i,
    localPath: path.resolve(__dirname, '../../libs/ag-grid-community/ag-grid.css'),
    contentType: 'text/css; charset=utf-8'
  },
  {
    match: /\/(?:npm\/)?ag-grid-community@32\.3\.3\/styles\/ag-theme-balham\.css$/i,
    localPath: path.resolve(__dirname, '../../libs/ag-grid-community/ag-theme-balham.css'),
    contentType: 'text/css; charset=utf-8'
  },
  {
    match: /\/(?:npm\/)?ag-grid-community@32\.3\.3\/dist\/ag-grid-community\.min\.noStyle\.js$/i,
    localPath: path.resolve(__dirname, '../../libs/ag-grid-community/ag-grid-community.min.noStyle.js'),
    contentType: 'text/javascript; charset=utf-8'
  },
  {
    match: /\/(?:npm\/)?jstat@1\.9\.5\/dist\/jstat\.min\.js$/i,
    localPath: path.resolve(__dirname, '../../libs/jstat.min.js'),
    contentType: 'text/javascript; charset=utf-8'
  },
  {
    match: /\/(?:npm\/)?jszip@3\.10\.1\/dist\/jszip\.min\.js$/i,
    localPath: path.resolve(__dirname, '../../libs/jszip.min.js'),
    contentType: 'text/javascript; charset=utf-8'
  },
  {
    match: /\/(?:npm\/)?svd-js@1\.1\.1\/build-umd\/svd-js\.min\.js$/i,
    localPath: path.resolve(__dirname, '../../libs/svd-js.min.js'),
    contentType: 'text/javascript; charset=utf-8'
  }
];

const CDN_OVERRIDE_CACHE = new Map();

const COMPONENT_MATRIX = [
  { type: 'venn', pageId: 'vennPage', exampleButtonId: 'sample' },
  { type: 'box', pageId: 'boxPage', exampleButtonId: 'boxLoadExample' },
  { type: 'scatter', pageId: 'scatterPage', exampleButtonId: 'scatterLoadExample' },
  { type: 'pca', pageId: 'pcaPage', exampleButtonId: 'pcaLoadExample' },
  { type: 'line', pageId: 'linePage', exampleButtonId: 'lineLoadExample' },
  { type: 'heatmap', pageId: 'heatmapPage', exampleButtonId: 'heatmapLoadExample' },
  { type: 'surface', pageId: 'surfacePage', exampleButtonId: 'surfaceLoadExample' },
  { type: 'roc', pageId: 'rocPage', exampleButtonId: 'rocLoadExample' },
  { type: 'survival', pageId: 'survivalPage', exampleButtonId: 'survivalLoadExample' },
  { type: 'hist', pageId: 'histPage', exampleButtonId: 'histLoadExample' },
  { type: 'pie', pageId: 'piePage', exampleButtonId: 'pieLoadExample' }
];

function shouldIgnoreConsoleEntry(text) {
  return KNOWN_NON_FATAL_LOG_PATTERNS.some(pattern => pattern.test(String(text || '')));
}

function shouldIgnoreRequestFailure(text) {
  return /(?:NS_BINDING_ABORTED|net::ERR_ABORTED|cancelled|canceled)/i.test(String(text || ''));
}

function readOverrideBody(entry) {
  const key = entry.localPath;
  if (CDN_OVERRIDE_CACHE.has(key)) {
    return CDN_OVERRIDE_CACHE.get(key);
  }
  const body = fs.readFileSync(entry.localPath);
  CDN_OVERRIDE_CACHE.set(key, body);
  return body;
}

async function installLocalCdnOverrides(page) {
  await page.route('https://cdn.jsdelivr.net/**', route => {
    const url = route.request().url();
    const entry = CDN_OVERRIDE_ENTRIES.find(item => item.match.test(url));
    if (!entry) {
      route.continue();
      return;
    }
    try {
      const body = readOverrideBody(entry);
      route.fulfill({
        status: 200,
        contentType: entry.contentType,
        body
      });
    } catch (err) {
      route.abort();
    }
  });
}

function registerIssueCollectors(page) {
  const all = [];
  const critical = [];

  page.on('console', async message => {
    let serializedArgs = [];
    if (message.type() === 'error') {
      serializedArgs = await Promise.all(message.args().map(async arg => {
        try {
          return await arg.evaluate(value => {
            if (value instanceof Error) {
              return { name: value.name, message: value.message, stack: value.stack };
            }
            if (value && typeof value === 'object') {
              return JSON.parse(JSON.stringify(value, (_key, entry) => {
                if (entry instanceof Error) {
                  return { name: entry.name, message: entry.message, stack: entry.stack };
                }
                return entry;
              }));
            }
            return value;
          });
        } catch (err) {
          return null;
        }
      }));
    }
    const entry = {
      kind: 'console',
      type: message.type(),
      text: message.text(),
      args: serializedArgs
    };
    all.push(entry);
    if (entry.type === 'error' && !shouldIgnoreConsoleEntry(entry.text)) {
      critical.push(entry);
    }
  });

  page.on('pageerror', err => {
    const entry = {
      kind: 'pageerror',
      type: 'error',
      text: err?.stack || String(err)
    };
    all.push(entry);
    critical.push(entry);
  });

  page.on('requestfailed', request => {
    const text = `${request.method()} ${request.url()} :: ${request.failure()?.errorText || 'unknown'}`;
    const entry = {
      kind: 'requestfailed',
      type: 'error',
      text
    };
    all.push(entry);
    if (!shouldIgnoreRequestFailure(text)) {
      critical.push(entry);
    }
  });

  return {
    all,
    critical
  };
}

async function maybeHandleDuplicatePrompt(page) {
  const prompt = page.locator('#duplicatePrompt:not([hidden])');
  if (await prompt.count() < 1) {
    return;
  }
  const emptyButton = page.locator('#duplicateEmpty');
  if (await emptyButton.isVisible()) {
    await emptyButton.click();
    await page.waitForTimeout(200);
  }
}

async function getActiveWorkspaceTabMeta(page) {
  return page.evaluate(() => {
    const state = window.Main?.session?.workspaceState;
    const active = state?.tabs?.find(tab => tab?.id === state.activeTabId) || null;
    return active
      ? { id: String(active.id || ''), type: active.type || null, title: active.title || '' }
      : null;
  }).catch(() => null);
}

async function waitForActiveComponentLaunch(page, component, timeout = 20_000, expectedTabId = null) {
  const startedAt = Date.now();
  const pollMs = 120;
  while (Date.now() - startedAt < timeout) {
    const launched = await page.evaluate(({ type, pageId, expectedId }) => {
      const state = window.Main?.session?.workspaceState;
      const active = state?.tabs?.find(tab => tab?.id === state.activeTabId) || null;
      if (expectedId && String(active?.id || '') !== String(expectedId)) {
        return false;
      }
      if (!active || active.type !== type) {
        return false;
      }
      const mountedRoot = window.Shared?.workspaceTabs?.getMountedRoot?.(active.id, type) || null;
      const searchRoot = mountedRoot || document.querySelector(`#${pageId}:not([hidden])`) || null;
      if (!searchRoot) {
        return false;
      }
      return !!searchRoot.querySelector?.([
        '.ag-root-wrapper',
        '.ag-root',
        '.workspace-toolbar',
        '.svgbox',
        '.config-panel',
        `[id="${type}LoadExample"]`
      ].join(','));
    }, { type: component.type, pageId: component.pageId, expectedId: expectedTabId || null }).catch(() => false);
    if (launched) {
      return true;
    }
    await page.waitForTimeout(pollMs);
  }
  return false;
}

async function openComponentFromWelcome(page, component, options = {}) {
  const previousActive = await getActiveWorkspaceTabMeta(page);
  let expectedTabId = options.expectedTabId || null;
  const tileAction = options.loadExample === true ? 'example' : 'new';
  if (!options.first) {
    await page.locator('#addWorkspaceTab').click();
    await maybeHandleDuplicatePrompt(page);
    const startedAt = Date.now();
    while (Date.now() - startedAt < 10_000 && !expectedTabId) {
      const active = await getActiveWorkspaceTabMeta(page);
      if (active?.id && active.id !== previousActive?.id) {
        expectedTabId = active.id;
        break;
      }
      await page.waitForTimeout(120);
    }
  }
  if (!expectedTabId && !options.first) {
    expectedTabId = (await getActiveWorkspaceTabMeta(page))?.id || null;
  }
  const selector = `#graphSelectionGrid [data-graph-type="${component.type}"]`;
  const card = page.locator(selector);
  await page.waitForSelector(selector, { timeout: 20_000 });
  let launched = false;
  let lastError = null;
  for (let attempt = 0; attempt < 4 && !launched; attempt += 1) {
    try {
      if (!(await card.first().isVisible().catch(() => false))) {
        break;
      }
      await card.scrollIntoViewIfNeeded({ timeout: 3000 });
      const preferredButton = tileAction === 'example'
        ? card.getByRole('button', { name: /^Load example\b/i }).first()
        : card.getByRole('button', { name: /^New\b/i }).first();
      const fallbackButton = tileAction === 'example'
        ? card.getByRole('button', { name: /^New\b/i }).first()
        : card.getByRole('button', { name: /^Load example\b/i }).first();
      const target = await preferredButton.count()
        ? preferredButton
        : (await fallbackButton.count() ? fallbackButton : card);
      await target.click({ force: true, timeout: 5000 });
      launched = await waitForActiveComponentLaunch(page, component, 10_000, expectedTabId);
    } catch (err) {
      lastError = err;
      if (page.isClosed()) {
        throw err;
      }
      await page.waitForTimeout(200 * (attempt + 1));
    }
  }
  if (!launched && !page.isClosed()) {
    try {
      const fallbackState = await page.evaluate(({ type, expectedId, loadExample }) => {
        if (expectedId && window.Main?.tabs?.activateTab) {
          window.Main.tabs.activateTab(expectedId, {
            skipPersist: true,
            skipDuplicatePrompt: true,
            disableDuplicatePrompt: true,
            forceBlankWorkspace: true,
            reason: 'e2e-open-component-reactivate-target'
          });
        }
        const promptVisible = !!document.querySelector('#duplicatePrompt:not([hidden])');
        const state = window.Main?.session?.workspaceState;
        const before = state?.tabs?.find(tab => tab?.id === state.activeTabId) || null;
        const fn = window.Main?.tabs?.launchWelcomeGraph || window.Main?.tabs?.handleGraphSelection;
        if (typeof fn === 'function') {
          if (fn === window.Main?.tabs?.launchWelcomeGraph) {
            void fn(type, {
              loadExample: !!loadExample,
              reason: loadExample ? 'e2e-open-component-example-fallback' : 'e2e-open-component-new-fallback'
            });
          } else {
            fn(type, {
              forceBlankWorkspace: !loadExample,
              loadExample: !!loadExample,
              skipDuplicatePrompt: true,
              disableDuplicatePrompt: true,
              reason: loadExample ? 'e2e-open-component-example-fallback' : 'e2e-open-component-fallback'
            });
          }
        }
        const afterState = window.Main?.session?.workspaceState;
        const after = afterState?.tabs?.find(tab => tab?.id === afterState.activeTabId) || null;
        return {
          promptVisible,
          before: before ? { id: before.id, type: before.type || null, title: before.title || '' } : null,
          after: after ? { id: after.id, type: after.type || null, title: after.title || '' } : null
        };
      }, { type: component.type, expectedId: expectedTabId || null, loadExample: tileAction === 'example' });
      launched = await waitForActiveComponentLaunch(page, component, 20_000, expectedTabId);
    } catch (err) {
      lastError = err;
    }
  }
  if (!launched) {
    const state = await page.evaluate(() => {
      const workspaceState = window.Main?.session?.workspaceState;
      const active = workspaceState?.tabs?.find(tab => tab?.id === workspaceState.activeTabId) || null;
      return {
        activeTabId: workspaceState?.activeTabId || null,
        active: active ? { id: active.id, type: active.type || null, title: active.title || '' } : null,
        tabs: Array.isArray(workspaceState?.tabs)
          ? workspaceState.tabs.map(tab => ({ id: tab.id, type: tab.type || null, title: tab.title || '', isWelcome: !!tab.isWelcome }))
          : [],
        expectedTabId: expectedTabId || null
      };
    }).catch(() => null);
    const details = state ? ` ${JSON.stringify(state)}` : '';
    const causeMessage = lastError ? ` Cause: ${lastError.message || String(lastError)}` : '';
    throw new Error(`Failed to open component card: ${component.type}.${details}${causeMessage}`);
  }
}

async function clickExampleButtonIfPresent(page, buttonId) {
  if (!buttonId) {
    return false;
  }
  const activeTabMeta = await page.evaluate(async (targetId) => {
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    const startedAt = Date.now();
    while (Date.now() - startedAt < 8000) {
      const state = window.Main?.session?.workspaceState;
      const activeTab = state?.tabs?.find(tab => tab?.id === state?.activeTabId) || null;
      const type = activeTab?.type || '';
      if (type) {
        const mountedRoot = window.Shared?.workspaceTabs?.getMountedRoot?.(activeTab.id, type) || null;
        const pageRoot = document.getElementById(`${type}Page`);
        const searchRoot = mountedRoot || pageRoot || null;
        const button = searchRoot?.querySelector?.(`#${targetId}`) || null;
        if (button && !button.disabled) {
          const style = window.getComputedStyle(button);
          const visible = !!button.offsetParent
            && style.display !== 'none'
            && style.visibility !== 'hidden';
          if (visible) {
            return {
              tabId: String(activeTab.id || ''),
              type,
              hasMountedRoot: !!mountedRoot
            };
          }
        }
      }
      await wait(120);
    }
    const fallbackState = window.Main?.session?.workspaceState;
    const fallbackTab = fallbackState?.tabs?.find(tab => tab?.id === fallbackState?.activeTabId) || null;
    return {
      tabId: String(fallbackTab?.id || ''),
      type: fallbackTab?.type || '',
      hasMountedRoot: false
    };
  }, buttonId);
  const activeType = String(activeTabMeta?.type || '').trim();
  const activeTabId = String(activeTabMeta?.tabId || '').trim();
  const clickCandidates = [
    activeTabId ? `[data-tab-id="${activeTabId}"] #${buttonId}` : '',
    activeTabId ? `[data-workspace-tab-id="${activeTabId}"] #${buttonId}` : '',
    activeType ? `#${activeType}Page:not([hidden]) #${buttonId}` : '',
    activeType ? `#${activeType}Page #${buttonId}` : ''
  ].filter(Boolean);
  for (const selector of clickCandidates) {
    const trustedButton = page.locator(selector).first();
    const trustedVisible = await trustedButton.isVisible().catch(() => false);
    const trustedEnabled = trustedVisible
      ? await trustedButton.isEnabled().catch(() => false)
      : false;
    if (!trustedVisible || !trustedEnabled) {
      continue;
    }
    await trustedButton.click({ force: true });
    await page.waitForTimeout(700);
    return true;
  }
  const clicked = await page.evaluate((targetId) => {
    const state = window.Main?.session?.workspaceState;
    const activeTab = state?.tabs?.find(tab => tab?.id === state?.activeTabId) || null;
    const type = activeTab?.type || '';
    const mountedRoot = window.Shared?.workspaceTabs?.getMountedRoot?.(activeTab?.id || null, type) || null;
    const pageRoot = type ? document.getElementById(`${type}Page`) : null;
    const searchRoot = mountedRoot || pageRoot || document;
    const button = searchRoot?.querySelector?.(`#${targetId}`) || null;
    if (!button || button.disabled) {
      return false;
    }
    const style = window.getComputedStyle(button);
    if (!button.offsetParent || style.display === 'none' || style.visibility === 'hidden') {
      return false;
    }
    button.click();
    return true;
  }, buttonId);
  if (!clicked) {
    return false;
  }
  await page.waitForTimeout(700);
  return true;
}

async function confirmDataImportPrompt(page, options = {}) {
  const timeout = Number.isFinite(Number(options.timeout)) ? Number(options.timeout) : 60_000;
  const prompt = page.locator('#welcomeDataImportPrompt');
  await prompt.waitFor({ state: 'visible', timeout });
  await page.waitForFunction(() => {
    const modal = document.getElementById('welcomeDataImportPrompt');
    const status = document.getElementById('welcomeDataImportPreviewStatus');
    const submit = document.getElementById('welcomeDataImportOpen');
    if (!modal || modal.hidden || !status || !submit || submit.disabled) {
      return false;
    }
    const text = String(status.textContent || '').trim();
    return !!text && !/loading preview/i.test(text) && !/preview failed|preview unavailable/i.test(text);
  }, null, { timeout });
  await page.locator('#welcomeDataImportOpen').click();
  await prompt.waitFor({ state: 'hidden', timeout });
}

async function importDataFile(page, inputSelector, filePath, options = {}) {
  await page.locator(inputSelector).setInputFiles(filePath);
  await confirmDataImportPrompt(page, options);
}

function toMs(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) {
    return 0;
  }
  return Number(numeric.toFixed(3));
}

function normalizePerfEntry(entry) {
  if (!entry || typeof entry !== 'object') {
    return null;
  }
  const id = Number(entry.id);
  const duration = Number(entry.duration);
  return {
    id: Number.isFinite(id) ? id : 0,
    label: typeof entry.label === 'string' ? entry.label : 'unknown',
    duration: Number.isFinite(duration) ? toMs(duration) : 0,
    meta: entry.meta && typeof entry.meta === 'object' ? entry.meta : null
  };
}

function summarizeReportDelta(beforeReport, afterReport) {
  const beforeMap = new Map((beforeReport || []).map(entry => [entry.key, entry]));
  const changes = [];
  for (const entry of (afterReport || [])) {
    const before = beforeMap.get(entry.key);
    const beforeTotal = Number(before?.totalMs || 0);
    const afterTotal = Number(entry.totalMs || 0);
    const deltaTotal = afterTotal - beforeTotal;
    const beforeCount = Number(before?.count || 0);
    const afterCount = Number(entry.count || 0);
    const deltaCount = afterCount - beforeCount;
    if (deltaCount > 0 || deltaTotal > 0.1) {
      changes.push({
        key: entry.key,
        deltaCount,
        deltaTotalMs: toMs(deltaTotal),
        latestAvgMs: Number(entry.avgMs || 0),
        latestP95Ms: Number(entry.p95Ms || 0)
      });
    }
  }
  changes.sort((a, b) => b.deltaTotalMs - a.deltaTotalMs);
  return changes.slice(0, 8);
}

function summarizeHookDelta(beforeHook, afterHook) {
  const sections = ['loadData', 'evaluation', 'draw'];
  const result = {};
  for (const section of sections) {
    const before = beforeHook?.performance?.[section] || null;
    const after = afterHook?.performance?.[section] || null;
    if (!after || typeof after !== 'object') {
      continue;
    }
    const changed = (after?.timestamp || 0) !== (before?.timestamp || 0);
    if (!changed) {
      continue;
    }
    result[section] = {
      totalMs: toMs(after.totalMs),
      parseMs: toMs(after.parseMs),
      computeMs: toMs(after.computeMs),
      renderMs: toMs(after.renderMs),
      rows: Number(after.rows || 0),
      cols: Number(after.cols || 0),
      reason: after.reason || null
    };
  }
  return result;
}

function summarizeSharedEntryDelta(beforeSnapshot, afterSnapshot) {
  const beforeMaxId = Number(beforeSnapshot?.sharedPerformance?.maxEntryId || 0);
  const nextEntries = (afterSnapshot?.sharedPerformance?.entries || [])
    .filter(entry => Number(entry.id) > beforeMaxId)
    .map(normalizePerfEntry)
    .filter(Boolean);
  nextEntries.sort((a, b) => b.duration - a.duration);
  return nextEntries.slice(0, 10);
}

async function collectComponentPerformanceSnapshot(page, componentType) {
  try {
    return await page.evaluate(({ componentType }) => {
      const Shared = window.Shared || {};
      const Components = window.Components || {};
      const perfApi = Shared.Performance || {};
      const allEntries = Array.isArray(perfApi._entries) ? perfApi._entries : [];
      const componentPrefix = `${componentType}.`;
      const relevantEntries = allEntries.filter(entry => {
        const label = typeof entry?.label === 'string' ? entry.label : '';
        return label.startsWith(componentPrefix) || label.startsWith('hot.');
      });
      const reportForPrefix = prefix => {
        if (typeof perfApi.getReport !== 'function') {
          return [];
        }
        return perfApi.getReport({
          filter: entry => typeof entry?.label === 'string' && entry.label.startsWith(prefix)
        }).slice(0, 12);
      };
      const componentHook = (() => {
        if (componentType === 'pca') {
          return Components?.pca?.__testHooks?.getPerformance?.() || null;
        }
        if (componentType === 'heatmap') {
          return Components?.heatmap?.__testHooks?.getPerformance?.() || null;
        }
        return null;
      })();
      const maxEntryId = relevantEntries.reduce((maxId, entry) => {
        const id = Number(entry?.id);
        return Number.isFinite(id) && id > maxId ? id : maxId;
      }, 0);
      return {
        componentType,
        capturedAt: Date.now(),
        componentHook,
        sharedPerformance: {
          totalEntries: allEntries.length,
          relevantEntries: relevantEntries.slice(-120).map(entry => ({
            id: Number(entry?.id || 0),
            label: String(entry?.label || ''),
            duration: Number(entry?.duration || 0),
            meta: entry?.meta || null
          })),
          maxEntryId,
          componentReport: reportForPrefix(componentPrefix),
          hotReport: reportForPrefix('hot.')
        }
      };
    }, { componentType });
  } catch (err) {
    return {
      componentType,
      capturedAt: Date.now(),
      error: err?.message || String(err)
    };
  }
}

async function runTimedStep(page, component, stepName, action) {
  const beforeSnapshot = await collectComponentPerformanceSnapshot(page, component.type);
  const start = Date.now();
  const actionResult = await action();
  const durationMs = Date.now() - start;
  const afterSnapshot = await collectComponentPerformanceSnapshot(page, component.type);
  return {
    step: stepName,
    durationMs: toMs(durationMs),
    actionResult: actionResult || null,
    perfDelta: {
      hook: summarizeHookDelta(beforeSnapshot?.componentHook, afterSnapshot?.componentHook),
      sharedEntries: summarizeSharedEntryDelta(beforeSnapshot, afterSnapshot),
      componentReport: summarizeReportDelta(
        beforeSnapshot?.sharedPerformance?.componentReport,
        afterSnapshot?.sharedPerformance?.componentReport
      ),
      hotReport: summarizeReportDelta(
        beforeSnapshot?.sharedPerformance?.hotReport,
        afterSnapshot?.sharedPerformance?.hotReport
      )
    }
  };
}

async function cycleVisibleSelects(pageRoot, maxCount = 4) {
  const start = Date.now();
  const selects = pageRoot.locator('select:visible');
  const count = await selects.count();
  const limit = Math.min(count, maxCount);
  let changed = 0;
  for (let i = 0; i < limit; i += 1) {
    const select = selects.nth(i);
    if (!(await select.isEnabled())) {
      continue;
    }
    const current = await select.inputValue().catch(() => null);
    const nextOptions = await select.evaluate(el => {
      const currentValue = String(el.value || '');
      return Array.from(el.options || [])
        .filter(option => !option.disabled && String(option.value || '') !== currentValue)
        .map(option => String(option.value || ''))
        .filter(value => value.length > 0);
    }).catch(() => []);
    if (!Array.isArray(nextOptions) || !nextOptions.length) {
      continue;
    }
    await select.selectOption(nextOptions[0], { timeout: 1_500 }).catch(() => {});
    await pageRoot.page().waitForTimeout(60);
    if (current != null) {
      await select.selectOption(String(current), { timeout: 1_500 }).catch(() => {});
      await pageRoot.page().waitForTimeout(60);
    }
    changed += 1;
  }
  return {
    visible: count,
    attempted: limit,
    changed,
    durationMs: toMs(Date.now() - start)
  };
}

async function toggleVisibleCheckboxes(pageRoot, maxCount = 5) {
  const start = Date.now();
  const checkboxes = pageRoot.locator('input[type="checkbox"]:visible');
  const count = await checkboxes.count();
  const limit = Math.min(count, maxCount);
  let toggled = 0;
  for (let i = 0; i < limit; i += 1) {
    const checkbox = checkboxes.nth(i);
    if (!(await checkbox.isEnabled())) {
      continue;
    }
    await checkbox.click({ timeout: 1_500 }).catch(() => {});
    await pageRoot.page().waitForTimeout(50);
    await checkbox.click({ timeout: 1_500 }).catch(() => {});
    await pageRoot.page().waitForTimeout(50);
    toggled += 1;
  }
  return {
    visible: count,
    attempted: limit,
    toggled,
    durationMs: toMs(Date.now() - start)
  };
}

async function clickAnalysisButtons(pageRoot, maxCount = 6) {
  const start = Date.now();
  const analysisPattern = /calculate statistics|recalculate statistics|guide me|diagnostics|log-rank|cox|chi|delong|forecast|anova|t-test|fit/i;
  const buttons = pageRoot.locator('button:visible');
  const count = await buttons.count();
  let clicks = 0;
  const clickedLabels = [];
  for (let i = 0; i < count && clicks < maxCount; i += 1) {
    const button = buttons.nth(i);
    const text = await button.innerText().catch(() => '');
    if (!analysisPattern.test(String(text || ''))) {
      continue;
    }
    if (!(await button.isEnabled().catch(() => false))) {
      continue;
    }
    await button.click({ timeout: 1_500 }).catch(() => {});
    clicks += 1;
    clickedLabels.push(String(text || '').trim());
    await pageRoot.page().waitForTimeout(90);
  }
  return {
    visible: count,
    clicked: clicks,
    clickedLabels: clickedLabels.slice(0, 6),
    durationMs: toMs(Date.now() - start)
  };
}

async function adjustVisibleZoomControls(pageRoot) {
  const start = Date.now();
  const zoomIn = pageRoot.locator('button[aria-label="Zoom in graph view"]:visible').first();
  const zoomOut = pageRoot.locator('button[aria-label="Zoom out graph view"]:visible').first();
  let zoomInClicks = 0;
  let zoomOutClicks = 0;
  if (await zoomIn.count()) {
    await zoomIn.click().catch(() => {});
    zoomInClicks += 1;
    await pageRoot.page().waitForTimeout(80);
    await zoomIn.click().catch(() => {});
    zoomInClicks += 1;
    await pageRoot.page().waitForTimeout(80);
  }
  if (await zoomOut.count()) {
    await zoomOut.click().catch(() => {});
    zoomOutClicks += 1;
    await pageRoot.page().waitForTimeout(80);
  }
  return {
    zoomInClicks,
    zoomOutClicks,
    durationMs: toMs(Date.now() - start)
  };
}

async function dragPanelResizer(page, pageRoot) {
  const start = Date.now();
  const resizer = pageRoot.locator('.panel-resizer:visible').first();
  if (await resizer.count() < 1) {
    return { present: false, moved: false, durationMs: toMs(Date.now() - start) };
  }
  const box = await resizer.boundingBox();
  if (!box) {
    return { present: true, moved: false, durationMs: toMs(Date.now() - start) };
  }
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  await page.mouse.move(cx, cy);
  await page.mouse.down();
  await page.mouse.move(cx + 100, cy, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(90);
  await page.mouse.move(cx + 100, cy);
  await page.mouse.down();
  await page.mouse.move(cx - 60, cy, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(90);
  return { present: true, moved: true, durationMs: toMs(Date.now() - start) };
}

async function exerciseVisibleComponentControls(page, component) {
  const pageRoot = page.locator(`#${component.pageId}:not([hidden])`);
  const isHeavy = component.type === 'pca' || component.type === 'line';
  const before = await collectComponentPerformanceSnapshot(page, component.type);
  const steps = [];
  steps.push(await runTimedStep(page, component, 'cycle-selects', () => cycleVisibleSelects(pageRoot, isHeavy ? 2 : 4)));
  steps.push(await runTimedStep(page, component, 'toggle-checkboxes', () => toggleVisibleCheckboxes(pageRoot, isHeavy ? 2 : 5)));
  steps.push(await runTimedStep(page, component, 'click-analysis-buttons', () => clickAnalysisButtons(pageRoot, isHeavy ? 3 : 6)));
  steps.push(await runTimedStep(page, component, 'drag-panel-resizer', () => dragPanelResizer(page, pageRoot)));
  steps.push(await runTimedStep(page, component, 'adjust-zoom', () => adjustVisibleZoomControls(pageRoot)));
  await page.waitForTimeout(250);
  const after = await collectComponentPerformanceSnapshot(page, component.type);
  return {
    steps,
    before,
    after
  };
}

async function waitForDocumentOpenComplete(page, timeoutMs = 120_000) {
  const handle = await page.waitForFunction(() => {
    const operation = window.Main?.session?.workspaceState?.documentOperation || null;
    const overlay = document.getElementById('documentOpenOverlay');
    if (overlay?.dataset?.state === 'error') {
      const diagnostics = window.Main?.sessionActions?.getDocumentOpenDiagnostics?.() || null;
      return {
        status: 'error',
        title: overlay.querySelector('.document-open-overlay__title')?.textContent || '',
        detail: overlay.querySelector('.document-open-overlay__detail')?.textContent || '',
        diagnostics: diagnostics?.message || ''
      };
    }
    if (operation?.active !== true && (!overlay || overlay.hidden === true)) {
      return { status: 'complete' };
    }
    return false;
  }, null, { timeout: timeoutMs });
  const result = await handle.jsonValue();
  if (result?.status === 'error') {
    throw new Error([result.title, result.detail, result.diagnostics].filter(Boolean).join(': ') || 'Document open failed');
  }
}

module.exports = {
  COMPONENT_MATRIX,
  installLocalCdnOverrides,
  registerIssueCollectors,
  openComponentFromWelcome,
  clickExampleButtonIfPresent,
  confirmDataImportPrompt,
  importDataFile,
  waitForDocumentOpenComplete,
  exerciseVisibleComponentControls,
  collectComponentPerformanceSnapshot,
  shouldIgnoreConsoleEntry
};
