(function(global){
  'use strict';
  const Shared = global.Shared = global.Shared || {};
  const stats = Shared.stats = Shared.stats || {};
  const DEFAULT_METHOD = 'bonferroni';
  const METHOD_CONFIG = {
    none: {
      label: 'None (unadjusted)',
      shortLabel: 'None',
      description: 'No multiple-testing correction applied.',
      footnote: count => `P-values are unadjusted${count > 0 ? ` (${count} comparison${count === 1 ? '' : 's'})` : ''}.`,
      aliases: ['unadjusted']
    },
    bonferroni: {
      label: 'Bonferroni',
      shortLabel: 'Bonferroni',
      description: 'Controls family-wise error rate via Bonferroni adjustment.',
      footnote: count => `Bonferroni-adjusted P values across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: []
    },
    holm: {
      label: 'Holm',
      shortLabel: 'Holm',
      description: 'Holm step-down adjustment for family-wise error control.',
      footnote: count => `Holm correction applied across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: ['holm-bonferroni', 'holm_bonferroni']
    },
    'holm-sidak': {
      label: 'Holm-Šidák',
      shortLabel: 'Holm-Šidák',
      description: 'Holm-Šidák step-down adjustment for family-wise error control.',
      footnote: count => `Holm-Šidák correction applied across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: ['holm-sidak', 'holm sidak', 'holmsidak', 'holm_sidak']
    },
    sidak: {
      label: 'Šidák',
      shortLabel: 'Šidák',
      description: 'Šidák correction assuming independent tests.',
      footnote: count => `Šidák correction applied across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: ['sidak', 'sidak-bonferroni', 'sidak_bonferroni']
    },
    hochberg: {
      label: 'Hochberg',
      shortLabel: 'Hochberg',
      description: 'Hochberg step-up procedure for family-wise error control.',
      footnote: count => `Hochberg correction applied across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: []
    },
    bh: {
      label: 'Benjamini–Hochberg (FDR)',
      shortLabel: 'BH',
      description: 'Benjamini–Hochberg false discovery rate control.',
      footnote: count => `Benjamini–Hochberg FDR correction across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: ['fdr', 'benjamini-hochberg', 'benjaminihochberg', 'bh-fdr']
    },
    by: {
      label: 'Benjamini–Yekutieli (FDR)',
      shortLabel: 'BY',
      description: 'Benjamini–Yekutieli false discovery rate control for dependent tests.',
      footnote: count => `Benjamini–Yekutieli FDR correction across ${count} test${count === 1 ? '' : 's'}.`,
      aliases: ['benjamini-yekutieli', 'benjaminiyekutieli', 'by-fdr']
    }
  };

  const DEFAULT_PVALUE_SIG_DIGITS = 6;

  const DEFAULT_REPORT_PVALUE_DECIMALS = 4;
  const DEFAULT_REPORT_PVALUE_MIN = 0.0001;
  const DEFAULT_PVALUE_FORMAT_SCIENTIFIC = false;

  function statsDebugEnabled(){
    return typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled();
  }

  function clampSignificantDigits(value){
    const coerced = Math.floor(Number(value));
    if(Number.isFinite(coerced) && coerced >= 1 && coerced <= 15){
      return coerced;
    }
    return DEFAULT_PVALUE_SIG_DIGITS;
  }

  function normalizeExponentText(value){
    if(typeof value !== 'string'){
      return value;
    }
    let result = value.replace('E', 'e');
    result = result.replace(/e\+/, 'e');
    result = result.replace(/e([+-])0+(\d+)/, (_, sign, digits) => `e${sign}${digits}`);
    return result;
  }

  function finalizeNumberString(value){
    if(typeof value !== 'string'){
      return value;
    }
    let result = value;
    const expMatch = result.match(/^[+-]?(?:\d+\.?\d*|\.\d+)[eE][+-]?\d+$/);
    if(expMatch){
      const parts = result.split(/[eE]/);
      let mantissa = parts[0];
      const exponent = parts[1];
      if(mantissa.includes('.')){
        mantissa = mantissa.replace(/0+$/, '').replace(/\.$/, '');
        if(mantissa === '' || mantissa === '+' || mantissa === '-'){
          mantissa = `${mantissa}0`;
        }
      }
      result = `${mantissa}e${exponent}`;
      return normalizeExponentText(result);
    }
    if(!/[eE]/.test(result) && result.includes('.')){
      result = result.replace(/0+$/, '').replace(/\.$/, '');
      if(result === ''){
        result = '0';
      }
    }
    return normalizeExponentText(result);
  }

  const NUMERICAL_MAX_ITER = 10000;
  const NUMERICAL_EPSILON = 3e-14;
  const NUMERICAL_FPMIN = 1e-300;
  const LANCZOS_COEFFS = [
    676.5203681218851,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.13857109526572012,
    9.9843695780195716e-6,
    1.5056327351493116e-7
  ];

  function clampProbability(value){
    const num = Number(value);
    if(!Number.isFinite(num)){
      return NaN;
    }
    if(num <= 0){
      return 0;
    }
    if(num >= 1){
      return 1;
    }
    return num;
  }

  function logGamma(value){
    const z = Number(value);
    if(!Number.isFinite(z) || z <= 0){
      return NaN;
    }
    if(z < 0.5){
      return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - logGamma(1 - z);
    }
    const shifted = z - 1;
    let x = 0.99999999999980993;
    for(let i = 0; i < LANCZOS_COEFFS.length; i += 1){
      x += LANCZOS_COEFFS[i] / (shifted + i + 1);
    }
    const t = shifted + LANCZOS_COEFFS.length - 0.5;
    return 0.5 * Math.log(2 * Math.PI) + (shifted + 0.5) * Math.log(t) - t + Math.log(x);
  }

  function regularizedGammaSeries(a, x){
    const gln = logGamma(a);
    if(!Number.isFinite(gln)){
      return NaN;
    }
    if(x <= 0){
      return 0;
    }
    let sum = 1 / a;
    let del = sum;
    let ap = a;
    for(let n = 1; n <= NUMERICAL_MAX_ITER; n += 1){
      ap += 1;
      del *= x / ap;
      sum += del;
      if(Math.abs(del) < Math.abs(sum) * NUMERICAL_EPSILON){
        break;
      }
    }
    return sum * Math.exp(-x + a * Math.log(x) - gln);
  }

  function regularizedGammaContinuedFraction(a, x){
    const gln = logGamma(a);
    if(!Number.isFinite(gln)){
      return NaN;
    }
    let b = x + 1 - a;
    let c = 1 / NUMERICAL_FPMIN;
    let d = 1 / Math.max(Math.abs(b), NUMERICAL_FPMIN);
    if(b < 0 && Math.abs(b) < NUMERICAL_FPMIN){
      d = -d;
    }
    let h = d;
    for(let i = 1; i <= NUMERICAL_MAX_ITER; i += 1){
      const an = -i * (i - a);
      b += 2;
      d = an * d + b;
      if(Math.abs(d) < NUMERICAL_FPMIN){
        d = NUMERICAL_FPMIN;
      }
      c = b + an / c;
      if(Math.abs(c) < NUMERICAL_FPMIN){
        c = NUMERICAL_FPMIN;
      }
      d = 1 / d;
      const del = d * c;
      h *= del;
      if(Math.abs(del - 1) < NUMERICAL_EPSILON){
        break;
      }
    }
    return Math.exp(-x + a * Math.log(x) - gln) * h;
  }

  function regularizedGammaQ(a, x){
    const aa = Number(a);
    const xx = Number(x);
    if(!Number.isFinite(aa) || !Number.isFinite(xx) || aa <= 0){
      return NaN;
    }
    if(xx <= 0){
      return 1;
    }
    if(xx < aa + 1){
      return clampProbability(1 - regularizedGammaSeries(aa, xx));
    }
    return clampProbability(regularizedGammaContinuedFraction(aa, xx));
  }

  function betaContinuedFraction(a, b, x){
    const qab = a + b;
    const qap = a + 1;
    const qam = a - 1;
    let c = 1;
    let d = 1 - qab * x / qap;
    if(Math.abs(d) < NUMERICAL_FPMIN){
      d = NUMERICAL_FPMIN;
    }
    d = 1 / d;
    let h = d;
    for(let m = 1; m <= NUMERICAL_MAX_ITER; m += 1){
      const m2 = 2 * m;
      let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
      d = 1 + aa * d;
      if(Math.abs(d) < NUMERICAL_FPMIN){
        d = NUMERICAL_FPMIN;
      }
      c = 1 + aa / c;
      if(Math.abs(c) < NUMERICAL_FPMIN){
        c = NUMERICAL_FPMIN;
      }
      d = 1 / d;
      h *= d * c;
      aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
      d = 1 + aa * d;
      if(Math.abs(d) < NUMERICAL_FPMIN){
        d = NUMERICAL_FPMIN;
      }
      c = 1 + aa / c;
      if(Math.abs(c) < NUMERICAL_FPMIN){
        c = NUMERICAL_FPMIN;
      }
      d = 1 / d;
      const del = d * c;
      h *= del;
      if(Math.abs(del - 1) < NUMERICAL_EPSILON){
        break;
      }
    }
    return h;
  }

  function regularizedBeta(x, a, b){
    const xx = Number(x);
    const aa = Number(a);
    const bb = Number(b);
    if(!Number.isFinite(xx) || !Number.isFinite(aa) || !Number.isFinite(bb) || aa <= 0 || bb <= 0){
      return NaN;
    }
    if(xx <= 0){
      return 0;
    }
    if(xx >= 1){
      return 1;
    }
    const logBt = logGamma(aa + bb) - logGamma(aa) - logGamma(bb) + aa * Math.log(xx) + bb * Math.log1p(-xx);
    const bt = Math.exp(logBt);
    if(!Number.isFinite(bt)){
      return logBt < Math.log(Number.MIN_VALUE || 5e-324) ? 0 : NaN;
    }
    if(xx < (aa + 1) / (aa + bb + 2)){
      return clampProbability((bt * betaContinuedFraction(aa, bb, xx)) / aa);
    }
    return clampProbability(1 - (bt * betaContinuedFraction(bb, aa, 1 - xx)) / bb);
  }

  function chiSquareUpperTail(statistic, df){
    const x = Number(statistic);
    const degrees = Number(df);
    if(!Number.isFinite(x) || !Number.isFinite(degrees) || degrees <= 0){
      return NaN;
    }
    if(x <= 0){
      return 1;
    }
    return regularizedGammaQ(degrees / 2, x / 2);
  }

  function fUpperTail(statistic, df1, df2){
    const f = Number(statistic);
    const d1 = Number(df1);
    const d2 = Number(df2);
    if(!Number.isFinite(f) || !Number.isFinite(d1) || !Number.isFinite(d2) || d1 <= 0 || d2 <= 0){
      return NaN;
    }
    if(f <= 0){
      return 1;
    }
    const x = d2 / (d2 + d1 * f);
    return regularizedBeta(x, d2 / 2, d1 / 2);
  }

  function studentTTwoSidedPValue(statistic, df){
    const t = Number(statistic);
    const degrees = Number(df);
    if(!Number.isFinite(t) || !Number.isFinite(degrees) || degrees <= 0){
      return NaN;
    }
    const x = degrees / (degrees + t * t);
    return regularizedBeta(x, degrees / 2, 0.5);
  }

  function studentTUpperTail(statistic, df){
    const t = Number(statistic);
    const degrees = Number(df);
    if(!Number.isFinite(t) || !Number.isFinite(degrees) || degrees <= 0){
      return NaN;
    }
    if(t === 0){
      return 0.5;
    }
    const twoSided = studentTTwoSidedPValue(Math.abs(t), degrees);
    if(!Number.isFinite(twoSided)){
      return NaN;
    }
    return t > 0 ? twoSided / 2 : 1 - (twoSided / 2);
  }

  function normalTwoSidedPValue(z){
    const value = Number(z);
    if(!Number.isFinite(value)){
      return NaN;
    }
    return regularizedGammaQ(0.5, (value * value) / 2);
  }

  function normalUpperTail(z){
    const value = Number(z);
    if(!Number.isFinite(value)){
      return NaN;
    }
    if(value === 0){
      return 0.5;
    }
    const halfTwoSided = normalTwoSidedPValue(Math.abs(value)) / 2;
    if(!Number.isFinite(halfTwoSided)){
      return NaN;
    }
    return value > 0 ? halfTwoSided : 1 - halfTwoSided;
  }

  function finiteProbabilityOrFallback(value, fallback){
    const p = clampProbability(value);
    if(Number.isFinite(p)){
      return p;
    }
    const candidate = clampProbability(fallback);
    return Number.isFinite(candidate) ? candidate : NaN;
  }

  function formatFixedTrimmed(value, decimals){
    const num = Number(value);
    if(!Number.isFinite(num)){
      return String(value);
    }
    const safeDecimals = Number.isInteger(decimals) && decimals >= 0
      ? decimals
      : DEFAULT_REPORT_PVALUE_DECIMALS;
    return num
      .toFixed(safeDecimals)
      .replace(/(\.\d*?[1-9])0+$/, '$1')
      .replace(/\.0+$/, '')
      .replace(/^-0$/, '0');
  }

  function createPValueDisplayString(text, rawValue, metadata = {}){
    const label = new String(String(text == null ? '' : text));
    const numeric = Number(rawValue);
    Object.defineProperties(label, {
      __statsPValueRaw: { value: Number.isFinite(numeric) ? numeric : NaN, enumerable: false },
      __statsPValueOperator: { value: typeof metadata.operator === 'string' && metadata.operator ? metadata.operator : '=', enumerable: false },
      __statsPValueScientific: { value: metadata.scientific === true, enumerable: false },
      __statsPValueThresholded: { value: metadata.thresholded === true, enumerable: false }
    });
    return label;
  }

  function sanitizePValueScientific(value, fallback){
    if(value === true || value === 'true' || value === 1 || value === '1'){
      return true;
    }
    if(value === false || value === 'false' || value === 0 || value === '0'){
      return false;
    }
    return fallback === true;
  }

  const panelPValueScientificState = new WeakMap();
  const tabPValueScientificState = new Map();

  function normalizeStatsTabId(value){
    const text = typeof value === 'string' ? value.trim() : String(value || '').trim();
    return text || '';
  }

  function resolveActiveStatsTabId(){
    try{
      return normalizeStatsTabId(global.Main?.session?.getActiveTab?.()?.id);
    }catch(err){
      statsReportingDebug('resolveActiveTabError', { message: err?.message || String(err) });
      return '';
    }
  }

  function resolveComponentStatsTabId(target){
    const targetId = typeof target?.id === 'string' ? target.id : '';
    if(!targetId){
      return '';
    }
    const componentKeyByPanelId = {
      statsResults: 'box',
      scatterStatsResults: 'scatter',
      lineStatsResults: 'line',
      heatmapStatsContent: 'heatmap',
      heatmapStats: 'heatmap',
      rocStatsResults: 'roc',
      histStatsResults: 'hist',
      pieStatsResults: 'pie',
      pcaStatsResults: 'pca',
      surfaceStatsSummary: 'surface',
      survivalStatsSummary: 'survival',
      survivalStatsLogRank: 'survival',
      survivalStatsHazardRatios: 'survival',
      survivalStatsCox: 'survival',
      significanceResults: 'venn'
    };
    const key = componentKeyByPanelId[targetId] || '';
    return key ? normalizeStatsTabId(global.Components?.[key]?.__boundTabId) : '';
  }

  function resolveTargetStatsTabId(target, options = {}){
    const explicit = normalizeStatsTabId(options?.tabId || options?.tab?.id);
    if(explicit){
      return explicit;
    }
    const stored = normalizeStatsTabId(target?.dataset?.statsPvalueTabId || target?.__statsPValueTabId);
    if(stored){
      return stored;
    }
    const closest = target?.closest?.('[data-tab-id], [data-workspace-tab-id], [data-graphitix-tab-id]');
    const closestId = normalizeStatsTabId(
      closest?.dataset?.tabId
      || closest?.dataset?.workspaceTabId
      || closest?.dataset?.graphitixTabId
    );
    if(closestId){
      return closestId;
    }
    const componentTabId = resolveComponentStatsTabId(target);
    if(componentTabId){
      return componentTabId;
    }
    return resolveActiveStatsTabId();
  }

  function ensurePanelPValueTabId(target, options = {}){
    if(!target || target.nodeType !== 1){
      return '';
    }
    const tabId = resolveTargetStatsTabId(target, options);
    if(tabId){
      target.__statsPValueTabId = tabId;
      if(target.dataset){
        target.dataset.statsPvalueTabId = tabId;
      }
    }
    return tabId;
  }

  function readStoredPValueScientificForTab(tabId){
    const key = normalizeStatsTabId(tabId);
    if(key && tabPValueScientificState.has(key)){
      return tabPValueScientificState.get(key) === true;
    }
    return DEFAULT_PVALUE_FORMAT_SCIENTIFIC;
  }

  function getPanelPValueScientific(target, options = {}){
    if(target && target.nodeType === 1){
      if(panelPValueScientificState.has(target)){
        return panelPValueScientificState.get(target) === true;
      }
      if(Object.prototype.hasOwnProperty.call(target, '__statsPValueScientific')){
        return sanitizePValueScientific(target.__statsPValueScientific, DEFAULT_PVALUE_FORMAT_SCIENTIFIC);
      }
      if(target.dataset && Object.prototype.hasOwnProperty.call(target.dataset, 'statsPvalueScientific')){
        return sanitizePValueScientific(target.dataset.statsPvalueScientific, DEFAULT_PVALUE_FORMAT_SCIENTIFIC);
      }
    }
    const tabId = resolveTargetStatsTabId(target, options);
    return readStoredPValueScientificForTab(tabId);
  }

  function setPanelPValueScientific(target, value, options = {}){
    const next = sanitizePValueScientific(value, DEFAULT_PVALUE_FORMAT_SCIENTIFIC);
    const tabId = ensurePanelPValueTabId(target, options);
    if(tabId){
      tabPValueScientificState.set(tabId, next);
    }
    if(target && target.nodeType === 1){
      panelPValueScientificState.set(target, next);
      target.__statsPValueScientific = next;
      if(target.dataset){
        target.dataset.statsPvalueScientific = next ? '1' : '0';
      }
    }
    return next;
  }

  function setActiveTabPValueScientific(value, options = {}){
    const next = sanitizePValueScientific(value, DEFAULT_PVALUE_FORMAT_SCIENTIFIC);
    const tabId = normalizeStatsTabId(options?.tabId || options?.tab?.id) || resolveActiveStatsTabId();
    if(tabId){
      tabPValueScientificState.set(tabId, next);
    }
    return next;
  }

  function sharedFormatPValue(value, options){
    const num = Number(value);
    if(!Number.isFinite(num)){
      return String(value);
    }
    const digits = clampSignificantDigits(options?.significantDigits);
    const fractionalDigits = Math.max(0, digits - 1);
    const decimals = Number.isInteger(options?.decimals) && options.decimals >= 0
      ? options.decimals
      : DEFAULT_REPORT_PVALUE_DECIMALS;
    const decimalThreshold = Number.isFinite(options?.decimalThreshold) && options.decimalThreshold > 0
      ? options.decimalThreshold
      : DEFAULT_REPORT_PVALUE_MIN;
    const scientific = options?.forceScientific === true
      ? true
      : (options?.scientific === true
        ? true
        : (options?.scientific === false
          ? false
          : DEFAULT_PVALUE_FORMAT_SCIENTIFIC));
    const bounded = Math.max(0, Math.min(1, num));
    let formatted;
    let thresholded = false;
    if(scientific){
      formatted = bounded.toExponential(fractionalDigits);
    }else{
      if(bounded >= 0 && bounded < decimalThreshold){
        formatted = `<${formatFixedTrimmed(decimalThreshold, decimals)}`;
        thresholded = true;
      }else{
        formatted = formatFixedTrimmed(bounded, decimals);
      }
    }
    const result = finalizeNumberString(formatted);
    if(statsDebugEnabled()){
      console.debug('Debug: Shared.formatPValue',{ input: value, formatted: result, scientific, thresholded, options });
    }
    return createPValueDisplayString(result, bounded, { scientific, thresholded });
  }

  Shared.formatPValue = sharedFormatPValue;

  function formatShortNumber(value, options){
    const opts = options || {};
    const emptyValue = typeof opts.emptyValue === 'string' ? opts.emptyValue : 'n/a';
    const maxSignificantDigits = Number.isFinite(opts.maxSignificantDigits)
      ? opts.maxSignificantDigits
      : 6;
    if(value === null || value === undefined){
      return emptyValue;
    }
    if(typeof value === 'number'){
      if(!Number.isFinite(value)){
        return String(value);
      }
      return value.toLocaleString('en-US', { maximumSignificantDigits: maxSignificantDigits });
    }
    const numeric = Number(value);
    if(Number.isFinite(numeric)){
      return numeric.toLocaleString('en-US', { maximumSignificantDigits: maxSignificantDigits });
    }
    return String(value);
  }

  function formatFixedNumber(value, options){
    const opts = options || {};
    const num = Number(value);
    if(!Number.isFinite(num)){
      return typeof opts.emptyValue === 'string' ? opts.emptyValue : '-';
    }
    const decimals = Number.isFinite(opts.decimals) ? opts.decimals : 4;
    return num.toFixed(decimals);
  }

  const formatters = Shared.formatters = Shared.formatters || {};
  if(typeof formatters.formatShortNumber !== 'function'){
    formatters.formatShortNumber = formatShortNumber;
  }
  if(typeof formatters.formatFixedNumber !== 'function'){
    formatters.formatFixedNumber = formatFixedNumber;
  }
  formatters.formatPValue = sharedFormatPValue;

  function sanitizeP(value){
    const num = Number(value);
    return Number.isFinite(num) && num >= 0 && num <= 1 ? num : null;
  }

  function clampUnit(value){
    if(!Number.isFinite(value)){
      return null;
    }
    return Math.max(0, Math.min(1, value));
  }

  function normalizeMethod(method){
    const raw = typeof method === 'string' ? method.toLowerCase() : '';
    if(raw && METHOD_CONFIG[raw]){
      console.debug('Debug: stats.normalizeMethod direct match',{ method: raw });
      return raw;
    }
    if(raw){
      for(const [key, cfg] of Object.entries(METHOD_CONFIG)){
        if(Array.isArray(cfg.aliases) && cfg.aliases.includes(raw)){
          console.debug('Debug: stats.normalizeMethod alias match',{ alias: raw, resolved: key });
          return key;
        }
      }
    }
    console.debug('Debug: stats.normalizeMethod fallback',{ requested: method, fallback: DEFAULT_METHOD });
    return DEFAULT_METHOD;
  }

  function adjustBonferroni(values){
    const m = values.length || 1;
    return values.map(p => clampUnit(p * m));
  }

  function adjustSidak(values){
    const m = values.length || 1;
    return values.map(p => clampUnit(1 - Math.pow(1 - p, m)));
  }

  function adjustHolm(values){
    const m = values.length;
    const ordered = values.map((p, index) => ({ p, index })).sort((a, b) => a.p - b.p);
    const adjusted = new Array(m).fill(1);
    let running = 0;
    ordered.forEach((entry, idx) => {
      running = Math.max(running, clampUnit(entry.p * (m - idx)));
      adjusted[entry.index] = clampUnit(running);
    });
    return adjusted;
  }

  function adjustHolmSidak(values){
    const m = values.length;
    const ordered = values.map((p, index) => ({ p, index })).sort((a, b) => a.p - b.p);
    const adjusted = new Array(m).fill(1);
    let running = 0;
    ordered.forEach((entry, idx) => {
      running = Math.max(running, clampUnit(1 - Math.pow(1 - entry.p, m - idx)));
      adjusted[entry.index] = clampUnit(running);
    });
    return adjusted;
  }

  function adjustHochberg(values){
    const m = values.length;
    const ordered = values.map((p, index) => ({ p, index })).sort((a, b) => b.p - a.p);
    const adjusted = new Array(m).fill(1);
    let running = 1;
    ordered.forEach((entry, idx) => {
      running = Math.min(running, clampUnit(entry.p * (idx + 1)));
      adjusted[entry.index] = clampUnit(running);
    });
    return adjusted;
  }

  function adjustBenjaminiHochberg(values){
    const m = values.length;
    const ordered = values.map((p, index) => ({ p, index })).sort((a, b) => a.p - b.p);
    const adjusted = new Array(m).fill(1);
    let running = 1;
    for(let i = m - 1; i >= 0; i--){
      const entry = ordered[i];
      running = Math.min(running, clampUnit((entry.p * m) / (i + 1)));
      adjusted[entry.index] = clampUnit(running);
    }
    return adjusted;
  }

  function adjustBenjaminiYekutieli(values){
    const m = values.length;
    let harmonic = 0;
    for(let k = 1; k <= m; k++) harmonic += 1 / k;
    const ordered = values.map((p, index) => ({ p, index })).sort((a, b) => a.p - b.p);
    const adjusted = new Array(m).fill(1);
    let running = 1;
    for(let i = m - 1; i >= 0; i--){
      const entry = ordered[i];
      running = Math.min(running, clampUnit((entry.p * m * harmonic) / (i + 1)));
      adjusted[entry.index] = clampUnit(running);
    }
    return adjusted;
  }

  function adjustNone(values){
    return values.slice();
  }

  const METHOD_ADJUSTERS = {
    none: adjustNone,
    bonferroni: adjustBonferroni,
    holm: adjustHolm,
    'holm-sidak': adjustHolmSidak,
    sidak: adjustSidak,
    hochberg: adjustHochberg,
    bh: adjustBenjaminiHochberg,
    by: adjustBenjaminiYekutieli
  };

  stats.adjustPValues = function(pValues, options){
    const values = Array.isArray(pValues) ? pValues.slice() : [];
    const methodKey = normalizeMethod(options?.method);
    const valid = [];
    values.forEach((value, index) => {
      const pValue = sanitizeP(value);
      if(pValue != null) valid.push({ index, pValue });
    });
    const output = new Array(values.length).fill(null);
    if(valid.length){
      const adjuster = METHOD_ADJUSTERS[methodKey] || METHOD_ADJUSTERS[DEFAULT_METHOD];
      const adjustedValid = adjuster(valid.map(entry => entry.pValue));
      valid.forEach((entry, validIndex) => { output[entry.index] = adjustedValid[validIndex]; });
    }
    console.debug('Debug: stats.adjustPValues complete',{
      method: methodKey,
      totalCount: values.length,
      validCount: valid.length,
      omittedCount: values.length - valid.length,
      adjusted: output
    });
    return output;
  };

  const CONTINUOUS_DISTRIBUTION_COLORS = {
    normal: '#d95f02',
    lognormal: '#1b9e77',
    exponential: '#7570b3'
  };

  const SQRT_TWO = Math.sqrt(2);
  const SQRT_TWO_PI = Math.sqrt(2 * Math.PI);

  function erf(x){
    const sign = x >= 0 ? 1 : -1;
    const absX = Math.abs(x);
    if(!Number.isFinite(absX)){ return sign; }
    const p = 0.3275911;
    const a1 = 0.254829592;
    const a2 = -0.284496736;
    const a3 = 1.421413741;
    const a4 = -1.453152027;
    const a5 = 1.061405429;
    const t = 1 / (1 + p * absX);
    const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);
    return sign * y;
  }

  function normalCdf(z){
    if(!Number.isFinite(z)){ return z < 0 ? 0 : 1; }
    return 0.5 * (1 + erf(z / SQRT_TWO));
  }

  function normalQuantile(probability){
    const p = Number(probability);
    if(!Number.isFinite(p) || p <= 0 || p >= 1){
      return p === 0 ? -Infinity : (p === 1 ? Infinity : NaN);
    }
    let low = -8;
    let high = 8;
    for(let iteration = 0; iteration < 80; iteration += 1){
      const mid = (low + high) / 2;
      if(normalCdf(mid) < p){
        low = mid;
      }else{
        high = mid;
      }
    }
    return (low + high) / 2;
  }

  function correlationConfidenceInterval(r, sampleSize, alpha = 0.05){
    const correlation = Number(r);
    const n = Number(sampleSize);
    const levelAlpha = Number(alpha);
    if(!Number.isFinite(correlation) || !Number.isFinite(n) || n <= 3){
      return null;
    }
    const safeAlpha = Number.isFinite(levelAlpha) && levelAlpha > 0 && levelAlpha < 1
      ? levelAlpha
      : 0.05;
    const clamped = Math.max(-0.999999999999, Math.min(0.999999999999, correlation));
    const fisherZ = 0.5 * Math.log((1 + clamped) / (1 - clamped));
    const standardError = 1 / Math.sqrt(n - 3);
    const critical = normalQuantile(1 - (safeAlpha / 2));
    if(!Number.isFinite(standardError) || standardError <= 0 || !Number.isFinite(critical)){
      return null;
    }
    const toCorrelation = value => Math.tanh(value);
    return {
      low: toCorrelation(fisherZ - (critical * standardError)),
      high: toCorrelation(fisherZ + (critical * standardError)),
      method: 'fisher-z'
    };
  }

  function normalPdf(x, mean, sigma){
    if(!Number.isFinite(x) || !Number.isFinite(mean) || !Number.isFinite(sigma) || sigma <= 0){ return 0; }
    const z = (x - mean) / sigma;
    return Math.exp(-0.5 * z * z) / (sigma * SQRT_TWO_PI);
  }

  function logNormalPdf(x, mu, sigma){
    if(!Number.isFinite(x) || x <= 0 || !Number.isFinite(mu) || !Number.isFinite(sigma) || sigma <= 0){ return 0; }
    const z = (Math.log(x) - mu) / sigma;
    return Math.exp(-0.5 * z * z) / (x * sigma * SQRT_TWO_PI);
  }

  function logNormalCdf(x, mu, sigma){
    if(!Number.isFinite(x) || x <= 0 || !Number.isFinite(mu) || !Number.isFinite(sigma) || sigma <= 0){ return 0; }
    return normalCdf((Math.log(x) - mu) / sigma);
  }

  function exponentialPdf(x, lambda){
    if(!Number.isFinite(x) || !Number.isFinite(lambda) || lambda <= 0){ return 0; }
    if(x < 0){ return 0; }
    return lambda * Math.exp(-lambda * x);
  }

  function exponentialCdf(x, lambda){
    if(!Number.isFinite(x) || !Number.isFinite(lambda) || lambda <= 0){ return 0; }
    if(x < 0){ return 0; }
    return 1 - Math.exp(-lambda * x);
  }

  function kolmogorovPValue(d, n){
    if(!Number.isFinite(d) || d <= 0 || !Number.isFinite(n) || n <= 0){
      return 1;
    }
    const sqrtN = Math.sqrt(n);
    const lambda = (sqrtN + 0.12 + 0.11 / sqrtN) * d;
    let sum = 0;
    for(let k = 1; k <= 100; k++){
      const term = Math.exp(-2 * k * k * lambda * lambda);
      const contribution = (k % 2 ? 1 : -1) * term;
      sum += contribution;
      if(term < 1e-10){
        break;
      }
    }
    const p = Math.max(0, Math.min(1, 2 * sum));
    return p;
  }

  function andersonDarlingStatistic(sortedValues, cdf){
    const n = Array.isArray(sortedValues) ? sortedValues.length : 0;
    if(!n || typeof cdf !== 'function'){
      return 0;
    }
    const epsilon = 1e-12;
    let sum = 0;
    for(let i = 0; i < n; i++){
      const xLower = sortedValues[i];
      const xUpper = sortedValues[n - 1 - i];
      const Fi = clampUnit(cdf(xLower));
      const FiClamped = Math.min(Math.max(Fi, epsilon), 1 - epsilon);
      const FjRaw = clampUnit(cdf(xUpper));
      const Fj = Math.min(Math.max(1 - FjRaw, epsilon), 1 - epsilon);
      sum += (2 * (i + 1) - 1) * (Math.log(FiClamped) + Math.log(Fj));
    }
    return -n - (sum / n);
  }

  const AD_CRITICALS = {
    normal: {
      values: [0.576, 0.656, 0.787, 0.918, 1.092],
      sigLevels: [0.15, 0.1, 0.05, 0.025, 0.01]
    },
    exponential: {
      values: [0.922, 1.078, 1.341, 1.606, 1.957],
      sigLevels: [0.15, 0.1, 0.05, 0.025, 0.01]
    }
  };

  function adPValueNormal(adjusted){
    const a = Math.max(0, adjusted);
    if(a < 0.2){
      return 1 - Math.exp(-13.436 + 101.14 * a - 223.73 * a * a);
    }
    if(a < 0.34){
      return 1 - Math.exp(-8.318 + 42.796 * a - 59.938 * a * a);
    }
    if(a < 0.6){
      return Math.exp(0.9177 - 4.279 * a - 1.38 * a * a);
    }
    const expo = 1.2937 - 5.709 * a + 0.0186 * a * a;
    return Math.exp(Math.min(expo, 0));
  }

  function adPValueExponential(adjusted){
    const a = Math.max(0, adjusted);
    if(a < 0.3){
      return 1 - Math.exp(-1.2937 + 5.709 * a - 0.0186 * a * a);
    }
    if(a < 0.6){
      return Math.exp(0.9177 - 4.279 * a - 1.38 * a * a);
    }
    const expo = 1.2937 - 5.709 * a + 0.0186 * a * a;
    return Math.exp(Math.min(expo, 0));
  }

  function interpolateAdPValue(value, config){
    const thresholds = config.values;
    const sig = config.sigLevels;
    if(!thresholds.length){ return 1; }
    if(value <= thresholds[0]){
      const ratio = thresholds[0] ? value / thresholds[0] : 0;
      const upper = 0.25;
      const p = sig[0] + (upper - sig[0]) * (1 - ratio);
      return clampUnit(p);
    }
    for(let i = 0; i < thresholds.length - 1; i++){
      const start = thresholds[i];
      const end = thresholds[i + 1];
      if(value <= end){
        const span = end - start || 1;
        const t = (value - start) / span;
        const p0 = sig[i];
        const p1 = sig[i + 1];
        return clampUnit(p0 + (p1 - p0) * t);
      }
    }
    const lastThreshold = thresholds[thresholds.length - 1];
    const lastSig = sig[sig.length - 1];
    const tail = lastSig * Math.exp(-(value - lastThreshold));
    return clampUnit(tail);
  }

  function andersonDarlingPValue(statistic, key, n){
    if(!Number.isFinite(statistic) || statistic < 0 || !Number.isFinite(n) || n <= 0){
      return 1;
    }
    const id = typeof key === 'string' ? key.toLowerCase() : '';
    let adjusted = statistic;
    if(id === 'exponential'){
      adjusted = statistic * (1 + 0.6 / n);
      const approx = adPValueExponential(adjusted);
      const fallback = interpolateAdPValue(adjusted, AD_CRITICALS.exponential);
      return clampUnit(Number.isFinite(approx) ? approx : fallback);
    }
    adjusted = statistic * (1 + 4 / n - 25 / (n * n));
    const approx = adPValueNormal(adjusted);
    const fallback = interpolateAdPValue(adjusted, AD_CRITICALS.normal);
    return clampUnit(Number.isFinite(approx) ? approx : fallback);
  }

  const CONTINUOUS_DISTRIBUTIONS = {
    normal: {
      key: 'normal',
      label: 'Normal',
      color: CONTINUOUS_DISTRIBUTION_COLORS.normal,
      fit(values){
        let count = 0;
        let sum = 0;
        let sumSq = 0;
        for(let i = 0; i < values.length; i++){
          const v = values[i];
          if(!Number.isFinite(v)){ continue; }
          count += 1;
          sum += v;
          sumSq += v * v;
        }
        if(count < 2){
          return { key: 'normal', label: 'Normal', valid: false, message: 'Need at least two numeric values.' };
        }
        const mean = sum / count;
        const variance = Math.max(0, sumSq / count - mean * mean);
        const sigma = Math.sqrt(variance);
        const result = {
          key: 'normal',
          label: 'Normal',
          color: CONTINUOUS_DISTRIBUTION_COLORS.normal,
          valid: sigma > 0,
          params: { mu: mean, sigma, variance },
          paramOrder: ['mu', 'sigma', 'variance'],
          warnings: [],
          logLikelihood: Number.isFinite(variance) && variance > 0 ? (-0.5 * count * (Math.log(2 * Math.PI * variance) + 1)) : NaN
        };
        if(!result.valid){
          result.message = 'Variance is zero; unable to fit a normal distribution.';
          result.warnings.push(result.message);
        }
        result.pdf = x => sigma > 0 ? normalPdf(x, mean, sigma) : 0;
        result.cdf = x => sigma > 0 ? normalCdf((x - mean) / sigma) : (x < mean ? 0 : 1);
        return result;
      }
    },
    lognormal: {
      key: 'lognormal',
      label: 'Log-normal',
      color: CONTINUOUS_DISTRIBUTION_COLORS.lognormal,
      fit(values){
        let count = 0;
        let logSum = 0;
        let logSumSq = 0;
        let invalid = 0;
        for(let i = 0; i < values.length; i++){
          const v = values[i];
          if(!Number.isFinite(v) || v <= 0){
            invalid += 1;
            continue;
          }
          const logVal = Math.log(v);
          count += 1;
          logSum += logVal;
          logSumSq += logVal * logVal;
        }
        if(count < 2){
          return { key: 'lognormal', label: 'Log-normal', valid: false, message: 'Need at least two positive values.' };
        }
        const mu = logSum / count;
        const varianceLog = Math.max(0, logSumSq / count - mu * mu);
        const sigma = Math.sqrt(varianceLog);
        const mean = Math.exp(mu + varianceLog / 2);
        const median = Math.exp(mu);
        const result = {
          key: 'lognormal',
          label: 'Log-normal',
          color: CONTINUOUS_DISTRIBUTION_COLORS.lognormal,
          valid: sigma > 0,
          params: { mu, sigma, mean, median },
          paramOrder: ['mu', 'sigma', 'mean', 'median'],
          warnings: [],
          logLikelihood: sigma > 0
            ? (-count * (Math.log(sigma) + 0.5 * Math.log(2 * Math.PI)) - logSum - count / 2)
            : NaN
        };
        if(invalid > 0){
          result.warnings.push(`${invalid} value${invalid === 1 ? '' : 's'} ignored (non-positive).`);
        }
        if(!result.valid){
          result.message = 'Log-scale variance is zero; unable to fit a log-normal distribution.';
          result.warnings.push(result.message);
        }
        result.pdf = x => sigma > 0 ? logNormalPdf(x, mu, sigma) : 0;
        result.cdf = x => sigma > 0 ? logNormalCdf(x, mu, sigma) : (x < median ? 0 : 1);
        return result;
      }
    },
    exponential: {
      key: 'exponential',
      label: 'Exponential',
      color: CONTINUOUS_DISTRIBUTION_COLORS.exponential,
      fit(values){
        let count = 0;
        let sum = 0;
        let invalid = 0;
        for(let i = 0; i < values.length; i++){
          const v = values[i];
          if(!Number.isFinite(v) || v < 0){
            invalid += 1;
            continue;
          }
          count += 1;
          sum += v;
        }
        if(!count){
          return { key: 'exponential', label: 'Exponential', valid: false, message: 'No non-negative values supplied.' };
        }
        const mean = sum / count;
        const lambda = mean > 0 ? 1 / mean : 0;
        const result = {
          key: 'exponential',
          label: 'Exponential',
          color: CONTINUOUS_DISTRIBUTION_COLORS.exponential,
          valid: lambda > 0,
          params: { lambda, mean },
          paramOrder: ['lambda', 'mean'],
          warnings: [],
          logLikelihood: lambda > 0 ? (count * Math.log(lambda) - lambda * sum) : NaN
        };
        if(invalid > 0){
          result.warnings.push(`${invalid} value${invalid === 1 ? '' : 's'} ignored (negative or invalid).`);
        }
        if(!result.valid){
          result.message = 'Mean is zero; unable to fit an exponential distribution.';
          result.warnings.push(result.message);
        }
        result.pdf = x => lambda > 0 ? exponentialPdf(x, lambda) : 0;
        result.cdf = x => lambda > 0 ? exponentialCdf(x, lambda) : (x < 0 ? 0 : 1);
        return result;
      }
    }
  };

  stats.listContinuousDistributions = function listContinuousDistributions(){
    return Object.values(CONTINUOUS_DISTRIBUTIONS).map(entry => ({
      key: entry.key,
      label: entry.label,
      color: entry.color
    }));
  };

  stats.fitDistribution = function fitDistribution(values, options){
    const list = Array.isArray(values) ? values : [];
    const keyRaw = options?.distribution || options?.type || options?.key || '';
    const key = typeof keyRaw === 'string' ? keyRaw.toLowerCase() : '';
    const def = CONTINUOUS_DISTRIBUTIONS[key];
    if(!def){
      console.warn('stats.fitDistribution unknown distribution',{ distribution: keyRaw });
      return null;
    }
    try{
      const result = def.fit(list);
      return result;
    }catch(err){
      console.error('stats.fitDistribution error',{ distribution: key, message: err?.message });
      return { key, label: def.label, valid: false, message: err?.message || 'Fit failed.' };
    }
  };

  function createStatsSeededRandom(seed){
    let stateValue=(Number(seed) || 1337)>>>0;
    return function next(){
      stateValue=(stateValue+0x6D2B79F5)>>>0;
      let value=stateValue;
      value=Math.imul(value^(value>>>15),value|1);
      value^=value+Math.imul(value^(value>>>7),value|61);
      return ((value^(value>>>14))>>>0)/4294967296;
    };
  }

  function sampleStandardNormal(random){
    const u1=Math.max(Number.EPSILON,random());
    const u2=random();
    return Math.sqrt(-2*Math.log(u1))*Math.cos(2*Math.PI*u2);
  }

  function sampleFittedDistribution(key,fit,count,random){
    const params=fit?.params || {};
    const result=[];
    for(let i=0;i<count;i++){
      if(key==='normal') result.push(params.mu+params.sigma*sampleStandardNormal(random));
      else if(key==='lognormal') result.push(Math.exp(params.mu+params.sigma*sampleStandardNormal(random)));
      else if(key==='exponential') result.push(-Math.log(Math.max(Number.EPSILON,1-random()))/params.lambda);
    }
    return result;
  }

  function computeOneSampleKsStatistic(sorted,cdf){
    let maxDiff=0;
    for(let i=0;i<sorted.length;i++){
      const Fi=clampUnit(cdf(sorted[i]));
      if(Fi==null) return NaN;
      const diff=Math.max(Math.abs(Fi-(i+1)/sorted.length),Math.abs(Fi-i/sorted.length));
      if(diff>maxDiff) maxDiff=diff;
    }
    return maxDiff;
  }

  stats.goodnessOfFit = function goodnessOfFit(values, options){
    const keyRaw=options?.distribution || options?.fit?.key || '';
    const key=typeof keyRaw==='string'?keyRaw.toLowerCase():'';
    const def=CONTINUOUS_DISTRIBUTIONS[key];
    if(!def) return null;
    const raw=Array.isArray(values)?values.filter(Number.isFinite):[];
    if(!raw.length) return null;
    const supportValid=key==='lognormal'?raw.every(v=>v>0):key==='exponential'?raw.every(v=>v>=0):true;
    if(!supportValid){
      return {available:false,n:raw.length,message:`${def.label} goodness-of-fit is unavailable because one or more observations violate the distribution support.`};
    }
    const sorted=raw.slice().sort((a,b)=>a-b);
    const alpha=Number.isFinite(options?.alpha)&&options.alpha>0&&options.alpha<1?options.alpha:0.05;
    const fit=options?.fit?.valid===false?null:(options?.fit || def.fit(sorted));
    if(!fit || fit.valid===false || typeof fit.cdf!=='function') return {available:false,n:sorted.length,message:fit?.message || 'Distribution fit unavailable.'};
    const ksStat=computeOneSampleKsStatistic(sorted,fit.cdf);
    const adStat=andersonDarlingStatistic(sorted,fit.cdf);
    const parametersEstimated=options?.parametersEstimated!==false;
    let ksP=kolmogorovPValue(ksStat,sorted.length);
    let adP=andersonDarlingPValue(adStat,key,sorted.length);
    let calibration='fully-specified asymptotic';
    let iterations=0;
    let seed=null;
    if(parametersEstimated){
      iterations=Math.max(200,Math.min(5000,Math.round(Number(options?.iterations)||500)));
      seed=(Number(options?.seed)||1337)>>>0;
      const random=createStatsSeededRandom(seed);
      let ksExtreme=0;
      let adExtreme=0;
      let validIterations=0;
      for(let iteration=0;iteration<iterations;iteration++){
        const simulated=sampleFittedDistribution(key,fit,sorted.length,random).sort((a,b)=>a-b);
        const refit=def.fit(simulated);
        if(!refit?.valid || typeof refit.cdf!=='function') continue;
        const simulatedKs=computeOneSampleKsStatistic(simulated,refit.cdf);
        const simulatedAd=andersonDarlingStatistic(simulated,refit.cdf);
        if(Number.isFinite(simulatedKs) && Number.isFinite(simulatedAd)){
          validIterations+=1;
          if(simulatedKs>=ksStat-1e-15) ksExtreme+=1;
          if(simulatedAd>=adStat-1e-15) adExtreme+=1;
        }
      }
      if(validIterations){
        ksP=(ksExtreme+1)/(validIterations+1);
        adP=(adExtreme+1)/(validIterations+1);
        iterations=validIterations;
        calibration='parametric bootstrap with parameter refitting';
      }else{
        return {available:false,n:sorted.length,message:'Parametric-bootstrap goodness-of-fit calibration failed.'};
      }
    }
    return {
      available:true,alpha,n:sorted.length,pdf:fit.pdf || null,cdf:fit.cdf,fit,
      calibration,parametersEstimated,iterations,seed,
      ks:{statistic:ksStat,pValue:ksP,reject:ksP<alpha,decision:ksP<alpha?'Reject H₀':'Fail to reject H₀'},
      ad:{statistic:adStat,pValue:adP,reject:adP<alpha,decision:adP<alpha?'Reject H₀':'Fail to reject H₀'}
    };
  };

  function createLogFactorialCache(){
    return {
      values: [0],
      maxComputed: 0
    };
  }

  function ensureLogFactorialCache(cache, target){
    const store = cache || createLogFactorialCache();
    const maxTarget = Math.max(0, Math.floor(target));
    if(store.maxComputed < maxTarget){
      let running = store.values[store.maxComputed] || 0;
      for(let i = store.maxComputed + 1; i <= maxTarget; i++){
        running += Math.log(i);
        store.values[i] = running;
      }
      store.maxComputed = maxTarget;
      console.debug('Debug: stats.logFactCache extended',{ maxComputed: store.maxComputed }); // Debug: log factorial cache grow
    }
    return store;
  }

  function trimLogFactorialCache(cache, target){
    if(!cache){
      return null;
    }
    const maxTarget = Math.max(0, Math.floor(target));
    if(cache.maxComputed > maxTarget){
      cache.values.length = maxTarget + 1;
      cache.maxComputed = maxTarget;
      console.debug('Debug: stats.logFactCache trimmed',{ maxComputed: cache.maxComputed }); // Debug: log factorial cache trim
    }
    return cache;
  }

  function logChooseWithCache(n, k, cache){
    if(k < 0 || k > n){
      return -Infinity;
    }
    const prepared = ensureLogFactorialCache(cache, n);
    return prepared.values[n] - prepared.values[k] - prepared.values[n - k];
  }

  function computeHypergeometricRightTail(params){
    const {
      populationSize,
      successPopulation,
      draws,
      observedSuccesses,
      cache
    } = params || {};
    const N = Math.max(0, Math.floor(populationSize || 0));
    const K = Math.max(0, Math.floor(successPopulation || 0));
    const n = Math.max(0, Math.floor(draws || 0));
    const k = Math.max(0, Math.floor(observedSuccesses || 0));
    if(!N || !n || K < 0){
      return 0;
    }
    const store = ensureLogFactorialCache(cache?.logFactorial, N);
    if(cache){
      cache.logFactorial = store;
    }
    const denominator = logChooseWithCache(N, n, store);
    if(!Number.isFinite(denominator)){
      return 0;
    }
    let p = 0;
    const maxIter = Math.min(K, n);
    const start = Math.min(Math.max(k, 0), maxIter);
    for(let i = start; i <= maxIter; i++){
      const logTerm = logChooseWithCache(K, i, store) +
        logChooseWithCache(N - K, n - i, store) -
        denominator;
      const term = Math.exp(logTerm);
      p += term;
    }
    console.debug('Debug: stats.hypergeom right tail',{ N, K, n, k, p }); // Debug: hypergeometric right tail
    return p;
  }

  stats.clampProbability = clampProbability;
  stats.logGamma = logGamma;
  stats.regularizedGammaQ = regularizedGammaQ;
  stats.regularizedBeta = regularizedBeta;
  stats.chiSquareUpperTail = chiSquareUpperTail;
  stats.fUpperTail = fUpperTail;
  stats.studentTUpperTail = studentTUpperTail;
  stats.studentTTwoSidedPValue = studentTTwoSidedPValue;
  stats.normalUpperTail = normalUpperTail;
  stats.normalTwoSidedPValue = normalTwoSidedPValue;
  stats.normalQuantile = normalQuantile;
  stats.correlationConfidenceInterval = correlationConfidenceInterval;
  stats.finiteProbabilityOrFallback = finiteProbabilityOrFallback;

  stats.createLogFactorialCache = createLogFactorialCache;
  stats.ensureLogFactorialCache = ensureLogFactorialCache;
  stats.trimLogFactorialCache = trimLogFactorialCache;
  stats.logChooseWithCache = logChooseWithCache;
  stats.computeHypergeometricRightTail = computeHypergeometricRightTail;

  stats.listCorrections = function(){
    const list = Object.entries(METHOD_CONFIG).map(([value, cfg]) => ({ value, label: cfg.label }));
    console.debug('Debug: stats.listCorrections',{ methods: list.map(item => item.value) });
    return list;
  };



  const reporting = Shared.statsReporting = Shared.statsReporting || {};

  function humanizeAnalysisKey(key){
    if(typeof key !== 'string' || !key){
      return '';
    }
    return key
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/[_-]+/g, ' ')
      .replace(/\bci\b/gi, 'CI')
      .replace(/\baicc\b/gi, 'AICc')
      .replace(/\baic\b/gi, 'AIC')
      .replace(/\bbic\b/gi, 'BIC')
      .replace(/\bauc\b/gi, 'AUC')
      .replace(/\broc\b/gi, 'ROC')
      .replace(/\bpr\b/gi, 'PR')
      .replace(/\bpca\b/gi, 'PCA')
      .replace(/\bqq\b/gi, 'QQ')
      .replace(/\bcox\b/gi, 'Cox')
      .trim()
      .replace(/^./, char => char.toUpperCase());
  }

  function isInternalAnalysisSpecKey(key){
    return key === 'index' || key === 'key' || key === '__internal' || key === '__debug';
  }

  function sanitizeAnalysisSpecForDisplay(value){
    if(value == null || value === ''){
      return undefined;
    }
    if(Array.isArray(value)){
      const items = value
        .map(item => sanitizeAnalysisSpecForDisplay(item))
        .filter(item => item !== undefined);
      return items.length ? items : undefined;
    }
    if(typeof value === 'object'){
      const output = {};
      Object.entries(value).forEach(([key, entry]) => {
        if(isInternalAnalysisSpecKey(key)){
          return;
        }
        const cleaned = sanitizeAnalysisSpecForDisplay(entry);
        if(cleaned === undefined){
          return;
        }
        if(cleaned && typeof cleaned === 'object' && !Array.isArray(cleaned) && !Object.keys(cleaned).length){
          return;
        }
        output[key] = cleaned;
      });
      return Object.keys(output).length ? output : undefined;
    }
    return value;
  }

  function formatAnalysisSummaryValue(key, value){
    if(value == null || value === ''){
      return '';
    }
    if(typeof value === 'boolean'){
      return value ? 'Yes' : 'No';
    }
    if(typeof value === 'number'){
      if((key === 'ciLevel' || /confidence/i.test(key)) && value > 0 && value <= 1){
        return `${(value * 100).toFixed(value * 100 % 1 === 0 ? 0 : 1)}%`;
      }
      return String(value);
    }
    if(Array.isArray(value)){
      if(!value.length){
        return '';
      }
      const namedItems = value.map(item => {
        if(item && typeof item === 'object'){
          return item.header || item.label || item.name || item.value || null;
        }
        return item;
      }).filter(item => item != null && item !== '');
      if(namedItems.length){
        return namedItems.join(', ');
      }
      return `${value.length} item${value.length === 1 ? '' : 's'}`;
    }
    if(typeof value === 'object'){
      const named = value.label || value.name || value.header || value.value || null;
      if(named != null && named !== ''){
        return String(named);
      }
      return '';
    }
    return String(value);
  }

  function shouldHideAnalysisSummaryKey(key){
    if(typeof key !== 'string' || !key){
      return false;
    }
    const normalized = key.trim();
    return normalized === 'schemaVersion'
      || normalized === 'seed'
      || normalized === 'randomSeed'
      || normalized === 'generatedAt'
      || normalized === 'hazardRatioRows'
      || normalized === 'coxCoefficientCount'
      || normalized === 'logRankAvailable'
      || normalized === 'rowCount'
      || normalized === 'columnCount'
      || normalized === 'colCount'
      || normalized === 'pointCount';
  }

  function copyReportTextToClipboard(text, button){
    const value = typeof text === 'string' ? text : String(text ?? '');
    const onDebug = typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled();
    const setButtonState = (label, isError) => {
      if(!button){
        return;
      }
      button.textContent = label;
      if(isError){
        button.dataset.copyState = 'error';
      }else if(label === 'Copied'){
        button.dataset.copyState = 'copied';
      }else{
        delete button.dataset.copyState;
      }
    };
    const resetLater = () => {
      if(!button){
        return;
      }
      global.setTimeout(() => {
        button.textContent = 'Copy';
        delete button.dataset.copyState;
      }, 1600);
    };
    const fallbackCopy = () => {
      if(!global.document || !global.document.createElement || !global.document.body){
        return false;
      }
      const textarea = global.document.createElement('textarea');
      textarea.value = value;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      textarea.style.pointerEvents = 'none';
      global.document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      let ok = false;
      try{
        ok = typeof global.document.execCommand === 'function' ? !!global.document.execCommand('copy') : false;
      }catch(error){
        if(onDebug){
          console.debug('Debug: statsReporting.copyReportTextToClipboard fallback failed', { message: error?.message || String(error) });
        }
        ok = false;
      }
      global.document.body.removeChild(textarea);
      return ok;
    };
    const complete = copied => {
      if(copied){
        setButtonState('Copied', false);
      }else{
        setButtonState('Copy failed', true);
      }
      resetLater();
      if(onDebug){
        console.debug('Debug: statsReporting.copyReportTextToClipboard', { copied, length: value.length });
      }
      return copied;
    };
    try{
      if(global.navigator?.clipboard?.writeText){
        return global.navigator.clipboard.writeText(value)
          .then(() => complete(true))
          .catch(error => {
            if(onDebug){
              console.debug('Debug: statsReporting.copyReportTextToClipboard navigator fallback', { message: error?.message || String(error) });
            }
            return complete(fallbackCopy());
          });
      }
    }catch(error){
      if(onDebug){
        console.debug('Debug: statsReporting.copyReportTextToClipboard navigator failed', { message: error?.message || String(error) });
      }
    }
    return Promise.resolve(complete(fallbackCopy()));
  }

  function createReportBlockHeader(documentRef, labelText, copyText){
    const row = documentRef.createElement('div');
    row.className = 'stats-report-panel__header';
    const label = documentRef.createElement('div');
    label.className = 'stats-table-lead';
    label.textContent = labelText;
    row.appendChild(label);
    const button = documentRef.createElement('button');
    button.type = 'button';
    button.className = 'stats-report-panel__copy-btn';
    button.textContent = 'Copy';
    button.__statsReportCopyText = String(copyText || '');
    button.setAttribute('aria-label', `${labelText}: copy to clipboard`);
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      copyReportTextToClipboard(button.__statsReportCopyText || '', button);
    });
    row.appendChild(button);
    return row;
  }

  function buildAnalysisSummaryLines(spec){
    const cleaned = sanitizeAnalysisSpecForDisplay(spec);
    if(!cleaned || typeof cleaned !== 'object'){
      return [];
    }
    const priorityKeys = [
      'component','testFamily','test','analysis','analysisMode','mode','regressionMode','associationMethod','metric',
      'groupCount','paired','alternative','alpha','ciLevel','correction','fitMethod','fitModel','fitEquation',
      'showHazardRatios','fitCox','covariates','selectedColumns','referenceIndex','postHoc'
    ];
    const seen = new Set();
    const lines = [];
    const pushLine = (label, value) => {
      if(!label || value == null || value === ''){
        return;
      }
      lines.push({ label, value: String(value) });
    };
    const processEntry = (key, value, prefix) => {
      if(value == null || value === '' || shouldHideAnalysisSummaryKey(key)){
        return;
      }
      const label = prefix ? `${prefix}: ${humanizeAnalysisKey(key)}` : humanizeAnalysisKey(key);
      if(Array.isArray(value) || typeof value !== 'object'){
        pushLine(label, formatAnalysisSummaryValue(key, value));
        return;
      }
      const compactValue = formatAnalysisSummaryValue(key, value);
      if(compactValue){
        pushLine(label, compactValue);
        return;
      }
      Object.entries(value).forEach(([childKey, childValue]) => {
        processEntry(childKey, childValue, label);
      });
    };

    priorityKeys.forEach(key => {
      if(Object.prototype.hasOwnProperty.call(cleaned, key)){
        seen.add(key);
        processEntry(key, cleaned[key], '');
      }
    });
    Object.entries(cleaned).forEach(([key, value]) => {
      if(seen.has(key) || shouldHideAnalysisSummaryKey(key)){
        return;
      }
      processEntry(key, value, '');
    });
    return lines.filter(line => line.value && line.value !== 'null').slice(0, 14);
  }

  function appendAnalysisSummaryBlock(target, lines, documentRef){
    if(!target || !Array.isArray(lines) || !lines.length || !documentRef || !documentRef.createElement){
      return;
    }
    const summaryText = lines.map(line => `${line.label}: ${line.value}`).join('\n');
    target.appendChild(createReportBlockHeader(documentRef, 'Configuration summary', summaryText));

    const list = documentRef.createElement('ul');
    list.className = 'stats-report-panel__summary-list';
    lines.forEach(line => {
      const item = documentRef.createElement('li');
      item.className = 'stats-report-panel__summary-item';
      const strong = documentRef.createElement('strong');
      strong.textContent = `${line.label}: `;
      item.appendChild(strong);
      item.appendChild(documentRef.createTextNode(line.value));
      list.appendChild(item);
    });
    target.appendChild(list);
  }

  function cloneStatsReportingValue(value){
    if(value == null || typeof value !== 'object'){
      return value;
    }
    try{
      if(typeof global.structuredClone === 'function'){
        return global.structuredClone(value);
      }
    }catch(_err){}
    try{ return JSON.parse(JSON.stringify(value)); }
    catch(_err){ return value; }
  }

  function isStatsReportPValueObject(value){
    if(!value || typeof value !== 'object'){
      return false;
    }
    if(Object.prototype.hasOwnProperty.call(value, '__statsPValueRaw')){
      return true;
    }
    const type = typeof value.type === 'string' ? value.type.toLowerCase() : '';
    return type === 'pvalue' || type === 'p-value' || type === 'p_value';
  }

  function normalizeStatsReportPValueToken(value){
    if(!isStatsReportPValueObject(value)){
      return null;
    }
    const rawSource = Object.prototype.hasOwnProperty.call(value, '__statsPValueRaw')
      ? value.__statsPValueRaw
      : value.value;
    const raw = rawSource == null || rawSource === '' ? NaN : Number(rawSource);
    const operator = typeof value.operator === 'string' && value.operator.trim()
      ? value.operator.trim()
      : (typeof value.__statsPValueOperator === 'string' && value.__statsPValueOperator.trim() ? value.__statsPValueOperator.trim() : '=');
    const fallback = typeof value.fallback === 'string'
      ? value.fallback
      : (typeof value.text === 'string' ? value.text : '—');
    return {
      type: 'pValue',
      value: raw,
      operator,
      fallback
    };
  }

  function normalizeStatsReportTextParts(value){
    const parts = [];
    const push = item => {
      if(item == null || item === false){
        return;
      }
      if(Array.isArray(item)){
        item.forEach(push);
        return;
      }
      const pValueToken = normalizeStatsReportPValueToken(item);
      if(pValueToken){
        parts.push(pValueToken);
        return;
      }
      if(item && typeof item === 'object' && typeof item.text === 'string'){
        parts.push({ type: 'text', text: item.text });
        return;
      }
      parts.push({ type: 'text', text: String(item) });
    };
    push(value);
    const merged = [];
    parts.forEach(part => {
      if(!part){
        return;
      }
      if(part.type === 'text'){
        if(!part.text){
          return;
        }
        const previous = merged[merged.length - 1];
        if(previous && previous.type === 'text'){
          previous.text += part.text;
        }else{
          merged.push({ type: 'text', text: part.text });
        }
        return;
      }
      merged.push(part);
    });
    return merged;
  }

  function renderStatsReportTextParts(parts, options = {}){
    const scientific = options.scientific === true;
    return normalizeStatsReportTextParts(parts).map(part => {
      if(part.type === 'pValue'){
        const formatted = formatPValueFromParsedInfo({ value: part.value, operator: part.operator || '=' }, { scientific });
        return formatted == null ? (part.fallback || '—') : String(formatted);
      }
      return String(part.text || '');
    }).join('');
  }

  function getReportSourceParts(source, baseName){
    const candidates = [
      `${baseName}Parts`,
      `${baseName}Segments`,
      `${baseName}Fragments`
    ];
    for(let index = 0; index < candidates.length; index += 1){
      const key = candidates[index];
      if(Object.prototype.hasOwnProperty.call(source, key) && source[key] != null){
        return source[key];
      }
    }
    const textKey = `${baseName}Text`;
    return Object.prototype.hasOwnProperty.call(source, textKey) ? source[textKey] : '';
  }

  function normalizeReportModel(report, options = {}){
    const source = report && typeof report === 'object' ? report : {};
    const title = typeof options?.title === 'string' && options.title.trim()
      ? options.title.trim()
      : (typeof source.title === 'string' && source.title.trim() ? source.title.trim() : 'Reporting and reproducibility');
    const methodsParts = normalizeStatsReportTextParts(getReportSourceParts(source, 'methods'));
    const resultsParts = normalizeStatsReportTextParts(getReportSourceParts(source, 'results'));
    return {
      schemaVersion: 2,
      kind: 'stats-report',
      title,
      methodsLabel: typeof options?.methodsLabel === 'string' && options.methodsLabel.trim()
        ? options.methodsLabel.trim()
        : (typeof source.methodsLabel === 'string' && source.methodsLabel.trim() ? source.methodsLabel.trim() : 'Methods text'),
      resultsLabel: typeof options?.resultsLabel === 'string' && options.resultsLabel.trim()
        ? options.resultsLabel.trim()
        : (typeof source.resultsLabel === 'string' && source.resultsLabel.trim() ? source.resultsLabel.trim() : 'Results text'),
      specLabel: typeof options?.specLabel === 'string' && options.specLabel.trim()
        ? options.specLabel.trim()
        : (typeof source.specLabel === 'string' && source.specLabel.trim() ? source.specLabel.trim() : 'Technical analysis record (advanced)'),
      methodsText: renderStatsReportTextParts(methodsParts, { scientific: DEFAULT_PVALUE_FORMAT_SCIENTIFIC }),
      resultsText: renderStatsReportTextParts(resultsParts, { scientific: DEFAULT_PVALUE_FORMAT_SCIENTIFIC }),
      methodsParts,
      resultsParts,
      analysisSpec: cloneStatsReportingValue(source.analysisSpec || options?.analysisSpecFallback || null)
    };
  }

  reporting.appendReportPanel = function appendReportPanel(target, report, options){
    const documentRef = global.document;
    if(!target || !report || !documentRef || !documentRef.createElement){
      return;
    }
    const reportModel = normalizeReportModel(report, options || {});
    if(typeof reporting.clearReportHost === 'function' && options?.replaceExisting !== false){
      reporting.clearReportHost(target);
    }
    let reportTarget = resolveReportingHost(target);
    if(
      target
      && reportTarget
      && reportTarget !== target
      && !reportTarget.isConnected
      && typeof reporting.ensureReportHost === 'function'
    ){
      reportTarget = reporting.ensureReportHost(target, { attachToTarget: true, position: 'last' }) || reportTarget;
    }
    if(!reportTarget || !reportTarget.appendChild){
      reportTarget = target;
    }
    const panel = documentRef.createElement('details');
    panel.className = 'stats-report-panel';
    panel.dataset.statsReporting = '1';
    panel.__statsReportModel = cloneStatsReportingValue(reportModel);
    const summary = documentRef.createElement('summary');
    summary.textContent = reportModel.title;
    panel.appendChild(summary);

    const scientific = getPanelPValueScientific(target);
    const addBlock = (blockName, labelText, parts) => {
      const normalizedText = renderStatsReportTextParts(parts, { scientific });
      const header = createReportBlockHeader(documentRef, labelText, normalizedText);
      header.dataset.statsReportBlockHeader = blockName;
      panel.appendChild(header);
      const pre = documentRef.createElement('pre');
      pre.dataset.statsReportBlock = blockName;
      pre.dataset.statsReportStructured = '1';
      pre.textContent = normalizedText;
      panel.appendChild(pre);
    };

    addBlock('methods', reportModel.methodsLabel, reportModel.methodsParts || reportModel.methodsText || '');
    addBlock('results', reportModel.resultsLabel, reportModel.resultsParts || reportModel.resultsText || '');

    const spec = reportModel.analysisSpec || null;
    const displaySpec = sanitizeAnalysisSpecForDisplay(spec);
    const summaryLines = buildAnalysisSummaryLines(displaySpec);
    if(summaryLines.length){
      appendAnalysisSummaryBlock(panel, summaryLines, documentRef);
    }
    if(displaySpec){
      const advanced = documentRef.createElement('details');
      advanced.className = 'stats-report-panel__advanced';
      const advancedSummary = documentRef.createElement('summary');
      advancedSummary.textContent = reportModel.specLabel;
      advanced.appendChild(advancedSummary);
      const note = documentRef.createElement('p');
      note.className = 'stats-report-panel__note';
      note.textContent = 'Machine-readable analysis settings snapshot kept for reproducibility and troubleshooting.';
      advanced.appendChild(note);
      const advancedJson = JSON.stringify(displaySpec, null, 2);
      advanced.appendChild(createReportBlockHeader(documentRef, 'Technical analysis record', advancedJson));
      const pre = documentRef.createElement('pre');
      pre.textContent = advancedJson;
      advanced.appendChild(pre);
      panel.appendChild(advanced);
    }

    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: statsReporting.appendReportPanel',{ title: reportModel.title, hasMethods: !!reportModel.methodsText, hasResults: !!reportModel.resultsText, hasAnalysisSpec: !!displaySpec });
    }
    reportTarget.appendChild(panel);
    if(reportTarget && typeof reportTarget === 'object'){
      reportTarget.__statsReportModel = cloneStatsReportingValue(reportModel);
    }
    if(typeof reporting.pinReportHostLast === 'function'){
      reporting.pinReportHostLast(target);
    }
  };

  const SIGNIFICANCE_THRESHOLD_STORAGE_KEY = 'venn.stats.significanceThreshold';
  const DEFAULT_SIGNIFICANCE_THRESHOLD = 0.05;
  const STATS_PANEL_SELECTORS = [
    '#statsResults',
    '#scatterStatsResults',
    '#lineStatsResults',
    '#rocStatsResults',
    '#histStatsResults',
    '#pieStatsResults',
    '#heatmapStatsContent',
    '#pcaStatsResults',
    '#surfaceStatsSummary',
    '#survivalStatsSummary',
    '#survivalStatsLogRank',
    '#survivalStatsHazardRatios',
    '#survivalStatsCox'
  ];
  const COLLAPSED_STATS_SECTIONS = new Set(['diagnostics', 'supplementary']);
  const STATS_SECTION_ORDER = Object.freeze({
    summary: 0,
    estimates: 1,
    comparisons: 2,
    diagnostics: 3,
    supplementary: 4,
    descriptive: 5
  });

  function readStatsSection(node){
    if(!node || node.nodeType !== 1){
      return 'summary';
    }
    const section = String(node.getAttribute('data-stats-section') || '').trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(STATS_SECTION_ORDER, section) ? section : 'summary';
  }
  const panelEnhancerState = new WeakMap();
  const enhancedStatsPanels = new Set();
  const TRACKED_STATS_PANEL_IDS = STATS_PANEL_SELECTORS
    .filter(selector => typeof selector === 'string' && selector.startsWith('#'))
    .map(selector => selector.slice(1))
    .filter(Boolean);
  const trackedStatsPanelIdSet = new Set(TRACKED_STATS_PANEL_IDS);
  let panelsInstallAttempted = false;
  let panelInstallRescanObserver = null;
  let panelInstallRescanScheduled = false;

  function statsReportingDebug(label, payload){
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug(`Debug: statsReporting.${label}`, payload || {});
    }
  }

  function sanitizeSignificanceThreshold(value, fallback){
    const fallbackValue = Number.isFinite(fallback) && fallback > 0 && fallback <= 1
      ? fallback
      : DEFAULT_SIGNIFICANCE_THRESHOLD;
    const numeric = Number(value);
    if(!Number.isFinite(numeric) || numeric <= 0){
      return fallbackValue;
    }
    if(numeric > 1){
      return 1;
    }
    return numeric;
  }

  function formatThresholdLabel(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)){
      return String(DEFAULT_SIGNIFICANCE_THRESHOLD);
    }
    if(numeric >= 0.01){
      return numeric.toFixed(3).replace(/0+$/,'').replace(/\.$/, '');
    }
    return numeric.toExponential(2);
  }

  function getStoredSignificanceThreshold(){
    try{
      if(global.localStorage){
        const stored = global.localStorage.getItem(SIGNIFICANCE_THRESHOLD_STORAGE_KEY);
        if(stored != null && stored !== ''){
          return sanitizeSignificanceThreshold(stored, DEFAULT_SIGNIFICANCE_THRESHOLD);
        }
      }
    }catch(err){
      statsReportingDebug('readThresholdStorageError', { message: err?.message || String(err) });
    }
    return DEFAULT_SIGNIFICANCE_THRESHOLD;
  }

  let sharedSignificanceThreshold = getStoredSignificanceThreshold();

  function persistSignificanceThreshold(value){
    try{
      if(global.localStorage){
        global.localStorage.setItem(SIGNIFICANCE_THRESHOLD_STORAGE_KEY, String(value));
      }
    }catch(err){
      statsReportingDebug('writeThresholdStorageError', { message: err?.message || String(err) });
    }
  }

  function getPValueFormatLabel(scientific){
    return scientific ? 'Scientific' : 'Decimal';
  }

  function getPValueFormatButtonLabel(scientific){
    return scientific ? 'Decimal' : 'Scientific';
  }

  function formatPValueFromParsedInfo(pInfo, options){
    if(!pInfo || !Number.isFinite(Number(pInfo.value))){
      return null;
    }
    const numeric = Number(pInfo.value);
    const operator = typeof pInfo.operator === 'string' ? pInfo.operator.trim() : '=';
    const scientific = options?.scientific === true;
    const formatted = sharedFormatPValue(numeric, { scientific, forceScientific: scientific });
    const formattedText = String(formatted);
    if(scientific){
      return formatted;
    }
    if(operator === '<' || operator === '<='){
      return formattedText.startsWith('<')
        ? formatted
        : `<${formattedText.replace(/^[<>=\s]+/, '')}`;
    }
    if(operator === '>' || operator === '>='){
      return formattedText.startsWith('>')
        ? formatted
        : `>${formattedText.replace(/^[<>=\s]+/, '')}`;
    }
    return formatted;
  }

  function formatInlinePValueReplacement(label, operator, numericText, options){
    const numeric = Number(numericText);
    if(!Number.isFinite(numeric)){
      return null;
    }
    const display = formatPValueFromParsedInfo({ value: numeric, operator: operator || '=' }, options);
    if(display == null){
      return null;
    }
    const normalizedOperator = typeof operator === 'string' ? operator.trim() : '=';
    const displayText = String(display);
    if(normalizedOperator === '<' || normalizedOperator === '<=' || normalizedOperator === '>' || normalizedOperator === '>='){
      if(options?.scientific === true){
        return `${label}= ${displayText}`;
      }
      const symbolLength = (displayText.startsWith('<=') || displayText.startsWith('>=')) ? 2 : 1;
      const symbol = displayText.slice(0, symbolLength);
      const valueText = displayText.slice(symbolLength).trim();
      return `${label}${symbol} ${valueText}`;
    }
    return `${label}${normalizedOperator || '='} ${displayText}`;
  }

  function replaceInlinePValueText(text, options){
    const source = String(text == null ? '' : text);
    if(!source){
      return source;
    }
    const scientific = options?.scientific === true;
    return source.replace(
      /(\b(?:p(?:\s*[-]?\s*value)?|padj|p\s*\([^)]+\))\b(?:\s*\([^)]+\))?\s*)([<>]=?|=)\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)/gi,
      (match, label, operator, numericText) => {
        return formatInlinePValueReplacement(label, operator, numericText, { scientific }) || match;
      }
    );
  }

  function createDefaultPValueFormatControl(documentRef, target){
    if(!documentRef || !documentRef.createElement){
      return null;
    }
    const scientific = getPanelPValueScientific(target);
    const wrap = documentRef.createElement('span');
    wrap.className = 'stats-pvalue-format-inline';
    const label = documentRef.createElement('span');
    label.className = 'stats-pvalue-format-inline__label';
    label.textContent = `P-value format: ${getPValueFormatLabel(scientific)}`;
    wrap.appendChild(label);
    const button = documentRef.createElement('button');
    button.type = 'button';
    button.className = 'stats-pvalue-format-toggle';
    button.textContent = getPValueFormatButtonLabel(scientific);
    button.setAttribute('data-undo-ignore', '1');
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      reporting.setPValueFormatScientific(!getPanelPValueScientific(target), { target, source: target?.id || null });
    });
    wrap.appendChild(button);
    return wrap;
  }

  function setReportBlockCopyText(panel, blockName, text){
    if(!panel || typeof panel.querySelector !== 'function'){
      return;
    }
    const header = panel.querySelector(`:scope > .stats-report-panel__header[data-stats-report-block-header="${blockName}"]`);
    const button = header?.querySelector?.('.stats-report-panel__copy-btn') || null;
    if(button){
      button.__statsReportCopyText = String(text || '');
    }
  }

  function rerenderStructuredReportPanel(panel, target){
    if(!panel || panel.nodeType !== 1){
      return false;
    }
    const storedModel = panel.__statsReportModel;
    if(!storedModel || typeof storedModel !== 'object'){
      return false;
    }
    const model = normalizeReportModel(storedModel, storedModel);
    const scientific = getPanelPValueScientific(target || panel);
    const methodsText = renderStatsReportTextParts(model.methodsParts || model.methodsText || '', { scientific });
    const resultsText = renderStatsReportTextParts(model.resultsParts || model.resultsText || '', { scientific });
    const methodsBlock = panel.querySelector(':scope > pre[data-stats-report-block="methods"]')
      || Array.from(panel.querySelectorAll(':scope > pre'))[0];
    const resultsBlock = panel.querySelector(':scope > pre[data-stats-report-block="results"]')
      || Array.from(panel.querySelectorAll(':scope > pre'))[1];
    if(methodsBlock){
      methodsBlock.dataset.statsReportStructured = '1';
      methodsBlock.textContent = methodsText;
      setReportBlockCopyText(panel, 'methods', methodsText);
    }
    if(resultsBlock){
      resultsBlock.dataset.statsReportStructured = '1';
      resultsBlock.textContent = resultsText;
      setReportBlockCopyText(panel, 'results', resultsText);
    }
    panel.__statsReportModel = cloneStatsReportingValue(model);
    return true;
  }

  function rerenderStructuredReportPanels(target){
    if(!target || typeof target.querySelectorAll !== 'function'){
      return;
    }
    const panels = target.classList?.contains('stats-report-panel')
      ? [target]
      : Array.from(target.querySelectorAll('.stats-report-panel'));
    panels.forEach(panel => rerenderStructuredReportPanel(panel, target));
  }

  function rewriteInlinePValueElements(target){
    if(!target || typeof target.querySelectorAll !== 'function'){
      return;
    }
    const scientific = getPanelPValueScientific(target);
    rerenderStructuredReportPanels(target);
    const elements = target.querySelectorAll(
      '.stats-report-panel pre, .stats-report-panel__summary-item, .stats-table-footnote, .stats-table-lead, .stats-assumption-section .assumption-detail'
    );
    elements.forEach(element => {
      if(!element || element.closest('.stats-significance-controls')){
        return;
      }
      const reportPanel = element.closest?.('.stats-report-panel') || null;
      if(reportPanel?.__statsReportModel && element.dataset?.statsReportStructured === '1'){
        return;
      }
      const structuredParts = Array.isArray(element.__statsTextParts) ? element.__statsTextParts : null;
      if(structuredParts){
        const rendered = renderStatsReportTextParts(structuredParts, { scientific });
        if(rendered !== element.textContent){
          element.textContent = rendered;
        }
        return;
      }
      const source = element.dataset.statsPvalueSourceText || element.textContent || '';
      if(!element.dataset.statsPvalueSourceText){
        element.dataset.statsPvalueSourceText = source;
      }
      const replaced = replaceInlinePValueText(source, { scientific });
      if(replaced !== element.textContent){
        element.textContent = replaced;
      }
    });
  }

  function getElementStoredPValueInfo(element){
    if(!element || element.nodeType !== 1){
      return null;
    }
    const rawValue = element.dataset?.statsPvalueRaw;
    if(rawValue == null || rawValue === ''){
      return null;
    }
    const numeric = Number(rawValue);
    if(!Number.isFinite(numeric)){
      return null;
    }
    const operator = typeof element.dataset?.statsPvalueOperator === 'string' && element.dataset.statsPvalueOperator
      ? element.dataset.statsPvalueOperator
      : '=';
    return { value: numeric, operator };
  }

  function parseElementPValue(element, options){
    return getElementStoredPValueInfo(element) || parsePValue(element?.textContent, options);
  }

  function rewriteTablePValueCells(table, target){
    if(!table || typeof table.querySelectorAll !== 'function'){
      return;
    }
    const scientific = getPanelPValueScientific(target || table.closest?.('.stats-results-main, .stats-results-advanced-panel') || table.parentElement);
    let headerCells = Array.from(table.querySelectorAll('thead tr th'));
    if(!headerCells.length){
      const firstRow = table.querySelector('tr');
      if(firstRow && firstRow.querySelector('th')){
        headerCells = Array.from(firstRow.querySelectorAll('th'));
      }
    }
    const pColumnIndexes = [];
    headerCells.forEach((cell, index) => {
      if(isPLabel(cell?.textContent || '')){
        pColumnIndexes.push(index);
      }
    });
    let bodyRows = Array.from(table.querySelectorAll('tbody tr'));
    if(!bodyRows.length){
      const allRows = Array.from(table.querySelectorAll('tr'));
      if(allRows.length){
        const firstRowCells = Array.from(allRows[0].cells || []);
        const firstRowIsHeader = firstRowCells.some(cell => String(cell.tagName || '').toLowerCase() === 'th');
        bodyRows = firstRowIsHeader ? allRows.slice(1) : allRows;
      }
    }
    const rewriteBareCell = cell => {
      if(!cell){
        return;
      }
      const stored = getElementStoredPValueInfo(cell);
      let parsed = stored;
      if(!parsed){
        const source = cell.dataset.statsPvalueSourceText || cell.textContent || '';
        if(!cell.dataset.statsPvalueSourceText){
          cell.dataset.statsPvalueSourceText = source;
        }
        parsed = parsePValue(source, { allowBare: true });
      }
      const formatted = formatPValueFromParsedInfo(parsed, { scientific });
      if(formatted != null){
        cell.textContent = String(formatted);
      }
    };
    bodyRows.forEach(row => {
      const cells = Array.from(row.cells || []);
      if(!cells.length){
        return;
      }
      pColumnIndexes.forEach(index => {
        rewriteBareCell(cells[index]);
      });
      if(cells.length >= 2 && isPLabel(cells[0]?.textContent || '')){
        rewriteBareCell(cells[cells.length - 1]);
      }
    });
  }

  function parsePValue(rawText, options){
    const source = String(rawText == null ? '' : rawText)
      .replace(/\u2212/g, '-')
      .replace(/,/g, '')
      .trim();
    if(!source){
      return null;
    }
    const explicitMatch = source.match(/\bp(?:\s*[-]?\s*value)?\b[^0-9<>=]*([<>]=?|=)\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)/i);
    if(explicitMatch){
      const numeric = Number(explicitMatch[2]);
      if(Number.isFinite(numeric)){
        return { value: numeric, operator: explicitMatch[1] || '=' };
      }
    }
    const compactMatch = source.match(/\bp(?:adj|adj\.|value|val)?\s*[:=]\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)/i);
    if(compactMatch){
      const numeric = Number(compactMatch[1]);
      if(Number.isFinite(numeric)){
        return { value: numeric, operator: '=' };
      }
    }
    if(options?.allowBare === true){
      const bareMatch = source.match(/^([<>]=?|=)?\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)$/i);
      if(bareMatch){
        const numeric = Number(bareMatch[2]);
        if(Number.isFinite(numeric)){
          return { value: numeric, operator: bareMatch[1] || '=' };
        }
      }
    }
    return null;
  }

  function isPLabel(text){
    const source = String(text || '').toLowerCase();
    return /\b(?:p|p[-\s]?value|p[-\s]?val|adj(?:usted)?\s*p|padj|p\*)\b/.test(source);
  }

  function resolveSignificanceToken(pInfo, threshold){
    if(!pInfo || !Number.isFinite(pInfo.value)){
      return null;
    }
    const alpha = sanitizeSignificanceThreshold(threshold, DEFAULT_SIGNIFICANCE_THRESHOLD);
    const operator = typeof pInfo.operator === 'string' ? pInfo.operator : '=';
    const value = pInfo.value;
    const isSignificant = (operator === '>' || operator === '>=') ? false : (value <= alpha);
    if(!isSignificant){
      return 'NS';
    }
    if(value <= alpha / 1000){
      return '****';
    }
    if(value <= alpha / 100){
      return '***';
    }
    if(value <= alpha / 10){
      return '**';
    }
    return '*';
  }

  function renderSignificanceBadge(cell, pInfo, threshold){
    if(!cell || typeof cell.querySelectorAll !== 'function'){
      return false;
    }
    cell.querySelectorAll('.stats-significance-badge').forEach(node => {
      try{
        node.remove();
      }catch(err){}
    });
    const token = resolveSignificanceToken(pInfo, threshold);
    if(!token || !cell.ownerDocument || typeof cell.ownerDocument.createElement !== 'function'){
      return false;
    }
    const badge = cell.ownerDocument.createElement('span');
    badge.className = `stats-significance-badge ${token === 'NS' ? 'stats-significance-badge--ns' : 'stats-significance-badge--sig'}`;
    badge.textContent = token;
    const thresholdLabel = formatThresholdLabel(threshold);
    badge.title = `Significance summary at p <= ${thresholdLabel}`;
    cell.appendChild(badge);
    return true;
  }

  function annotateTablePValues(table, threshold){
    if(!table || typeof table.querySelectorAll !== 'function'){
      return 0;
    }
    let headerCells = Array.from(table.querySelectorAll('thead tr th'));
    if(!headerCells.length){
      const firstRow = table.querySelector('tr');
      if(firstRow && firstRow.querySelector('th')){
        headerCells = Array.from(firstRow.querySelectorAll('th'));
      }
    }
    const pColumnIndexes = [];
    headerCells.forEach((cell, index) => {
      if(isPLabel(cell?.textContent || '')){
        pColumnIndexes.push(index);
      }
    });
    let badgeCount = 0;
    let bodyRows = Array.from(table.querySelectorAll('tbody tr'));
    if(!bodyRows.length){
      const allRows = Array.from(table.querySelectorAll('tr'));
      if(allRows.length){
        const firstRowCells = Array.from(allRows[0].cells || []);
        const firstRowIsHeader = firstRowCells.some(cell => String(cell.tagName || '').toLowerCase() === 'th');
        bodyRows = firstRowIsHeader ? allRows.slice(1) : allRows;
      }
    }
    bodyRows.forEach(row => {
      const cells = Array.from(row.cells || []);
      if(!cells.length){
        return;
      }
      const taggedCells = new Set();
      pColumnIndexes.forEach(index => {
        const candidate = cells[index];
        if(!candidate){
          return;
        }
        const parsed = parseElementPValue(candidate, { allowBare: true });
        if(renderSignificanceBadge(candidate, parsed, threshold)){
          badgeCount += 1;
          taggedCells.add(candidate);
        }
      });
      if(cells.length >= 2 && isPLabel(cells[0]?.textContent || '')){
        const candidate = cells[cells.length - 1];
        if(candidate && !taggedCells.has(candidate)){
          const parsed = parseElementPValue(candidate, { allowBare: true });
          if(renderSignificanceBadge(candidate, parsed, threshold)){
            badgeCount += 1;
            taggedCells.add(candidate);
          }
        }
      }
      cells.forEach(cell => {
        if(taggedCells.has(cell)){
          return;
        }
        const parsed = parseElementPValue(cell, { allowBare: false });
        if(renderSignificanceBadge(cell, parsed, threshold)){
          badgeCount += 1;
          taggedCells.add(cell);
        }
      });
    });
    return badgeCount;
  }

  function isAdvancedNode(node){
    if(!node || node.nodeType !== 1){
      return false;
    }
    if(node.classList.contains('stats-report-panel') || node.classList.contains('stats-report-panel__advanced')){
      return false;
    }
    return COLLAPSED_STATS_SECTIONS.has(readStatsSection(node));
  }

  function isReportingNode(node){
    if(!node || node.nodeType !== 1){
      return false;
    }
    if(node.getAttribute('data-stats-reporting') === '1'){
      return true;
    }
    return node.classList.contains('stats-report-panel') || node.classList.contains('stats-report-panel__advanced');
  }

  function resolveReportingHost(target){
    const explicitHost = target && target.__statsReportHost;
    if(explicitHost && explicitHost.nodeType === 1){
      return explicitHost;
    }
    return target || null;
  }

  function resolveReportingHostParent(target){
    if(!target || target.nodeType !== 1){
      return null;
    }
    const explicitHost = target.__statsReportHost;
    if(explicitHost && explicitHost.nodeType === 1 && explicitHost.parentNode === target){
      return target;
    }
    if(target.classList?.contains('stats-report-host') && target.parentNode?.nodeType === 1){
      return target.parentNode;
    }
    return null;
  }

  reporting.ensureReportHost = function ensureReportHost(target, options = {}){
    if(!target || target.nodeType !== 1){
      return null;
    }
    const documentRef = target.ownerDocument || global.document;
    if(!documentRef || typeof documentRef.createElement !== 'function'){
      return null;
    }
    const desiredId = typeof options.id === 'string' && options.id.trim()
      ? options.id.trim()
      : null;
    let host = target.__statsReportHost;
    if((!host || host.nodeType !== 1) && desiredId && typeof documentRef.getElementById === 'function'){
      const existing = documentRef.getElementById(desiredId);
      if(existing && existing.nodeType === 1){
        host = existing;
      }
    }
    if(!host || host.nodeType !== 1){
      host = documentRef.createElement('div');
    }
    if(desiredId){
      host.id = desiredId;
    }
    const desiredClassName = typeof options.className === 'string' && options.className.trim()
      ? options.className.trim()
      : (host.className || 'stats-report-host');
    host.className = desiredClassName;
    target.__statsReportHost = host;
    if(options.attachToTarget !== false && typeof target.appendChild === 'function'){
      if(host.parentNode !== target){
        target.appendChild(host);
      }
      if(options.position === 'first'){
        if(target.firstElementChild !== host){
          target.insertBefore(host, target.firstChild || null);
        }
      }else if(options.position !== 'keep' && target.lastElementChild !== host){
        target.appendChild(host);
      }
    }
    if(options.migrateReportPanels && host.parentNode === target){
      const strayPanels = Array.from(target.children || []).filter(node => node !== host && isReportingNode(node));
      strayPanels.forEach(panel => {
        host.appendChild(panel);
      });
    }
    if(typeof reporting.pinReportHostLast === 'function'){
      reporting.pinReportHostLast(target);
    }
    return host;
  };

  reporting.pinReportHostLast = function pinReportHostLast(target){
    const parent = resolveReportingHostParent(target);
    if(!parent || typeof parent.appendChild !== 'function'){
      return false;
    }
    const host = resolveReportingHost(parent);
    if(!host || host === parent || host.parentNode !== parent){
      return false;
    }
    if(parent.lastElementChild !== host){
      parent.appendChild(host);
      return true;
    }
    return false;
  };

  reporting.clearReportHost = function clearReportHost(target){
    const reportHost = resolveReportingHost(target);
    if(!reportHost || reportHost.nodeType !== 1){
      return false;
    }
    if(reportHost !== target){
      reportHost.innerHTML = '';
      delete reportHost.__statsReportModel;
      delete reportHost.__statsPanelModel;
      return true;
    }
    let removed = false;
    Array.from(reportHost.children || []).forEach(node => {
      if(isReportingNode(node)){
        reportHost.removeChild(node);
        removed = true;
      }
    });
    if(removed){
      delete reportHost.__statsReportModel;
      delete reportHost.__statsPanelModel;
    }
    return removed;
  };

  const STATS_MODEL_ALLOWED_TAGS = new Set([
    'div', 'p', 'span', 'strong', 'em', 'i', 'b', 'small',
    'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption',
    'ul', 'ol', 'li', 'details', 'summary', 'pre', 'br'
  ]);
  const STATS_MODEL_ALLOWED_CLASS_PREFIXES = [
    'stats-', 'variance-', 'pca-', 'box-', 'scatter-', 'line-', 'roc-', 'hist-', 'pie-', 'survival-', 'heatmap-', 'surface-'
  ];

  function sanitizeStatsClassName(value){
    if(typeof value !== 'string' || !value.trim()){
      return '';
    }
    return value.split(/\s+/)
      .filter(name => STATS_MODEL_ALLOWED_CLASS_PREFIXES.some(prefix => name.startsWith(prefix)))
      .join(' ');
  }

  function captureStatsNodeModel(node){
    if(!node){
      return null;
    }
    if(node.nodeType === 3){
      const text = String(node.nodeValue || '');
      return text ? { type: 'text', text } : null;
    }
    if(node.nodeType !== 1){
      return null;
    }
    // Stats-table cards carry interactive Download/Copy export controls
    // that the tag whitelist below would mangle into raw text and that cannot be re-wired
    // from markup. Capture the card's plain data model instead and re-render it (with live
    // controls) on restore — see renderStatsNodeModel.
    if(node.__statsTableModel && typeof node.__statsTableModel === 'object'){
      const captured = { type: 'stats-table', model: cloneStatsReportingValue(node.__statsTableModel) };
      const cardClass = sanitizeStatsClassName(node.getAttribute?.('class') || '');
      if(cardClass){ captured.className = cardClass; }
      const section = node.getAttribute?.('data-stats-section');
      if(section != null){ captured.section = section; }
      return captured;
    }
    const tag = String(node.tagName || '').toLowerCase();
    if(!STATS_MODEL_ALLOWED_TAGS.has(tag)){
      const text = String(node.textContent || '').trim();
      return text ? { type: 'text', text } : null;
    }
    const model = { type: 'element', tag };
    const className = sanitizeStatsClassName(node.getAttribute?.('class') || '');
    if(className){
      model.className = className;
    }
    const statsAttrs = {};
    ['statsPvalueRaw', 'statsPvalueOperator', 'statsPvalueSourceText'].forEach(key => {
      if(node.dataset && Object.prototype.hasOwnProperty.call(node.dataset, key)){
        statsAttrs[key] = String(node.dataset[key]);
      }
    });
    if(Object.keys(statsAttrs).length){
      model.statsAttrs = statsAttrs;
    }
    const statsSection = node.getAttribute?.('data-stats-section');
    if(statsSection){
      model.statsSection = String(statsSection);
    }
    if(tag === 'details' && node.open === true){
      model.open = true;
    }
    const children = Array.from(node.childNodes || [])
      .map(captureStatsNodeModel)
      .filter(Boolean);
    if(children.length){
      model.children = children;
    }else if(tag !== 'br'){
      const text = String(node.textContent || '');
      if(text){
        model.children = [{ type: 'text', text }];
      }
    }
    return model;
  }

  function captureStatsChildrenModel(target, options = {}){
    if(!target || target.nodeType !== 1){
      return null;
    }
    const children = Array.from(target.childNodes || [])
      .filter(node => {
        if(options.excludeNode && node === options.excludeNode){
          return false;
        }
        return !(options.excludeReportNodes === true && node.nodeType === 1 && isReportingNode(node));
      })
      .map(captureStatsNodeModel)
      .filter(Boolean);
    return children.length
      ? {
          schemaVersion: 1,
          kind: 'stats-panel',
          children,
          pValueScientific: getPanelPValueScientific(target)
        }
      : null;
  }

  function normalizeStatsPanelModel(model){
    if(!model || typeof model !== 'object'){
      return null;
    }
    const children = Array.isArray(model.children)
      ? model.children
      : (Array.isArray(model.nodes) ? model.nodes : null);
    if(!children){
      return null;
    }
    const normalized = {
      schemaVersion: 1,
      kind: 'stats-panel',
      children: cloneStatsReportingValue(children)
    };
    if(Object.prototype.hasOwnProperty.call(model, 'pValueScientific')){
      normalized.pValueScientific = sanitizePValueScientific(model.pValueScientific, DEFAULT_PVALUE_FORMAT_SCIENTIFIC);
    }
    return normalized;
  }

  function renderStatsNodeModel(documentRef, model){
    if(!documentRef || !model || typeof model !== 'object'){
      return null;
    }
    if(model.type === 'text'){
      return documentRef.createTextNode(String(model.text || ''));
    }
    // Re-render a stats-table card from its persisted data model so the interactive
    // Download/Copy export controls are mounted live again (they cannot survive DOM
    // serialization). Falls back to null if the shared renderer is unavailable.
    if(model.type === 'stats-table'){
      if(!model.model || !global.Shared?.statsTable || typeof global.Shared.statsTable.render !== 'function'){
        return null;
      }
      const holder = documentRef.createElement('div');
      global.Shared.statsTable.render({
        target: holder,
        model: model.model,
        contextLabel: model.model?.options?.contextLabel
      });
      const card = holder.firstChild;
      if(card && card.nodeType === 1){
        if(model.className){ card.setAttribute('class', model.className); }
        if(model.section != null){ card.setAttribute('data-stats-section', model.section); }
      }
      return card || null;
    }
    if(model.type !== 'element'){
      return null;
    }
    const tag = STATS_MODEL_ALLOWED_TAGS.has(String(model.tag || '').toLowerCase())
      ? String(model.tag).toLowerCase()
      : 'span';
    const node = documentRef.createElement(tag);
    const className = sanitizeStatsClassName(model.className || '');
    if(className){
      node.className = className;
    }
    if(model.statsAttrs && typeof model.statsAttrs === 'object' && node.dataset){
      ['statsPvalueRaw', 'statsPvalueOperator', 'statsPvalueSourceText'].forEach(key => {
        if(Object.prototype.hasOwnProperty.call(model.statsAttrs, key)){
          node.dataset[key] = String(model.statsAttrs[key]);
        }
      });
    }
    if(typeof model.statsSection === 'string' && model.statsSection){
      node.setAttribute('data-stats-section', model.statsSection);
    }
    if(tag === 'details' && model.open === true){
      node.open = true;
    }
    (Array.isArray(model.children) ? model.children : []).forEach(childModel => {
      const child = renderStatsNodeModel(documentRef, childModel);
      if(child){
        node.appendChild(child);
      }
    });
    return node;
  }

  function renderStatsPanelModel(target, model){
    const documentRef = target?.ownerDocument || global.document;
    const normalized = normalizeStatsPanelModel(model);
    if(!target || !documentRef || !normalized){
      return false;
    }
    target.textContent = '';
    if(Object.prototype.hasOwnProperty.call(normalized, 'pValueScientific')){
      setPanelPValueScientific(target, normalized.pValueScientific);
    }else{
      ensurePanelPValueTabId(target);
    }
    normalized.children.forEach(childModel => {
      const child = renderStatsNodeModel(documentRef, childModel);
      if(child){
        target.appendChild(child);
      }
    });
    target.__statsPanelModel = cloneStatsReportingValue(normalized);
    return true;
  }

  function readDirectChildText(node, selector){
    const child = node?.querySelector?.(selector) || null;
    return child ? String(child.textContent || '').trim() : '';
  }

  function extractReportModelFromPanel(panel){
    if(!panel || panel.nodeType !== 1){
      return null;
    }
    const storedModel = panel.__statsReportModel;
    if(storedModel && typeof storedModel === 'object'){
      return normalizeReportModel(storedModel, storedModel);
    }
    if(!panel.classList?.contains('stats-report-panel')){
      return null;
    }
    const title = readDirectChildText(panel, ':scope > summary') || 'Reporting and reproducibility';
    const preBlocks = Array.from(panel.querySelectorAll?.(':scope > pre') || []);
    const methodsText = preBlocks[0] ? String(preBlocks[0].textContent || '') : '';
    const resultsText = preBlocks[1] ? String(preBlocks[1].textContent || '') : '';
    const advancedPre = panel.querySelector?.(':scope > .stats-report-panel__advanced pre');
    let analysisSpec = null;
    if(advancedPre){
      const rawSpec = String(advancedPre.textContent || '').trim();
      if(rawSpec){
        try{ analysisSpec = JSON.parse(rawSpec); }
        catch(_err){ analysisSpec = { note: rawSpec }; }
      }
    }
    if(!methodsText && !resultsText && !analysisSpec){
      return null;
    }
    return normalizeReportModel({ title, methodsText, resultsText, analysisSpec }, { title });
  }

  function captureReportModelFromHost(reportHost){
    if(!reportHost || reportHost.nodeType !== 1){
      return null;
    }
    const storedModel = reportHost.__statsReportModel;
    if(storedModel && typeof storedModel === 'object'){
      return storedModel.kind === 'stats-report'
        ? normalizeReportModel(storedModel, storedModel)
        : normalizeStatsPanelModel(storedModel);
    }
    const reportPanel = reportHost.classList?.contains('stats-report-panel')
      ? reportHost
      : (reportHost.querySelector?.('.stats-report-panel') || null);
    return extractReportModelFromPanel(reportPanel);
  }

  reporting.capturePanelModel = function capturePanelModel(target){
    if(!target || target.nodeType !== 1){
      return { resultsModel: null, reportModel: null };
    }
    const reportHost = resolveReportingHost(target);
    const reportModel = captureReportModelFromHost(reportHost);
    if(reportHost && reportHost !== target){
      if(reportHost.parentNode === target){
        const resultsModel = captureStatsChildrenModel(target, { excludeReportNodes: true, excludeNode: reportHost });
        return { resultsModel, reportModel };
      }
      return { resultsModel: captureStatsChildrenModel(target), reportModel };
    }
    const directReport = target.querySelector?.(':scope > .stats-report-panel') || null;
    return {
      resultsModel: captureStatsChildrenModel(target, { excludeReportNodes: true }),
      reportModel: captureReportModelFromHost(directReport)
    };
  };

  reporting.normalizeSavedPanelModel = function normalizeSavedPanelModel(saved){
    const source = saved && typeof saved === 'object' ? saved : {};
    const resultsModel = normalizeStatsPanelModel(source.resultsModel || source.panelModel || null);
    const reportModel = source.reportModel && typeof source.reportModel === 'object'
      ? (source.reportModel.kind === 'stats-report'
        ? normalizeReportModel(source.reportModel, source.reportModel)
        : normalizeStatsPanelModel(source.reportModel))
      : null;
    return {
      resultsModel,
      reportModel
    };
  };

  reporting.restorePanelModel = function restorePanelModel(target, saved, options = {}){
    if(!target || target.nodeType !== 1){
      return { restoredMain: false, restoredReport: false };
    }
    const normalized = reporting.normalizeSavedPanelModel(saved);
    let restoredMain = false;
    if(normalized.resultsModel){
      restoredMain = renderStatsPanelModel(target, normalized.resultsModel);
    }else if(options.clearMainWhenMissing !== false){
      target.textContent = '';
    }
    let reportHost = null;
    if(typeof options.ensureReportHost === 'function'){
      reportHost = options.ensureReportHost();
    }else{
      reportHost = resolveReportingHost(target);
      if(reportHost && reportHost !== target && !reportHost.isConnected && typeof target.appendChild === 'function'){
        target.appendChild(reportHost);
      }
    }
    let restoredReport = false;
    if(reportHost && reportHost !== target){
      if(normalized.reportModel?.kind === 'stats-report'){
        reportHost.textContent = '';
        reporting.appendReportPanel(target, normalized.reportModel, { replaceExisting: false });
        restoredReport = true;
      }else if(normalized.reportModel){
        restoredReport = renderStatsPanelModel(reportHost, normalized.reportModel);
      }else{
        reportHost.textContent = '';
      }
    }
    if(typeof reporting.pinReportHostLast === 'function'){
      reporting.pinReportHostLast(target);
    }
    if(typeof reporting.enhancePanelNow === 'function'){
      reporting.enhancePanelNow(target, 'restore-panel-model');
    }
    return {
      restoredMain,
      restoredReport
    };
  };

  function findDirectChildByClass(parent, className){
    if(!parent || !className){
      return null;
    }
    const children = Array.from(parent.children || []);
    for(let index = 0; index < children.length; index += 1){
      const child = children[index];
      if(child?.classList?.contains(className)){
        return child;
      }
    }
    return null;
  }

  function panelHasEnhanceableContent(target){
    if(!target || typeof target.querySelector !== 'function'){
      return false;
    }
    return !!target.querySelector('.stats-table-card, table, .stats-report-panel, .stats-assumption-container');
  }

  function suppressThresholdControlsForPanel(target){
    if(!target){
      return false;
    }
    const targetId = typeof target.id === 'string' ? target.id : '';
    if(targetId === 'surfaceStatsSummary' || targetId === 'pcaStatsResults'){
      return true;
    }
    if(
      targetId === 'survivalStatsLogRank'
      || targetId === 'survivalStatsHazardRatios'
      || targetId === 'survivalStatsCox'
    ){
      return true;
    }
    return false;
  }

  function ensurePanelScaffold(target, state){
    if(!target || !target.ownerDocument){
      return null;
    }
    const documentRef = target.ownerDocument;
    ensurePanelPValueTabId(target);
    const suppressThresholdControls = suppressThresholdControlsForPanel(target);
    let controls = findDirectChildByClass(target, 'stats-significance-controls');
    if(suppressThresholdControls){
      if(controls && controls.parentNode){
        controls.parentNode.removeChild(controls);
      }
      controls = null;
    }else if(!controls){
      controls = documentRef.createElement('div');
      controls.className = 'stats-significance-controls';
      controls.innerHTML = '<label class="stats-significance-controls__label">Significance threshold (p \u2264) <input type="number" class="stats-significance-controls__input" min="0.000001" max="1" step="0.0001" data-undo-ignore="1" /></label><span class="stats-significance-controls__hint">Applies when p-values are present.</span><span class="stats-significance-controls__extra"></span>';
      target.insertBefore(controls, target.firstChild || null);
      statsReportingDebug('createSignificanceControls', { id: target.id || null });
    }
    const thresholdInput = controls ? controls.querySelector('.stats-significance-controls__input') : null;
    if(thresholdInput){
      thresholdInput.value = String(sharedSignificanceThreshold);
      if(state.thresholdInputEl !== thresholdInput){
        thresholdInput.addEventListener('change', () => {
          reporting.setSignificanceThreshold(thresholdInput.value, { source: target.id || null });
        });
        thresholdInput.addEventListener('blur', () => {
          thresholdInput.value = String(reporting.getSignificanceThreshold());
        });
        state.thresholdInputEl = thresholdInput;
      }
    }
    if(controls){
      let extraControls = controls.querySelector('.stats-significance-controls__extra');
      if(!extraControls){
        extraControls = documentRef.createElement('span');
        extraControls.className = 'stats-significance-controls__extra';
        controls.appendChild(extraControls);
      }
      if(extraControls){
        extraControls.textContent = '';
        const extraFactory = typeof target.__statsExtraControlFactory === 'function'
          ? target.__statsExtraControlFactory
          : ((context) => createDefaultPValueFormatControl(context.document, context.target));
        const extraNode = extraFactory ? extraFactory({ document: documentRef, target, controls }) : null;
        if(extraNode){
          extraControls.appendChild(extraNode);
          extraControls.hidden = false;
        }else{
          extraControls.hidden = true;
        }
      }
    }
    let main = findDirectChildByClass(target, 'stats-results-main');
    if(!main){
      main = documentRef.createElement('div');
      main.className = 'stats-results-main';
      target.appendChild(main);
    }
    let advancedPanel = findDirectChildByClass(target, 'stats-results-advanced-panel');
    if(!advancedPanel){
      advancedPanel = documentRef.createElement('details');
      advancedPanel.className = 'stats-results-advanced-panel';
      advancedPanel.innerHTML = '<summary>Diagnostics and model details</summary><div class="stats-results-advanced-panel__body"></div>';
      target.appendChild(advancedPanel);
      statsReportingDebug('createAdvancedPanel', { id: target.id || null });
    }
    if(main.nextSibling !== advancedPanel){
      target.insertBefore(advancedPanel, main.nextSibling);
    }
    const advancedBody = findDirectChildByClass(advancedPanel, 'stats-results-advanced-panel__body');
    let descriptive = findDirectChildByClass(target, 'stats-results-descriptive');
    if(!descriptive){
      descriptive = documentRef.createElement('div');
      descriptive.className = 'stats-results-descriptive';
      target.appendChild(descriptive);
    }
    if(advancedPanel.nextSibling !== descriptive){
      target.insertBefore(descriptive, advancedPanel.nextSibling);
    }
    if(typeof reporting.pinReportHostLast === 'function'){
      reporting.pinReportHostLast(target);
    }
    return {
      controls,
      thresholdInput,
      hint: controls ? controls.querySelector('.stats-significance-controls__hint') : null,
      main,
      advancedPanel,
      advancedBody,
      descriptive
    };
  }

  function redistributePanelNodes(target, scaffold){
    if(!target || !scaffold?.main || !scaffold?.advancedBody || !scaffold?.descriptive){
      return;
    }
    const candidates = [];
    const reportingHost = resolveReportingHost(target);
    const pushCandidate = node => {
      if(!node){
        return;
      }
      if(node === scaffold.controls || node === scaffold.main || node === scaffold.advancedPanel || node === scaffold.descriptive || node === reportingHost){
        return;
      }
      if(node.nodeType === 3){
        if(!String(node.textContent || '').trim()){
          return;
        }
        candidates.push(node);
        return;
      }
      if(node.nodeType !== 1){
        return;
      }
      candidates.push(node);
    };
    Array.from(target.childNodes).forEach(pushCandidate);
    Array.from(scaffold.main.childNodes).forEach(pushCandidate);
    Array.from(scaffold.advancedBody.childNodes).forEach(pushCandidate);
    Array.from(scaffold.descriptive.childNodes).forEach(pushCandidate);
    const unique = Array.from(new Set(candidates));
    unique.sort((left, right) => {
      const leftOrder = left.nodeType === 1 ? STATS_SECTION_ORDER[readStatsSection(left)] : 0;
      const rightOrder = right.nodeType === 1 ? STATS_SECTION_ORDER[readStatsSection(right)] : 0;
      return leftOrder - rightOrder;
    });
    const reportingNodes = [];
    unique.forEach(node => {
      if(isReportingNode(node)){
        reportingNodes.push(node);
        return;
      }
      const section = readStatsSection(node);
      const destination = section === 'descriptive'
        ? scaffold.descriptive
        : (isAdvancedNode(node) ? scaffold.advancedBody : scaffold.main);
      destination.appendChild(node);
    });
    reportingNodes.forEach(node => {
      if(reportingHost && typeof reportingHost.appendChild === 'function'){
        reportingHost.appendChild(node);
      }
    });
    scaffold.advancedPanel.hidden = scaffold.advancedBody.childNodes.length === 0;
    scaffold.advancedPanel.setAttribute('aria-hidden', scaffold.advancedPanel.hidden ? 'true' : 'false');
    scaffold.descriptive.hidden = scaffold.descriptive.childNodes.length === 0;
    scaffold.descriptive.setAttribute('aria-hidden', scaffold.descriptive.hidden ? 'true' : 'false');
  }

  function applyPanelEnhancements(target, reason){
    if(!target){
      return;
    }
    const state = panelEnhancerState.get(target);
    if(!state){
      return;
    }
    if(state.applying){
      return;
    }
    state.applying = true;
    state.mutationSuspended = true;
    try{
      const hasMain = !!findDirectChildByClass(target, 'stats-results-main');
      const hasAdvanced = !!findDirectChildByClass(target, 'stats-results-advanced-panel');
      if(!hasMain && !hasAdvanced && !panelHasEnhanceableContent(target)){
        return;
      }
      const scaffold = ensurePanelScaffold(target, state);
      if(!scaffold){
        return;
      }
      redistributePanelNodes(target, scaffold);
      if(typeof reporting.pinReportHostLast === 'function'){
        reporting.pinReportHostLast(target);
      }
      if(global.Shared?.statsTable && typeof global.Shared.statsTable.refreshPValueFormatting === 'function'){
        global.Shared.statsTable.refreshPValueFormatting(target);
      }
      rewriteInlinePValueElements(target);
      const threshold = reporting.getSignificanceThreshold();
      let badgeCount = 0;
      const tables = target.querySelectorAll('table');
      tables.forEach(table => {
        rewriteTablePValueCells(table, target);
        badgeCount += annotateTablePValues(table, threshold);
      });
      if(scaffold.hint){
        scaffold.hint.textContent = badgeCount
          ? `Legend: NS, *, **, ***, **** (p <= ${formatThresholdLabel(threshold)})`
          : 'Applies when p-values are present.';
      }
      statsReportingDebug('enhancePanel', { id: target.id || null, reason: reason || 'manual', badgeCount, tables: tables.length });
    }finally{
      state.applying = false;
      if(typeof global.setTimeout === 'function'){
        global.setTimeout(() => {
          state.mutationSuspended = false;
        }, 0);
      }else{
        state.mutationSuspended = false;
      }
    }
  }

  function schedulePanelEnhancement(target, reason){
    if(!target){
      return;
    }
    let state = panelEnhancerState.get(target);
    if(!state){
      state = {
        applying: false,
        scheduled: false,
        thresholdInputEl: null,
        mutationSuspended: false,
        observer: null
      };
      panelEnhancerState.set(target, state);
    }
    if(state.scheduled){
      return;
    }
    state.scheduled = true;
    const runner = () => {
      state.scheduled = false;
      applyPanelEnhancements(target, reason);
    };
    if(typeof global.requestAnimationFrame === 'function'){
      global.requestAnimationFrame(runner);
    }else{
      global.setTimeout(runner, 0);
    }
  }

  function observeStatsPanel(target){
    if(!target || panelEnhancerState.get(target)?.observer){
      return;
    }
    const state = panelEnhancerState.get(target) || {
      applying: false,
      scheduled: false,
      thresholdInputEl: null,
      mutationSuspended: false,
      observer: null
    };
    if(typeof MutationObserver !== 'function'){
      panelEnhancerState.set(target, state);
      enhancedStatsPanels.add(target);
      schedulePanelEnhancement(target, 'observe-init-no-observer');
      return;
    }
    const observer = new MutationObserver(() => {
      if(state.applying || state.mutationSuspended){
        return;
      }
      schedulePanelEnhancement(target, 'mutation');
    });
    observer.observe(target, { childList: true, subtree: true, characterData: true });
    state.observer = observer;
    panelEnhancerState.set(target, state);
    enhancedStatsPanels.add(target);
    schedulePanelEnhancement(target, 'observe-init');
  }

  function resolveStatsPanelsFromSelectors(selectors){
    const list = Array.isArray(selectors) ? selectors : STATS_PANEL_SELECTORS;
    if(!global.document){
      return [];
    }
    const found = [];
    list.forEach(selector => {
      if(typeof selector !== 'string' || !selector.trim()){
        return;
      }
      if(selector.startsWith('#')){
        const node = global.document.getElementById(selector.slice(1));
        if(node){
          found.push(node);
        }
        return;
      }
      const nodes = global.document.querySelectorAll(selector);
      nodes.forEach(node => found.push(node));
    });
    return Array.from(new Set(found));
  }

  function refreshAllEnhancedPanels(reason){
    enhancedStatsPanels.forEach(panel => {
      if(!panel || !panel.isConnected){
        return;
      }
      schedulePanelEnhancement(panel, reason || 'refresh');
    });
  }

  function nodeTouchesTrackedStatsPanel(node){
    if(!node || node.nodeType !== 1){
      return false;
    }
    const element = node;
    if(element.id && trackedStatsPanelIdSet.has(element.id)){
      return true;
    }
    if(typeof element.querySelector === 'function'){
      for(let index = 0; index < TRACKED_STATS_PANEL_IDS.length; index += 1){
        const panelId = TRACKED_STATS_PANEL_IDS[index];
        if(element.querySelector(`#${panelId}`)){
          return true;
        }
      }
    }
    return false;
  }

  function mutationTouchesTrackedStatsPanel(mutations){
    if(!Array.isArray(mutations) && !(mutations && typeof mutations.forEach === 'function')){
      return false;
    }
    let touched = false;
    mutations.forEach(mutation => {
      if(touched || !mutation){
        return;
      }
      const addedNodes = Array.from(mutation.addedNodes || []);
      const removedNodes = Array.from(mutation.removedNodes || []);
      for(let index = 0; index < addedNodes.length; index += 1){
        if(nodeTouchesTrackedStatsPanel(addedNodes[index])){
          touched = true;
          return;
        }
      }
      for(let index = 0; index < removedNodes.length; index += 1){
        if(nodeTouchesTrackedStatsPanel(removedNodes[index])){
          touched = true;
          return;
        }
      }
    });
    return touched;
  }

  function schedulePanelInstallRescan(reason){
    if(panelInstallRescanScheduled){
      return;
    }
    panelInstallRescanScheduled = true;
    const run = () => {
      panelInstallRescanScheduled = false;
      const panelCount = reporting.installEnhancedPanels();
      statsReportingDebug('rescanInstallEnhancedPanels', { reason: reason || 'mutation', panelCount });
    };
    if(typeof global.requestAnimationFrame === 'function'){
      global.requestAnimationFrame(run);
      return;
    }
    if(typeof global.setTimeout === 'function'){
      global.setTimeout(run, 0);
      return;
    }
    run();
  }

  function ensurePanelInstallRescanObserver(){
    if(panelInstallRescanObserver || typeof MutationObserver !== 'function' || !global.document){
      return;
    }
    const root = global.document.body || global.document.documentElement;
    if(!root){
      return;
    }
    panelInstallRescanObserver = new MutationObserver(mutations => {
      if(mutationTouchesTrackedStatsPanel(mutations)){
        schedulePanelInstallRescan('tracked-panel-mutation');
      }
    });
    panelInstallRescanObserver.observe(root, { childList: true, subtree: true });
    statsReportingDebug('installRescanObserverReady', { trackedPanels: TRACKED_STATS_PANEL_IDS.length });
  }

  reporting.pValue = function createStatsReportPValue(value, options = {}){
    const numeric = Number(value);
    const fallback = typeof options.fallback === 'string'
      ? options.fallback
      : (Number.isFinite(numeric) ? String(sharedFormatPValue(numeric, { scientific: DEFAULT_PVALUE_FORMAT_SCIENTIFIC })) : '—');
    return {
      type: 'pValue',
      value: numeric,
      operator: typeof options.operator === 'string' && options.operator.trim() ? options.operator.trim() : '=',
      fallback
    };
  };

  reporting.renderTextParts = function renderStatsReportText(parts, options = {}){
    return renderStatsReportTextParts(parts, { scientific: options.scientific === true });
  };

  reporting.getSignificanceThreshold = function getSignificanceThreshold(){
    return sharedSignificanceThreshold;
  };

  reporting.getPValueFormatScientific = function getPValueFormatScientific(options = {}){
    return getPanelPValueScientific(options?.target || null, options || {});
  };

  reporting.setPanelPValueFormatScientific = function setPanelPValueFormatScientific(target, value, options = {}){
    return setPanelPValueScientific(target, value, options);
  };

  reporting.setPValueFormatScientific = function setPValueFormatScientific(value, options = {}){
    const target = options?.target && options.target.nodeType === 1 ? options.target : null;
    const previous = target
      ? getPanelPValueScientific(target, options)
      : readStoredPValueScientificForTab(options?.tabId || resolveActiveStatsTabId());
    const next = target
      ? setPanelPValueScientific(target, value, options)
      : setActiveTabPValueScientific(value, options);
    const tabId = resolveTargetStatsTabId(target, options) || null;
    statsReportingDebug('setPValueFormatScientific', {
      previous,
      next,
      source: options?.source || null,
      targetId: target?.id || null,
      tabId
    });
    try{
      if(typeof global.dispatchEvent === 'function' && typeof global.CustomEvent === 'function'){
        global.dispatchEvent(new global.CustomEvent('venn:stats-pvalue-format-change', {
          detail: { scientific: next, source: options?.source || null, targetId: target?.id || null, tabId }
        }));
      }
    }catch(err){
      statsReportingDebug('dispatchPValueFormatEventError', { message: err?.message || String(err) });
    }
    if(target){
      schedulePanelEnhancement(target, previous === next ? 'pvalue-format-sync' : 'pvalue-format-change');
    }else{
      refreshAllEnhancedPanels(previous === next ? 'pvalue-format-sync' : 'pvalue-format-change');
    }
    return next;
  };

  reporting.setSignificanceThreshold = function setSignificanceThreshold(value, options){
    const previous = sharedSignificanceThreshold;
    const next = sanitizeSignificanceThreshold(value, previous);
    sharedSignificanceThreshold = next;
    persistSignificanceThreshold(next);
    if(previous !== next){
      statsReportingDebug('setSignificanceThreshold', { previous, next, source: options?.source || null });
      refreshAllEnhancedPanels('threshold-change');
    }else{
      refreshAllEnhancedPanels('threshold-sync');
    }
    return next;
  };

  reporting.getSignificanceToken = function getSignificanceToken(pValue, threshold){
    const parsed = Number.isFinite(Number(pValue))
      ? { value: Number(pValue), operator: '=' }
      : null;
    return resolveSignificanceToken(parsed, sanitizeSignificanceThreshold(threshold, sharedSignificanceThreshold));
  };

  reporting.enhancePanelNow = function enhancePanelNow(target, reason){
    if(!target || target.nodeType !== 1){
      return false;
    }
    observeStatsPanel(target);
    applyPanelEnhancements(target, reason || 'manual-sync');
    if(typeof reporting.pinReportHostLast === 'function'){
      reporting.pinReportHostLast(target);
    }
    return true;
  };

  reporting.refreshEnhancedPanels = function refreshEnhancedPanels(reason){
    refreshAllEnhancedPanels(reason || 'manual');
  };

  reporting.installEnhancedPanels = function installEnhancedPanels(options){
    if(!global.document){
      return 0;
    }
    const panels = resolveStatsPanelsFromSelectors(options?.selectors || STATS_PANEL_SELECTORS);
    panels.forEach(panel => observeStatsPanel(panel));
    statsReportingDebug('installEnhancedPanels', { panelCount: panels.length });
    return panels.length;
  };

  function autoInstallEnhancedPanels(){
    if(panelsInstallAttempted){
      ensurePanelInstallRescanObserver();
      return;
    }
    panelsInstallAttempted = true;
    reporting.installEnhancedPanels();
    ensurePanelInstallRescanObserver();
  }

  if(global.document){
    if(global.document.readyState === 'loading'){
      global.document.addEventListener('DOMContentLoaded', autoInstallEnhancedPanels, { once: true });
    }else{
      autoInstallEnhancedPanels();
    }
  }

  stats.getCorrectionMeta = function(method){
    const methodKey = normalizeMethod(method);
    const cfg = METHOD_CONFIG[methodKey] || METHOD_CONFIG[DEFAULT_METHOD];
    const meta = {
      key: methodKey,
      label: cfg.label,
      shortLabel: cfg.shortLabel || cfg.label,
      description: cfg.description,
      aliases: cfg.aliases ? cfg.aliases.slice() : [],
      footnote: cfg.footnote
    };
    console.debug('Debug: stats.getCorrectionMeta',{ method: methodKey, label: meta.label });
    return meta;
  };
})(typeof window !== 'undefined' ? window : globalThis);
