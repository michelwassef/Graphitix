(function(global){
  'use strict';

  const Shared = global.Shared = global.Shared || {};
  const dataViews = Shared.dataViews = Shared.dataViews || {};
  const VERSION = 3;
  const DEFAULT_MAX_VIEWS = 12;
  const tableProjectionDepth = new WeakMap();

  function debugLog(message, payload){
    if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
      console.debug('Debug: dataViews ' + message, payload || {});
    }
  }

  function nowMs(){
    if(global.performance && typeof global.performance.now === 'function'){
      return global.performance.now();
    }
    return Date.now();
  }

  function shapeOfMatrix(matrix){
    if(Shared.dataTransforms && typeof Shared.dataTransforms.matrixShape === 'function'){
      return Shared.dataTransforms.matrixShape(matrix);
    }
    if(!Array.isArray(matrix)){
      return { rows: 0, cols: 0 };
    }
    let cols = 0;
    for(let i = 0; i < matrix.length; i += 1){
      const row = matrix[i];
      if(Array.isArray(row) && row.length > cols){
        cols = row.length;
      }
    }
    return { rows: matrix.length, cols };
  }

  function cloneSimple(value){
    try{
      return JSON.parse(JSON.stringify(value));
    }catch(err){
      return value;
    }
  }

  function matrixShapesMatch(left, right){
    const leftShape = shapeOfMatrix(left);
    const rightShape = shapeOfMatrix(right);
    return leftShape.rows === rightShape.rows && leftShape.cols === rightShape.cols;
  }

  function truncateLabel(label, maxLength){
    const text = String(label || '').trim();
    const limit = Number.isFinite(maxLength) ? Math.max(8, Math.floor(maxLength)) : 40;
    if(text.length <= limit){
      return text;
    }
    return `${text.slice(0, Math.max(4, limit - 3))}...`;
  }

  function sanitizeSuggestedFileName(value, fallback){
    const base = String(value || '').trim() || String(fallback || '').trim() || 'data-view';
    return base.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim() || 'data-view';
  }

  function normalizePickerMimeType(value, fallback){
    const raw = String(value || '').trim();
    if(!raw){
      return fallback || 'application/octet-stream';
    }
    const primary = raw.split(';')[0].trim().toLowerCase();
    if(primary && /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(primary)){
      return primary;
    }
    return fallback || 'application/octet-stream';
  }

  function getActiveWorkspaceTitle(){
    try{
      const tab = global.Main?.session?.getActiveTab?.();
      const title = String(tab?.title || '').trim();
      return title || '';
    }catch(err){
      return '';
    }
  }

  function valueToText(value){
    if(value == null){
      return '';
    }
    if(typeof value === 'number'){
      return Number.isFinite(value) ? String(value) : '';
    }
    if(typeof value === 'boolean'){
      return value ? 'true' : 'false';
    }
    return String(value);
  }

  function buildDelimitedText(data, delimiter){
    const rows = Array.isArray(data) ? data : [];
    const delim = delimiter === '\t' ? '\t' : ',';
    const out = new Array(rows.length);
    for(let rowIndex = 0; rowIndex < rows.length; rowIndex += 1){
      const row = Array.isArray(rows[rowIndex]) ? rows[rowIndex] : [rows[rowIndex]];
      const cells = new Array(row.length);
      for(let colIndex = 0; colIndex < row.length; colIndex += 1){
        const text = valueToText(row[colIndex]);
        if(text.indexOf('"') >= 0 || text.indexOf('\n') >= 0 || text.indexOf('\r') >= 0 || text.indexOf(delim) >= 0){
          cells[colIndex] = `"${text.replace(/"/g, '""')}"`;
        }else{
          cells[colIndex] = text;
        }
      }
      out[rowIndex] = cells.join(delim);
    }
    return out.join('\n');
  }

  function normalizeTitle(value, fallback){
    const text = String(value || '').trim();
    return text || fallback;
  }

  function nextDerivedTitle(views){
    let count = 1;
    const source = Array.isArray(views) ? views : [];
    for(let i = 0; i < source.length; i += 1){
      const view = source[i];
      if(view && view.kind === 'derived'){
        count += 1;
      }
    }
    return `Derived ${count}`;
  }

  function normalizeViewRecord(input, fallbackKind){
    const source = input && typeof input === 'object' ? input : {};
    const kind = source.kind === 'raw' ? 'raw' : (fallbackKind === 'raw' ? 'raw' : 'derived');
    const id = kind === 'raw' ? 'raw' : String(source.id || '').trim();
    return {
      id: id || null,
      kind,
      title: normalizeTitle(source.title, kind === 'raw' ? 'Raw' : 'Derived'),
      data: Array.isArray(source.data) ? source.data : [],
      sourceViewId: source.sourceViewId == null ? null : String(source.sourceViewId),
      transformSpec: source.transformSpec || null,
      summary: source.summary || null,
      shareExclusions: typeof source.shareExclusions === 'boolean' ? source.shareExclusions : null,
      exclusions: source.exclusions ? cloneSimple(source.exclusions) : null,
      filters: source.filters ? cloneSimple(source.filters) : null,
      createdAt: Number.isFinite(Number(source.createdAt)) ? Number(source.createdAt) : nowMs()
    };
  }

  function isTableProjectionActive(table){
    return !!table && (tableProjectionDepth.get(table) || 0) > 0;
  }

  function applyViewToTable(table, view, options){
    if(!table || typeof table.loadData !== 'function' || !view){
      return false;
    }
    const settings = options && typeof options === 'object' ? options : {};
    const nextData = Array.isArray(view.data) ? view.data : [];
    // Snapshot view-owned state before loadData. Component load hooks may run
    // synchronously, but an atomic projection must never capture the previous
    // table view into the newly activated DataView.
    const exclusions = view.exclusions ? cloneSimple(view.exclusions) : null;
    const filters = view.filters ? cloneSimple(view.filters) : null;
    const loadOptions = settings.loadOptions && typeof settings.loadOptions === 'object'
      ? { ...settings.loadOptions }
      : {};
    if(!Object.prototype.hasOwnProperty.call(loadOptions, 'suppressSchedule')){
      loadOptions.suppressSchedule = settings.suppressLoadSchedule !== false;
    }

    const currentDepth = tableProjectionDepth.get(table) || 0;
    tableProjectionDepth.set(table, currentDepth + 1);
    try{
      table.loadData(nextData, loadOptions);
      if(typeof settings.applyExclusions === 'function'){
        settings.applyExclusions(table, exclusions);
      }else if(typeof table.applyExclusions === 'function'){
        table.applyExclusions(exclusions, {
          silent: true,
          source: settings.exclusionSource || 'data-view-switch'
        });
      }
      if(typeof table.applyFilters === 'function'){
        table.applyFilters(filters, {
          schedule: false,
          reason: settings.filterReason || 'data-view-switch'
        });
      }
      return true;
    }finally{
      if(currentDepth > 0){
        tableProjectionDepth.set(table, currentDepth);
      }else{
        tableProjectionDepth.delete(table);
      }
    }
  }

  function defaultLabelForTransform(spec){
    const normalized = Shared.dataTransforms?.normalizeTransformSpec
      ? Shared.dataTransforms.normalizeTransformSpec(spec)
      : (spec || {});
    const type = String(normalized.type || '').toLowerCase();
    if(type === 'cpm'){ return 'CPM'; }
    if(type === 'log'){
      const base = Number(normalized.base) || 2;
      const pseudo = Number(normalized.pseudoCount) || 0;
      if(pseudo === 1){
        return `log${base}(x+1)`;
      }
      if(pseudo){
        return `log${base}(x+${pseudo})`;
      }
      return `log${base}(x)`;
    }
    if(type === 'scale'){
      return `x*${normalized.factor}`;
    }
    if(type === 'divide'){
      return `x/${normalized.divisor}`;
    }
    if(type === 'add'){
      return `x+${normalized.value}`;
    }
    if(type === 'subtract'){
      return `x-${normalized.value}`;
    }
    if(type === 'custom'){
      return truncateLabel(normalized.expression, 28);
    }
    if(type === 'centerrows'){
      return normalized.method === 'median' ? 'Center rows (median)' : 'Center rows (mean)';
    }
    if(type === 'centercolumns'){
      return normalized.method === 'median' ? 'Center cols (median)' : 'Center cols (mean)';
    }
    if(type === 'normalizerows'){ return 'Normalize Rows'; }
    if(type === 'normalizecolumns'){ return 'Normalize Columns'; }
    return type || 'Derived';
  }

  function defaultLabelForPipeline(specs){
    const source = Array.isArray(specs) ? specs : [];
    const labels = source
      .map(spec => defaultLabelForTransform(spec))
      .filter(label => typeof label === 'string' && label.trim().length > 0);
    if(!labels.length){
      return 'Pipeline';
    }
    const joined = labels.join(' + ');
    return joined.length > 64 ? `${joined.slice(0, 61)}...` : joined;
  }

  function createManager(options){
    const settings = options && typeof options === 'object' ? options : {};
    const componentKey = String(settings.componentKey || '').trim();
    const maxViews = Math.max(2, Number(settings.maxViews) || DEFAULT_MAX_VIEWS);
    const onActiveViewChanged = typeof settings.onActiveViewChanged === 'function'
      ? settings.onActiveViewChanged
      : null;
    const onViewsChanged = typeof settings.onViewsChanged === 'function'
      ? settings.onViewsChanged
      : null;
    const onInteraction = typeof settings.onInteraction === 'function'
      ? settings.onInteraction
      : null;
    const resolveWorkspaceTitle = typeof settings.getFileTabTitle === 'function'
      ? settings.getFileTabTitle
      : getActiveWorkspaceTitle;

    let mounted = null;
    let views = [];
    let activeViewId = 'raw';
    let nextIdCounter = 1;
    let inActiveCallback = false;
    let sharedExclusions = null;

    const manager = {};

    function findViewIndex(viewId){
      const id = String(viewId || '').trim();
      if(!id){
        return -1;
      }
      for(let i = 0; i < views.length; i += 1){
        if(views[i]?.id === id){
          return i;
        }
      }
      return -1;
    }

    function getView(viewId){
      const targetId = viewId == null ? activeViewId : viewId;
      const index = findViewIndex(targetId);
      if(index < 0){
        return null;
      }
      return views[index];
    }

    function viewSharesExclusions(view){
      return !!view && view.shareExclusions !== false;
    }

    function syncSharedExclusionsToViews(){
      for(let i = 0; i < views.length; i += 1){
        if(viewSharesExclusions(views[i])){
          views[i].exclusions = sharedExclusions ? cloneSimple(sharedExclusions) : null;
        }
      }
    }

    function inferViewExclusionSharing(view, resolving){
      if(!view){
        return false;
      }
      if(view.kind === 'raw'){
        view.shareExclusions = true;
        return true;
      }
      if(typeof view.shareExclusions === 'boolean'){
        return view.shareExclusions;
      }
      const resolvingIds = resolving || new Set();
      if(resolvingIds.has(view.id)){
        view.shareExclusions = false;
        return false;
      }
      resolvingIds.add(view.id);
      const sourceView = getView(view.sourceViewId || 'raw');
      const shares = !!sourceView
        && inferViewExclusionSharing(sourceView, resolvingIds)
        && matrixShapesMatch(view.data, sourceView.data);
      resolvingIds.delete(view.id);
      view.shareExclusions = shares;
      return shares;
    }

    function emitViewsChanged(reason){
      if(!onViewsChanged){
        return;
      }
      try{
        onViewsChanged({
          reason: reason || 'unknown',
          activeViewId,
          viewCount: views.length,
          views: views.map(view => ({
            id: view.id,
            kind: view.kind,
            title: view.title,
            summary: view.summary || null,
            sourceViewId: view.sourceViewId || null,
            shareExclusions: viewSharesExclusions(view),
            shape: shapeOfMatrix(view.data)
          }))
        });
      }catch(err){
        debugLog('views changed callback failed', { message: err?.message || String(err) });
      }
    }

    function emitActiveChanged(reason, previousViewId){
      if(!onActiveViewChanged || inActiveCallback){
        return;
      }
      const active = getView(activeViewId);
      if(!active){
        return;
      }
      inActiveCallback = true;
      try{
        onActiveViewChanged(active, {
          reason: reason || 'activate',
          previousViewId: previousViewId || null,
          componentKey
        });
      }catch(err){
        debugLog('active view callback failed', { message: err?.message || String(err) });
      }finally{
        inActiveCallback = false;
      }
    }

    function buildViewId(){
      nextIdCounter += 1;
      return `view-${nextIdCounter}`;
    }

    function ensureRawView(rawData){
      if(views.length){
        const first = views[0];
        if(first && first.kind === 'raw'){
          if(Array.isArray(rawData)){
            first.data = rawData;
          }
          if(!first.id){
            first.id = 'raw';
          }
          first.shareExclusions = true;
          first.exclusions = sharedExclusions ? cloneSimple(sharedExclusions) : null;
          return first;
        }
      }
      const raw = {
        id: 'raw',
        kind: 'raw',
        title: 'Raw',
        data: Array.isArray(rawData) ? rawData : [],
        sourceViewId: null,
        transformSpec: null,
        summary: null,
        shareExclusions: true,
        exclusions: sharedExclusions ? cloneSimple(sharedExclusions) : null,
        filters: null,
        createdAt: nowMs()
      };
      views.unshift(raw);
      return raw;
    }

    function toSerializableRecord(view){
      return {
        id: view.id,
        kind: view.kind,
        title: view.title,
        data: view.data,
        sourceViewId: view.sourceViewId || null,
        transformSpec: view.transformSpec || null,
        summary: view.summary || null,
        shareExclusions: viewSharesExclusions(view),
        exclusions: view.exclusions ? cloneSimple(view.exclusions) : null,
        filters: view.filters ? cloneSimple(view.filters) : null,
        createdAt: view.createdAt
      };
    }

    function renderTabs(){
      if(!mounted?.tabs){
        return;
      }
      const tabs = mounted.tabs;
      while(tabs.firstChild){
        tabs.removeChild(tabs.firstChild);
      }
      const doc = tabs.ownerDocument || global.document;
      views.forEach(view => {
        const item = doc.createElement('div');
        item.className = 'data-view-tabs__item';
        if(view.id === activeViewId){
          item.classList.add('data-view-tabs__item--active');
        }

        const tab = doc.createElement('button');
        tab.type = 'button';
        tab.className = 'data-view-tabs__tab';
        if(view.id === activeViewId){
          tab.classList.add('data-view-tabs__tab--active');
        }
        tab.dataset.viewId = view.id;
        tab.setAttribute('role', 'tab');
        tab.setAttribute('aria-selected', view.id === activeViewId ? 'true' : 'false');
        tab.textContent = view.title;
        if(view.summary?.transform){
          tab.title = `${view.title} (${view.summary.transform})`;
        }else{
          tab.title = view.title;
        }
        item.appendChild(tab);

        const save = doc.createElement('button');
        save.type = 'button';
        save.className = 'data-view-tabs__save';
        save.dataset.viewId = view.id;
        save.setAttribute('aria-label', `Save ${view.title}`);
        save.setAttribute('title', `Save ${view.title}`);
        save.textContent = '\u{1F4BE}';
        item.appendChild(save);

        if(view.kind !== 'raw'){
          const close = doc.createElement('button');
          close.type = 'button';
          close.className = 'data-view-tabs__close';
          close.dataset.viewId = view.id;
          close.setAttribute('aria-label', `Close ${view.title}`);
          close.textContent = '\u00D7';
          item.appendChild(close);
        }
        tabs.appendChild(item);
      });
    }

    function pruneToMaxViews(){
      if(views.length < maxViews){
        return;
      }
      let candidateIndex = -1;
      let candidateTime = Number.POSITIVE_INFINITY;
      for(let i = 0; i < views.length; i += 1){
        const view = views[i];
        if(!view || view.kind !== 'derived'){
          continue;
        }
        if(view.id === activeViewId){
          continue;
        }
        const createdAt = Number.isFinite(Number(view.createdAt)) ? Number(view.createdAt) : Number.POSITIVE_INFINITY;
        if(createdAt < candidateTime){
          candidateTime = createdAt;
          candidateIndex = i;
        }
      }
      if(candidateIndex < 0){
        for(let i = 0; i < views.length; i += 1){
          const view = views[i];
          if(!view || view.kind !== 'derived'){
            continue;
          }
          const createdAt = Number.isFinite(Number(view.createdAt)) ? Number(view.createdAt) : Number.POSITIVE_INFINITY;
          if(createdAt < candidateTime){
            candidateTime = createdAt;
            candidateIndex = i;
          }
        }
      }
      if(candidateIndex >= 0){
        const removed = views.splice(candidateIndex, 1)[0];
        if(removed?.id && removed.id === activeViewId){
          activeViewId = 'raw';
        }
        debugLog('derived view evicted', { id: removed?.id, title: removed?.title, maxViews });
      }
    }

    function mount(params){
      const wrapper = params?.wrapper || null;
      const tableContainer = params?.tableContainer || null;
      if(!wrapper || !tableContainer){
        return false;
      }
      if(mounted && mounted.wrapper === wrapper && mounted.tableContainer === tableContainer){
        renderTabs();
        return true;
      }
      manager.unmount();
      const existingOwner = wrapper.__dataViewsOwner || null;
      if(existingOwner && existingOwner !== manager && typeof existingOwner.unmount === 'function'){
        existingOwner.unmount();
      }
      const doc = wrapper.ownerDocument || global.document;
      const tabs = doc.createElement('div');
      tabs.className = 'data-view-tabs';
      tabs.setAttribute('role', 'tablist');
      tabs.setAttribute('aria-label', 'Input data views');
      tabs.dataset.componentKey = componentKey || '';

      const exportMenu = doc.createElement('div');
      exportMenu.className = 'data-view-tabs__export-menu';
      exportMenu.setAttribute('hidden', 'hidden');
      exportMenu.setAttribute('role', 'menu');
      exportMenu.innerHTML = ''
        + '<div class="data-view-tabs__export-label" aria-hidden="true">Save as:</div>'
        + '<button type="button" class="data-view-tabs__export-item" data-format="csv" role="menuitem">CSV</button>'
        + '<button type="button" class="data-view-tabs__export-item" data-format="tsv" role="menuitem">TSV</button>'
        + '<button type="button" class="data-view-tabs__export-item" data-format="ods" role="menuitem">ODS</button>'
        + '<button type="button" class="data-view-tabs__export-item" data-format="xlsx" role="menuitem">XLSX</button>';

      let exportMenuViewId = null;

      const hideExportMenu = () => {
        if(exportMenu.hasAttribute('hidden')){
          return;
        }
        exportMenu.setAttribute('hidden', 'hidden');
        exportMenuViewId = null;
      };

      const showExportMenu = (button, viewId) => {
        if(!button || !viewId){
          return;
        }
        exportMenuViewId = String(viewId);
        exportMenu.removeAttribute('hidden');
        const buttonRect = button.getBoundingClientRect();
        const hostRect = wrapper.getBoundingClientRect();
        let left = buttonRect.left - hostRect.left;
        let top = buttonRect.bottom - hostRect.top + 4;
        const maxLeft = Math.max(0, wrapper.clientWidth - exportMenu.offsetWidth - 6);
        if(left > maxLeft){
          left = maxLeft;
        }
        const maxTop = Math.max(0, wrapper.clientHeight - exportMenu.offsetHeight - 6);
        if(top > maxTop){
          top = Math.max(0, buttonRect.top - hostRect.top - exportMenu.offsetHeight - 4);
        }
        exportMenu.style.left = `${Math.round(Math.max(0, left))}px`;
        exportMenu.style.top = `${Math.round(Math.max(0, top))}px`;
      };

      const saveBlobAs = async (blob, fileName, contextLabel, acceptMime, acceptExt) => {
        const fileIO = Shared.fileIO;
        const pickerMime = normalizePickerMimeType(acceptMime, blob?.type || 'application/octet-stream');
        if(fileIO && typeof fileIO.saveGraphFileAs === 'function'){
          await fileIO.saveGraphFileAs({
            context: contextLabel,
            payload: blob,
            fileName,
            downloadFileName: fileName,
            mimeType: blob?.type || acceptMime || pickerMime,
            fileTypes: [
              {
                description: `Data Files (${String(acceptExt || '').toUpperCase()})`,
                accept: {
                  [pickerMime]: [acceptExt || '']
                }
              }
            ]
          });
          return;
        }
        if(Shared.exporter && typeof Shared.exporter.downloadBlob === 'function'){
          Shared.exporter.downloadBlob(blob, fileName, contextLabel);
          return;
        }
        if(fileIO && typeof fileIO.downloadBlob === 'function'){
          fileIO.downloadBlob(blob, fileName, blob?.type || acceptMime || 'application/octet-stream');
        }
      };

      const exportViewData = async (viewId, format) => {
        const view = getView(viewId);
        if(!view){
          return;
        }
        const ext = String(format || '').toLowerCase();
        const workspaceTitle = String(resolveWorkspaceTitle?.() || '').trim();
        const workspaceStem = sanitizeSuggestedFileName(workspaceTitle, '');
        const viewStem = sanitizeSuggestedFileName(view.title, view.kind === 'raw' ? 'raw' : 'derived');
        const fileStem = workspaceStem ? `${workspaceStem}_${viewStem}` : viewStem;
        const targetName = `${fileStem}.${ext}`;
        const rows = Array.isArray(view.data) ? view.data : [];
        if(ext === 'csv' || ext === 'tsv'){
          const delimiter = ext === 'tsv' ? '\t' : ',';
          const mime = ext === 'tsv' ? 'text/tab-separated-values;charset=utf-8' : 'text/csv;charset=utf-8';
          const text = buildDelimitedText(rows, delimiter);
          const blob = new Blob([text], { type: mime });
          await saveBlobAs(blob, targetName, `data-view-${ext}`, mime, `.${ext}`);
          return;
        }
        if(ext !== 'xlsx' && ext !== 'ods'){
          return;
        }
        const xlsxLoader = Shared.lazyXlsx;
        if(typeof xlsxLoader !== 'function'){
          return;
        }
        const XLSX = await xlsxLoader();
        if(!XLSX?.utils || typeof XLSX.write !== 'function'){
          return;
        }
        const workbook = XLSX.utils.book_new();
        const sheetName = String(view.title || 'Data').slice(0, 31) || 'Data';
        const worksheet = XLSX.utils.aoa_to_sheet(rows);
        XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
        const output = XLSX.write(workbook, { bookType: ext, type: 'array' });
        const mime = ext === 'ods'
          ? 'application/vnd.oasis.opendocument.spreadsheet'
          : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        const blob = new Blob([output], { type: mime });
        await saveBlobAs(blob, targetName, `data-view-${ext}`, mime, `.${ext}`);
      };

      const pointerDownHandler = event => {
        if(exportMenu.hasAttribute('hidden')){
          return;
        }
        if(exportMenu.contains(event.target)){
          return;
        }
        if(tabs.contains(event.target) && event.target.closest('.data-view-tabs__save')){
          return;
        }
        hideExportMenu();
      };

      const keydownHandler = event => {
        if(event.key === 'Escape'){
          hideExportMenu();
        }
      };

      const clickHandler = event => {
        const exportItem = event.target?.closest?.('.data-view-tabs__export-item[data-format]');
        if(exportItem){
          const format = exportItem.dataset.format || '';
          const targetViewId = exportMenuViewId;
          hideExportMenu();
          if(targetViewId){
            exportViewData(targetViewId, format).catch(err => {
              if(typeof Shared.isDebugEnabled === 'function' && Shared.isDebugEnabled()){
                console.debug('Debug: dataViews export failed', {
                  viewId: targetViewId,
                  format,
                  message: err?.message || String(err)
                });
              }
            });
          }
          return;
        }
        const saveButton = event.target?.closest?.('.data-view-tabs__save[data-view-id]');
        if(saveButton){
          event.preventDefault();
          event.stopPropagation();
          const viewId = saveButton.dataset.viewId || '';
          if(viewId){
            if(exportMenuViewId === viewId && !exportMenu.hasAttribute('hidden')){
              hideExportMenu();
            }else{
              showExportMenu(saveButton, viewId);
            }
          }
          return;
        }
        const closeButton = event.target?.closest?.('.data-view-tabs__close[data-view-id]');
        if(closeButton){
          event.preventDefault();
          event.stopPropagation();
          const viewId = closeButton.dataset.viewId || '';
          manager.removeView(viewId, { reason: 'tab-close' });
          if(onInteraction){
            onInteraction({ reason: 'tab-close', viewId });
          }
          return;
        }
        const tabButton = event.target?.closest?.('.data-view-tabs__tab[data-view-id]');
        if(!tabButton){
          return;
        }
        const viewId = tabButton.dataset.viewId || '';
        if(!viewId){
          return;
        }
        manager.activateView(viewId, { reason: 'tab-click' });
        if(onInteraction){
          onInteraction({ reason: 'tab-click', viewId });
        }
      };

      tabs.addEventListener('click', clickHandler);
      exportMenu.addEventListener('click', clickHandler);
      doc.addEventListener('pointerdown', pointerDownHandler);
      doc.addEventListener('keydown', keydownHandler);
      if(tableContainer.parentNode !== wrapper){
        wrapper.appendChild(tableContainer);
      }
      wrapper.insertBefore(tabs, tableContainer);
      wrapper.appendChild(exportMenu);
      wrapper.classList.add('data-view-host');
      tableContainer.classList.add('data-view-host__table');
      wrapper.__dataViewsOwner = manager;
      mounted = {
        wrapper,
        tableContainer,
        tabs,
        exportMenu,
        clickHandler,
        pointerDownHandler,
        keydownHandler
      };
      renderTabs();
      return true;
    }

    function unmount(){
      if(!mounted){
        return;
      }
      const { wrapper, tableContainer, tabs, exportMenu, clickHandler, pointerDownHandler, keydownHandler } = mounted;
      if(tabs && clickHandler){
        tabs.removeEventListener('click', clickHandler);
      }
      if(exportMenu && clickHandler){
        exportMenu.removeEventListener('click', clickHandler);
      }
      const doc = wrapper?.ownerDocument || global.document;
      if(doc && pointerDownHandler){
        doc.removeEventListener('pointerdown', pointerDownHandler);
      }
      if(doc && keydownHandler){
        doc.removeEventListener('keydown', keydownHandler);
      }
      if(tabs && tabs.parentNode){
        tabs.parentNode.removeChild(tabs);
      }
      if(exportMenu && exportMenu.parentNode){
        exportMenu.parentNode.removeChild(exportMenu);
      }
      wrapper?.classList?.remove('data-view-host');
      tableContainer?.classList?.remove('data-view-host__table');
      if(wrapper && wrapper.__dataViewsOwner === manager){
        delete wrapper.__dataViewsOwner;
      }
      mounted = null;
    }

    function initialize(rawData, options){
      sharedExclusions = null;
      const rawTitle = normalizeTitle(options?.rawTitle, 'Raw');
      views = [{
        id: 'raw',
        kind: 'raw',
        title: rawTitle,
        data: Array.isArray(rawData) ? rawData : [],
        sourceViewId: null,
        transformSpec: null,
        summary: null,
        shareExclusions: true,
        exclusions: null,
        filters: null,
        createdAt: nowMs()
      }];
      activeViewId = 'raw';
      nextIdCounter = 1;
      renderTabs();
      emitViewsChanged('initialize');
      return views[0];
    }

    function activateView(viewId, options){
      const targetId = String(viewId || '').trim();
      const next = getView(targetId);
      if(!next){
        return null;
      }
      const previous = activeViewId;
      activeViewId = next.id;
      renderTabs();
      emitViewsChanged('activate');
      if(options?.silent !== true && previous !== activeViewId){
        emitActiveChanged(options?.reason || 'activate', previous);
      }
      return next;
    }

    function updateActiveData(data, options){
      const active = getView(activeViewId);
      if(!active){
        return false;
      }
      active.data = Array.isArray(data) ? data : [];
      if(options && Object.prototype.hasOwnProperty.call(options, 'summary')){
        active.summary = options.summary || null;
      }
      return true;
    }

    function updateSharedExclusions(exclusions){
      if(!views.length){
        return false;
      }
      sharedExclusions = exclusions ? cloneSimple(exclusions) : null;
      syncSharedExclusionsToViews();
      return true;
    }

    function updateActiveExclusions(exclusions){
      const active = getView(activeViewId);
      if(!active){
        return false;
      }
      if(viewSharesExclusions(active)){
        return updateSharedExclusions(exclusions);
      }
      active.exclusions = exclusions ? cloneSimple(exclusions) : null;
      return true;
    }

    function setViewExclusionSharing(viewId, shouldShare, options){
      const view = getView(viewId);
      if(!view){
        return false;
      }
      view.shareExclusions = shouldShare !== false;
      if(view.shareExclusions){
        view.exclusions = sharedExclusions ? cloneSimple(sharedExclusions) : null;
      }else if(options && Object.prototype.hasOwnProperty.call(options, 'exclusions')){
        view.exclusions = options.exclusions ? cloneSimple(options.exclusions) : null;
      }
      return true;
    }

    function updateActiveFilters(filters){
      const active = getView(activeViewId);
      if(!active){
        return false;
      }
      active.filters = filters ? cloneSimple(filters) : null;
      return true;
    }

    function createDerivedView(params){
      const source = params && typeof params === 'object' ? params : {};
      const data = Array.isArray(source.data) ? source.data : [];
      const sourceViewId = source.sourceViewId == null ? activeViewId : String(source.sourceViewId);
      const sourceView = getView(sourceViewId);
      const shareExclusions = typeof source.shareExclusions === 'boolean'
        ? source.shareExclusions
        : !!sourceView && viewSharesExclusions(sourceView) && matrixShapesMatch(data, sourceView.data);
      pruneToMaxViews();
      const record = {
        id: buildViewId(),
        kind: 'derived',
        title: normalizeTitle(source.title, nextDerivedTitle(views)),
        data,
        sourceViewId,
        transformSpec: source.transformSpec || null,
        summary: source.summary || null,
        shareExclusions,
        exclusions: shareExclusions
          ? (sharedExclusions ? cloneSimple(sharedExclusions) : null)
          : (source.exclusions ? cloneSimple(source.exclusions) : null),
        filters: source.filters ? cloneSimple(source.filters) : null,
        createdAt: nowMs()
      };
      views.push(record);
      renderTabs();
      emitViewsChanged('create-derived');
      if(source.activate !== false){
        activateView(record.id, { reason: source.reason || 'create-derived' });
      }
      return record;
    }

    function removeView(viewId, options){
      const index = findViewIndex(viewId);
      if(index < 0){
        return false;
      }
      const target = views[index];
      if(!target || target.kind === 'raw'){
        return false;
      }
      const wasActive = target.id === activeViewId;
      views.splice(index, 1);
      if(wasActive){
        activeViewId = 'raw';
      }
      renderTabs();
      emitViewsChanged(options?.reason || 'remove');
      if(wasActive && options?.silent !== true){
        emitActiveChanged(options?.reason || 'remove', target.id);
      }
      return true;
    }

    function applyTransform(transformSpec, options){
      const sourceView = getView(options?.sourceViewId || activeViewId);
      if(!sourceView){
        return { ok: false, error: 'No source view selected.' };
      }
      const transformsApi = Shared.dataTransforms;
      if(!transformsApi || typeof transformsApi.applyTransform !== 'function'){
        return { ok: false, error: 'Shared.dataTransforms.applyTransform is unavailable.' };
      }
      const transformResult = transformsApi.applyTransform(
        sourceView.data,
        transformSpec,
        options?.transformOptions || {}
      );
      if(!transformResult?.ok){
        return { ok: false, error: transformResult?.error || 'Transform failed.', result: transformResult || null };
      }
      const title = normalizeTitle(options?.title, defaultLabelForTransform(transformResult.spec));
      const view = createDerivedView({
        title,
        data: transformResult.data,
        sourceViewId: sourceView.id,
        transformSpec: transformResult.spec,
        summary: transformResult.summary || null,
        activate: options?.activate !== false,
        reason: options?.reason || 'transform'
      });
      return {
        ok: true,
        view,
        result: transformResult
      };
    }

    function applyPipeline(transformSpecs, options){
      const sourceView = getView(options?.sourceViewId || activeViewId);
      if(!sourceView){
        return { ok: false, error: 'No source view selected.' };
      }
      const transformsApi = Shared.dataTransforms;
      if(!transformsApi || typeof transformsApi.applyPipeline !== 'function'){
        return { ok: false, error: 'Shared.dataTransforms.applyPipeline is unavailable.' };
      }
      const pipelineResult = transformsApi.applyPipeline(
        sourceView.data,
        Array.isArray(transformSpecs) ? transformSpecs : [],
        options?.transformOptions || {}
      );
      if(!pipelineResult?.ok){
        const failedStep = Array.isArray(pipelineResult?.steps) ? pipelineResult.steps.find(step => step && step.ok === false) : null;
        return {
          ok: false,
          error: failedStep?.error || 'Pipeline transform failed.',
          result: pipelineResult || null
        };
      }
      const steps = Array.isArray(pipelineResult.steps) ? pipelineResult.steps : [];
      const normalizedSpecs = steps.map(step => step?.spec).filter(Boolean);
      const finalStep = steps.length ? steps[steps.length - 1] : null;
      const title = normalizeTitle(options?.title, defaultLabelForPipeline(normalizedSpecs));
      const summary = {
        transform: 'pipeline',
        steps: normalizedSpecs.map(spec => defaultLabelForTransform(spec)),
        stepCount: normalizedSpecs.length,
        rows: shapeOfMatrix(pipelineResult.data).rows,
        cols: shapeOfMatrix(pipelineResult.data).cols,
        changedCells: Number(finalStep?.summary?.changedCells) || 0,
        numericCells: Number(finalStep?.summary?.numericCells) || 0,
        skippedCells: Number(finalStep?.summary?.skippedCells) || 0,
        warnings: steps.reduce((acc, step) => {
          if(Array.isArray(step?.warnings)){
            return acc.concat(step.warnings);
          }
          if(Array.isArray(step?.summary?.warnings)){
            return acc.concat(step.summary.warnings);
          }
          return acc;
        }, []).slice(0, 8)
      };
      const view = createDerivedView({
        title,
        data: pipelineResult.data,
        sourceViewId: sourceView.id,
        transformSpec: {
          type: 'pipeline',
          specs: normalizedSpecs
        },
        summary,
        activate: options?.activate !== false,
        reason: options?.reason || 'pipeline'
      });
      return {
        ok: true,
        view,
        result: pipelineResult
      };
    }

    function serialize(options){
      const includeData = options?.includeData !== false;
      return {
        version: VERSION,
        activeViewId,
        sharedExclusions: sharedExclusions ? cloneSimple(sharedExclusions) : null,
        views: views.map(view => {
          const record = {
            id: view.id,
            kind: view.kind,
            title: view.title,
            sourceViewId: view.sourceViewId || null,
            transformSpec: view.transformSpec || null,
            summary: view.summary || null,
            shareExclusions: viewSharesExclusions(view),
            exclusions: view.exclusions ? cloneSimple(view.exclusions) : null,
            filters: view.filters ? cloneSimple(view.filters) : null,
            createdAt: view.createdAt
          };
          if(includeData){
            record.data = view.data;
          }
          return record;
        })
      };
    }

    function deserialize(payload, options){
      const source = payload && typeof payload === 'object' ? payload : null;
      const incomingViews = Array.isArray(source?.views) ? source.views : [];
      const fallbackData = Array.isArray(options?.fallbackData) ? options.fallbackData : [];

      if(!incomingViews.length){
        initialize(fallbackData, { rawTitle: options?.rawTitle || 'Raw' });
        return false;
      }

      const restored = [];
      let hasRaw = false;
      let localCounter = 1;
      for(let i = 0; i < incomingViews.length; i += 1){
        const isRaw = !hasRaw && (
          incomingViews[i]?.kind === 'raw'
          || String(incomingViews[i]?.id || '').trim().toLowerCase() === 'raw'
          || i === 0
        );
        const normalized = normalizeViewRecord(incomingViews[i], isRaw ? 'raw' : 'derived');
        if(normalized.kind === 'raw'){
          normalized.id = 'raw';
          hasRaw = true;
        }else{
          normalized.id = normalized.id || `view-${i + 2}`;
          const match = normalized.id.match(/^view-(\d+)$/);
          if(match){
            const numericId = Number(match[1]);
            if(Number.isFinite(numericId) && numericId > localCounter){
              localCounter = numericId;
            }
          }
        }
        restored.push(normalized);
      }

      if(!hasRaw){
        restored.unshift({
          id: 'raw',
          kind: 'raw',
          title: normalizeTitle(options?.rawTitle, 'Raw'),
          data: fallbackData,
          sourceViewId: null,
          transformSpec: null,
          summary: null,
          shareExclusions: true,
          exclusions: null,
          filters: null,
          createdAt: nowMs()
        });
      }

      views = restored;
      const rawView = views.find(view => view?.kind === 'raw') || null;
      const incomingRaw = incomingViews.find((view, index) => (
        view?.kind === 'raw'
        || String(view?.id || '').trim().toLowerCase() === 'raw'
        || index === 0
      )) || null;
      if(rawView && !Array.isArray(incomingRaw?.data)){
        rawView.data = fallbackData;
      }
      for(let i = 0; i < views.length; i += 1){
        inferViewExclusionSharing(views[i]);
      }
      const requestedActive = String(options?.activeViewId || source?.activeViewId || 'raw').trim();
      activeViewId = findViewIndex(requestedActive) >= 0 ? requestedActive : 'raw';
      const hasSerializedSharedExclusions = !!source
        && Object.prototype.hasOwnProperty.call(source, 'sharedExclusions');
      const activeSharedView = getView(activeViewId);
      const legacySharedView = (
        activeSharedView
        && viewSharesExclusions(activeSharedView)
        && activeSharedView.exclusions != null
          ? activeSharedView
          : views.find(view => viewSharesExclusions(view) && view.exclusions != null)
            || views.find(view => viewSharesExclusions(view))
            || null
      );
      sharedExclusions = hasSerializedSharedExclusions
        ? (source.sharedExclusions ? cloneSimple(source.sharedExclusions) : null)
        : (legacySharedView?.exclusions ? cloneSimple(legacySharedView.exclusions) : null);
      syncSharedExclusionsToViews();
      nextIdCounter = Math.max(1, localCounter);
      renderTabs();
      emitViewsChanged('deserialize');
      if(options?.silent !== true && options?.activate !== false){
        emitActiveChanged('deserialize', null);
      }
      return true;
    }

    function getViews(){
      return views.map(view => toSerializableRecord(view));
    }

    manager.mount = mount;
    manager.unmount = unmount;
    manager.initialize = initialize;
    manager.ensureRawView = ensureRawView;
    manager.activateView = activateView;
    manager.getActiveView = () => getView(activeViewId);
    manager.getActiveViewId = () => activeViewId;
    manager.getView = getView;
    manager.getViews = getViews;
    manager.getViewCount = () => views.length;
    manager.updateActiveData = updateActiveData;
    manager.updateActiveExclusions = updateActiveExclusions;
    manager.updateSharedExclusions = updateSharedExclusions;
    manager.setViewExclusionSharing = setViewExclusionSharing;
    manager.getSharedExclusions = () => sharedExclusions ? cloneSimple(sharedExclusions) : null;
    manager.updateActiveFilters = updateActiveFilters;
    manager.createDerivedView = createDerivedView;
    manager.removeView = removeView;
    manager.applyTransform = applyTransform;
    manager.applyPipeline = applyPipeline;
    manager.serialize = serialize;
    manager.deserialize = deserialize;
    manager.defaultLabelForTransform = defaultLabelForTransform;
    manager.refresh = renderTabs;
    manager.destroy = function destroy(){
      manager.unmount();
      views = [];
      activeViewId = 'raw';
      sharedExclusions = null;
    };

    if(Array.isArray(settings.initialViews) && settings.initialViews.length){
      manager.deserialize({
        version: VERSION,
        activeViewId: settings.initialActiveViewId || 'raw',
        views: cloneSimple(settings.initialViews)
      }, {
        fallbackData: settings.fallbackData || [],
        silent: true,
        activate: false
      });
    }else{
      manager.initialize(Array.isArray(settings.initialData) ? settings.initialData : [], {
        rawTitle: settings.rawTitle || 'Raw'
      });
    }

    debugLog('manager created', { componentKey, views: views.length, maxViews });
    return manager;
  }

  dataViews.createManager = createManager;
  dataViews.applyViewToTable = applyViewToTable;
  dataViews.isTableProjectionActive = isTableProjectionActive;
  dataViews.VERSION = VERSION;
})(window);
